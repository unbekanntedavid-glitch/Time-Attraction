# r3 upload labels — author uploads only

Zenodo: Mass_TAL_time_field_EN_r3.pdf, Mass_TAL_time_field_HU_r3.pdf, TAL_time_field_mass_data_r3.zip, LICENSE.txt; optional single-download set archive. Use zenodo_EN.txt / zenodo_HU.txt for the description. A new r3 DOI is not assigned in this package.
Academia: EN/HU PDFs with academia_EN.txt / academia_HU.txt; provide the data archive and LICENSE.txt alongside them where supported.
GitHub: EN/HU PDFs, data archive, LICENSE.txt and the bilingual paste-in files; the article and calculation sources are in the data archive. Publish only as a new r3 directory/version; do not overwrite the published r2.
Nothing has been uploaded or sent by this build.

The reduced source model did not pass genuine validation. This r3 applies published experimental limits as external constraints only, and is less independent than a source-model reconstruction. Not excluded is not confirmation.
The original r4 archive was absent; its three named member files were recovered by SHA. Supplemental Material positions and prior M2 diagnostic files were not recovered.

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). CC BY-NC 4.0 International, https://creativecommons.org/licenses/by-nc/4.0/. Commercial use only with the author's written permission.
