#!/usr/bin/env python3
"""Overlay published bounds only, from the recomputed scan. CC BY-NC 4.0.
© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X).
Commercial use only with the author's written permission.
"""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B=Path(__file__).resolve().parent
rows=list(csv.DictReader((B/'eotwash_external_scan.csv').open()))
r=json.loads((B/'external_bound_results.json').read_text())
fig,axs=plt.subplots(1,2,figsize=(11,5.1),gridspec_kw={'width_ratios':[1.35,1]})
styles=[('abs','Table 11.4 |α₉₅|','#155E91','-'),('plus','Table 11.4 +α₉₅','#E39131','--'),('fig5','Fig. 5 Eöt-Wash 2020','#217C5B',':'),('envelope','Combined / Kombinált','#9A3C58','-.')]
for ax in axs:
 for col,lab,color,ls in styles:
  data=[(float(v['lambda_um']),float(v[f'alphaY_max_{col}'])) for v in rows if v[f'alphaY_max_{col}']!='NA']
  xx,yy=np.array(data).T;ax.plot(xx,yy,label=lab,color=color,ls=ls,lw=1.8)
 xx,yy=np.array([(float(v['lambda_um']),float(v['alphaY_max_abs'])) for v in rows if v['alphaY_max_abs']!='NA']).T
 ax.fill_between(xx,yy,1e10,color='#155E91',alpha=.07)
 ax.axhline(1,color='black',lw=1,label='αY = 1');ax.set_yscale('log');ax.grid(which='major',alpha=.2);ax.set_xlabel('λ = L [μm]')
 ax.set_ylabel('αY,max = 4π αlim')
axs[0].set_xscale('log');axs[0].set_xlim(2,10000);axs[0].set_ylim(.01,1e9)
axs[0].legend(loc='upper right',fontsize=8,framealpha=.95)
axs[1].set_xlim(40,125);axs[1].set_ylim(.5,16)
for key,col,y in [('combined_envelope','#9A3C58',.6),('table_abs','#155E91',.72),('table_plus','#E39131',1.5)]:
 xx=r['crossings'][key]['lambda_um'];axs[1].plot(xx,1,'o',color=col,ms=4)
 axs[1].annotate(f'{xx:.3f} μm',(xx,1),xytext=(xx,y),ha='center',fontsize=8,color=col,arrowprops={'arrowstyle':'-','color':col,'lw':.7})
axs[0].set_title('Published bounds / Publikált korlátok',fontsize=10)
axs[1].set_title('Micron window / Mikronos ablak',fontsize=10)
fig.tight_layout();fig.savefig(B/'external_bound_alphaY.png',dpi=180)
