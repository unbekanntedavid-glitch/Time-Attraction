#!/usr/bin/env python3
"""Published experimental bounds only. No source-model fit. Run from any directory.
CC BY-NC 4.0; © 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X).
Commercial use only with the author's written permission.
"""
from pathlib import Path
import csv,json,math,hashlib,sys
import numpy as np
B=Path(__file__).resolve().parent
A=1/(4*math.pi); HBARC=1.97326980e-7
EXPECTED={
 'Lee2020_thesis_table11_4.csv':'cf711b4fe52db194eb23d71bba284b7af11ab5be7a95b7fdd2c0e9a5eec06794',
 'Lee2020_fig5__Eot-Wash_2020.csv':'093fabd78879a17d3cadea8ec328f3f8c8ead0a875ad72cde31154d1d10363b1',
 'envelopes.npz':'54eb95655554be451f05ba56cd2e6dde7f35d20fa2bc6347b43cef7b8f3f7630'}
def need(v,msg):
 if not v: raise ValueError(msg)
def finite(x): return bool(np.all(np.isfinite(x)))
def dump(n,d): (B/n).write_text(json.dumps(d,indent=2,allow_nan=False,ensure_ascii=False)+'\n')
manifest=json.loads((B/'input_manifest.json').read_text())
for n,d in manifest.items():
 f=B/n; need(f.stat().st_size==d['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==d['sha256'],'input digest mismatch '+n)
for n,s in EXPECTED.items(): need(manifest['inputs/'+n]['sha256']==s,'expected SHA mismatch '+n)
def csvrows(p):
 with p.open() as f: return list(csv.DictReader(l for l in f if not l.startswith('#')))
t=csvrows(B/'inputs/Lee2020_thesis_table11_4.csv')
x=np.array([float(r['lambda_mm'])*1e-3 for r in t]); ys={k:np.array([float(r[k]) for r in t]) for k in ['alpha95_abs','alpha95_pos']}
need(len(x)==66 and finite(x) and np.all(x>0) and np.all(np.diff(x)>0),'bad thesis grid')
for k,y in ys.items(): need(finite(y) and np.all(y>0) and np.all(np.diff(y)<=0),'bad thesis bound '+k)
f=csvrows(B/'inputs/Lee2020_fig5__Eot-Wash_2020.csv'); fx=np.array([float(r['lambda_m']) for r in f]); fy=np.array([float(r['alpha_abs_lim']) for r in f])
curves={}
for p in sorted((B/'inputs/curves').glob('*.csv')):
 r=csvrows(p); cx=np.array([float(v['lambda_m']) for v in r]);cy=np.array([float(v['alpha_abs_lim']) for v in r])
 need(len(cx)>1 and finite(cx) and finite(cy) and np.all(np.diff(cx)>0) and np.all(cx>0) and np.all(cy>0),'bad curve '+p.name)
 curves[p.stem]=(cx,cy)
need(len(curves)==17,'expected 17 curves')
def interp(q,cx,cy):
 need(cx[0]<=q<=cx[-1],'interpolation outside coverage')
 return float(np.exp(np.interp(np.log(q),np.log(cx),np.log(cy))))
def crossing(cx,cy,target=A):
 # Strict piecewise log-linear crossing, no extrapolation or alpha* interpolation.
 i=np.where((cy[:-1]>target)&(cy[1:]<=target))[0]; need(len(i)==1,'crossing not unique')
 j=int(i[0]); v=float(np.exp(np.log(cx[j])+(np.log(target)-np.log(cy[j]))/(np.log(cy[j+1])-np.log(cy[j]))*(np.log(cx[j+1])-np.log(cx[j]))))
 return {'lambda_m':v,'lambda_um':v*1e6,'mc2_eV':HBARC/v,'bracket_m':[float(cx[j]),float(cx[j+1])],'bracket_alpha':[float(cy[j]),float(cy[j+1])]}
g=np.load(B/'inputs/envelopes.npz'); gx=g['log10_lambda'];gy=g['combined_abs'];need(gx.ndim==gy.ndim==1 and len(gx)==len(gy) and finite(gx) and np.all(np.diff(gx)>0),'bad envelope grid')
coverage=np.zeros(len(gx),bool); envraw=np.full(len(gx),np.inf)
for cx,cy in curves.values():
 m=(gx>=np.log10(cx[0]))&(gx<=np.log10(cx[-1]));coverage|=m
 envraw[m]=np.minimum(envraw[m],10**np.interp(gx[m],np.log10(cx),np.log10(cy)))
need(np.array_equal(np.isfinite(gy),coverage),'envelope coverage mismatch')
need(np.all(np.isnan(gy[~coverage])) and not np.any(np.isinf(gy)),'invalid uncovered sentinel')
need(np.all(gy[coverage]>0) and finite(gy[coverage]),'nonpositive/nonfinite covered envelope')
env_dev=float(np.max(abs(gy[coverage]/envraw[coverage]-1)));need(env_dev<1e-12,'17-curve envelope mismatch')
idx=np.where(coverage)[0];need(np.all(np.diff(idx)==1),'disconnected combined coverage')
ex=10**gx[coverage];ey=gy[coverage]
cross={
 'table_abs':crossing(x,ys['alpha95_abs']), 'table_plus':crossing(x,ys['alpha95_pos']),
 'fig5':crossing(fx,fy), 'combined_envelope':crossing(ex,ey)}
recorded={'table_abs':98.1355,'table_plus':101.03,'fig5':98.07,'combined_envelope':75.877}
compare={k:{'recorded_um':v,'recomputed_um':cross[k]['lambda_um'],'relative_difference':abs(cross[k]['lambda_um']/v-1)} for k,v in recorded.items()}
need(all(c['relative_difference']<=0.001 for c in compare.values()),'recorded crossing difference >0.1%; stop')
# Independent packaged window F check: exactly the 23 previously compared bound values.
w=json.loads((B/'inputs/window_key_table.json').read_text());checks=[]
for r in w['representative']:
 q=r['lambda_um']/1e6
 for name,xx,yy in [('Lee2020_thesis_Table11.4/|alpha95|',x,ys['alpha95_abs']),('Lee2020_thesis_Table11.4/+alpha95',x,ys['alpha95_pos']),('Lee2020_fig5/Eot-Wash_2020',fx,fy)]:
  if xx[0]<=q<=xx[-1]:
   ref=r['per_bound'][name]['improvement_factor']; mine=interp(q,xx,yy)/A; dev=abs(mine/ref-1)
   need(math.isfinite(ref) and math.isfinite(mine) and dev<=1e-9,'window F mismatch')
   checks.append({'lambda_um':r['lambda_um'],'bound':name,'recomputed_F':mine,'packaged_F':ref,'relative_difference':dev})
need(len(checks)==23,'expected 23 checks')
wc=json.loads((B/'inputs/window_crossings.json').read_text());ed=abs(cross['combined_envelope']['lambda_um']/wc['edge_um']-1);need(ed<1e-6,'edge mismatch')
refs=json.loads((B/'inputs/results.json').read_text());fd=abs(cross['fig5']['lambda_m']/refs['curves']['Lee2020_fig5/Eot-Wash_2020']['crossings'][0]['lambda_m']-1);need(fd<1e-6,'fig5 packaged crossing mismatch')
qedge=cross['combined_envelope']['lambda_m'];binding=min((interp(qedge,cx,cy),n) for n,(cx,cy) in curves.items() if cx[0]<=qedge<=cx[-1])[1];need(binding=='Lee2020_fig5__HUST_2020','unexpected binding experiment')
rat=[interp(q,fx,fy)/v for q,v in zip(x,ys['alpha95_abs']) if fx[0]<=q<=fx[-1]]
pre={'pass':True,'input_manifest':'input_manifest.json','sha256':{n:d['sha256'] for n,d in manifest.items()},'recorded_crossings':compare,'window_F':{'n':len(checks),'max_relative_difference':max(c['relative_difference'] for c in checks),'tolerance':1e-9,'checks':checks},'envelope_17curve_max_relative_difference':env_dev,'envelope_edge_relative_difference':ed,'fig5_crossing_relative_difference':fd,'binding_at_envelope_edge':binding,'table_rows':len(x),'figure_rows':len(fx),'fig5_table_overlap_rows':len(rat),'fig5_over_table_range':[min(rat),max(rat)],'strict_coverage':'NaN only outside the proven union of 17 curve domains; no nonfinite value accepted inside coverage','hbarc_eV_m':HBARC}
dump('preflight.json',pre)
keys=[2,5,10,20,30,38.6,40,50,52,56,63,70,71,75,75.87709630440307,79,89,cross['table_abs']['lambda_um'],100,110,250,1000,8900,10000]
def row(u):
 q=u/1e6;r={'lambda_um':u,'mc2_eV':HBARC/q}
 for n,xx,yy in [('abs',x,ys['alpha95_abs']),('plus',x,ys['alpha95_pos']),('fig5',fx,fy),('envelope',ex,ey)]:
  if xx[0]<=q<=xx[-1]:
   a=interp(q,xx,yy);R=A/a;r.update({f'alpha_lim_{n}':a,f'alphaY_max_{n}':4*math.pi*a,f'R_{n}':R,f'F_{n}':1/R,f'category_{n}':'b_excluded' if R>1 else 'not_excluded'})
  else:
   r.update({f'alpha_lim_{n}':None,f'alphaY_max_{n}':None,f'R_{n}':None,f'F_{n}':None,f'category_{n}':'not_computed'})
 return r
key=[row(u) for u in keys]
# The crossing is a mathematical equality: classify it as boundary (not R>1).
key[17]['category_abs']='boundary_not_excluded'
res={'method':'published experimental bound only; no source-model fit','alpha_TAL':A,'alphaY':1,'hbarc_eV_m':HBARC,'crossings':cross,'table_domain_m':[float(x[0]),float(x[-1])],'mass_domain_eV':[HBARC/float(x[-1]),HBARC/float(x[0])],'F_at_50um':interp(50e-6,x,ys['alpha95_abs'])/A,'fig5_over_table_range':[min(rat),max(rat)],'key_table':key,'source_model_status':'No genuine validation in the prior M2 variants (owner-supplied status; missing diagnostic files were not reconstructed or rerun). No TAL prediction from that fit.'}
dump('external_bound_results.json',res)
def outcsv(n,rr):
 with (B/n).open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rr[0]));wr.writeheader();wr.writerows([{k:('NA' if v is None else v) for k,v in r.items()} for r in rr])
outcsv('external_bound_key_table.csv',key)
outcsv('eotwash_external_scan.csv',[row(float(u)) for u in np.geomspace(2,10000,401)])
print(json.dumps({'crossings':cross,'F50':res['F_at_50um'],'window_F_maxrel':pre['window_F']['max_relative_difference'],'envelope_17curve_maxrel':env_dev,'preflight':True},indent=2))
