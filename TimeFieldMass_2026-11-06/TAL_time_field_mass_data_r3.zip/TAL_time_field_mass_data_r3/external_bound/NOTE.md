# Published external bound, recovered-input recomputation — 2026-11-06

This calculation uses only published experimental Yukawa limits. There is no own source-model fit and no TAL prediction from the failed reduced model.

## Dictionary and method
α = α_Y/(4π), λ = L, mc² = ħc/λ, ħc = 1.97326980e-7 eV·m (CODATA 2018). For α_Y = 1, α_TAL = 0.07957747154594767. R = α_TAL/α_lim; F = 1/R. R is a conditional bound ratio, never a sigma. R > 1 is excluded (category b); R ≤ 1 is not excluded, not confirmation.

Primary input: Lee thesis Table 11.4 |α95|, log–log interpolation between adjacent rows only. No α* interpolation. +α95 is a sign-specific variant, not interchangeable with |α95|. The digitized Eöt-Wash 2020 Fig. 5 curve is a cross-check. The combined envelope is the minimum over 17 drawn curves, not a new statistical combination.

## Recomputed values
| Bound | λ crossing (µm) | mc² (eV) |
|---|---:|---:|
| Table 11.4 \|α95\| | 98.13550273929751 | 0.0020107603720562806 |
| Table 11.4 +α95 | 101.02864570219583 | 0.0019531785131680843 |
| Fig. 5 Eöt-Wash 2020 | 98.07372167495679 | 0.0020120270407805647 |
| Combined envelope | 75.87709630440325 | 0.0026006132233680227 |

For the primary Eöt-Wash bound and α_Y = 1:
- Excluded: 98.1355 µm < λ ≤ 8.9 mm; 2.217e-5 eV ≤ mc² < 2.0108 meV.
- Not excluded: 5 µm ≤ λ ≤ 98.1355 µm; 2.0108 meV ≤ mc² ≤ 39.47 meV. This is not confirmation.
- Outside the table domain: not computed.
- F at 50 µm = 5.265309287416493.

The combined-window statement is unchanged: 2 µm ≤ λ < 75.877 µm, or 2.6006 meV < mc² ≤ 98.66 meV. HUST 2020 sets this large-λ edge. The open endpoint is the packaged convention; mathematically R = 1 at the continuous boundary is not strict exclusion. The scan stops at 1 cm and does not make new long-range claims.

## Preflight and provenance
Preflight passed. All four crossings agree with the recorded lost-run values within 0.1%. The 17 recovered curves reproduce the covered envelope exactly. The 23 F checks against the recovered window table have max relative deviation 6.439293542825908e-15 (tolerance 1e-9); the earlier report of 0.0 and this machine-roundoff result are consistent. Fig. 5/table spans 0.99615–1.00528 over 45 overlapping rows.

The original r4 archive is absent. Its recorded SHA-256 is e3f027587b7462900d607d858315668bc65346eada7489f34f3a06d31096ae46; it was not verified here. Recovered Table 11.4, Fig. 5 Eöt-Wash and envelope files match the previously recorded member hashes:
- cf711b4fe52db194eb23d71bba284b7af11ab5be7a95b7fdd2c0e9a5eec06794 (Table 11.4; 8423 bytes)
- 093fabd78879a17d3cadea8ec328f3f8c8ead0a875ad72cde31154d1d10363b1 (Fig. 5; 7964 bytes)
- 54eb95655554be451f05ba56cd2e6dde7f35d20fa2bc6347b43cef7b8f3f7630 (envelope; 838768 bytes)

The recovered r3 results JSON has SHA aa258c9577f53e1fca16c2baba12a5cf8cfba946b8d5d6e40dc1df2f8b477e0c. It is not the absent r4 results JSON. Its discrete first excluded node differs from the continuously interpolated boundary; the calculation uses the latter. Full recovered-input hashes and bytes: input_manifest.json; provenance: provenance.json; checks: preflight.json.

## Independence and limitations
This external constraint is less independent than reproducing the experiment's analysis: it inherits its geometry, calibration, nuisances and systematics. Table/figure agreement checks representation, not those assumptions. The bound assumes a universal, unscreened Yukawa force. The combined curves retain graphical uncertainties, a short-range attribution gap, and the assumption that drawn absolute-strength limits apply to positive coupling. Digits printed here are computational values, not precision claims.

The rebuilt M2 reduced source model had no genuine validation (prior status supplied by the owner; missing diagnostic artifacts were not reconstructed or rerun here). No formal n/7 result is treated as a pass, no fitted limit is used, and there is no TAL prediction from that fit. The ±20%, 2-of-7 and Δχ²95 = 6.17 rules are unchanged. The 9.2 µm screen hypothesis remains undocumented. Supplemental Material per-run positions and the explanation of the prior roughly 8 µm separation offset are still missing.

## Sources
Lee et al., Phys. Rev. Lett. 124, 101101 (2020), https://doi.org/10.1103/PhysRevLett.124.101101.
Lee thesis (2020), Table 11.4, https://hdl.handle.net/1773/45542.
Tan et al., Phys. Rev. Lett. 124, 051301 (2020), https://doi.org/10.1103/PhysRevLett.124.051301.
Adelberger, Heckel and Nelson, Annu. Rev. Nucl. Part. Sci. 53, 77–121 (2003), https://doi.org/10.1146/annurev.nucl.53.041002.110503.

Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.
