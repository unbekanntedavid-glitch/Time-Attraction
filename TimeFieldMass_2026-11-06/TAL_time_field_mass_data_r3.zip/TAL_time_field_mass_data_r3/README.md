# TAL time-field mass: external published bounds, r3 (2026-11-06)

Author: Szabolcsi Dávid, ORCID 0009-0005-6300-074X.

This package converts published Yukawa limits to a conditional TAL mass/coupling constraint. There is no own source-model fit. The prior rebuilt M2 reduced model had no genuine validation; no TAL prediction is derived from it. Diagnostic files were absent and were not rerun or reconstructed here. The ±20%, 2-of-7 and Δχ²95 = 6.17 criteria remain unchanged; the 9.2 µm screen hypothesis is undocumented.

## Contents
- external_bound/: verified recovered inputs, input_manifest.json, provenance.json, external_bound.py, make_figure.py, external_bound_results.json, external_bound_key_table.csv, eotwash_external_scan.csv, external_bound_alphaY.png, preflight.json, run_log.txt, NOTE.md.
- article_source/: EN/HU LaTeX and the shared r2 typography; generated numeric tables/values and build_articles.py.
- requirements.txt, run_all.sh, LICENSE.txt, SHA256SUMS.

## Reproduction
Tested: Python 3.13.5, NumPy 2.5.4, Matplotlib 3.11.2, pdfTeX 1.40.29 (TeX Live 2026), Latin Modern and the LaTeX packages in article_source/tex/common.tex; Hungarian babel is needed for HU.
Install the Python versions in requirements.txt. Run ./run_all.sh from this extracted directory. It verifies all input hashes before computing, stops on an error, writes JSON/CSV/PNG and generates article_source/tex/article_en.pdf and article_hu.pdf. No source-model fitting code is run. SHA256SUMS records the shipped files; newly generated PDFs may differ in metadata timestamps.
The recomputation matched the recorded crossings within 0.1%, the 23 recovered window F values within 6.439293542825908e-15 relative, and the 17-curve envelope exactly. R = α_TAL/α_lim is a conditional ratio, not sigma. Not excluded is not confirmation.

## Sources
Primary: J. G. Lee thesis (2020), Table 11.4, https://hdl.handle.net/1773/45542. The CSV preserves all 66 table rows and their raw text. Log–log interpolation is used only between adjacent rows; alpha-star is not interpolated.
Cross-check: Lee et al., PRL 124, 101101 (2020), https://doi.org/10.1103/PhysRevLett.124.101101, Fig. 5 digitization. Positive-coupling variant: thesis +alpha95 column, distinct from the integral |alpha95| bound.
Envelope: the 17 digitized curves in external_bound/inputs/curves/ from Lee Fig. 5 and Adelberger–Heckel–Nelson, Annu. Rev. Nucl. Part. Sci. 53, 77–121 (2003), https://doi.org/10.1146/annurev.nucl.53.041002.110503, Fig. 5. The HUST 2020 curve (Tan et al., PRL 124, 051301, https://doi.org/10.1103/PhysRevLett.124.051301) sets the combined-window edge. The envelope is not a new statistical combination; applying drawn absolute-strength limits to positive alpha is an assumption. Short-range attribution is missing for one drawn curve. No third-party publication PDF is included.
The conversion uses hbar*c = 1.97326980e-7 eV*m (CODATA 2018).

## Recovery provenance and missing inputs
The original r4 archive is absent; it was not verified on this box. Its recovered Table 11.4 CSV, Eot-Wash Fig. 5 CSV and envelopes.npz match the recorded r4 member digests exactly. The r3 results.json is only a cross-check and is explicitly not the absent r4 results.json. See external_bound/provenance.json and input_manifest.json.
window_key_table.json and window_crossings.json were recovered from the published r2 data archive. The preflight recomputes 23 F values rather than copying the old output.
Still missing: original r4 archive, PRL Supplemental Material per-run positions, and prior M2 diagnostic artifacts. The published bound remains usable, but this is less independent than reproducing the experiment's source analysis. No claim is made outside the input domains.

Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.

## License
© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). CC BY-NC 4.0 International.
https://creativecommons.org/licenses/by-nc/4.0/
Commercial use only with the author's written permission. Third-party data retain their own terms; see LICENSE.txt.
