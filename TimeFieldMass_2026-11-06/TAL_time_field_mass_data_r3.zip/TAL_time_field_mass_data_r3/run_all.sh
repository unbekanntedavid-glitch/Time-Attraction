#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
python3 external_bound/external_bound.py > external_bound/run_log.txt
python3 external_bound/make_figure.py
python3 article_source/build_articles.py
cd article_source/tex
for lang in en hu; do
 pdflatex -interaction=nonstopmode -halt-on-error "article_${lang}.tex"
 pdflatex -interaction=nonstopmode -halt-on-error "article_${lang}.tex"
done
