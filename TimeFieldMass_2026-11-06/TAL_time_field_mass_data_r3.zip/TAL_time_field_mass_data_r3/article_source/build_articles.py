#!/usr/bin/env python3
"""Build bilingual article TeX from the packaged external-bound JSON. CC BY-NC 4.0.
© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X).
Commercial use only with the author's written permission.
"""
from pathlib import Path
import json,math
HERE=Path(__file__).resolve().parent
B=HERE.parent/'external_bound'
def require_finite_tree(value, path):
    """Reject nonfinite floats anywhere in an input tree; out-of-domain nulls remain valid."""
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError('nonfinite article input: ' + path)
    if isinstance(value, dict):
        for k, v in value.items():
            require_finite_tree(v, path + '.' + str(k))
    elif isinstance(value, list):
        for i, v in enumerate(value):
            require_finite_tree(v, path + '[' + str(i) + ']')

D=json.loads((B/'external_bound_results.json').read_text());P=json.loads((B/'preflight.json').read_text())
try:
    require_finite_tree(D, 'external_bound_results.json')
    require_finite_tree(P, 'preflight.json')
except ValueError as exc:
    raise SystemExit(str(exc)) from None
assert P['pass'] and P['window_F']['n']==23
assert D['method']=='published experimental bound only; no source-model fit'
G=HERE/'generated';G.mkdir(exist_ok=True)
cs=D['crossings']
def num(v,d=5):
 if not math.isfinite(v):raise ValueError('nonfinite article value')
 return f'{v:.{d}g}'
def texnum(v):
 s=num(v)
 if 'e' in s:
  a,b=s.split('e');return a+r'\!\times\!10^{'+str(int(b))+'}'
 return s
vals={'edgeAbs':f"{cs['table_abs']['lambda_um']:.4f}",'edgePlus':f"{cs['table_plus']['lambda_um']:.4f}",'edgeFig':f"{cs['fig5']['lambda_um']:.4f}",'edgeEnv':f"{cs['combined_envelope']['lambda_um']:.4f}",'massAbs':f"{cs['table_abs']['mc2_eV']*1000:.5f}",'massPlus':f"{cs['table_plus']['mc2_eV']*1000:.5f}",'massFig':f"{cs['fig5']['mc2_eV']*1000:.5f}",'massEnv':f"{cs['combined_envelope']['mc2_eV']*1000:.5f}",'massMin':f"{D['mass_domain_eV'][0]*1000:.7f}",'massMax':f"{D['mass_domain_eV'][1]*1000:.5f}",'mass2um':f"{D['hbarc_eV_m']/2e-6*1000:.5f}",'F50':f"{D['F_at_50um']:.5f}",'aTAL':f"{D['alpha_TAL']:.8f}",'Fdev':texnum(P['window_F']['max_relative_difference']),'figLo':f"{D['fig5_over_table_range'][0]:.5f}",'figHi':f"{D['fig5_over_table_range'][1]:.5f}"}
(G/'values.tex').write_text(''.join('\\expandafter\\def\\csname val@'+k+'\\endcsname{'+v+'}\n' for k,v in vals.items()))
want=[5,10,20,40,50,63,75.87709630440307,89,cs['table_abs']['lambda_um'],100,110,250,1000,8900]
rr=[]
for u in want:
 matches=[r for r in D['key_table'] if abs(r['lambda_um']-u)<1e-9];assert len(matches)==1;r=matches[0]
 for k in ['alpha_lim_abs','alphaY_max_abs','R_abs','F_abs']:assert r[k] is not None and math.isfinite(r[k])
 rr.append(' & '.join('$'+texnum(v)+'$' for v in [r['lambda_um'],r['mc2_eV']*1000,r['alpha_lim_abs'],r['alphaY_max_abs'],r['R_abs'],r['F_abs']])+r' \\')
(G/'key_table.tex').write_text('\n'.join(rr)+'\n')
foot=r'''\pagestyle{fancy}\fancyhf{}
\renewcommand{\headrulewidth}{0pt}
\newcommand{\copyrightfoot}{\scriptsize \copyright\ 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) \textperiodcentered\ CC BY-NC 4.0 International, \url{https://creativecommons.org/licenses/by-nc/4.0/} \textperiodcentered\ commercial use only with the author's written permission \hfill \thepage/\pageref{LastPage}}
\fancyfoot[C]{\copyrightfoot}
\fancypagestyle{plain}{\fancyhf{}\fancyfoot[C]{\copyrightfoot}}
'''
bib=r'''\begin{thebibliography}{9}\small
\bibitem{leeprl} J.\,G.~Lee, E.\,G.~Adelberger, T.\,S.~Cook, S.\,M.~Fleischer, B.\,R.~Heckel, New test of the gravitational $1/r^2$ law at separations down to 52\um, Phys.\ Rev.\ Lett.\ 124, 101101 (2020), \doi{10.1103/PhysRevLett.124.101101}.
\bibitem{thesis} J.\,G.~Lee, A Fourier-Bessel Test of the Gravitational Inverse-Square Law, PhD thesis, University of Washington (2020), Table~11.4, \url{https://hdl.handle.net/1773/45542}.
\bibitem{hust} W.-H.~Tan et al., Improvement for testing the gravitational inverse-square law at the submillimeter range, Phys.\ Rev.\ Lett.\ 124, 051301 (2020), \doi{10.1103/PhysRevLett.124.051301}.
\bibitem{ahn} E.\,G.~Adelberger, B.\,R.~Heckel, A.\,E.~Nelson, Tests of the gravitational inverse-square law, Annu.\ Rev.\ Nucl.\ Part.\ Sci.\ 53, 77--121 (2003), \doi{10.1146/annurev.nucl.53.041002.110503}.
\bibitem{codata} E.~Tiesinga et al., CODATA recommended values of the fundamental physical constants: 2018, Rev.\ Mod.\ Phys.\ 93, 025010 (2021), \doi{10.1103/RevModPhys.93.025010}.
\end{thebibliography}'''
EN=[r'''
\maketitle
\begin{abstract}
\noindent We translate published Yukawa-strength limits into a conditional mass constraint for the TAL time field, without fitting the experimental source model. The primary input is $|\alpha_{95}|$ in Lee's thesis Table~11.4 for Eöt-Wash 2020, with log--log interpolation between rows. For $\alpha_Y=1$, the crossing is $\lambda=\V{edgeAbs}\um$, or $mc^2=\V{massAbs}\meV$. Within the tabulated domain, masses from $\V{massMin}\meV$ up to (but not including) this crossing mass are excluded; higher masses up to $\V{massMax}\meV$ are not excluded. The sign-specific $+\alpha_{95}$ edge is $\V{edgePlus}\um$ and the digitized Fig.~5 edge is $\V{edgeFig}\um$. The combined published envelope retains the micron-window edge $\V{edgeEnv}\um$ ($\V{massEnv}\meV$), set by HUST 2020, not Eöt-Wash. The rebuilt reduced source model did not pass genuine validation, so no TAL prediction is derived from that fit. This result is an external application of published experimental bounds, not an independent reproduction of their analysis. ``Not excluded'' is not confirmation.
\end{abstract}
\section{Scope and conventions}
We ask which masses and couplings survive a specified published bound. No best-fitting mass, force, or torque is inferred. We assume a universal, composition-independent, unscreened Yukawa addition to Newtonian gravity:
\begin{equation}
V(r)=-\frac{Gm_1m_2}{r}\big(1+\alpha e^{-r/\lambda}\big),\quad
\alpha=\frac{\alpha_Y}{4\pi},\quad \lambda=L,\quad mc^2=\frac{\hbar c}{\lambda}.
\end{equation}
The fixed dictionary uses $\hbar c=1.97326980\times10^{-7}\,\mathrm{eV\,m}$ (CODATA 2018 \cite{codata}). Thus $\alpha_Y=1$ means $\alpha_{\rm TAL}=1/(4\pi)=\V{aTAL}$, not $\alpha=1$.

For a published bound $\alpha_{\rm lim}(\lambda)$ we define
\begin{equation}
\alpha_{Y,\max}=4\pi\alpha_{\rm lim},\qquad
R=\frac{\alpha_{\rm TAL}}{\alpha_{\rm lim}},\qquad F=\frac1R.
\end{equation}
$R>1$ is excluded (category b); $R\le1$ is not excluded. $R$ is a conditional ratio, never a sigma. $F$ is a factor relative to a bound, not detector sensitivity. Outside an input's domain the result is not computed, not extrapolated.
''',r'''
\section{Published inputs and the calculation}
The primary input is the published Table~11.4 $|\alpha_{95}|$ column \cite{thesis}, not a result of our source-model fit. Its 66 rows span $5\um$ to $8.9\,\mathrm{mm}$. We interpolate $\log\alpha_{\rm lim}$ linearly against $\log\lambda$ between adjacent rows only. The primary crossing lies between $(89\um,0.097)$ and $(100\um,0.0766)$. No $\alpha^*$ is interpolated.

The thesis defines two different bound constructions: $+\alpha_{95}$ and $-\alpha_{95}$ come from the $\Delta\chi^2=6.17$ surface; $|\alpha_{95}|$ is obtained by enclosing 95\% of $N(\alpha^*,\sigma_\alpha)$ between symmetric endpoints. We do not interchange these columns. We report $+\alpha_{95}$ as the positive-coupling variant. The digitized Eöt-Wash 2020 curve in PRL Fig.~5 \cite{leeprl} is a cross-check, not the primary limit.

The combined envelope is the minimum of 17 packaged digitized curves from Lee Fig.~5 and Adelberger--Heckel--Nelson Fig.~5 \cite{ahn}. It is contextual: it is not refitted, and it is not a newly combined statistical confidence region. Applying its drawn absolute-strength curves to positive $\alpha$ is an explicit reading assumption, particularly for HUST \cite{hust}.

\subsection*{Recovered-file provenance}
The original r4 archive is absent from this box. Three recovered member files have exactly the previously recorded SHA-256 values: the Table~11.4 CSV, the Eöt-Wash Fig.~5 CSV, and \file{external_bound/inputs/envelopes.npz}. Full digests and byte counts are shipped in \file{external_bound/input_manifest.json}. No claim is made that the absent archive itself was verified here.

The recovered \file{external_bound/inputs/results.json} is the r3 window output (SHA prefix \file{aa258c9577f53e1f}), not the absent r4 output. Its first excluded grid node is not the continuous crossing. We recompute the crossing from the verified envelope; \file{external_bound/provenance.json} records this distinction.

\subsection*{Preflight: passed}
\begin{itemize}\itemsep2pt
\item All recovered inputs match their recorded digests. The 17 raw curves reproduce the covered envelope exactly (maximum relative deviation 0).
\item The 23 Table~11.4/Fig.~5 $F$ values agree with the recovered window table to a maximum relative deviation $\V{Fdev}$ (tolerance $10^{-9}$); the earlier recorded comparison was 0, so this difference is floating-point roundoff.
\item All four crossings match the lost calculation's recorded values within 0.1\%; the continuous envelope edge also matches the packaged window crossing to machine precision.
\item Finite, positive bounds and strictly increasing range grids are required. Uncovered envelope cells are checked against the union of the 17 input domains; no NaN or Inf is accepted inside coverage. No missing key is ignored.
\end{itemize}
Evidence: \file{external_bound/preflight.json}, \file{external_bound/inputs/window_key_table.json}, and \file{external_bound/inputs/window_crossings.json}.
''',r'''
\section{Eöt-Wash 2020: results for $\alpha_Y=1$}
\begin{center}\small
\begin{tabular}{lrr}\toprule
Published bound & crossing $\lambda$ [\um] & $mc^2$ [meV]\\\midrule
Table 11.4 $|\alpha_{95}|$ (primary) & \V{edgeAbs} & \V{massAbs}\\
Table 11.4 $+\alpha_{95}$ & \V{edgePlus} & \V{massPlus}\\
Fig. 5 Eöt-Wash (digitized) & \V{edgeFig} & \V{massFig}\\
Combined envelope (context) & \V{edgeEnv} & \V{massEnv}\\\bottomrule
\end{tabular}
\end{center}
The primary and Fig.~5 limits agree at digitization level: Fig.~5/table ranges from $\V{figLo}$ to $\V{figHi}$ over 45 overlapping table rows. The two crossings differ by about $0.062\um$. This is a cross-check of two representations of the same experimental result, not independent evidence.

\subsection*{Key table}
\noindent All bound columns below use the published Table~11.4 $|\alpha_{95}|$, interpolated where needed. At the crossing $R=F=1$ by definition. See \file{external_bound/external_bound_key_table.csv}.
\begin{center}\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{rrrrrr}\toprule
$\lambda$ [\um] & $mc^2$ [meV] & $|\alpha_{95}|$ & $\alpha_{Y,\max}$ & $R$ & $F$\\\midrule
\tabinput{../generated/key_table.tex}
\bottomrule\end{tabular}
\end{center}
\subsection*{Mass intervals within the table domain}
\textbf{Excluded:} $98.1355\um<\lambda\le8.9\,\mathrm{mm}$, or
$2.217\times10^{-5}\,\mathrm{eV}\le mc^2<2.0108\meV$.

\textbf{Not excluded (not confirmation):} $5\um\le\lambda\le98.1355\um$, or
$2.0108\meV\le mc^2\le39.47\meV$. The exact crossing belongs to $R\le1$.

\textbf{Not computed by this source:} $\lambda<5\um$ or $\lambda>8.9\,\mathrm{mm}$. At $50\um$, $F=\V{F50}$. At $100\um$ the primary bound excludes $\alpha_Y=1$, whereas $+\alpha_{95}=0.0813$ gives $R=0.9788$, still not excluded.
''',r'''
\section{The $(\lambda,\alpha_Y)$ diagram and the combined window}
\begin{figure}[h]\centering
\includegraphics[width=\textwidth]{../../external_bound/external_bound_alphaY.png}
\caption{Published $\alpha_{Y,\max}=4\pi\alpha_{\rm lim}$ versus the $\alpha_Y=1$ branch; right panel: micron-scale detail. Pale shading above the primary curve marks exclusion by that curve. The combined envelope is context, not an independent statistical combination. Data: \file{external_bound/eotwash_external_scan.csv}; plotting: \file{external_bound/make_figure.py}.}
\end{figure}
The combined window is unchanged: over the specified search range, it is not excluded only for
\begin{equation}
2\um\le\lambda<75.877\um,\qquad
2.6006\meV<mc^2\le98.66\meV.
\end{equation}
HUST 2020, not Eöt-Wash, sets the large-$\lambda$ edge. HUST closes the strip between about $75.877\um$ and $98.136\um$ (masses about $2.01$--$2.60\meV$) which Eöt-Wash alone does not exclude. The packaged boundary convention uses an open upper end for the combined window; at the exact continuous crossing $R=1$, so equality itself is not a strict $R>1$ exclusion.

This statement is limited to the covered range ($2\um$--$1\,\mathrm{cm}$ in the scan). It does not establish an allowed interval at shorter ranges or make a new long-range claim. One short-range input is an unattributed drawn curve; the combined diagram preserves that provenance limitation. The envelope's step near $1\,\mathrm{mm}$ is the end of a digitized curve's coverage, not a new physical feature.

The experiment-specific and envelope statements must not be swapped: the Eöt-Wash edge is $\V{edgeAbs}\um$; the combined-envelope edge is $\V{edgeEnv}\um$. Neither is a measurement of the time-field mass.
''',r'''
\section{Source-model status, independence, and limitations}
\textbf{The rebuilt Eöt-Wash reduced source-model validation did not pass.} The prior M2 variants with the documented inputs yielded no genuine validation. Formal threshold crossings were not accepted as validation. Consequently, \textbf{there is no TAL prediction from our source-model fit} and none of its fitted limits enters this article.

The validation criteria remain $\pm20\%$ at at least 2 of the 7 specified points, with $\Delta\chi^2_{95}=6.17$. We neither loosen them nor invent nuisance parameters. The $9.2\um$ screen-offset hypothesis is not treated as a documented fact. Missing diagnostic artifacts were not reconstructed or rerun here; the negative status is an explicitly recorded prior result in \file{external_bound/provenance.json}, not a claim of a new source-model calculation.

\subsection*{What this external result is worth}
It gives a reproducible dictionary conversion and a conditional exclusion for a specified coupling and force law. It is useful even without our source fit because the experimental limit is published. It is, however, \textbf{less independent} than reproducing the experiment's analysis: it inherits the authors' geometry, calibration, nuisance treatment, and systematics. Agreement between the table and figure checks transcription and digitization, not those underlying assumptions.

\subsection*{Caveats}
\begin{enumerate}\itemsep4pt
\item The PRL Supplemental Material per-run position table was not retrieved. Its absence does not prevent use of the published bound, but prevents an independent source-model reconstruction. The unexplained roughly $8\um$ separation offset in the prior diagnostics remains unresolved.
\item The $|\alpha_{95}|$ integral bound and the $+\alpha_{95}$ profile boundary are different constructions. The latter moves the edge from $98.14\um$ to $101.03\um$; this difference is not hidden.
\item Log--log interpolation is an approximation between published table rows. The displayed digits reproduce the calculation, not an experimental precision claim.
\item The figure is digitized and the combined envelope carries graphical and attribution uncertainties. No new uncertainty model or tolerance is fitted here. HUST's drawn absolute-strength curve is used as packaged; no sign-separated HUST analysis is inferred.
\item Only the universal, unscreened Yukawa mapping is tested. Environment-dependent screening or alternative couplings require a different calculation.
\item $R$ and $F$ are conditional bound ratios, not significances or discovery probabilities. ``Not excluded'' is not confirmation, and no force or torque detectability calculation is supplied.
\end{enumerate}
''',r'''
\section{Data, code, and reproduction}
\file{TAL_time_field_mass_data_r3.zip} includes \file{external_bound/}, \file{article_source/}, \file{README.md}, \file{LICENSE.txt}, \file{requirements.txt}, \file{run_all.sh}, and \file{SHA256SUMS}. No third-party publication PDF is redistributed.

The primary calculation is \file{external_bound/external_bound.py}. It verifies input SHA-256, recomputes crossings directly from the table/curves/envelope, checks the recorded results and 23 window $F$ values, and writes \file{external_bound_results.json}, \file{external_bound_key_table.csv}, \file{eotwash_external_scan.csv}, and \file{preflight.json} inside \file{external_bound/}. The package includes every local file cited here. The raw input digests are:
\begin{center}\small
\begin{tabular}{ll}\toprule
Recovered input & SHA-256 prefix\\\midrule
Table 11.4 CSV & \texttt{cf711b4fe52db194}\\
Eöt-Wash Fig. 5 CSV & \texttt{093fabd78879a17d}\\
\file{envelopes.npz} & \texttt{54eb95655554be45}\\
r3 \file{results.json} & \texttt{aa258c9577f53e1f}\\\bottomrule
\end{tabular}
\end{center}
Full hashes, byte counts and the absent-r4-archive provenance are in \file{external_bound/input_manifest.json} and \file{external_bound/provenance.json}.

\textbf{Reproduction.} In the extracted data directory, install the versions listed in \file{requirements.txt}, then run \file{./run_all.sh}. The bound script stops on a missing key, a non-finite covered input, a digest mismatch, or a crossing difference above 0.1\% from the recorded result. The figure script reads the scan, and \file{article_source/build_articles.py} reads the JSON outputs to regenerate both articles. PDF rendering uses pdfLaTeX and the shared \file{article_source/tex/common.tex}. Sources contain no own source-model fit. The packaged results can be inspected without running any calculation.

\medskip\noindent Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.

\medskip\noindent\textbf{License.} \copyright\ 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). CC BY-NC 4.0 International, \url{https://creativecommons.org/licenses/by-nc/4.0/}. Commercial use only with the author's written permission. Third-party data retain their own terms; see \file{LICENSE.txt}.
''']
HU=[r'''
\maketitle
\begin{abstract}
\noindent Publikált Yukawa-erősségkorlátokat fordítunk át a TAL időmező feltételes tömegkorlátjára, a kísérleti forrásmodell saját illesztése nélkül. Az elsődleges bemenet Lee disszertációjának 11.4.~táblázata, az Eöt-Wash 2020 $|\alpha_{95}|$ oszlopa, a sorok között log--log interpolációval. $\alpha_Y=1$ mellett a metszés $\lambda=\V{edgeAbs}\um$, vagyis $mc^2=\V{massAbs}\meV$. A táblázat tartományában $\V{massMin}\meV$-tól a metszési tömegig (azt nem beleértve) a tömegek kizártak; fölötte $\V{massMax}\meV$-ig nincsenek kizárva. Az előjelspecifikus $+\alpha_{95}$ széle $\V{edgePlus}\um$, az 5.~ábra digitalizált görbéjéé $\V{edgeFig}\um$. A kombinált publikált burkoló mikronos ablakának széle változatlanul $\V{edgeEnv}\um$ ($\V{massEnv}\meV$), és azt a HUST 2020, nem az Eöt-Wash szabja meg. Az újraépített redukált forrásmodell nem ment át valódi validáción, ezért abból TAL-jóslatot nem származtatunk. Ez az eredmény külső, publikált kísérleti korlátok alkalmazása, nem elemzésük független reprodukciója. A ,,nincs kizárva'' nem megerősítés.
\end{abstract}
\section{Hatókör és konvenciók}
Azt kérdezzük, mely tömegek és csatolások nem kizártak egy adott publikált korlát szerint. Nem határozunk meg legjobban illeszkedő tömeget, erőt vagy nyomatékot. Univerzális, összetételfüggetlen, árnyékolatlan Yukawa-tagot feltételezünk a Newton-gravitáció mellett:
\begin{equation}
V(r)=-\frac{Gm_1m_2}{r}\big(1+\alpha e^{-r/\lambda}\big),\quad
\alpha=\frac{\alpha_Y}{4\pi},\quad \lambda=L,\quad mc^2=\frac{\hbar c}{\lambda}.
\end{equation}
A rögzített szótárban $\hbar c=1.97326980\times10^{-7}\,\mathrm{eV\,m}$ (CODATA 2018 \cite{codata}). Így $\alpha_Y=1$ esetén $\alpha_{\rm TAL}=1/(4\pi)=\V{aTAL}$, nem pedig $\alpha=1$.

A publikált $\alpha_{\rm lim}(\lambda)$ korlátra
\begin{equation}
\alpha_{Y,\max}=4\pi\alpha_{\rm lim},\qquad
R=\frac{\alpha_{\rm TAL}}{\alpha_{\rm lim}},\qquad F=\frac1R.
\end{equation}
$R>1$: kizárt (b kategória); $R\le1$: nincs kizárva. $R$ feltételes arány, sohasem szigma. $F$ korláthoz viszonyított tényező, nem detektorérzékenység. A bemenet tartományán kívül nem számolunk, és nem extrapolálunk.
''',r'''
\section{Publikált bemenetek és számítás}
Az elsődleges bemenet a publikált 11.4.~táblázat $|\alpha_{95}|$ oszlopa \cite{thesis}, nem saját forrásmodell-illesztésünk eredménye. A 66 sor $5\um$ és $8.9\,\mathrm{mm}$ közötti tartományt fed le. $\log\alpha_{\rm lim}$ értékét lineárisan interpoláljuk $\log\lambda$ szerint, csak szomszédos sorok között. Az elsődleges metszés a $(89\um,0.097)$ és $(100\um,0.0766)$ pontok közé esik. $\alpha^*$-ot nem interpolálunk.

A disszertáció két különböző korlátkonstrukciót definiál: $+\alpha_{95}$ és $-\alpha_{95}$ a $\Delta\chi^2=6.17$ felületből származik; $|\alpha_{95}|$ az $N(\alpha^*,\sigma_\alpha)$ eloszlás 95\%-át zárja szimmetrikus végpontok közé. Az oszlopokat nem cseréljük fel. A $+\alpha_{95}$ értéket pozitív csatolásra vonatkozó változatként közöljük. A PRL 5.~ábrájának digitalizált Eöt-Wash 2020 görbéje \cite{leeprl} keresztellenőrzés, nem elsődleges korlát.

A kombinált burkoló Lee 5.~ábrájának és Adelberger--Heckel--Nelson 5.~ábrájának \cite{ahn} 17 csomagolt, digitalizált görbéje közül a minimum. Kontextust ad: nem illesztjük újra, és nem új statisztikai konfidenciatartomány. A rajzolt abszolút erősségkorlátok pozitív $\alpha$-ra alkalmazása kimondott értelmezési feltevés, különösen a HUST esetében \cite{hust}.

\subsection*{Visszanyert fájlok eredete}
Az eredeti r4 archívum nincs ezen a gépen. Három visszanyert tagfájl SHA-256 értéke egyezik a korábban rögzítettel: a 11.4.~táblázat CSV-je, az Eöt-Wash 5.~ábra CSV-je és az \file{external_bound/inputs/envelopes.npz}. A hash-ek és bájtméretek az \file{external_bound/input_manifest.json} fájlban vannak. A hiányzó archívumot magát itt nem ellenőriztük.

A visszanyert \file{external_bound/inputs/results.json} az r3 ablak kimenete (SHA-előtag: \file{aa258c9577f53e1f}), nem a hiányzó r4 kimeneté. Az első kizárt rácspont nem a folytonos metszés. A metszést az ellenőrzött burkolóból újraszámoljuk; ezt az \file{external_bound/provenance.json} rögzíti.

\subsection*{Előellenőrzés: sikeres}
\begin{itemize}\itemsep2pt
\item Minden visszanyert bemenet hash-e egyezik a rögzítettel. A 17 nyers görbe a lefedett burkolót pontosan reprodukálja (legnagyobb relatív eltérés: 0).
\item A 11.4.~táblázat és az 5.~ábra 23 $F$ értéke a visszanyert ablaktáblázattal legfeljebb $\V{Fdev}$ relatív eltéréssel egyezik ($10^{-9}$ tolerancia); a korábbi rögzített eltérés 0 volt, a mostani különbség lebegőpontos kerekítés.
\item Mind a négy metszés 0.1\%-on belül egyezik az elveszett számítás rögzített értékével; a folytonos burkolószél a csomagolt ablak metszésével gépi pontosságig egyezik.
\item Véges, pozitív korlátot és szigorúan növekvő tartományrácsot követelünk meg. A nem lefedett cellákat a 17 görbe tartományuniója ellenőrzi; lefedésen belül NaN vagy Inf nem fogadható el. Hiányzó kulcsot nem hagyunk figyelmen kívül.
\end{itemize}
Bizonylat: \file{external_bound/preflight.json}, \file{external_bound/inputs/window_key_table.json} és \file{external_bound/inputs/window_crossings.json}.
''',r'''
\section{Eöt-Wash 2020: eredmények $\alpha_Y=1$ mellett}
\begin{center}\small
\begin{tabular}{lrr}\toprule
Publikált korlát & metszési $\lambda$ [\um] & $mc^2$ [meV]\\\midrule
11.4. táblázat $|\alpha_{95}|$ (elsődleges) & \V{edgeAbs} & \V{massAbs}\\
11.4. táblázat $+\alpha_{95}$ & \V{edgePlus} & \V{massPlus}\\
5. ábra Eöt-Wash (digitalizált) & \V{edgeFig} & \V{massFig}\\
Kombinált burkoló (kontextus) & \V{edgeEnv} & \V{massEnv}\\\bottomrule
\end{tabular}
\end{center}
Az elsődleges és az 5.~ábrából vett korlát digitalizálási szinten egyezik: 45 közös táblázatsoron az ábra/táblázat arány $\V{figLo}$ és $\V{figHi}$ közé esik. A két metszés eltérése mintegy $0.062\um$. Ez ugyanazon kísérleti eredmény két ábrázolásának ellenőrzése, nem független bizonyíték.

\subsection*{Kulcstáblázat}
\noindent A korlátoszlopok a publikált 11.4.~táblázat $|\alpha_{95}|$ értékein alapulnak, szükség esetén interpolálva. A metszésben definíció szerint $R=F=1$. Lásd: \file{external_bound/external_bound_key_table.csv}.
\begin{center}\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{rrrrrr}\toprule
$\lambda$ [\um] & $mc^2$ [meV] & $|\alpha_{95}|$ & $\alpha_{Y,\max}$ & $R$ & $F$\\\midrule
\tabinput{../generated/key_table.tex}
\bottomrule\end{tabular}
\end{center}
\subsection*{Tömegtartományok a táblázat tartományán belül}
\textbf{Kizárt:} $98.1355\um<\lambda\le8.9\,\mathrm{mm}$, azaz
$2.217\times10^{-5}\,\mathrm{eV}\le mc^2<2.0108\meV$.

\textbf{Nincs kizárva (nem megerősítés):} $5\um\le\lambda\le98.1355\um$, azaz
$2.0108\meV\le mc^2\le39.47\meV$. A pontos metszési pont az $R\le1$ esethez tartozik.

\textbf{E forrásból nem számolt:} $\lambda<5\um$ vagy $\lambda>8.9\,\mathrm{mm}$. $50\um$-nél $F=\V{F50}$. $100\um$-nél az elsődleges korlát kizárja az $\alpha_Y=1$ esetet, míg $+\alpha_{95}=0.0813$ mellett $R=0.9788$, tehát az még nincs kizárva.
''',r'''
\section{A $(\lambda,\alpha_Y)$ ábra és a kombinált ablak}
\begin{figure}[h]\centering
\includegraphics[width=\textwidth]{../../external_bound/external_bound_alphaY.png}
\caption{Publikált $\alpha_{Y,\max}=4\pi\alpha_{\rm lim}$ korlátok és az $\alpha_Y=1$ ág; jobbra a mikronos részlet. Az elsődleges görbe feletti halvány kitöltés az általa kizárt tartományt jelöli. A kombinált burkoló kontextus, nem független statisztikai kombináció. Adat: \file{external_bound/eotwash_external_scan.csv}; rajzolás: \file{external_bound/make_figure.py}.}
\end{figure}
A kombinált ablak változatlan: a megadott keresési tartományban csak itt nincs kizárva:
\begin{equation}
2\um\le\lambda<75.877\um,\qquad
2.6006\meV<mc^2\le98.66\meV.
\end{equation}
A nagy-$\lambda$ szélt a HUST 2020, nem az Eöt-Wash adja. A HUST zárja a mintegy $75.877\um$ és $98.136\um$ közötti sávot (körülbelül $2.01$--$2.60\meV$), amelyet az Eöt-Wash önmagában nem zár ki. A csomagolt határkonvenció a kombinált ablak felső végét nyitottnak írja; a pontos folytonos metszésben azonban $R=1$, így maga az egyenlőség nem szigorú $R>1$ kizárás.

Ez az állítás a lefedett tartományra vonatkozik (a pásztázásban $2\um$--$1\,\mathrm{cm}$). Nem állapít meg megengedett intervallumot rövidebb hatótávon, és nem tesz új nagy hatótávú állítást. Egy rövid hatótávú bemenet nem azonosított eredetű rajzolt görbe; a kombinált ábra ezt az eredetkorlátot megőrzi. A burkoló $1\,\mathrm{mm}$ körüli lépcsője egy digitalizált görbe lefedésének vége, nem új fizikai jelenség.

A kísérletspecifikus és a burkolóállítás nem cserélhető fel: az Eöt-Wash széle $\V{edgeAbs}\um$, a kombinált burkolóé $\V{edgeEnv}\um$. Egyik sem az időmező tömegének mérése.
''',r'''
\section{A forrásmodell állapota, függetlenség és korlátok}
\textbf{Az újraépített redukált Eöt-Wash forrásmodell validációja nem sikerült.} A dokumentált bemenetekkel vizsgált korábbi M2-változatok egyike sem adott valódi validációt. A formális küszöb elérését nem fogadtuk el validációnak. Következésképp \textbf{saját forrásmodell-illesztésünkből nincs TAL-jóslat}, és annak illesztett korlátait nem használjuk a cikkben.

A validációs feltételek változatlanok: a 7 kijelölt pontból legalább 2-ben $\pm20\%$, továbbá $\Delta\chi^2_{95}=6.17$. Nem enyhítjük őket, és nem találunk ki új zavaró paramétereket. A $9.2\um$-es árnyékolóeltolási hipotézist nem kezeljük dokumentált tényként. A hiányzó diagnosztikai állományokat itt nem állítottuk elő és nem futtattuk újra; a negatív állapot az \file{external_bound/provenance.json} fájlban rögzített korábbi eredmény, nem új forrásmodell-számítás állítása.

\subsection*{Mire jó a külső eredmény?}
Reprodukálható szótárátváltást és feltételes kizárást ad adott csatolásra és erőtörvényre. Saját forrásillesztés nélkül is használható, mert a kísérleti korlát publikált. Ugyanakkor \textbf{kevésbé független}, mint a kísérleti elemzés reprodukciója: örökli a szerzők geometriáját, kalibrációját, zavaróparaméter-kezelését és szisztematikáit. A táblázat és az ábra egyezése az átírást és digitalizálást ellenőrzi, nem e mögöttes feltevéseket.

\subsection*{Korlátozások}
\begin{enumerate}\itemsep4pt
\item A PRL Supplemental Material futásonkénti pozíciótáblázatát nem sikerült elérni. Hiánya nem akadálya a publikált korlát alkalmazásának, de a független forrásmodell-rekonstrukciónak igen. A korábbi diagnosztikában jelentkező, megmagyarázatlan mintegy $8\um$-es szeparációeltolás nyitott kérdés.
\item A $|\alpha_{95}|$ integrálkorlát és a $+\alpha_{95}$ profilhatár különböző konstrukció. Az utóbbi $98.14\um$-ről $101.03\um$-re tolja a szélt; ezt nem rejtjük el.
\item A log--log interpoláció a publikált sorok közötti közelítés. A kiírt számjegyek a számítást reprodukálják, nem kísérleti pontosságot állítanak.
\item Az ábra digitalizált, a kombinált burkoló grafikus és eredetbizonytalanságokat hordoz. Új bizonytalansági modellt vagy toleranciát nem illesztünk. A HUST rajzolt abszolút görbéjét csomagolt formában használjuk; előjelszétválasztott HUST-elemzést nem következtetünk ki.
\item Csak az univerzális, árnyékolatlan Yukawa-leképezést vizsgáljuk. Környezetfüggő árnyékolás vagy más csatolás más számítást igényel.
\item $R$ és $F$ feltételes korlátarány, nem szignifikancia vagy felfedezési valószínűség. A ,,nincs kizárva'' nem megerősítés; erő- vagy nyomatékkimutathatósági számítást nem adunk.
\end{enumerate}
''',r'''
\section{Adatok, kód és reprodukció}
A \file{TAL_time_field_mass_data_r3.zip} tartalmazza az \file{external_bound/} és \file{article_source/} könyvtárat, valamint a \file{README.md}, \file{LICENSE.txt}, \file{requirements.txt}, \file{run_all.sh} és \file{SHA256SUMS} fájlokat. Harmadik fél publikációs PDF-jét nem terjesztjük újra.

Az elsődleges számítás: \file{external_bound/external_bound.py}. Bemeneti SHA-256-ot ellenőriz, a metszéseket közvetlenül a táblázatból/görbékből/burkolóból újraszámolja, a rögzített eredményeket és a 23 ablak-$F$ értéket ellenőrzi, majd az \file{external_bound/} könyvtárban kiírja az \file{external_bound_results.json}, \file{external_bound_key_table.csv}, \file{eotwash_external_scan.csv} és \file{preflight.json} fájlokat. A csomag minden itt hivatkozott helyi fájlt tartalmaz. A nyers bemeneti hash-ek:
\begin{center}\small
\begin{tabular}{ll}\toprule
Visszanyert bemenet & SHA-256 előtag\\\midrule
11.4. táblázat CSV & \texttt{cf711b4fe52db194}\\
Eöt-Wash 5. ábra CSV & \texttt{093fabd78879a17d}\\
\file{envelopes.npz} & \texttt{54eb95655554be45}\\
r3 \file{results.json} & \texttt{aa258c9577f53e1f}\\\bottomrule
\end{tabular}
\end{center}
A hash-ek, bájtméretek és a hiányzó r4 archívum eredetadatai az \file{external_bound/input_manifest.json} és \file{external_bound/provenance.json} fájlban vannak.

\textbf{Reprodukció.} A kibontott adatkönyvtárban telepítsük a \file{requirements.txt} verzióit, majd futtassuk a \file{./run_all.sh} parancsot. A korlátszkript hiányzó kulcs, lefedett nem véges bemenet, hasheltérés vagy a rögzített eredménytől 0.1\%-nál jobban eltérő metszés esetén megáll. Az ábraszkript a pásztázást olvassa, az \file{article_source/build_articles.py} pedig a JSON-kimenetekből újra előállítja a két cikket. A PDF pdfLaTeX-kel és a közös \file{article_source/tex/common.tex} fájllal készül. Saját forrásmodell-illesztés nincs a forrásokban. A csomagolt eredmények számítás futtatása nélkül is vizsgálhatók.

\medskip\noindent Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); nem szakmai lektorálás.

\medskip\noindent\textbf{Licenc.} \copyright\ 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). CC BY-NC 4.0 International, \url{https://creativecommons.org/licenses/by-nc/4.0/}. Kereskedelmi felhasználás csak a szerző írásos engedélyével. Harmadik fél adataira saját feltételeik érvényesek; lásd: \file{LICENSE.txt}.
''']
for lang,pages in [('en',EN),('hu',HU)]:
 title=(r'TAL time-field mass and $(\lambda,\alpha_Y)$ exclusion:\\published Eöt-Wash bounds and the combined window (r3)' if lang=='en' else r'A TAL időmező tömege és a $(\lambda,\alpha_Y)$ kizárás:\\publikált Eöt-Wash korlátok és a kombinált ablak (r3)')
 s=r'\documentclass[11pt,a4paper]{article}'+'\n'+r'\input{common.tex}'+'\n'+r'\input{../generated/values.tex}'+'\n'
 if lang=='hu': s+=r'\usepackage[magyar]{babel}'+'\n'
 s+=foot+r'\hypersetup{pdftitle={TAL time-field mass - published Eot-Wash bounds and combined window (r3)},pdfauthor={Szabolcsi Dávid},pdfsubject={External published bounds; CC BY-NC 4.0 International}}'+'\n'
 s+=r'\title{'+title+'}\n'+r'\author{Szabolcsi Dávid\\ \small ORCID 0009-0005-6300-074X}'+'\n'+r'\date{6 November 2026 / 2026. november 6. \quad r3}'+'\n'+r'\begin{document}'+'\n'
 s+='\n\\clearpage\n'.join(pages)+bib+'\n'+r'\end{document}'+'\n'
 (HERE/'tex'/f'article_{lang}.tex').write_text(s)
print('Articles generated from verified external-bound JSON')
