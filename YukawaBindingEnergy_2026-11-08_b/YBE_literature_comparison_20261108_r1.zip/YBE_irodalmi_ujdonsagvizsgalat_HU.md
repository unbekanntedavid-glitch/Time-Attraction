# YBE: irodalmi újdonságvizsgálat

**Azonosító:** YBE-LIT-2026-11-08-r1. **Időhatár:** 2026. november 8., Europe/Zurich (CET). **Tárgy:** a [10.5281/zenodo.24053942](https://doi.org/10.5281/zenodo.24053942) alatt közzétett *Equilibrium binding energy at fixed baryon and ADM mass in a local massive-scalar neutron-star model* és a hozzá tartozó helyi források összevetése elsődleges szakirodalommal. Ez külön kutatási jegyzet; nem a közzétett kézirat módosítása, nem szakmai lektorálás.

## Rövid állásfoglalás

**Az energetikai grafikon és az általános skalár–folyadék formalizmus nem új. A védhető hozzájárulás a pontosan megadott modell numerikus adatkészlete és dokumentált összehasonlítási protokollja.**

- A kötési energia bariontömeg szerinti görbéje, a közös bariontömegű ADM-energetikai összevetés és a közös ADM-tömegű barionkapacitás vizsgálata korábban is megjelent.
- Különösen fontos: nem csupán konformális skalár–tenzor előzmény van. A közvetlen **f(φ)L_m, L_m=−ε** csatolás, annak ε-forrása és exponenciális példája csillagokra már **Folomeev–Aringazin–Dzhunushaliev (2013)** munkájában szerepel. A megőrzött számáramú általános variációs keretet **Böhmer–Tamanini–Wright (2015)** kifejti.
- A YBE saját f=exp(−φ), kvadratikus potenciál, SLy/APR4/H4, α_Y=1, L=1 és 10 km választása, konkrét megoldásai és kauzális párosítása ettől külön vizsgálandó **modellfüggő numerikus alkalmazás**.
- A vizsgált elsődleges forrásokban nem azonosítottam a YBE pontos paramétereihez tartozó azonos CSV-adatsort. **Ez nem bizonyít elsőséget**, és nem jogosít „első elmélet”, „első ilyen diagram” vagy új csillagfajta állítására.

Ez nem értéktelenségi ítélet: egy jól dokumentált, reprodukálható új modellalkalmazás tudományosan hasznos lehet anélkül, hogy új általános gravitációs mechanizmust vezetne be.

## 1. Mit hasonlítottam össze ténylegesen?

A helyi EN/HU TeX, tömeg-összevetési és szekvencia-CSV-k és a nyilvános EN PDF volt az YBE-oldali alap. A nyilvánosan letöltött EN PDF **bájtról bájtra azonos** a helyi kiadási PDF-fel: 395192 bájt, SHA256 `91f4f9dcd04d320d15f2b8e53e049f00e5475e12847e65584e84dc6714c654cf`. A rekord a vizsgálatkor **v37**, 2026-11-08 dátummal szerepelt. Az aktuális rekord korábbi verziókra mutató lánca nem igazolja, hogy az adott YBE-egyenletek vagy adatok már azok időpontjában megjelentek.

**18 elsődleges kutatási tétel** célzott releváns részeit olvastam, a megnyitott PDF-eket helyben rögzített hash azonosítja. A mátrix megkülönbözteti a legközelebbi modell-, energetikai, EOS- és tágabb Yukawa-előzményeket. Nem minden hivatkozás azonos súlyú. Azonos eredmény későbbi konferenciás összefoglalóját nem számoltam új, független előzménynek.

Keresési irányok: közvetlen scalar–fluid algebraic coupling; f(φ)L_m és L_m=−ε; massive scalar-tensor neutron star binding energy/baryonic mass; fixed baryon/fixed ADM; Yukawa-force stellar binding; SLy/APR4/H4 piecewise polytropes és kauzalitás. A régi alapmunkák mellett 2025-ös és az időhatár előtti 2026-os cikket is bevontam. Keresési találatokból önmagukban nem vontam le műszaki állítást: az alábbi következtetések megnyitott elsődleges szöveghelyekhez kapcsolódnak. A keresés célzott, nem minden lehetséges nyelvre/adatbázisra kiterjedő prioritási bizonyítás.

## 2. A YBE valódi modellje és definíciói

A kézirat (1)–(9) egyenletei szerint, G=c=1 egységekben:

\[
S=\int\!\sqrt{-g}\left[\frac{R}{16\pi}-\frac{(\nabla\phi)^2+\phi^2/L^2}{2\alpha_Y}-e^{-\phi}\epsilon(n)\right]d^4x,
\qquad \nabla_\mu(nu^\mu)=0,\quad\rho_0=m_Bn.
\]

A megadott n és ρ₀ **g** metrikával definiált puszta folyadéksűrűség. Az anyag energiája és nyomása e^−φ ε, illetve e^−φ P. A skaláregyenletben **−α_Y e^−φ ε** szerepel, nem az ε−3P anyagnyom. A hidrosztatikai egyenlet h′=−ν′+φ′. A számáram-megőrzés feltevése az akció rövid alakjához hozzátartozik: a variációs kényszereket a kézirat nem írja ki külön.

\[
B=1-2m/r,\quad
M_B=4\pi\int_0^R\frac{\rho_0 r^2}{\sqrt B}\,dr,\quad
M_{\rm ADM}=m(\infty),\quad E_{\rm bind}=(M_B-M_{\rm ADM})c^2.
\]

A barionintegrálban nincs lapse és nincs e^−φ súly. A felszíni m(R) nem az ADM-tömeg, ha a külső skalármező energiája nem nulla. Ezek a YBE-ben választott modell belső definíciói; nem minden más skaláros elméletre másolhatóak.

A hideg EOS-ra P=n dε/dn−ε; a darabonként polytrop energia-integrálási állandók és az alacsony sűrűségű ε/(ρ₀c²)→1 konvenció rögzítik a nyugalmitömeg-referenciát. A „bariontömeg” ezért nem egy önkényes ε/c² integrál. A megadott EOS konvencióján túl nincs ebből önálló mikroszkopikus barionszám-kalibráció.

## 3. A legközelebbi közvetlen akció-előzmények

### 3.1 FAD2013: a modellcsalád már csillagokra is megjelent

[FAD2013] PDF 2–5. lap, (1), (6), (7), (14): Einstein–Hilbert tag, kanonikus skalár, V és f(φ)L_DM; választásuk **L_DM=−ε**. A skalárforrás ε f_φ; a hidrosztatikában (ln f)′ is jelen van. Konkrét exponenciális függvényük f=exp[β(φ−φ₀)]. Ez ugyanaz a közvetlen energia-sűrűség-csatolási család, amelybe a YBE tartozik.

**Nem ugyanaz a számítás:** a bemutatott anyag degenerált sötét fermiongáz, a potenciál inverz hatvány, a külső háttér kozmológiai értékhez illesztett, és a közölt csillagtömeg m(r_b), nem a YBE sík aszimptotikus ADM-mínusz-barion mérlege. E különbségek miatt nem állítom, hogy a YBE táblázata ott már szerepel. Viszont az általános exponenciális energia-sűrűség-csatolású csillagötletre elsőség nem tartható fenn.

### 3.2 BTW2015 és MH2012: a konzervált folyadék variációs kerete

[BTW2015] PDF 3–6. lap, (2), (14), (24)–(27), (34)–(35): megőrzött részecskeáram és általános −√−g f(n,s,χ) interakció. A Lagrange-kényszereket nem szorozzák az interakcióval. PDF 8–9. lap, (46)–(51): f_int=ρ(n,s)γ(χ) esetén az energia és nyomás egyaránt γ-val súlyozódik.

A korábbi általános kerettel való algebrai azonosítás – **nem új elméleti eredményként** –:

\[
\chi=\phi/\sqrt{\alpha_Y},\quad V(\chi)=\chi^2/(2L^2),\quad
f_{\rm int}(n,\chi)=[e^{-\sqrt{\alpha_Y}\chi}-1]\epsilon(n).
\]

A puszta folyadék plusz e kölcsönhatás összege éppen a YBE e^−φ ε(n) anyagenergiája; a szokásos számáramkényszerek változatlanok. A cikk **általános** f függvénye engedi ezt; nem a bemutatott pozitív exponenciális γ és kifutó potenciál konkrét példáját azonosítjuk a YBE-vel.

[MH2012] PDF 2–3., 5. lap, (8), (13), (A4) különösen fontos az első főtételhez és ahhoz, hogy a f(Φ)ε anyagtag és a skalárfüggetlen áramkényszerek hogyan férnek össze. Ez segít a YBE feltevéseinek tisztázásában; nem bizonyítja azok nukleáris mikrofizikai helyességét.

**Lényegi következmény:** új variációs formalizmus helyett egy meglévő formalizmus konkrét, feltételezett anyagmodelljének numerikus alkalmazása állítható.

## 4. Miért nem egyszerűen a szokásos konformális tömeges skalár–tenzor modell?

[RP2016], [YDP2016], [RM2020], [UTYR2025] anyagakciója S_m[A²(χ)g,Ψ]. Az Einstein-keretbeli skalárforrás ezért a stressz-energia tenzor nyomát tartalmazza. A YBE **ε-forrása** nem azonos ezzel.

A különbség nem pusztán egy hiányzó A³ faktor. Konformális elméletben a Jordan-sűrűség ñ és az Einstein-proper-sűrűség n_E között n_E=A³ ñ. Ugyanazon barionszám írható A³ ñ vagy n_E integráljával. **Egy térfogati faktor hiánya önmagában nem elméletazonossági teszt.** [DEF1996] PDF 9. lap, (3.6f) és az utána álló definíció; [MS2016] PDF 10. lap, (72); [dAM2020] PDF 5. lap, (23).

A valódi funkcionális ellenőrzés: standard konformális hideg folyadék Einstein-energiája általában **A⁴ ε̃(n_E/A³)**. A YBE feltételezése **f(χ) ε_bare(n)** rögzített bare EOS mellett. Ezek általában nem azonosak. Például a nyugalmi n-tag és a polytrop n^Γ tag konformális súlya különböző; a YBE ugyanazt az f szorzót rendeli mindkettőhöz. Nyomásmentes porban vagy speciális EOS-nál lehet egyszerű egyezés, de ez nem általánosítható a többtagú relativisztikus Read-EOS-ra.

[YDP2016] már A=exp(α₀χ), kvadratikus potenciálú neutroncsillagokat is vizsgált. Az „exponenciális + tömeges skalár” szókapcsolat tehát szintén nem újdonsági bizonyíték. [B2025] PDF 35–36. lap, 3.3. szakasz a nem kölcsönható fermionok skalárfüggő tömegének és a konformális leírásnak ismert kapcsolatát mutatja; azt sem szabad automatikusan a YBE-re átvinni.

Hatótávnál is kell az egységkonvenció: a YBE L=1/m a redukált Compton-hossz; [RP2016] λ_φ=2π/m_φ jelölést használ. A címkéket nem szabad közvetlenül azonos számként összevetni.

## 5. A grafikon, a fix M_B és a fix ADM összehasonlítás előzményei

### 5.1 Kötésienergia–bariontömeg ábra

- **[MS2016], PDF 17. lap, 6. ábra:** frakcionális E_b=M_b/M−1 a bariontömeg függvényében; SLy4, GR és skaláros/diszformális modell. A PDF 13. lap I. táblázata fix M_b=1.5 M☉ mellett közöl ADM-tömegeket. A kötöttséghez a szöveg kifejezetten hozzáteszi: **„but not necessarily stable”** (10. lap).
- **[dAM2020], PDF 10. lap, IV.B:** E_b=M_b−M a bariontömeg függvényében, közös M_b energetikai összevetés. A radiális perturbációkat ettől külön vezeti le és oldja meg.
- **[UTYR2025], PDF 2–3. lap, 2–3. ábra:** (M_b−M_ADM)/M_b a bariontömeg függvényében, illetve azonos M_b csillagok ADM-különbsége. Ezzel még a kifejezetten tömeges skalár esetben sem új a diagram alapelve.

A normalizálás eltérése – energia ergben, tömegkülönbség, (M_b−M)/M vagy (M_b−M)/M_b – nem új fizikai mennyiség bevezetése, ha M_b és M definíciói adottak. A modellek közötti különbséget ettől még meg kell tartani.

### 5.2 Fix ADM és barionkapacitás

**[RP2016], PDF 6. lap, 1. ábra:** közös ADM=1.70 M☉ mellett HB EOS, m_φ=1.6×10^−13 eV; β=0,−4.5,−6,−10,−100 esetén a közölt bariontömegek rendre 2.06, 2.07, 2.10, 2.32, 5.37 M☉. Ezek nem a YBE számai, hanem konkrét bizonyíték arra, hogy az azonos ADM-hez tartozó eltérő bariontartalmat korábban már tanulmányozták.

**[GS2022], PDF 30–32. lap, 6.6. szakasz és 12. ábra:** Yukawa-csatolt fermionmodellben közös M=0.3 M☉ mellett vizsgálják a bariontartalmat és az átlagos kötést. Mikroszkopikus skalárforrásuk <ψ̄ψ>, nem ε; az EOS is a skalárfüggő fermiontömeggel módosul.

A YBE azonosságai:

\[
\Delta E_{\rm bind}|_{M_B}=-c^2\Delta M_{\rm ADM},\qquad
\Delta E_{\rm bind}|_{M_{\rm ADM}}=c^2\Delta M_B
\]

közvetlenül a definícióból következnek. Nem új tétel, és nem két független felfedezés. Az első azonos barionszámú energetikai kontraszt; a második azonos ADM mellett barionkapacitás-kontraszt. A YBE helyes elkülönítése jó közlési gyakorlat, nem új megmaradási törvény.

Ráadásul a GR és egy más csatolású modell összevetése önmagában nem fizikailag megengedett csillagátmenet. A c²ΔM elnevezése nem igazolja, hogy az energia sugárzásként felszabadulhat.

## 6. EOS, nyugalmi sűrűség és kauzális ágválasztás

[Read2009] PDF 3. lap, (2)–(10) adja a hideg termodinamikai összefüggést és a darabonként polytrop ε-t; PDF 20. lap III. táblázatában SLy, AP4 és H4 paraméterei szerepelnek. A YBE APR4 elnevezése itt az AP4 paraméterezéshez kapcsolódik. [AM2017] PDF 4–5. lap, 2.3–2.4. szakasz **SLy, APR4 és H4** EOS-okat ugyanabban a skalár–tenzor vizsgálatban, Read-féle megvalósítással használja. E hármas kiválasztása önmagában nem új.

A hangsebesség dP/dε vizsgálata és az, hogy a csillag által ténylegesen elért sűrűségekre kell a kauzalitást értelmezni, [Read2009] VI.A, PDF 8–10. lap tárgya. A cikk a fit bizonytalanságát is elemzi; az ott alkalmazott megengedést nem szabad automatikusan a YBE szigorú fit-küszöbére cserélni vagy fordítva.

A YBE saját munkaszabálya: az első ADM-csúcs és az első kauzalitássértés közül a korábbi végpont; majd a két modell közösen hozzáférhető tartományában a kisebb határ 99%-a, **külön** M_B és ADM tengelyre. Ez reprodukálható párosítási előírás, de a 99% nem univerzális fizikai tétel. A pozitív tömegderivált és c_s≤c együtt sem helyettesít csatolt skalár–folyadék perturbációs stabilitásvizsgálatot.

A rögzített bare EOS tiszta kontrollt ad a feltételezett fε-modellben, de nem teszi megoldottá a mikrofizika vagy az EOS–gravitáció degeneráció kérdését. [HF2015] éppen a kötési energia EOS- és gravitációfüggését vizsgálja; a nyugalmitömeg-konvenciót is hangsúlyozza. Ott B=M_G−M_B az YBE előjelének ellentettje.

## 7. Mi marad saját eredmény, és mire nincs bizonyíték?

| Állítás | Irodalmi helyzet | YBE-re védhető megfogalmazás |
|---|---|---|
| E_bind=(M_B−M_ADM)c² | Régi energiaazonosság | Alkalmazott definíció |
| Megőrzött barion proper-volume integrálja | Régi relativisztikus módszer | A megadott n-konvenció következetes használata |
| f(φ)ε-csatolás, exponenciális f | Korábbi akciócsalád és csillagmodell | Saját választás egy ismert modellcsaládban |
| Tömeges skalár és exponenciális függvény NS-ben | Korábbi konformális és közvetlen családok | Nem az alak neve, hanem a konkrét funkcionális anyagmodell azonosít |
| Kötésienergia-görbe M_B szerint | Legalább MS2016; újabban UTYR2025 | Új számértékek adott modellben, nem új diagramtípus |
| Fix M_B és fix ADM összevetés | Mindkettőnek konkrét előzménye van | Világosan elkülönített diagnosztikák ugyanarra az adatkészletre |
| SLy/APR4/H4 hármas | Korábban is használták | EOS-függés dokumentálása |
| Kauzalitás ellenőrzése | Ismert fizikai követelmény | Saját párosítási tartomány és CSV-ben követhető határ |
| 1391 állapot, 24 pár, 114 numerikus kontroll | A YBE saját dokumentációjának tartalma | Reprodukálhatósági hozzájárulás, nem önálló fizikai bizonyítás |
| Pontos YBE-adatsor prioritása | Nem állapítottam meg korábbi azonosságot, de a keresés nem kizárási bizonyítás | „Ebben a munkában előállított adatkészlet”; ne „a világon első” |
| Új stabil csillagág, mérési felfedezés, kibocsátási energia | E vizsgálat nem igazolja | Ne állítsa |

A közölt kanonikus eltérések α_Y=1, L=10 km mellett, minden EOS saját GR ADM=1.4 M☉ állapotának bariontömegén rögzített M_B-nél (SLy/APR4/H4: 10.850/11.233/8.443 ×10^51 erg) a YBE-modell **saját numerikus állításai**, nem az irodalmi azonosság bizonyítékai. A hasonló előjel, vagy más normalizálású korábbi görbe nem igazolja és nem cáfolja e számokat. Ez a feladat nem futtatott új csillagszekvenciát.

A 114 külső ADM-kontroll hasznos numerikus pontossági bizonyíték, nem a skalár–anyag kölcsönhatás természeti igazolása. A helyi korábbi elemzésben reprodukált kontrollok és az akkor archivált csúcsillesztések státuszát nem változtattam meg irodalmi olvasás alapján. A nyilvános rekord leírása későbbi 1391/114/18-as újraszámolást is jelent; **e későbbi állítást ebben az irodalmi feladatban nem reprodukáltam**, ezért nem jelölöm saját új ellenőrzésnek.

## 8. Nyitott kérdések a szigorúbb tudományos értékeléshez

1. **Anyagmodell:** mi indokolja, hogy a nukleáris bare ε(n) minden tagja ugyanazzal az e^−φ faktorral súlyozódjon? Ez feltételezett fenomenológia, nem a Read-illesztésből következő mikrofizika.
2. **Variációs kényszerek:** az akció rövid jelölése mellé kell a megőrzött áram explicit variációs specifikációja. BTW2015/MH2012 ehhez pontos előzmény, nem külső fizikai bizonyíték.
3. **Mérési kapcsolat:** a modell szerinti g metrikát, barionreferenciát és aszimptotikus tömeget hogyan kapcsoljuk tényleges anyagórákhoz és mérhető tömegekhez? A konformális elméletek megoldásait nem lehet definícióellenőrzés nélkül átvenni.
4. **Elméleten belüli dinamika:** szükséges a modell saját csatolt radiális perturbációinak vagy időfejlődésének vizsgálata. Egy más elmélet stabilitásvizsgálata nem vihető át.
5. **EOS-rendszertan:** a három fit összevetése nem fogja át az EOS-bizonytalanságot vagy skalár által módosított nukleáris kölcsönhatásokat. A puszta EOS kauzalitása nem minden összetett terjedési mód vizsgálata.
6. **Prioritás:** ha az „első” kérdés lényegi, régi rekordok konkrét fájltartalmát és azonos akció/paraméter/EOS adatsorokat kell időrendben ellenőrizni. A korábbi r3-archívum identitását e munka nem állapítja meg.

## 9. Javasolt, védhető újdonságmondat

**HU:** „Szabolcsi Dávid munkájának hozzájárulása a megadott exponenciális energiasűrűség-csatolású, kvadratikus potenciálú lokális skalár–folyadék modell SLy/APR4/H4 állapotegyenletekkel előállított reprodukálható egyensúlyi adatkészlete, a kauzális tartományban elkülönített közös bariontömegű és közös ADM-tömegű összevetésekkel; nem a kötési energia definíciójának vagy a skalár–folyadék csatolás általános formalizmusának bevezetése.”

**EN:** “The contribution is a reproducible equilibrium dataset for the specified exponentially energy-density-coupled local massive-scalar fluid model with a quadratic potential and SLy/APR4/H4 equations of state, with fixed-baryon-mass and fixed-ADM-mass comparisons separately restricted to the adopted causal domain; it is not the introduction of the binding-energy definition or of the general scalar–fluid coupling formalism.”

A kapcsolódó munkákat rögtön e mondat előtt érdemes idézni: **FAD2013 és BTW2015** a modellcsaládra, **MS2016 és UTYR2025** a bariontömegű kötésdiagramra, **RP2016** a közös ADM-re, **Read2009** az EOS-ra. Ez javaslat; ebben a munkában sem a közzétett fájl, sem a rekord nem módosult.

A `legkozelebbi_modellek_rovid_tabla_HU.md` külön rövid táblázatban rögzíti a határfeltételeket, G- és hatótávkonvenciókat, a tömegdefiníciókat és a korábbi fix M_B/külső energia kezelést. A megfigyelhetőségi állítás hiányzó feltételeit is elkülöníti; nincs új megfigyelési feladat.

## 10. Rövid kulcsbibliográfia

Az összes tétel szerzőit, DOI-ját, közlési/verziódátumát, pontos PDF-helyét és rövid részletét a `hivatkozasok_es_forrasreszletek.md` és `forrasmatrix_HU.csv` tartalmazza.

- **FAD2013:** V. Folomeev, A. Aringazin, V. Dzhunushaliev, *Chameleon dark matter stars*, Phys. Rev. D 88, 063005, 2013-09-05. https://doi.org/10.1103/PhysRevD.88.063005 ; https://arxiv.org/abs/1305.1087
- **BTW2015:** C. G. Böhmer, N. Tamanini, M. Wright, *Interacting quintessence from a variational approach. I. Algebraic couplings*, Phys. Rev. D 91, 123002, 2015-06-02. https://doi.org/10.1103/PhysRevD.91.123002 ; https://arxiv.org/abs/1501.06540
- **MS2016:** M. Minamitsuji, H. O. Silva, *Relativistic stars in scalar-tensor theories with disformal coupling*, Phys. Rev. D 93, 124041, 2016-06-16. https://doi.org/10.1103/PhysRevD.93.124041 ; https://arxiv.org/abs/1604.07742
- **RP2016:** F. M. Ramazanoğlu, F. Pretorius, *Spontaneous Scalarization with Massive Fields*, Phys. Rev. D 93, 064005, 2016-03-03. https://doi.org/10.1103/PhysRevD.93.064005 ; https://arxiv.org/abs/1601.07475
- **UTYR2025:** K. İ. Ünlütürk, S. Tuna, O. K. Yamak, F. M. Ramazanoğlu, *Nature of Phase Transitions and Metastability in Scalar-Tensor Theories*, Phys. Rev. Lett. 135, 061401, 2025-08-05. https://doi.org/10.1103/14xz-d7xf ; https://arxiv.org/abs/2502.01781v2
- **Read2009:** J. S. Read, B. D. Lackey, B. J. Owen, J. L. Friedman, *Constraints on a phenomenologically parametrized neutron-star equation of state*, Phys. Rev. D 79, 124032, 2009-06-22. https://doi.org/10.1103/PhysRevD.79.124032 ; https://arxiv.org/abs/0812.2163

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International + https://creativecommons.org/licenses/by-nc/4.0/ · commercial use only with the author's written permission.
