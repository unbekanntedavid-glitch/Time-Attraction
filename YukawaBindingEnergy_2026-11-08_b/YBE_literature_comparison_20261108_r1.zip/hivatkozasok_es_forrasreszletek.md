# Megnyitott elsődleges források

A PDF-lapszám a fájl első lapjától számol, nem feltétlenül a nyomtatott oldalszám. Az HTML-konverzió egyenletszámozása egyes cikkeknél eltér; a mátrix PDF-helyei az irányadók. A dátumok a kiadói Crossref-metaadatból, a verziódátumok a PDF arXiv-fejlécéből származnak. A megnyitott HTML néhol 2026-os konverziós dátumot mutat régi cikkeknél; ezt nem tekintettük eredeti közlési dátumnak.

## [FAD2013] Vladimir Folomeev; Ascar Aringazin; Vladimir Dzhunushaliev
Chameleon dark matter stars

Folyóirat online közlés: 2013-09-05; arXiv:1305.1087v2 [astro-ph.SR] 7 Sep 2013

https://doi.org/10.1103/PhysRevD.88.063005
https://arxiv.org/abs/1305.1087

Olvasott hely: PDF 2–6. lap: (1), (2), (6), (7), (11)–(14); II.B–C, III.B

Rövid forrásrészlet (matematikai jelek normalizálva): “In the present paper, we employ the model described by the general Lagrangian (1) with the dark matter Lagrangian L_DM = −ε.”

## [BTW2015] Christian G. Böhmer; Nicola Tamanini; Matthew Wright
Interacting quintessence from a variational approach. I. Algebraic couplings

Folyóirat online közlés: 2015-06-02; arXiv:1501.06540v2 [gr-qc] 3 Jun 2015

https://doi.org/10.1103/PhysRevD.91.123002
https://arxiv.org/abs/1501.06540

Olvasott hely: PDF 3–6., 8–9. lap: (2), (3), (14), (24)–(27), (34)–(35), (46)–(51)

Rövid forrásrészlet (matematikai jelek normalizálva): “Note that f cannot depend on the Lagrange multipliers, which are needed to impose the constraints ... and are not supposed to mix with the scalar field.”

## [MH2012] Olivier Minazzoli; Tiberiu Harko
New derivation of the Lagrangian of a perfect fluid with a barotropic equation of state

Folyóirat online közlés: 2012-10-09; arXiv:1209.2754v1 [gr-qc] 12 Sep 2012

https://doi.org/10.1103/PhysRevD.86.087502
https://arxiv.org/abs/1209.2754

Olvasott hely: PDF 2–3., 5. lap: (6), (8), (13), Appendix (A4)

Rövid forrásrészlet (matematikai jelek normalizálva): “one has to notice that the second term in the right hand side of equation (A4) does not couple neither with the metric, nor with the scalar field.”

## [MS2016] Masato Minamitsuji; Hector O. Silva
Relativistic stars in scalar-tensor theories with disformal coupling

Folyóirat online közlés: 2016-06-16; arXiv:1604.07742v2 [gr-qc] 17 Jun 2016

https://doi.org/10.1103/PhysRevD.93.124041
https://arxiv.org/abs/1604.07742

Olvasott hely: PDF 10., 13–14., 17. lap: (62), (63), (72); I. táblázat, 3. és 6. ábra

Rövid forrásrészlet (matematikai jelek normalizálva): “which is positive for bound (but not necessarily stable) configurations.”

## [RP2016] Fethi M. Ramazanoğlu; Frans Pretorius
Spontaneous scalarization with massive fields

Folyóirat online közlés: 2016-03-03; arXiv:1601.07475v1 [gr-qc] 27 Jan 2016

https://doi.org/10.1103/PhysRevD.93.064005
https://arxiv.org/abs/1601.07475

Olvasott hely: PDF 1., 3–4., 6–7. lap: (1)–(3), (11), (18); 1–2. ábra

Rövid forrásrészlet (matematikai jelek normalizálva): “All cases have a fixed ADM mass of 1.70M_sun”

## [YDP2016] Stoytcho S. Yazadjiev; Daniela D. Doneva; Dimitar Popchev
Slowly rotating neutron stars in scalar-tensor theories with a massive scalar field

Folyóirat online közlés: 2016-04-20; arXiv:1602.04766v1 [gr-qc] 15 Feb 2016

https://doi.org/10.1103/PhysRevD.93.084038
https://arxiv.org/abs/1602.04766

Olvasott hely: PDF 3–4., 7–11. lap: (2), (4), (6), (9)–(12); III.B

Rövid forrásrészlet (matematikai jelek normalizálva): “The first one is the massive Brans-Dicke theory with a coupling function ... A(φ)=exp(α0φ)”

## [Read2009] Jocelyn S. Read; Benjamin D. Lackey; Benjamin J. Owen; John L. Friedman
Constraints on a phenomenologically parametrized neutron-star equation of state

Folyóirat online közlés: 2009-06-22; arXiv:0812.2163v1 [astro-ph] 11 Dec 2008

https://doi.org/10.1103/PhysRevD.79.124032
https://arxiv.org/abs/0812.2163

Olvasott hely: PDF 2–4., 8–10., 19–20. lap: (1)–(10); VI.A; C függelék, II–III. táblázat

Rövid forrásrészlet (matematikai jelek normalizálva): “Perfect fluids have causal time evolutions ... only if v_s ... is less than the speed of light.”

## [GS2022] Christina Gao; Albert Stebbins
Structure of stellar remnants with coupling to a light scalar

Folyóirat online közlés: 2022-07-15; arXiv:2110.07012v2 [hep-ph] 4 Nov 2021

https://doi.org/10.1088/1475-7516/2022/07/025
https://arxiv.org/abs/2110.07012

Olvasott hely: PDF 7., 9., 30–32. lap: (3.3), (4.1)–(4.8); 6.6. szakasz, 12. ábra

Rövid forrásrészlet (matematikai jelek normalizálva): “One sees that the baryon content of a fixed gravitational mass stellar remnant increases ... due to the increased binding energy ...”

## [FS2012] Vladimir Folomeev; Douglas Singleton
Relativistic polytropic spheres embedded in a chameleon scalar field

Folyóirat online közlés: 2012-03-30; arXiv:1112.1786v3 [astro-ph.SR] 2 Apr 2012

https://doi.org/10.1103/PhysRevD.85.064045
https://arxiv.org/abs/1112.1786

Olvasott hely: PDF 2–4., 6–7. lap: (1), (11)–(13), (24), (38), (44)

Rövid forrásrészlet (matematikai jelek normalizálva): “the proper energy density E0 is the sum of the rest energy density E0g ... and its total microscopic kinetic energy”

## [DEF1996] Thibault Damour; Gilles Esposito-Farèse
Tensor-scalar gravity and binary-pulsar experiments

Folyóirat online közlés: 1996-07-15; arXiv:gr-qc/9602056v1 27 Feb 1996

https://doi.org/10.1103/PhysRevD.54.1474
https://arxiv.org/abs/gr-qc/9602056

Olvasott hely: PDF 1–2., 5., 8–9., 12–13. lap: (1.1), (1.2), (3.6f); II. és IV.A

Rövid forrásrészlet (matematikai jelek normalizálva): “As usual the value of M(ρ) at infinity is the total (ADM) mass.”

## [WLC2009] De-Hua Wen; Bao-An Li; Lie-Wen Chen
Supersoft Symmetry Energy Encountering Non-Newtonian Gravity in Neutron Stars

Folyóirat online közlés: 2009-11-16; arXiv:0908.1922v2 [nucl-th] 4 Nov 2009

https://doi.org/10.1103/PhysRevLett.103.211102
https://arxiv.org/abs/0908.1922

Olvasott hely: PDF 2–3. lap: (1), (2); 1–2. ábra

Rövid forrásrészlet (matematikai jelek normalizálva): “the Einstein equation remains the same and only the EOS is modified.”

## [HF2015] Xiao-Tao He; F. J. Fattoyev; Bao-An Li; W. G. Newton
Impact of the equation-of-state–gravity degeneracy on constraining the nuclear symmetry energy from astrophysical observables

Folyóirat online közlés: 2015-01-28; arXiv:1408.0857v2 [nucl-th] 16 Dec 2014

https://doi.org/10.1103/PhysRevC.91.015810
https://arxiv.org/abs/1408.0857

Olvasott hely: PDF 5–7., 10–12. lap: (6)–(7), (9)–(18); I. táblázat, 5. ábra

Rövid forrásrészlet (matematikai jelek normalizálva): “It is also important to specify the baryon mass m_B.”

## [RM2020] Roxana Rosca-Mead; Christopher J. Moore; Ulrich Sperhake; Michalis Agathos; Davide Gerosa
Structure of Neutron Stars in Massive Scalar-Tensor Gravity

Folyóirat online közlés: 2020-08-19; arXiv:2007.14429v3 [gr-qc] 31 Aug 2020

https://doi.org/10.3390/sym12091384
https://arxiv.org/abs/2007.14429

Olvasott hely: PDF 3–9., 15–18. lap: (3)–(5), (21)–(28), (31); 3., 4.1., 4.5. szakasz, 8–9. ábra

Rövid forrásrészlet (matematikai jelek normalizálva): “The motivation for using the baryon mass ... arises from the conservation of the baryon number”

## [B2025] Reuven Balkin; Javi Serra; Konstantin Springmann; Stefan Stelzl; Andreas Weiler
Heavy neutron stars from light scalars

Folyóirat online közlés: 2025-02-20; arXiv:2307.14418v1 [hep-ph] 26 Jul 2023

https://doi.org/10.1007/JHEP02(2025)141
https://arxiv.org/abs/2307.14418

Olvasott hely: PDF 6–8., 30–36. lap: (2.1), (2.7a)–(2.8c), (3.31), (3.46)–(3.50); 3.3. szakasz

Rövid forrásrészlet (matematikai jelek normalizálva): “Scalar-tensor theories ... can be equivalently described ... via scalar-dependent masses for the (non-interacting) matter fields.”

## [UTYR2025] Kıvanç İ. Ünlütürk; Semih Tuna; Oğuzhan K. Yamak; Fethi M. Ramazanoğlu
Nature of Phase Transitions and Metastability in Scalar-Tensor Theories

Folyóirat online közlés: 2025-08-05; arXiv:2502.01781v2 [gr-qc] 29 Jul 2025

https://doi.org/10.1103/14xz-d7xf
https://arxiv.org/abs/2502.01781v2

Olvasott hely: PDF 1–3., 7–8. lap: (1), (2), (E1)–(E4); 2–3. ábra

Rövid forrásrészlet (matematikai jelek normalizálva): “The total energy of a NS is its ADM mass M_ADM.”

## [AM2017] Zahra Altaha Motahar; Jose Luis Blázquez-Salcedo; Burkhard Kleihaus; Jutta Kunz
Scalarization of neutron stars with realistic equations of state

Folyóirat online közlés: 2017-09-26; arXiv:1707.05280v2 [gr-qc] 27 Sep 2017

https://doi.org/10.1103/PhysRevD.96.064046
https://arxiv.org/abs/1707.05280

Olvasott hely: PDF 2–5. lap: (2), (5), (7), (8); 2.3–2.4. szakasz

Rövid forrásrészlet (matematikai jelek normalizálva): “For the equations SLy, APR4, GNH3, H4 and ALF2, ALF4 we implement ... the piecewise polytropic interpolation”

## [dAM2020] Bernardo F. de Aguiar; Raissa F. P. Mendes
Highly compact neutron stars and screening mechanisms: Equilibrium and stability

Folyóirat online közlés: 2020-07-21; arXiv:2006.10080v2 [gr-qc] 22 Jul 2020

https://doi.org/10.1103/PhysRevD.102.024064
https://arxiv.org/abs/2006.10080

Olvasott hely: PDF 2–6., 10. lap: (1), (10), (15)–(23), (31)–(34); IV.B

Rövid forrásrészlet (matematikai jelek normalizálva): “we have computed the binding energy E_b ≡ M_b − M as a function of the baryon mass M_b”

## [BPC2026] Debadri Bhattacharjee; Grigorios Panotopoulos; Pradip Kumar Chattopadhyay
Probing Realistic Neutron Star Equations of State via the Chameleon Mechanism

Folyóirat online közlés: nem rendeltünk hozzá folyóiratközlést; arXiv:2610.41505v1 [gr-qc] 30 Oct 2026


https://arxiv.org/abs/2610.41505

Olvasott hely: PDF 1–4. lap: dátum, (1), (5), (10)–(14); III–V. szakasz

Rövid forrásrészlet (matematikai jelek normalizálva): “In the present framework, the scalar-matter interaction is mediated by the Jordan frame metric”
