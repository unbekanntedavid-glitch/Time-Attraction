# YBE irodalmi összevetés – külön kutatási melléklet

Azonosító: YBE-LIT-2026-11-08-r1; dátum: 2026-11-08, Europe/Zurich (CET).

Olvasási sorrend:
- `YBE_irodalmi_ujdonsagvizsgalat_HU.md`: állásfoglalás, valódi akció és sűrűségkonvenciók, legközelebbi előzmények, védhető újdonságmondat.
- `legkozelebbi_modellek_rovid_tabla_HU.md`: rövid egyenlet/határfeltétel/G/hatótáv/tömeg összevetés, ismeretlen részletek jelölésével; megfigyelhetőségi korlátok.
- `forrasmatrix_HU.csv`: 18 elsődleges tétel, részletes akció/EOS/tömeg/párosítás összevetés. UTF-8 BOM, vessző-elválasztó; táblázatkezelőben UTF-8 kódolással nyitható.
- `hivatkozasok_es_forrasreszletek.md`: szerzők, dátumok, DOI/arXiv-linkek, PDF-lap/egyenlet/ábra és rövid forrásrészletek.
- `bibliografiai_metaadatok.json`: a bibliográfiához használt kiadói Crossref-mezők.
- `provenance.json`: olvasott helyi YBE-bemenetek és az elsődleges PDF-ek mérete/SHA256; nyilvános/helyi EN PDF-azonosság.
- `LICENSE.txt`; `SHA256SUMS.txt`.

Az egyenlet- és oldalszámok a megnyitott PDF-változatokra vonatkoznak, nem az esetenként eltérően számozott HTML-re. A PDF-lapszám az első laptól számol. A forrás-PDF-ek az eredeti URL-eken érhetők el; szerzői jogi okból nincsenek a melléklet ZIP-jében. A provenance hash lehetővé teszi a vizsgált változat azonosítását. A jelenlegi arXiv-letöltés később változhat; a megadott verziófejléc segít a visszakeresésben.

Fájlellenőrzés a kicsomagolt könyvtárban: `sha256sum -c SHA256SUMS.txt`.

Ez irodalmi összevetés, nem új csillagszimuláció vagy numerikus újrafuttatás. Nincs hozzá futtatandó tudományos program. Nem módosítja a publikált kéziratokat; nem igazol új dinamikai stabilitást, megfigyelési kimutatást, átalakulási energiakibocsátást vagy fizikai modellhelyességet. Irodalmi egyezést és eltérést ellenőriz, nem szerzői elsőbbségi jogvélemény.

Sem GitHub-módosítás, sem feltöltés, sem külső üzenet nem történt ebben a feladatban.

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International + https://creativecommons.org/licenses/by-nc/4.0/ · commercial use only with the author's written permission.
