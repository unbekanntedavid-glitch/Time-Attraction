# Yukawa equilibrium binding energy — YBE-2026-11-08-b

Szabolcsi Dávid · ORCID 0009-0005-6300-074X · manuscript date 2026-11-08.
Local revised manuscript; not peer reviewed. Subsequent author-supplied Academia Co-scientist numerical-check report received. No upload, message or remote change was performed for this revision. No DOI is assigned to b. The earlier published a package is https://doi.org/10.5281/zenodo.24053942; this is not the identifier of b.

This is one equilibrium-energy analysis with EN/HU manuscript versions. It uses the supplied local massive-scalar model, not a laboratory-source-model prediction. H4 extends the SLy/APR4 comparison; common baryon and common ADM mass are different questions.

## Files

- `manuscript/binding_energy_EN.pdf`, `binding_energy_HU.pdf`: articles, both with the required license footer on every page.
- `manuscript/*.tex`: editable main files and CSV-generated tables. The bibliography is embedded in each main TeX file; no absent .bib is needed.
- `figures/energy_vs_MB_{EN,HU}.{png,pdf}`: E_bind vs baryon mass, in 10^53 erg against solar masses. Only causal first-rising equilibria are plotted; endpoints are not stability labels.
- `figures/mass_matching_contrasts_{EN,HU}.{png,pdf}`: separate fixed-MB energy and fixed-ADM baryon-capacity panels. Their vertical units differ intentionally.
- `data/`: unchanged supplied scientific tables, including peak-fit data subsequently reported as reproduced by Academia Co-scientist.
- `code/binding_sequences.py`, `code/source/`: unchanged supplied numerical/EOS sources and source-reference inputs. No source-model equation or EOS was edited.
- `code/make_figures.py`, `code/build_manuscripts.py`: new presentation-only code.
- `reproduce.py`: new integrity, physical-table and pointwise-control reproduction entry point. It does not depend on prior workspace files.
- `validation/`: numerical consistency/reproduction records, not physical validation or peer review.
- `metadata/`: provenance, exact input hashes, environment, references, ready-to-paste EN/HU descriptions and manual upload guidance.
- `LICENSE.txt`, `SHA256SUMS.txt`: reuse conditions and distribution fingerprints.

The research data/code archive excludes article PDFs and TeX, but includes numerical inputs, wrapper, plotting code, figures, metadata and license. Article-build commands below apply to the combined or editable-source distribution, not the numerical-only archive. The editable-source archive contains the manuscript, figures, presentation source and data required to rebuild its tables. The combined archive supplies these together with both article PDFs. Some shared inputs are repeated between standalone archives so each can be used on its own.

## Numerical reproduction

Tested with Python 3.13.5 and the exact versions in `requirements.txt`; other environments were not tested. Install dependencies once; afterwards no network or external scientific input is needed:

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 reproduce.py --check --out run/check
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 reproduce.py --controls --out run/controls
```

`--check` is also the default. It verifies required input hashes/keys, finite physical quantities, 1391 mass/energy budgets and causal flags, all 24 target-selection rules/residuals, EOS first-law consistency, and rejection of missing/NaN/infinite values. Diagnostic columns not applicable to one model can contain missing entries; they are never substituted for physical masses, energies or metrics. Inputs are unchanged; outputs go to the chosen run directory.

`--controls` re-executes all 114 archived pointwise numerical variants and 58 distinct baseline states using the supplied collocation algorithm; it also integrates the exterior scalar energy separately and checks metric positivity on sampled profiles. In the tested environment it takes roughly half a minute. Outputs: `data_check.json`, `control_check.json`, `reproduced_controls.csv`, `exterior_integrals.csv`. This is a reproduction and consistency check, not a distinct physical validation algorithm or perturbative stability calculation.

To reconstruct the whole sequence generation, optionally run:

```sh
python3 reproduce.py --regenerate --out run/fresh_sequences
```

This copies the unchanged production code into a new run directory and writes newly generated sequences/cache there. It refuses to overwrite an existing simulation directory. The cache is created by that run; no supplied pickle is needed or loaded. The initial a assembly did not regenerate the 1391-state archive; the subsequent author-supplied Academia report reports reproduction of all 1391 configurations and six main CSV tables. This b prose/bibliography revision retains the same science files and reruns strict integrity and consistency checks; it does not claim another new full sequence run. Original CSV snapshots stay under `data/`.

Optional original local-peak refitting (the later author-supplied Academia report reports all 18 fits reproduced):

```sh
python3 reproduce.py --archived-peak-validator --out run/refit_peaks
```

The original verifier is copied beside the frozen tables, with required source-reference CSV included. Its old historical workspace comparisons are conditional and not required scientific inputs. It can regenerate peak fits using the supplied algorithm. Those fits were archived-only in the initial a assembly; their later reported reproduction is recorded separately in `metadata/checking_history.json`. This mode is not an astrophysical stability test.

## Rebuild presentation and articles

```sh
python3 reproduce.py --figures --out run/figure_check
python3 code/build_manuscripts.py
sh build_articles.sh
python3 code/check_documents.py --out run/document_check.json
```

The TeX builder uses XeLaTeX twice per language and requires Liberation Serif, DejaVu Sans/Mono, English/Hungarian Babel patterns and the standard packages named in the TeX preamble (fontspec, geometry, amsmath/amssymb, booktabs, graphicx, float, placeins, fancyhdr, xurl, hyperref, fix-cm). It regenerates presentation files in this extracted copy, not the original source archive. The numerical entry point does not require TeX. Document checking requires `pdfinfo` and `pdftotext` (Poppler); numerical checks do not.

## Scientific conventions and limits

`rho0` is EOS rest-mass density, not epsilon/c². MB is the proper-spatial-volume integral 4π∫rho0 r²/sqrt(1−2m/r) dr, without lapse or exp(−phi). MADM includes the exterior scalar field. E_bind=(MB−MADM)c². Masses are in solar masses, radial lengths in km, EOS densities in g/cm³, pressure in dyn/cm². Tables express energies in 10^51 erg; the main curve uses 10^53 erg. The source uses Msun=1.988409870698051e30 kg and c=299792458 m/s.

All differences are Yukawa−GR. At fixed MB, ΔE=−c²ΔMADM; at fixed ADM, ΔE=c²ΔMB and the contrast measures baryon capacity. The EOS-specific GR ADM1.4 state sets the canonical common-MB target. Near-limit targets are separately 0.99 times the smaller shared causal-limit MB or ADM mass; do not mix them on one matching axis. Mathematical acausal continuations are retained in the raw CSV but excluded from the plotted comparison branches. Positive mass slope/energetic ordering does not establish dynamical stability. No emitted conversion energy, detection or discovery is claimed.

The EOS interpretation as bare epsilon(n), the coupling's empirical validity, and its physical calibration remain model assumptions. Rotation, finite temperature, EOS uncertainty and radiation are not included. Numerical sensitivities are not physical error bars or rigorous global error bounds. Historical source-method MB differences reach 1.083e-5 Msun, outside the much smaller internal tolerance/domain variation. Fine peak-window fits were not rerun in the initial a assembly; the subsequent author-supplied report reports all 18 fits reproduced. Prior archive identity is not inferred, and repeated quotations are not separate scientific findings.

## Provenance, disclosures and reuse

The supplied original ZIP is 464323 bytes with SHA-256 `4ffe19e74db5f5c9237d244dcbc0e9a1a12b1e89dd1b13c27ec5684f8e3e47fe`. Relevant original code/data are bundled unchanged; exact member mapping and fingerprints are in `metadata/source_members.csv` and `metadata/provenance.json`. The original ZIP itself is not required at runtime. Protected source packages were not edited.

Author-supplied EN disclosure: Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.

Szerzőtől kapott HU nyilatkozat: Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); nem szakmai lektorálás.

The received author-supplied report reports reproduction of 1391 configurations, six main CSV tables, 114 controls and 18 peak fits, plus rejection of six deliberate-error cases. Its stated conclusion supports the checked main claims and finds no publication-blocking scientific error within its checked scope. This attributed AI-assisted numerical report is not independent physical validation, peer review, an exhaustive priority proof or an audit of every source in the separate literature supplement. Initial local reruns and later external report are distinguished in `metadata/checking_history.json`. Distribution license: CC BY-NC 4.0 International, https://creativecommons.org/licenses/by-nc/4.0/ ; commercial use only with the author's written permission. Existing source notices remain. See LICENSE.txt.

## Contribution and literature context

Szabolcsi Dávid's contribution is the specified model's reproducible equilibrium dataset and documented, separately causal-restricted fixed-MB/fixed-ADM comparison protocol. General direct scalar–fluid coupling, binding-energy curves and the two mass-matching methods have earlier precedents cited in the articles and `metadata/related_work_sources.json`. Neither dataset nor protocol priority is proved here. The 18-source detailed literature study is delivered separately; it is not part of the scientific archive or a required run input.

The b revision changes presentation, bibliography and checking-history attribution only. All scientific data/EOS/solver files in `metadata/provenance.json` retain their a fingerprints. `validation/revision_integrity.json` records the comparison; `validation/revision_data_check.json` records the actual current integrity, first-law, mass-budget and causal-target checks. Historical validation records retain their initial-assembly scope. The ADM reference uses chapter 7 and arXiv:gr-qc/0405109 rather than an uncertain page locator.
