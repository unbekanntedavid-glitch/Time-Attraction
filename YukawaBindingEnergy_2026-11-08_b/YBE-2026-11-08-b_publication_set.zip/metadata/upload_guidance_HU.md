# Kézi közzétételi útmutató – YBE-2026-11-08-b

Ez helyi átdolgozás, nem új közzététel. Nem történt feltöltés, rekordmódosítás vagy GitHub-változtatás. A korábbi a csomag és a hozzá kapcsolódó közzétett V37 változatlan. A b nem V38 címke és még nincs saját DOI-ja.

## Zenodo: a saját korábbi YBE-rekord új verziója

- A korábbi a rekordja: https://zenodo.org/records/24053942 . Ebben a YBE-verzióláncban válaszd a saját fiókodban a **New version** lehetőséget, ne a közzétett a fájljait írd át. A Zenodo új verziója külön rekordot és verzió-DOI-t kap, a korábbi változatokhoz kapcsolva.
- A verziómezőbe a **YBE-2026-11-08-b** belső címke kerülhet. Ez nem adattári azonosító. A régi **10.5281/zenodo.24053942** csak korábbi a változatként hivatkozható; ne add meg a b meglévő DOI-jaként. Új azonosítót csak a Zenodo saját űrlapja adhat/foglalhat. A b PDF-jeiben most nincs kitalált DOI.
- A javasolt fájlkészlet: `YBE-2026-11-08-b_EN.pdf`, `YBE-2026-11-08-b_HU.pdf`, `YBE-2026-11-08-b_data_code.zip`, `YBE-2026-11-08-b_editable_sources.zip`, továbbá igény szerint a külön `YBE_literature_comparison_20261108_r1.zip`. Utóbbi önálló irodalmi melléklet, nem az adatkészlet része. Az együttes `publication_set.zip` alternatív átadási forma; nem szükséges ugyanazon tartalmat minden ZIP-ben párhuzamosan feltölteni.
- Ha korábbi fájlokat importálsz az új munkapéldányba, a régi a PDF/ZIP fájlokat ne hagyd b-ként címkézve. A `DELIVERY_MANIFEST.json` és `DELIVERY_SHA256.txt` szerinti helyi méretet és SHA256-ot ellenőrizd feltöltés előtt. A feltöltés után a letöltött fájlokat ugyanígy lehet ellenőrizni.
- A megfelelő EN/HU `metadata/description_*.txt` első sora a cím, a többi szöveg a leírás. Ugyanazon vizsgálat két nyelvi változatáról van szó, nem két független tudományos eredményről. A DOI-t említő sorok egyértelműen korábbi a változatról szólnak.
- Szerző: családnév **Szabolcsi**, utónév **Dávid**, ORCID **0009-0005-6300-074X**. A kézirat dátuma 2026-11-08; a rekord közzétételi dátumát a tényleges közzétételhez igazítsd. Nem adunk meg kitalált affiliációt, folyóirati elfogadást vagy lektorálást.
- Típus: preprintnek megfelelő kiadványtípus. Licenc: **Creative Commons Attribution Non Commercial 4.0 International / CC-BY-NC-4.0**, nem az esetleges CC BY alapbeállítás. A kötelező MI-mondatot és a jognyilatkozatot tartsd meg a leírásban.
- Kulcsszavak: neutron stars; binding energy; baryon mass; ADM mass; massive scalar; scalar–fluid coupling; Yukawa interaction; numerical reproducibility; equation of state.
- A munkapéldány mentése és előnézete után a közzétételt te indítod. Ez az útmutató nem jelent elfogadást vagy korlátlan publikációs alkalmassági igazolást.

## Academia: ugyanazon b kézirat

- Az angol PDF az elsődleges kézirat, a magyar ugyanannak nyelvi változata. A pontos cím, szerző, ORCID és belső címke egyezzen a fájllal.
- Az EN/HU leírás a megfelelő szövegfájlból másolható, az MI- és licencblokkal együtt. A kapott numerikus jelentésről beszél, nem szakmai lektorálásról. Ne jelöld accepted vagy peer-reviewed munkának.
- Adat/kód és szerkeszthető forrás csak kiegészítőként, ha a felület engedi. Máskülönben a majd valóban létrejött b Zenodo-verzió linkjét add meg; a korábbi a DOI-ja nem b-fájlhivatkozás.
- A külön irodalmi mellékletet kutatási kiegészítésként jelöld, ne új egyensúlyi eredményként. A korábbi kézirat automatikus felülírása helyett válaszd a saját szándékodnak megfelelő verziókezelést; itt a felület állapotát nem módosítottuk.

## Jognyilatkozat

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International + https://creativecommons.org/licenses/by-nc/4.0/ · commercial use only with the author's written permission.

## Hivatalos Zenodo-források, megnyitva 2026-11-08

https://help.zenodo.org/docs/deposit/manage-versions/
https://help.zenodo.org/docs/deposit/describe-records/reserve-doi/
