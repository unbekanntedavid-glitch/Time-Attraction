#!/usr/bin/env python3
"""Build bilingual TeX and tables from the unchanged CSV values; no scientific fit."""
from pathlib import Path
import pandas as pd,json,math
R=Path(__file__).resolve().parents[1];M=R/'manuscript'
c=pd.read_csv(R/'data/comparisons.csv');s=pd.read_csv(R/'data/sequence_summary.csv');v=pd.read_csv(R/'data/convergence.csv')
a=json.loads((R/'validation/reproduced_checks.json').read_text())

def sci(x):
 if x==0:return '0'
 e=math.floor(math.log10(abs(x)));return rf'{x/10**e:.3f}\times10^{{{e}}}'
def table(head,rows,caption,label,cols):
 return '\\begin{table}[htbp]\n\\centering\\small\n\\setlength{\\tabcolsep}{4pt}\n\\begin{tabular}{'+cols+'}\\toprule\n'+head+' \\\\ \\midrule\n'+'\n'.join(' & '.join(row)+' \\\\' for row in rows)+'\n\\bottomrule\\end{tabular}\n\\caption{'+caption+'}\\label{'+label+'}\n\\end{table}\n'
for lang in ['EN','HU']:
 hu=lang=='HU';can=[];near=[];limits=[];val=[]
 for name in ['SLy','APR4','H4']:
  for L in [1.,10.]:
   fixedA=c[(c.EOS==name)&(c.L_km==L)&(c.contrast=='common_ADM_1p4')].iloc[0]
   fixedB=c[(c.EOS==name)&(c.L_km==L)&(c.contrast=='common_MB_GR1p4')].iloc[0]
   can.append([name,f'{L:g}',f'{fixedB.target_Msun:.6f}',f'{fixedA.GR_Ebind_1e51erg:.3f}',f'{fixedA.delta_Ebind_1e51erg:.3f}',f'{fixedB.delta_Ebind_1e51erg:.3f}',f'{fixedA.delta_MB_Msun*1000:.3f}'])
   x=c[(c.EOS==name)&(c.L_km==L)&(c.contrast=='common_ADM_near_limit')].iloc[0];y=c[(c.EOS==name)&(c.L_km==L)&(c.contrast=='common_MB_near_limit')].iloc[0]
   near.append([name,f'{L:g}',f'{x.target_Msun:.6f}',f'{x.delta_Ebind_1e51erg:.3f}',f'{y.target_Msun:.6f}',f'{y.delta_Ebind_1e51erg:.3f}'])
  for q in s[s.EOS==name].itertuples():
   reason=('kauzalitás' if hu else 'causality') if q.limit_reason=='causality' else ('ADM-csúcs' if hu else 'ADM peak')
   limits.append([name,f'{q.L_km:g}',f'{q.logrho_candidate_supremum:.6f}',f'{q.candidate_supremum_ADM_Msun:.6f}',f'{q.candidate_supremum_MB_Msun:.6f}',reason])
 names={'short_domain':('12L külső tartomány' if hu else 'Exterior extent 12L'),'long_domain':('24L külső tartomány' if hu else 'Exterior extent 24L'),'tight_tol':('Szigorított Yukawa-tolerancia' if hu else 'Tighter Yukawa tolerance'),'tight_ivp':('Szigorított GR-kontroll' if hu else 'Tighter GR control'),'endpoint_tight':('Ághatár/csúcs: szigorított tolerancia' if hu else 'Branch limit/peak: tighter tolerance')}
 for key in ['short_domain','long_domain','tight_tol','tight_ivp','endpoint_tight']:
  g=v[v.test==key]
  val.append([names[key],str(len(g)), '$'+sci(g.delta_ADM_Msun.abs().max())+'$', '$'+sci(g.delta_MB_Msun.abs().max())+'$', '$'+sci(g.delta_Ebind_1e51erg.abs().max())+'$'])
 canon_caption=(r'Kanonikus összehasonlítások: $\alpha_Y=1$, Yukawa és azonos EOS-ú GR-kontroll. Minden energia $10^{51}$ erg egységű; $L$ km-ben. $M_{B,0}$ az adott EOS GR-állapotának bariontömege $M_{\rm ADM}=1{,}4M_\odot$ mellett, naptömegben. $E_{\rm GR,0}$ ugyanennek az állapotnak az energiája. A két $\Delta E$ oszlop külön konfigurációpárokra vonatkozik; minden különbség Yukawa mínusz GR. Az utolsó oszlop közös ADM mellett értendő, $10^{-3}M_\odot$ egységben.' if hu else r'Canonical contrasts; $\alpha_Y=1$, Yukawa versus the same-EOS GR control. Energies are in $10^{51}$ erg and $L$ in km. $M_{B,0}$ is the baryon mass, in solar masses, of the EOS-specific GR state with $M_{\rm ADM}=1.4M_\odot$; $E_{\rm GR,0}$ is the GR reference energy. The two $\Delta E$ columns refer to different configuration pairs; all differences are Yukawa minus GR. The last column is the fixed-ADM baryon excess in $10^{-3}M_\odot$.')
 near_caption=(r'A kauzális ághatárhoz közeli célok és kontrasztok: $\alpha_Y=1$, Yukawa és azonos EOS-ú GR. A tömegcélok naptömegben, az energiák $10^{51}$ erg-ben; $L$ km-ben. Az ADM- és MB-cél külön a két sorozat közösen elérhető megfelelő határtömegének 99\%-a. Nem az eltérő saját végpontokat vonjuk ki egymásból.' if hu else r'Near-limit targets and contrasts; $\alpha_Y=1$, Yukawa versus same-EOS GR. Target masses are in solar masses, energies in $10^{51}$ erg, and $L$ in km. Each ADM or MB target is separately 99\% of the corresponding smaller, jointly reachable causal branch-limit mass. Different individual endpoints are not subtracted as if they were matched states.')
 limit_caption=(r'Kauzális emelkedő ághatárok, nem igazolt stabil maximális tömegek. $L=0$ a GR-kontroll; $L$ km-ben, a tömegek naptömegben. A sűrűségoszlop $\log_{10}[\rho_{0c}/(\mathrm{g\,cm^{-3}})]$. A korlátozatlan ADM-csúcs és az első kauzalitási határ közül a korábbi határoz.' if hu else r'Causal first-rising branch limits, not established stable maximum masses. $L=0$ denotes GR; $L$ is in km and masses are in solar masses. Density is $\log_{10}[\rho_{0c}/(\mathrm{g\,cm^{-3}})]$. The earlier of the unconstrained ADM peak and first causal onset sets the limit.')
 val_caption=(r'Pontbeli numerikus érzékenység a tárolt kontrollokból; a 114 változatot újrafuttattuk. A tömegoszlopok naptömegben, az energia $10^{51}$ erg-ben. A kiinduló külső tartomány 18L. Ezek nem fizikai hibasávok vagy szigorú hibakorlátok.' if hu else r'Pointwise numerical sensitivity from the supplied control tables; all 114 variants were re-executed. Mass columns are in solar masses and energy in $10^{51}$ erg. The baseline exterior extent is 18L. These are not physical uncertainty intervals or rigorous error bounds.')
 tables=table(r'EOS & $L$ & $M_{B,0}$ & $E_{\rm GR,0}$ & $\Delta E|_{\rm ADM}$ & $\Delta E|_{B}$ & $\Delta M_B|_{\rm ADM}$',can,canon_caption,'tab:canonical','lrrrrrr')
 tables+=table(r'EOS & $L$ & $M_{\rm ADM}^{*}$ & $\Delta E|_{\rm ADM}$ & $M_B^{*}$ & $\Delta E|_{B}$',near,near_caption,'tab:near','lrrrrr')
 (M/f'tables_results_{lang}.tex').write_text(tables)
 (M/f'table_limits_{lang}.tex').write_text(table(r'EOS & $L$ & $\log_{10}\rho_{0c}$ & $M_{\rm ADM,lim}$ & $M_{B,\rm lim}$ & '+('Korlát' if hu else 'Limit'),limits,limit_caption,'tab:limits','lrrrrl'))
 (M/f'table_validation_{lang}.tex').write_text(table(('Kontroll' if hu else 'Control')+r' & $N$ & $\max|\delta M_{\rm ADM}|$ & $\max|\delta M_B|$ & $\max|\delta E|$',val,val_caption,'tab:validation','lrrrr'))

preamble=r'''\RequirePackage{fix-cm}
\documentclass[10pt,a4paper]{article}
\usepackage{fontspec}
\setmainfont{Liberation Serif}
\setsansfont{DejaVu Sans}
\setmonofont{DejaVu Sans Mono}[Scale=.84]
\usepackage[margin=21mm,bottom=30mm,top=19mm,headheight=15pt,footskip=20mm]{geometry}
\usepackage{amsmath,amssymb,booktabs,graphicx,float,placeins,fancyhdr,xurl}
\usepackage[colorlinks=true,linkcolor=black,citecolor=black,urlcolor=blue]{hyperref}
\setlength{\parindent}{0pt}\setlength{\parskip}{4.5pt}
\setlength{\emergencystretch}{2em}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\scriptsize YBE-2026-11-08-b}
\fancyhead[R]{\scriptsize Szabolcsi Dávid}
\fancyfoot[C]{\parbox{\textwidth}{\centering\fontsize{6.1}{7.4}\selectfont\addfontfeatures{Ligatures=TeXOff}
© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International\\
+ \url{https://creativecommons.org/licenses/by-nc/4.0/} · commercial use only with the author\char"0027s written permission.\\[2pt]\thepage}}
\renewcommand{\headrulewidth}{.25pt}\renewcommand{\footrulewidth}{.25pt}
\fancypagestyle{plain}{\fancyhf{}\fancyfoot[C]{\parbox{\textwidth}{\centering\fontsize{6.1}{7.4}\selectfont\addfontfeatures{Ligatures=TeXOff}
© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International\\
+ \url{https://creativecommons.org/licenses/by-nc/4.0/} · commercial use only with the author\char"0027s written permission.\\[2pt]\thepage}}}
\newcommand{\Ms}{M_\odot}\newcommand{\MB}{M_B}\newcommand{\MA}{M_{\rm ADM}}
\newcommand{\eps}{\varepsilon}\newcommand{\Eb}{E_{\rm bind}}
\newcommand{\aistatement}[1]{{\hyphenpenalty=10000\exhyphenpenalty=10000 #1\par}}
'''
model=r'''\begin{equation}
S=\int d^4x\sqrt{-g}\left[\frac{\mathcal R}{16\pi}-\frac{(\nabla\phi)^2+\phi^2/L^2}{2\alpha_Y}-e^{-\phi}\eps(n)\right].\label{eq:action}
\end{equation}
\begin{equation}
ds^2=-e^{2\nu}dt^2+B^{-1}dr^2+r^2d\Omega^2,\qquad B=1-2m/r.\label{eq:metric}
\end{equation}
\begin{align}
\tilde\eps&=e^{-\phi}\eps,&\tilde P&=e^{-\phi}P,\\
\rho_\phi&=\frac{B\phi'^2+\phi^2/L^2}{2\alpha_Y},& p_{r\phi}&=\frac{B\phi'^2-\phi^2/L^2}{2\alpha_Y},\\
m'&=4\pi r^2(\tilde\eps+\rho_\phi),&\nu'&=\frac{m+4\pi r^3(\tilde P+p_{r\phi})}{r^2B},\\
h'&=-\nu'+\phi',&h&=\ln\frac{\eps+P}{\rho_0c^2},\label{eq:equilibrium}\\
B\phi''+\left(\frac{2B}{r}+B\nu'+\frac{B'}2\right)\phi'-\frac{\phi}{L^2}&=-\alpha_Y\tilde\eps.\label{eq:scalar}
\end{align}
'''
equations=r'''\begin{equation}
P/c^2=k_i\rho_0^{\Gamma_i},\qquad \eps/c^2=(1+a_i)\rho_0+\frac{P/c^2}{\Gamma_i-1},\qquad
P=n\frac{d\eps}{dn}-\eps.\label{eq:eos}
\end{equation}
\begin{equation}
\MB=4\pi\int_0^R\frac{\rho_0(r)r^2}{\sqrt{1-2m(r)/r}}\,dr,\qquad
\MA=\lim_{r\to\infty}m(r),\qquad \Eb=(\MB-\MA)c^2.\label{eq:energy}
\end{equation}
'''
bib=r'''\begin{thebibliography}{99}\small
\bibitem{OV1939} J. R. Oppenheimer and G. M. Volkoff, ``On Massive Neutron Cores,'' \textit{Phys. Rev.} \textbf{55}, 374 (1939). \url{https://doi.org/10.1103/PhysRev.55.374}.
\bibitem{Read2009} J. S. Read, B. D. Lackey, B. J. Owen and J. L. Friedman, ``Constraints on a phenomenologically parametrized neutron-star equation of state,'' \textit{Phys. Rev. D} \textbf{79}, 124032 (2009). \url{https://doi.org/10.1103/PhysRevD.79.124032}; arXiv:0812.2163.
\bibitem{ADM} R. Arnowitt, S. Deser and C. W. Misner, ``The Dynamics of General Relativity,'' in \textit{Gravitation: An Introduction to Current Research}, edited by L. Witten (Wiley, 1962), chapter 7; accessible republication, arXiv:gr-qc/0405109. \url{https://arxiv.org/abs/gr-qc/0405109}.

\bibitem{FAD2013} V. Folomeev, A. Aringazin and V. Dzhunushaliev, ``Chameleon dark matter stars,'' \textit{Phys. Rev. D} \textbf{88}, 063005 (2013). \url{https://doi.org/10.1103/PhysRevD.88.063005}; arXiv:1305.1087.
\bibitem{BTW2015} C. G. Böhmer, N. Tamanini and M. Wright, ``Interacting quintessence from a variational approach. I. Algebraic couplings,'' \textit{Phys. Rev. D} \textbf{91}, 123002 (2015). \url{https://doi.org/10.1103/PhysRevD.91.123002}; arXiv:1501.06540.
\bibitem{MS2016} M. Minamitsuji and H. O. Silva, ``Relativistic stars in scalar-tensor theories with disformal coupling,'' \textit{Phys. Rev. D} \textbf{93}, 124041 (2016). \url{https://doi.org/10.1103/PhysRevD.93.124041}; arXiv:1604.07742.
\bibitem{RP2016} F. M. Ramazanoğlu and F. Pretorius, ``Spontaneous scalarization with massive fields,'' \textit{Phys. Rev. D} \textbf{93}, 064005 (2016). \url{https://doi.org/10.1103/PhysRevD.93.064005}; arXiv:1601.07475.
\bibitem{RM2020} R. Rosca-Mead, C. J. Moore, U. Sperhake, M. Agathos and D. Gerosa, ``Structure of Neutron Stars in Massive Scalar-Tensor Gravity,'' \textit{Symmetry} \textbf{12}, 1384 (2020). \url{https://doi.org/10.3390/sym12091384}; arXiv:2007.14429.
\bibitem{UTYR2025} K. İ. Ünlütürk, S. Tuna, O. K. Yamak and F. M. Ramazanoğlu, ``Nature of Phase Transitions and Metastability in Scalar-Tensor Theories,'' \textit{Phys. Rev. Lett.} \textbf{135}, 061401 (2025). \url{https://doi.org/10.1103/14xz-d7xf}; arXiv:2502.01781v2.
\end{thebibliography}
'''
EN=r'''\title{Equilibrium binding energy at fixed baryon and ADM mass in a local massive-scalar neutron-star model}
\author{Szabolcsi Dávid\\\small ORCID: \href{https://orcid.org/0009-0005-6300-074X}{0009-0005-6300-074X}}
\date{8 November 2026 · YBE-2026-11-08-b}
\begin{document}\maketitle\thispagestyle{fancy}
\begin{center}\small\textbf{Revised manuscript; not peer reviewed.}\end{center}
\begin{abstract}
We compare the equilibrium binding energy $\Eb=(\MB-\MA)c^2$ in a local massive-scalar fluid model and its scalar-free general-relativistic control. The unchanged SLy, APR4 and H4 piecewise-polytropic equations of state (EOSs) are used with $\alpha_Y=1$ and ranges $L=1$ and $10$ km. Baryon mass is integrated over proper spatial volume; ADM mass includes the exterior scalar energy. Equal-baryon-mass and equal-ADM-mass comparisons are explicitly separated. At the EOS-specific baryon mass of the GR configuration with ADM mass $1.4\Ms$, the $L=10$ km Yukawa-minus-GR binding-energy excess is $10.850$, $11.233$ and $8.443\times10^{51}$ erg, respectively. At equal ADM mass, the contrast instead measures the baryon-mass excess. Near-limit comparisons use 99\% of the smaller jointly accessible causal first-rising branch limit. All 24 matched pairs satisfy this selection. The contribution is Szabolcsi Dávid's reproducible dataset for this specified model and its documented comparison protocol, not a new general scalar--fluid coupling or binding-energy method. The original assembly re-executed 114 pointwise numerical controls; a subsequently supplied AI-assisted report also reports reproduction of all 1391 configurations and 18 local peak fits. These are model-dependent equilibrium diagnostics, not a proof of priority, physical model validity, dynamical stability, observability or energy emitted in a conversion.
\end{abstract}
\section{Question and model}
Binding energy can compare the energy budgets of stellar equilibria, provided the baryon and gravitational masses have compatible definitions. GR hydrostatic equilibria provide a control \cite{OV1939}; a scalar field outside the matter surface requires an asymptotic mass definition \cite{ADM}. Here the question is not whether a new stellar population has been detected, but how two distinct mass-matching prescriptions change the interpretation of a computed energy contrast.

We adopt the following phenomenological local action, rather than deriving a coupling from an experimental source fit. Throughout the field equations, $G=c=1$ and lengths are in km; $c$ is restored in energy conversions. The fluid number density $n$ is defined using $g_{\mu\nu}$, with the conserved current $\nabla_\mu(nu^\mu)=0$, and $\rho_0=m_Bn$ is the EOS rest-mass density.
''' + model+r'''
The scalar equation is sourced by $e^{-\phi}\eps$, not by a matter trace containing a $3P$ term. This is a specific assumed scalar--fluid model, not an identification with every trace-coupled scalar--tensor theory. The scalar-free GR control is solved separately with the same EOS. Applying the coupling to the bare tabulated $\eps(n)$ is a modelling assumption whose physical interpretation remains open.

\section{Related work and specific contribution}
Direct scalar--fluid coupling is not introduced here. Folomeev et al. already studied compact stars with $f(\phi)L_m$, $L_m=-\eps$, an exponential $f$ and an energy-density scalar source \cite{FAD2013}, Eqs.~(1), (6), (7), (14). Their dark-fermion EOS, inverse-power potential, background and reported surface mass differ from the present choices. The conserved-fluid algebraic-coupling framework of Böhmer et al. \cite{BTW2015}, Eqs.~(24)--(27), (34)--(35), (46)--(47), contains this coupling family. These precedents preclude a claim to a new general coupling formalism.

Binding-energy diagrams versus baryon mass and fixed-baryon energy comparisons also have explicit precedents: Fig.~6 and Table~I of Ref.~\cite{MS2016}, and the massive-scalar example in Fig.~2 of Ref.~\cite{UTYR2025}. Fixed-ADM baryon-content comparisons occur in Fig.~1 of Ref.~\cite{RP2016}. Exterior scalar-field treatment and fixed-baryon ADM comparisons are central to Ref.~\cite{RM2020}, Sections~3 and 4.5. These methods are not new contributions of the present study.

The present source $e^{-\phi}\eps(n)$ is not generically the trace source of conformal $S_m[A^2g,\Psi]$ theories. With consistent density conventions, conformal fluid energy has the form $A^4\tilde\eps(n_E/A^3)$, not in general $f\eps(n_E)$. Couplings and EOSs cannot therefore be equated by their names. Here $L$ is the inverse vacuum mass (exponential decay length), whereas Ref.~\cite{RP2016} defines the Compton wavelength as $2\pi/m_\phi$. The action's $G=c=1$ convention is not by itself an empirical calibration of this phenomenological coupling.

Szabolcsi Dávid's contribution is the reproducible equilibrium dataset for the stated exponential bare-energy coupling, quadratic potential, unchanged SLy/APR4/H4 fits, $\alpha_Y=1$ and $L=1,10$ km, together with documented, separately causal-restricted fixed-$\MB$ and fixed-$\MA$ comparisons. Neither the dataset's priority nor priority of the detailed protocol is proved by the targeted literature search. A separate detailed literature supplement accompanies the revision; it is not part of the numerical data or a claim of exhaustive review.

\section{EOS, mass definitions and numerical construction}
The supplied implementation uses the Read et al. piecewise-polytropic representation \cite{Read2009}: SLy, APR4 (the AP4 parametrization in that reference) and H4, with an SLy crust. The core division densities are $10^{14.7}$ and $10^{15}$ g\,cm$^{-3}$. The fitted parameters $(\log_{10}P_1,\Gamma_1,\Gamma_2,\Gamma_3)$ are $(34.384,3.005,2.988,2.851)$, $(34.269,2.830,3.445,3.348)$ and $(34.669,2.909,2.246,2.144)$, respectively, with $P_1$ in dyn\,cm$^{-2}$. Energy integration constants enforce continuity:
''' + equations+r'''
In Eq.~\eqref{eq:energy}, the mass integral is expressed in the geometric units of Eq.~\eqref{eq:metric}; the code converts cgs rest density to km$^{-2}$ before integrating. The cold first law and $\eps/(\rho_0c^2)\to1$ at low density fix the rest-mass convention. No arbitrary energy-density-to-baryon-density conversion is used. There is no lapse or $e^{-\phi}$ multiplier in $\MB$: those would change the conserved-baryon measure of this model. An absolute microscopic baryon count is not inferred beyond the EOS convention.

The matter surface is $h(R)=0$. $m(R)$ is not substituted for $\MA$, since the scalar exterior contributes positive energy. An interior and an exterior domain are solved simultaneously by nonlinear collocation, with a regular central expansion at $r_0=10^{-5}$ km, continuous $m,\nu,\phi,\phi'$ at the fluid surface, and no surface shell. The outer radius is $r_{\rm out}=R+18L$. The finite-domain conditions are
\begin{equation}
\phi'/\phi=-1/L-(1+m_{\rm out}/L)/r_{\rm out},\qquad
\nu_{\rm out}=\tfrac12\ln(1-2m_{\rm out}/r_{\rm out}).
\end{equation}
They approximate the decaying massive-scalar solution and $\nu(\infty)=0$. Reported ADM masses are the finite-domain approximants whose sensitivity to 12L/24L is tested below. The baseline collocation residual tolerance is $2\times10^{-7}$, with boundary tolerance at most $10^{-10}$ and at most 22000 nodes. GR has a separate scalar-free collocation system and an independent enthalpy-IVP control. Baryon quadratures use 48 and 96 Gauss--Legendre nodes separately in each EOS segment; the regular central volume is included.

Each of nine sequences has 89 fixed central-density points, $14.55\leq\log_{10}[\rho_{0c}/(\mathrm{g\,cm^{-3}})]\leq15.65$, spaced by 0.0125 dex. Stored peak searches, direct mass roots and derivative checks bring the archive to 1391 configurations. No equation, EOS parameter or numerical tolerance was adjusted to improve the reported contrasts. The source constants are $M_\odot=1.988409870698051\times10^{30}$ kg and $c=299792458$ m\,s$^{-1}$; $M_\odot c^2=1.787093668741279\times10^{54}$ erg.

\section{One energy analysis, two matching prescriptions}
Causality is imposed on the unchanged fitted EOS as $\max_r(dP/d\eps)\leq1$, including both sides of EOS junctions. Numerical comparisons use a roundoff allowance of $10^{-10}$ in this dimensionless test, not an EOS-uncertainty relaxation. The selected interval ends at the earlier of the first ADM peak and first causal onset. An increasing mass is a branch-selection condition, not a demonstrated stable branch. Baryon mass is checked to be monotone on this interval.

We use four contrasts for each EOS/range pair: common $\MA=1.4\Ms$; common $\MB$ equal to the EOS-specific GR $1.4\Ms$ state's baryon mass; and two separate near-limit targets at 99\% of the smaller GR/Yukawa causal branch-limit ADM or baryon mass. All targets are obtained by re-solving equilibria and root-finding within that branch, without cross-fold interpolation or extrapolation. The exact pair-specific targets are in Tables~\ref{tab:canonical}--\ref{tab:near}.
\begin{equation}
\left.\Delta\Eb\right|_{\MB}=-c^2\Delta\MA,\qquad
\left.\Delta\Eb\right|_{\MA}=c^2\Delta\MB,\label{eq:contrasts}
\end{equation}
where $\Delta$ means Yukawa minus GR. Thus a fixed-$\MB$ positive contrast means a lower ADM energy; a fixed-$\MA$ contrast measures a greater baryon capacity. These are complementary summaries of the same equilibrium-energy finding, not two independent discoveries. Nor is a GR-to-different-coupling comparison an allowed physical transition by itself.

\begin{figure}[htbp]\centering
\includegraphics[width=\textwidth]{../figures/energy_vs_MB_EN.png}
\caption{Binding energy versus baryon mass. Only the causal first-rising portions and their limiting points are plotted. Curves connect computed grid points; open circles denote branch limits, not stability labels. H4 begins at a larger baryon mass because the same central-density grid is used.}\label{fig:energy}
\end{figure}
\input{tables_results_EN.tex}

For $\alpha_Y=1$, relative to GR and in SLy/APR4/H4 order, the $L=1$ km canonical fixed-$\MB$ excess is $0.424$, $0.454$ and $0.277\times10^{51}$ erg for SLy/APR4/H4. For $L=10$ km it is $10.850$, $11.233$ and $8.443\times10^{51}$ erg. At common ADM $1.4\Ms$, the corresponding $L=10$ km baryon excess is $0.007612$, $0.007954$ and $0.005670\Ms$. The baryon-mass reference is EOS dependent and is not a universal $1.5\Ms$ target.

For $\alpha_Y=1$, SLy/APR4/H4 in that order, at the matched near-limit baryon targets of Table~\ref{tab:near}, the $L=10$ km Yukawa-minus-GR energy contrasts are $21.516$, $20.839$ and $18.137\times10^{51}$ erg. Equal-ADM near-limit contrasts are different pairs, with energy differences $32.543$, $31.198$ and $24.514\times10^{51}$ erg. They should not be pooled as repeated measurements of one universal conversion energy.
\input{table_limits_EN.tex}

All H4 ADM peaks are causal ($c_s^2/c^2=0.515838$, $0.516312$, $0.529803$ for GR, 1 km and 10 km). Both SLy Yukawa peaks and all APR4 peaks are acausal and are retained only as mathematical continuations in the CSV. The SLy GR peak remains just causal ($0.999774$). The greatest $c_s^2/c^2$ among actual pair members is $0.976933$.

\begin{figure}[htbp]\centering
\includegraphics[width=.94\textwidth]{../figures/mass_matching_contrasts_EN.png}
\caption{Mass matching changes the question. Left: energy at common baryon mass. Right: baryon capacity at common ADM mass, with a different vertical unit. The lower panels use separately defined 99\% common causal-limit targets; the two columns do not select the same states.}\label{fig:matches}
\end{figure}
\FloatBarrier
\section{Numerical checks and their scope}
All supplied input hashes, mass-budget identities and energy identities were checked. The 1391 sound-speed flags were recomputed from the EOS, and all 24 target pairs were verified to remain below the applicable causal branch limit. The maximum direct mass-target residual is $1.124\times10^{-10}\Ms$.

All 114 archived pointwise control variants were re-executed using 58 distinct baseline densities. For Yukawa configurations, the exterior is shortened from 18L to 12L or extended to 24L, and the collocation tolerance is tightened from $2\times10^{-7}$ to $5\times10^{-8}$. GR-IVP relative tolerances are tightened from $2\times10^{-12}$ to $2\times10^{-13}$, also triggering tighter GR collocation. Own endpoint/peak configurations have separate tolerance tests.
\input{table_validation_EN.tex}

Domain changes alone shift ADM mass by at most $4.823\times10^{-12}\Ms$; the largest shift including endpoint/tolerance controls is $1.817\times10^{-10}\Ms$. Reproduced ADM changes differ from their stored values by at most $2.502\times10^{-12}\Ms$. An additional quadrature of exterior scalar energy on the re-solved profiles agrees with $\MA-m(R)$ to $6.526\times10^{-12}\Ms$. These test finite-domain dependence at the selected points; they are not rigorous bounds over all densities and parameters.

The supplied 48/96-point baryon quadrature difference is at most $5.540\times10^{-12}\Ms$. Independent first-law checks in native enthalpy coordinates give a largest relative finite-difference residual of $3.516\times10^{-10}$. The archived sequence-slope diagnostic $d\MA/d\MB=e^{\nu_R-\phi_R}$ has residual at most $2.941\times10^{-6}$; it is not a mode calculation. A coarser/finer branch-only interpolation check gives maximum energy offsets from direct roots of $0.099695$ and $0.013642\times10^{51}$ erg, so tabulated contrasts use direct roots rather than these interpolants.

For each control perturbation, the empirical fixed-target diagnostic uses a linear projection back to the target:
\begin{equation}
\delta E_t=\delta E-\frac{dE/d\ell}{dM_t/d\ell}\,\delta M_t,\qquad \ell=\log_{10}\rho_{0c}.
\end{equation}
Here $M_t$ is the chosen matching mass and $\ell$ denotes the tabulated logarithmic density. The largest tested absolute projected changes of both pair members are summed, together with their quadrature shifts. Its maximum is $1.003\times10^{-6}\times10^{51}$ erg. This diagnostic is not a confidence interval. Fine local peak-fit outputs have stored position changes up to $1.102\times10^{-6}$ dex and mass changes up to $1.818\times10^{-10}\Ms$. They were archived-only in the initial a assembly; the subsequently supplied Academia Co-scientist report reports reproduction of all 18 fits, as distinguished below from the original local reruns. The historical comparison against another source discretization has a baryon-mass discrepancy up to $1.083\times10^{-5}\Ms$, outside the smaller internal collocation sensitivity; it is not assigned to a single error mechanism.

\section{Interpretation and limitations}
The useful result is Szabolcsi Dávid's model-specific dataset and documented application of established comparison methods. For the reported SLy/APR4/H4 pairs with $\alpha_Y=1$, relative to the same-EOS GR control, the fixed-$\MB$ energy contrast is positive at the explicitly tabulated targets; for $L=10$ km it grows between each EOS-specific canonical target and its selected near-limit target. This is neither a new general method nor a claim of a new physical theory, stellar phase or population. No priority proof follows from reproducibility.

The physical identification of the tabulated EOS with the bare $\eps(n)$ in Eq.~\eqref{eq:action}, the motivation and empirical validity of the coupling, and the interpretation of clocks/rods made of field-dependent matter remain open. Rotation, temperature, EOS uncertainty and radiation are not modelled or assigned uncertainty intervals. No coupled fluid--scalar perturbation problem or evolution was solved. Equal baryon mass between distinct theories does not specify initial/later states within one dynamical theory and cannot by itself predict emitted neutrino, scalar or gravitational-wave energy. 

Observability is a separate question: it would require a named measurable quantity (for example mass and radius or tidal deformability), a measurement-and-theory uncertainty budget, and separation of EOS/coupling/range degeneracies. A conserved-baryon target is not itself a directly measured baryon mass. No such observational inference is performed here.

\section{Data, reproducibility and disclosure}
The accompanying package contains the unchanged numerical inputs and production code, bilingual editable TeX, figures, and \texttt{reproduce.py}. Primary values come from \path{data/comparisons.csv}; limits from \path{data/sequence_summary.csv}; numerical sensitivity from \path{data/convergence.csv} and the reproduced control tables. No remote input is required. Internal revision YBE-2026-11-08-b has no assigned DOI and is not a published record identifier. The earlier published a package is identified by \url{https://doi.org/10.5281/zenodo.24053942}; that DOI is not assigned to b. Identity of older archives is not inferred. Scientific inputs and solver/EOS sources are byte-identical to a; only presentation, bibliography and checking-status attribution are revised.

The source archive has SHA-256
\begin{quote}\small\url{4ffe19e74db5f5c9237d244dcbc0e9a1a12b1e89dd1b13c27ec5684f8e3e47fe}.\end{quote}
Required-input hashes and their relative paths are in \path{metadata/provenance.json}. Re-execution reproduces the supplied algorithm; it is not independent physical validation or peer review.

\aistatement{\textbf{Author-supplied disclosure:} Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.}
The initial a assembly locally re-executed the 114 pointwise controls and integrity/thermodynamic checks, but did not regenerate the entire 1391-state archive or refit the 18 local peaks. The author's subsequently supplied Academia Co-scientist report now reports reproduction of all 1391 configurations, agreement of six main CSV tables, all 114 controls and 18 peak fits, and rejection of six deliberately corrupted cases. According to that report, the checked main claims are supported and no publication-blocking scientific error was found within its checked scope. This is an attributed AI-assisted numerical report, not independent physical validation, exhaustive literature-priority proof or an audit of every source in the separate 18-source supplement. This b revision reruns strict integrity and numerical-consistency checks without changing or retuning scientific code; no new simulations are needed for its prose-only revisions.

\textbf{Conclusion.} For the tabulated targets with SLy/APR4/H4, $\alpha_Y=1$ and $L=1,10$ km, relative to the same-EOS GR control, matched baryon mass gives lower ADM energy, while separately matched ADM mass gives greater baryon capacity. The contribution is this specified model's reproducible equilibrium dataset and documented comparison protocol, with causal selection and exterior scalar energy retained. It is one conditional energy analysis, not a new general coupling or binding-energy methodology, a priority proof, or evidence of physical validity, stability, observability or released conversion energy.
''' +bib+r'\end{document}'
HU=r'''\title{Egyensúlyi kötési energia rögzített barion- és ADM-tömegnél lokális tömeges skalármezős neutroncsillagmodellben}
\author{Szabolcsi Dávid\\\small ORCID: \href{https://orcid.org/0009-0005-6300-074X}{0009-0005-6300-074X}}
\date{2026. november 8. · YBE-2026-11-08-b}
\begin{document}\maketitle\thispagestyle{fancy}
\begin{center}\small\textbf{Átdolgozott kézirat; nem szakmailag lektorált közlemény.}\end{center}
\begin{abstract}
Az $\Eb=(\MB-\MA)c^2$ egyensúlyi kötési energiát lokális tömeges skalármezős folyadékmodellben és annak skalármentes általános relativitáselméleti kontrolljában hasonlítjuk össze. A változatlan SLy, APR4 és H4 szakaszonkénti politrop állapotegyenleteket (EOS) használjuk, $\alpha_Y=1$ és $L=1$, illetve 10 km mellett. A bariontömeget saját térfogaton integráljuk; az ADM-tömeg a külső skalárenergiát is tartalmazza. Az azonos bariontömegű és az azonos ADM-tömegű összevetéseket elkülönítjük. A GR-kontroll $1{,}4\Ms$ ADM-tömegű állapotának EOS-specifikus bariontömegénél az $L=10$ km-es Yukawa mínusz GR kötésienergia-többlet rendre $10{,}850$, $11{,}233$ és $8{,}443\times10^{51}$ erg. Azonos ADM-tömegnél a kontraszt ehelyett barionkapacitás-különbséget mér. A határközeli célok a közösen elérhető kauzális emelkedő ág megfelelő határtömegének 99\%-ai. Mind a 24 pár megfelel ennek a kiválasztásnak. Szabolcsi Dávid hozzájárulása e konkrét modell reprodukálható adatkészlete és dokumentált összehasonlítási protokollja, nem új általános skalár--folyadék csatolás vagy kötésienergia-módszer. Az eredeti összeállításkor 114 pontbeli kontrollt futtattunk újra; a később kapott MI-alapú jelentés az 1391 konfiguráció és 18 lokális csúcsillesztés reprodukciójáról is beszámol. Az eredmény modellfüggő egyensúlyi diagnosztika, nem elsőségi, fizikai modellhelyességi, stabilitási, megfigyelhetőségi vagy energiakibocsátási bizonyíték.
\end{abstract}
\section{Kérdés és modell}
A kötési energia akkor alkalmas csillagegyensúlyok energiamérlegének összevetésére, ha a barion- és gravitációs tömeg definíciója összhangban van. A relativisztikus hidrosztatikai egyensúly kontrollt ad \cite{OV1939}; az anyagfelszínen kívüli skalármező miatt aszimptotikus tömegdefiníció szükséges \cite{ADM}. Itt nem új csillagpopuláció megfigyelése a kérdés, hanem az, hogy két különböző tömegillesztés miként változtatja meg ugyanazon számított energiakontraszt értelmét.

Az alábbi fenomenologikus lokális hatást feltételezzük; a csatolást nem kísérleti forrásillesztésből vezetjük le. A téregyenletekben $G=c=1$, a hosszegység km; az energiaátváltásban visszaállítjuk $c$-t. Az $n$ számosságsűrűséget a $g_{\mu\nu}$ metrikával definiáljuk, a $\nabla_\mu(nu^\mu)=0$ megmaradó áramot feltételezve; az EOS nyugalmi tömegsűrűsége $\rho_0=m_Bn$.
''' +model+r'''
A skaláregyenlet forrása $e^{-\phi}\eps$, nem a $3P$ tagot is tartalmazó anyagi nyom. Ez meghatározott skalár--folyadék modellfeltevés, nem tetszőleges nyomcsatolt skalár--tenzor elmélet azonosítása. A skalármentes GR-kontrollt ugyanazzal az EOS-szal, külön oldjuk meg. A csatolás alkalmazása a tabulált bare $\eps(n)$-re modellfeltevés, amelynek fizikai értelmezése nyitott.

\section{Irodalmi előzmények és konkrét hozzájárulás}
A közvetlen skalár--folyadék csatolást nem itt vezetjük be. Folomeev és munkatársai már vizsgáltak $f(\phi)L_m$, $L_m=-\eps$ csatolású kompakt csillagokat, exponenciális $f$-fel és energiasűrűség-forrással \cite{FAD2013}, (1), (6), (7), (14). Sötét fermionos EOS-uk, inverz hatványpotenciáljuk, hátterük és közölt felszíni tömegük eltér az itt választottaktól. Böhmer és munkatársai megőrzött folyadékú algebrai csatolási kerete \cite{BTW2015}, (24)--(27), (34)--(35), (46)--(47) tartalmazza ezt a csatoláscsaládot. Új általános csatolási formalizmust ezért nem állítunk.

A bariontömeg szerinti kötésdiagramnak és a közös bariontömegű energetikai összevetésnek is vannak kifejezett előzményei: \cite{MS2016}, 6.~ábra és I.~táblázat; tömeges skalárnál \cite{UTYR2025}, 2.~ábra. Közös ADM melletti bariontartalom-összevetés szerepel \cite{RP2016} 1.~ábráján. A külső skalármező kezelése és a közös bariontömegű ADM-összevetés lényeges része a \cite{RM2020} munka 3. és 4.5.~szakaszának. Ezeket a módszereket nem e tanulmány vezeti be.

Az itteni $e^{-\phi}\eps(n)$ forrás általában nem azonos a konformális $S_m[A^2g,\Psi]$ elméletek nyomforrásával. Következetes sűrűségkonvencióval a konformális folyadék energiája $A^4\tilde\eps(n_E/A^3)$ alakú, nem általában $f\eps(n_E)$. Csatolásokat és EOS-okat nem lehet elnevezés alapján azonosítani. Az itteni $L$ a vákuumtömeg reciproka, az exponenciális lecsengési hossz; \cite{RP2016} a Compton-hosszt $2\pi/m_\phi$ szerint definiálja. A hatás $G=c=1$ konvenciója önmagában nem a fenomenológiai csatolás empirikus kalibrációja.

Szabolcsi Dávid hozzájárulása a megadott exponenciális bare-energiacsatolás, kvadratikus potenciál, változatlan SLy/APR4/H4 illesztések, $\alpha_Y=1$, $L=1,10$ km melletti reprodukálható egyensúlyi adatkészlet, továbbá a külön kauzális tartományra korlátozott közös-$\MB$ és közös-$\MA$ összevetés dokumentált protokollja. A célzott irodalomkutatás sem az adatkészlet, sem e részletes protokoll elsőségét nem bizonyítja. A részletes irodalmi melléklet külön kíséri az átdolgozást; nem numerikus bemenet és nem minden irodalomra kiterjedő vizsgálat állítása.

\section{EOS, tömegdefiníciók és numerikus eljárás}
A kapott implementáció Read és munkatársai szakaszonkénti politrop leírását használja \cite{Read2009}: SLy, APR4 (a hivatkozás AP4-paraméterezése) és H4 EOS, SLy-kéreggel. A mag szakaszhatárai $10^{14.7}$ és $10^{15}$ g\,cm$^{-3}$. A $(\log_{10}P_1,\Gamma_1,\Gamma_2,\Gamma_3)$ paraméterek rendre $(34.384,3.005,2.988,2.851)$, $(34.269,2.830,3.445,3.348)$ és $(34.669,2.909,2.246,2.144)$; $P_1$ egysége dyn\,cm$^{-2}$. Az energiaintegrálási állandók folytonosságot biztosítanak:
''' +equations+r'''
A \eqref{eq:energy} egyenlet tömegintegrálja a \eqref{eq:metric} metrika geometriai egységeiben értendő; a program a cgs nyugalmi sűrűséget integrálás előtt km$^{-2}$-be váltja. A hideg első főtétel és a kis sűrűségű $\eps/(\rho_0c^2)\to1$ határ rögzíti a nyugalmitömeg-konvenciót. Nem használunk önkényes energiasűrűség--barionsűrűség átváltást. Az $\MB$ integrálban nincs lapse- vagy $e^{-\phi}$-szorzó: ezek megváltoztatnák a modell megmaradó barionjainak mértékét. Az EOS-konvención túl nem következtetünk abszolút mikrofizikai barionszámra.

Az anyagfelszín $h(R)=0$. Az $m(R)$ nem helyettesíti $\MA$-t, mert a külső skalármező pozitív energiát hordoz. A belsőt és a külsőt két tartományon, egyidejű nemlineáris kollokációval oldjuk meg. A központ reguláris sorfejtése $r_0=10^{-5}$ km-nél indul; az anyagfelszínen $m,\nu,\phi,\phi'$ folytonos, felszíni héj nincs. A külső sugár $r_{\rm out}=R+18L$, a véges tartomány peremfeltételei:
\begin{equation}
\phi'/\phi=-1/L-(1+m_{\rm out}/L)/r_{\rm out},\qquad
\nu_{\rm out}=\tfrac12\ln(1-2m_{\rm out}/r_{\rm out}).
\end{equation}
Ezek a lecsengő tömeges skalármegoldást és a $\nu(\infty)=0$ feltételt közelítik. A közölt ADM-tömegek véges tartományú becslések; a 12L/24L függést alább teszteljük. A kiinduló kollokációs reziduumtolerancia $2\times10^{-7}$, a peremtolerancia legfeljebb $10^{-10}$, a csomópontok száma legfeljebb 22000. A GR-nek külön skalármentes kollokációs rendszere és önálló entalpia-IVP kontrollja van. A barionintegrál 48 és 96 pontos Gauss--Legendre-kvadratúrát használ, EOS-szakaszonként külön, a reguláris centrális térfogattal együtt.

A kilenc sorozat mindegyike 89 rögzített központisűrűség-pontot tartalmaz: $14.55\leq\log_{10}[\rho_{0c}/(\mathrm{g\,cm^{-3}})]\leq15.65$, 0,0125 dex lépéssel. A tárolt csúcs-, közvetlen tömeggyök- és deriváltellenőrzésekkel az archívum 1391 konfigurációt tartalmaz. A közölt kontrasztok javítására nem változtattuk meg az egyenleteket, az EOS paramétereit vagy a numerikus toleranciákat. A forrás állandói $M_\odot=1.988409870698051\times10^{30}$ kg és $c=299792458$ m\,s$^{-1}$; $M_\odot c^2=1.787093668741279\times10^{54}$ erg.

\section{Egy energetikai eredmény, két tömegillesztés}
A változatlan illesztett EOS-ra a $\max_r(dP/d\eps)\leq1$ kauzalitási feltételt alkalmazzuk, az EOS-szakaszhatárok mindkét oldalával. A dimenziótlan numerikus összehasonlítás $10^{-10}$ kerekítési ráhagyást használ, nem az EOS-bizonytalanság miatti lazítást. A kiválasztott intervallumot az első ADM-csúcs és az első kauzalitási határ közül a korábbi zárja. Az emelkedő tömeg ágkiválasztási feltétel, nem igazolt stabil ág. Ezen az intervallumon a bariontömeg monotonitását is ellenőrizzük.

EOS-onként és hatótávonként négy kontrasztot használunk: közös $\MA=1{,}4\Ms$; közös $\MB$, amely az adott EOS GR-beli $1{,}4\Ms$ állapotának bariontömege; valamint két külön határközeli cél, a kisebbik GR/Yukawa kauzális ághatár ADM-, illetve bariontömegének 99\%-án. Minden célt az egyensúly újramegoldásával és ugyanazon ágon végzett gyökkereséssel adunk meg, fordulóponton átívelő interpoláció vagy extrapoláció nélkül. A páronkénti célokat az \ref{tab:canonical}--\ref{tab:near}. táblázat közli.
\begin{equation}
\left.\Delta\Eb\right|_{\MB}=-c^2\Delta\MA,\qquad
\left.\Delta\Eb\right|_{\MA}=c^2\Delta\MB.\label{eq:contrasts}
\end{equation}
A $\Delta$ mindenütt Yukawa mínusz GR. Pozitív kontraszt azonos $\MB$ mellett kisebb ADM-energiát, azonos $\MA$ mellett nagyobb barionkapacitást jelent. Ezek ugyanazon egyensúlyi energetikai eredmény kiegészítő összegzései, nem két független felfedezés. A GR és egy más csatolású elmélet összevetése önmagában nem megengedett fizikai átmenet.

\begin{figure}[htbp]\centering
\includegraphics[width=\textwidth]{../figures/energy_vs_MB_HU.png}
\caption{Kötési energia bariontömeg szerint. Csak a kauzális első emelkedő szakasz és határpontjai látszanak. A görbék számított rácspontokat kötnek össze; az üres körök nem stabilitási címkék. H4-nél azonos központisűrűség-rács mellett nagyobb a kezdő bariontömeg.}\label{fig:energy}
\end{figure}
\input{tables_results_HU.tex}

Az $\alpha_Y=1$ melletti, GR-hez viszonyított $L=1$ km-es kanonikus, közös-$\MB$ energiatöbblet SLy/APR4/H4 sorrendben $0{,}424$, $0{,}454$ és $0{,}277\times10^{51}$ erg; $L=10$ km-nél $10{,}850$, $11{,}233$ és $8{,}443\times10^{51}$ erg. Közös $1{,}4\Ms$ ADM mellett az $L=10$ km-es bariontömeg-többlet $0{,}007612$, $0{,}007954$ és $0{,}005670\Ms$. A bariontömeg-referencia EOS-függő, nem univerzális $1{,}5\Ms$ cél.

Az $\alpha_Y=1$ mellett, SLy/APR4/H4 sorrendben, a \ref{tab:near}. táblázat határközeli közös bariontömegcéljainál az $L=10$ km-es Yukawa mínusz GR energiakontraszt $21{,}516$, $20{,}839$ és $18{,}137\times10^{51}$ erg. Az azonos ADM-mel kiválasztott határközeli párok más állapotokat jelentenek: energiaeltérésük $32{,}543$, $31{,}198$ és $24{,}514\times10^{51}$ erg. Nem vonhatók össze egyetemes átalakulási energia ismételt méréseiként.
\input{table_limits_HU.tex}

A H4 mindhárom ADM-csúcsa kauzális: $c_s^2/c^2=0{,}515838$, $0{,}516312$, $0{,}529803$ a GR-, 1 km-es és 10 km-es modellben. Mindkét SLy Yukawa-csúcs és az APR4 három csúcsa akauzális; a CSV ezeket matematikai folytatásként tárolja. A SLy GR-csúcs még kauzális ($0{,}999774$). A kiválasztott pártagok legnagyobb $c_s^2/c^2$ értéke $0{,}976933$.

\begin{figure}[htbp]\centering
\includegraphics[width=.94\textwidth]{../figures/mass_matching_contrasts_HU.png}
\caption{A tömegillesztés megváltoztatja a kérdést. Balra közös bariontömeg melletti energiaeltérés, jobbra közös ADM melletti barionkapacitás-különbség, más függőleges egységgel. Az alsó panelek célja külön-külön a közös kauzális határtömeg 99\%-a; az oszlopok nem ugyanazon állapotokat választják ki.}\label{fig:matches}
\end{figure}
\FloatBarrier
\section{Numerikus ellenőrzések és hatókörük}
Az összes átadott bemeneti lenyomatot, tömegmérleg- és energiaazonosságot ellenőriztük. Az 1391 hangsebességjelölést az EOS-ból újraszámoltuk; mind a 24 pár a megfelelő kauzális ághatár alatt marad. A közvetlen tömegcél-maradék legfeljebb $1{,}124\times10^{-10}\Ms$.

Az archivált 114 pontbeli kontrollváltozatot újrafuttattuk, 58 külön kiinduló sűrűséggel. A Yukawa-modellben a 18L-es külsőt 12L-re rövidítjük vagy 24L-re nyújtjuk, a kollokációs toleranciát $2\times10^{-7}$-ről $5\times10^{-8}$-ra szigorítjuk. A GR-IVP relatív toleranciája $2\times10^{-12}$-ről $2\times10^{-13}$-ra változik, ami szigorúbb GR-kollokációt is kivált. A saját ághatár- és csúcsállapotoknak külön toleranciatesztjük van.
\input{table_validation_HU.tex}

Pusztán a külső tartomány változtatása legfeljebb $4{,}823\times10^{-12}\Ms$ ADM-eltérést ad; a végpont- és toleranciatesztekkel együtt a legnagyobb eltérés $1{,}817\times10^{-10}\Ms$. Az újrafuttatott és tárolt ADM-változások legfeljebb $2{,}502\times10^{-12}\Ms$-gel térnek el. Az újramegoldott profilok külső skalárenergiájának külön kvadratúrája és $\MA-m(R)$ eltérése legfeljebb $6{,}526\times10^{-12}\Ms$. Ezek kiválasztott pontbeli tartományfüggési tesztek, nem minden sűrűségre és paraméterre szóló szigorú korlátok.

A kapott 48/96 pontos barionkvadratúra eltérése legfeljebb $5{,}540\times10^{-12}\Ms$. Az első főtétel külön, natív entalpiakoordinátás deriválásos próbájának legnagyobb relatív maradéka $3{,}516\times10^{-10}$. Az archivált $d\MA/d\MB=e^{\nu_R-\phi_R}$ szekvenciameredekség-próba maradéka legfeljebb $2{,}941\times10^{-6}$; ez nem módusszámítás. A ritkább/sűrűbb, ágra korlátozott interpoláció legnagyobb energiaeltérése a közvetlen gyökökhöz képest $0{,}099695$ és $0{,}013642\times10^{51}$ erg. A táblázatos kontrasztok ezért nem ezekből az interpolánsokból származnak.

Az empirikus rögzítettcél-diagnosztika minden kontrollváltozást lineárisan visszavetít a célra:
\begin{equation}
\delta E_t=\delta E-\frac{dE/d\ell}{dM_t/d\ell}\,\delta M_t,\qquad \ell=\log_{10}\rho_{0c}.
\end{equation}
Az $M_t$ a választott illesztett tömeg, $\ell$ a tabulált logaritmikus sűrűség. Mindkét pártag legnagyobb tesztelt abszolút visszavetített változását és kvadratúraeltérését összeadjuk. Maximuma $1{,}003\times10^{-6}\times10^{51}$ erg. Ez nem konfidenciaintervallum. A finom lokális csúcsillesztés tárolt helyváltozása legfeljebb $1{,}102\times10^{-6}$ dex, tömegváltozása $1{,}818\times10^{-10}\Ms$. Az eredeti a összeállításban ezek archivált adatok voltak; a később kapott Academia Co-scientist jelentés mind a 18 illesztés reprodukciójáról számol be, az alább elkülönített eredeti helyi újrafuttatások mellett. A másik történeti forrás-diszkretizációhoz viszonyított bariontömeg-eltérés eléri az $1{,}083\times10^{-5}\Ms$-et; ez nem része a kisebb belső kollokációs érzékenységnek, és nem rendeljük egyetlen hibaforráshoz.

\section{Értelmezés és korlátok}
A hasznos eredmény Szabolcsi Dávid modellfüggő adatkészlete és ismert összehasonlítási módszerek dokumentált alkalmazása. A közölt SLy/APR4/H4 pároknál, $\alpha_Y=1$ mellett, azonos EOS-ú GR-kontrollhoz képest a közös-$\MB$ kontraszt pozitív a táblázatban megadott céloknál; $L=10$ km-nél az adott EOS kanonikus céljától a kiválasztott határközeli céljáig nő. Ez nem új általános módszer, fizikai elmélet, csillagfázis vagy -populáció állítása. A reprodukálhatóság nem elsőségi bizonyíték.

Nyitott a táblázatos EOS bare $\eps(n)$-ként való azonosítása a \eqref{eq:action} hatásban, a csatolás motivációja és empirikus érvényessége, valamint a térfüggő anyagból készült órák és rudak értelmezése. Forgást, hőmérsékletet, EOS-bizonytalanságot és sugárzást nem modelleztünk, ezekre hibasávot sem adunk. Nem oldottunk meg kapcsolt folyadék--skalár perturbációs feladatot vagy időfejlődést. Különböző elméletek azonos bariontömege nem definiál kezdeti és későbbi állapotokat ugyanazon dinamikai elméletben; önmagában nem jósol kibocsátott neutrínó-, skalár- vagy gravitációshullám-energiát. 

A megfigyelhetőség külön kérdés: név szerint megadott mérhető mennyiség (például tömeg és sugár vagy árapály-deformálhatóság), mérési és elméleti bizonytalansági mérleg, valamint az EOS-, csatolás- és hatótáv-degenerációk elkülönítése szükséges hozzá. A megőrzött bariontömegű cél nem közvetlenül mért bariontömeg. Ilyen megfigyelési következtetést itt nem végzünk.

\section{Adatok, reprodukció és közlési nyilatkozat}
A mellékelt csomag tartalmazza a változatlan numerikus bemeneteket és számítási kódot, a kétnyelvű szerkeszthető TeX-et, ábrákat és a \texttt{reproduce.py} belépési pontot. Az elsődleges számok a \path{data/comparisons.csv}, a határok a \path{data/sequence_summary.csv}, az érzékenység a \path{data/convergence.csv} és az újrafuttatott kontrolltáblák adatai. Távoli bemenet nem kell. A YBE-2026-11-08-b belső átdolgozáshoz még nincs DOI rendelve; nem közzétett rekordazonosító. A korábbi a csomag közlési azonosítója \url{https://doi.org/10.5281/zenodo.24053942}; ezt nem rendeljük b-hez. Régebbi archívumok azonosságát nem állítjuk. A tudományos bemenetek, megoldó- és EOS-források bájtra azonosak az a csomagéival; csak a bemutatás, az irodalom és az ellenőrzési státusz attribúciója változik.

A bemeneti archívum SHA-256 lenyomata:
\begin{quote}\small\url{4ffe19e74db5f5c9237d244dcbc0e9a1a12b1e89dd1b13c27ec5684f8e3e47fe}.\end{quote}
A szükséges fájlok lenyomata és relatív útvonala a \path{metadata/provenance.json} fájlban van. Az újrafuttatás a megadott algoritmust reprodukálja; nem független fizikai validáció vagy szakmai lektorálás.

\aistatement{\textbf{A szerzőtől kapott közlési nyilatkozat:} Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); nem szakmai lektorálás.}
Az eredeti a összeállításban helyben újrafuttattuk a 114 pontbeli kontrollt, az integritási és termodinamikai próbákat, de akkor nem generáltuk újra az 1391 állapotot és nem illesztettük újra a 18 lokális csúcsot. A szerzőtől később kapott Academia Co-scientist jelentés az 1391 konfiguráció reprodukciójáról, hat fő CSV-tábla egyezéséről, a 114 kontroll és 18 csúcsillesztés reprodukciójáról, továbbá hat szándékosan rontott eset elutasításáról számol be. A jelentés szerint az ellenőrzött fő állítások alátámasztottak, és az ellenőrzött hatókörben nem talált közlést akadályozó tudományos hibát. Ez attribúcióval közölt MI-alapú numerikus jelentés, nem független fizikai validáció, minden irodalomra kiterjedő elsőségi bizonyítás vagy a külön 18-forrásos melléklet minden tételének auditja. A b átdolgozás szigorú integritási és numerikus konzisztenciapróbákat futtat újra, tudományos kódmódosítás vagy hangolás nélkül; a szöveges módosítások nem igényelnek új szimulációt.

\textbf{Következtetés.} A táblázatos céloknál, SLy/APR4/H4 EOS, $\alpha_Y=1$ és $L=1,10$ km mellett, azonos EOS-ú GR-kontrollhoz képest a közös bariontömeg kisebb ADM-energiát, a külön közös ADM-tömeg nagyobb barionkapacitást ad. A hozzájárulás e konkrét modell reprodukálható egyensúlyi adatkészlete és dokumentált összehasonlítási protokollja, kauzális kiválasztással és külső skalárenergiával. Ez egy feltételes energetikai vizsgálat, nem új általános csatolás vagy kötésienergia-módszer, elsőségi bizonyítás, illetve fizikai helyességi, stabilitási, megfigyelhetőségi vagy átalakulási energiakibocsátási bizonyíték.
''' +bib+r'\end{document}'
for lang,body in [('EN',EN),('HU',HU)]:
 language = r'\usepackage[magyar]{babel}' if lang=='HU' else r'\usepackage[english]{babel}'
 (M/f'binding_energy_{lang}.tex').write_text(preamble+language+'\n'+body)
