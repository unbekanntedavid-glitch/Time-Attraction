#!/usr/bin/env python3
"""Check emitted PDF pages, bilingual disclosure and CSV-derived table values."""
from pathlib import Path
import subprocess,json,argparse,csv,re,hashlib
R=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=R/'run/document_check.json');a=p.parse_args()
license_line="© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International + https://creativecommons.org/licenses/by-nc/4.0/ · commercial use only with the author's written permission."
reports=[]
for lang in ['EN','HU']:
 source=(R/'manuscript'/f'binding_energy_{lang}.tex').read_text()
 if 'chapter 7; accessible republication, arXiv:gr-qc/0405109' not in source:
  raise ValueError('ADM chapter/republication locator required')
 if '227--264' in source or '227–264' in source:
  raise ValueError('Superseded ADM page locator')
 for key in ['FAD2013','BTW2015','MS2016','RP2016','RM2020','UTYR2025']:
  if (r'\bibitem{'+key+'}') not in source:raise ValueError('Missing nearest-prior-art reference')
 if 'YBE-2026-11-08-b' not in source:raise ValueError('Revision label')
generator=(R/'code/build_manuscripts.py').read_text()
if '227--264' in generator or '227–264' in generator:
 raise ValueError('ADM locator would be reintroduced by generator')
for f in sorted((R/'figures').glob('*.pdf'))+sorted((R/'manuscript').glob('*.pdf')):
 txt=subprocess.check_output(['pdftotext','-layout',str(f),'-'],text=True)
 pages=[x for x in txt.split('\f') if x.strip()]
 for k,page in enumerate(pages,1):
  normalized=' '.join(page.split())
  if license_line not in normalized:raise ValueError(f'Exact full footer missing: {f.name}, page {k}')
 reports.append(dict(path=str(f.relative_to(R)),pages=len(pages),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),all_pages_exact_footer=True))
 if f.parent.name=='manuscript':
  normalized=' '.join(txt.split());lang=f.stem[-2:]
  if re.search(r'\b(final|végső|végleges|complete|teljes|befejezett)\b',normalized,re.I):raise ValueError('Disallowed manuscript wording')
  if '??' in normalized:raise ValueError('Unresolved reference')
  if lang=='EN':sentence='Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.'
  else:sentence='Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); nem szakmai lektorálás.'
  if sentence not in normalized:raise ValueError('Missing exact author-supplied AI disclosure')
  with (R/'data/comparisons.csv').open() as stream:rows=list(csv.DictReader(stream))
  for row in rows:
   value=f"{float(row['delta_Ebind_1e51erg']):.3f}"
   if value not in normalized:raise ValueError('Missing printed contrast: '+value)
if len(reports)!=6:raise ValueError('Expected two articles and four standalone figure PDFs')
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(dict(status='document_checks_passed',pdfs=reports,all_24_printed_contrast_values_checked=True,disclosure='Exact author-supplied disclosure; subsequent numerical report attributed, not peer review.'),indent=2)+'\n')
print(json.dumps(reports,indent=2))
