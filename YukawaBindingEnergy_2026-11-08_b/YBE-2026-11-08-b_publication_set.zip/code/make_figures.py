#!/usr/bin/env python3
"""Presentation only: no new equilibrium calculation; input tables are unchanged."""
from pathlib import Path
import os,argparse
os.environ['MPLBACKEND']='Agg'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=ROOT);args=ap.parse_args();ROOT=args.root
s=pd.read_csv(ROOT/'data/equilibrium_sequences.csv');su=pd.read_csv(ROOT/'data/sequence_summary.csv');c=pd.read_csv(ROOT/'data/comparisons.csv')
for cols,d in [(['MB_Msun','M_ADM_Msun','Ebind_1e51erg','logrho','cs2max'],s),(['target_Msun','delta_MB_Msun','delta_Ebind_1e51erg'],c)]:
 if not set(cols)<=set(d.columns) or not np.isfinite(d[cols]).all().all():raise ValueError('Missing/nonfinite plot input')
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':12.5,'axes.grid':True,'grid.alpha':.22,'savefig.dpi':190})
footer1='© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International'
footer2="+ https://creativecommons.org/licenses/by-nc/4.0/ · commercial use only with the author's written permission."
def save(fig,name):
 # PNG goes into the manuscript, whose page already has the mandatory footer.
 fig.savefig(OUT/(name+'.png'),bbox_inches='tight',pad_inches=.08)
 fig.text(.5,.045,footer1,ha='center',fontsize=6)
 fig.text(.5,.020,footer2,ha='center',fontsize=6)
 fig.savefig(OUT/(name+'.pdf'))
 plt.close(fig)
for lang in ['EN','HU']:
 hu=lang=='HU'
 fig,axs=plt.subplots(1,3,figsize=(11.8,4.8),sharey=True)
 for ax,name in zip(axs,['SLy','APR4','H4']):
  for L,color,label in [(0.,'#222222','GR'),(1.,'#277da8','Yukawa: L = 1 km'),(10.,'#c74832','Yukawa: L = 10 km')]:
   lim=su[(su.EOS==name)&(su.L_km==L)].iloc[0];group=s[(s.EOS==name)&(s.L_km==L)]
   d=group[group.grid_point & group.causal & (group.logrho<lim.logrho_candidate_supremum)]
   e=group.iloc[np.argmin(abs(group.logrho-lim.logrho_candidate_supremum))]
   if abs(e.logrho-lim.logrho_candidate_supremum)>1e-8 or e.cs2max>1+1e-10:raise ValueError('Invalid endpoint')
   d=pd.concat([d,pd.DataFrame([e])]).sort_values('logrho')
   ax.plot(d.MB_Msun,d.Ebind_1e51erg/100,lw=1.8,color=color,label=label)
   ax.scatter(e.MB_Msun,e.Ebind_1e51erg/100,facecolors='white',edgecolors=color,s=28,zorder=4)
  ax.set_xlim(.15,2.65);ax.set_title(name);ax.set_xlabel((r'Bariontömeg $M_B$' if hu else r'Baryon mass $M_B$')+r' [$M_\odot$]');ax.legend(fontsize=11,loc='upper left')
 axs[0].set_ylabel(r'$E_{\rm bind}=(M_B-M_{\rm ADM})c^2$ [$10^{53}$ erg]')
 fig.suptitle('Kauzális emelkedő egyensúlyok; αY = 1' if hu else 'Causal first-rising equilibria; αY = 1',fontsize=13,y=.98)
 fig.subplots_adjust(left=.07,right=.985,top=.86,bottom=.26,wspace=.12)
 fig.text(.5,.105,'Üres kör: kauzális ághatár; dinamikai stabilitás nincs igazolva.' if hu else 'Open circles: causal branch limits; dynamical stability is not established.',ha='center',fontsize=11)
 save(fig,'energy_vs_MB_'+lang)
 fig,axs=plt.subplots(2,2,figsize=(11.8,8.2));names=['SLy','APR4','H4'];x=np.arange(3);w=.32
 titlesHU=[['Azonos MB: az EOS saját\nGR ADM = 1,4 referenciaállapota','Azonos ADM: 1,4 M☉'],['Azonos MB: a kauzális ághatár közelében','Azonos ADM: a kauzális ághatár közelében']]
 titlesEN=[['Same MB: EOS-specific\nGR ADM = 1.4 reference state','Same ADM: 1.4 M☉'],['Same MB: near the causal branch limit','Same ADM: near the causal branch limit']]
 for row in [0,1]:
  for col in [0,1]:
   ax=axs[row,col];contrast=[['common_MB_GR1p4','common_ADM_1p4'],['common_MB_near_limit','common_ADM_near_limit']][row][col]
   for j,(L,color) in enumerate([(1.,'#277da8'),(10.,'#c74832')]):
    d=c[(c.contrast==contrast)&(c.L_km==L)].set_index('EOS').loc[names]
    val=d.delta_Ebind_1e51erg if col==0 else d.delta_MB_Msun*1000
    ax.bar(x+(j-.5)*w,val,width=w,color=color,label=f'L = {L:g} km')
   ax.set_xticks(x,names);ax.set_title((titlesHU if hu else titlesEN)[row][col],fontsize=12)
   ax.set_ylabel(r'$\Delta E_{\rm bind}$ [$10^{51}$ erg]' if col==0 else r'$\Delta M_B$ [$10^{-3}M_\odot$]');ax.legend(fontsize=11);ax.grid(axis='x',visible=False)
 fig.suptitle('αY = 1: külön energetikai és barionkapacitás-célok' if hu else 'αY = 1: distinct energy and baryon-capacity targets',fontsize=13,y=.98)
 fig.subplots_adjust(left=.09,right=.98,top=.88,bottom=.19,hspace=.40,wspace=.28)
 fig.text(.5,.115,'Balra azonos MB; jobbra azonos ADM. Alul: a közös kauzális határtömeg 99%-a, külön illesztéssel.' if hu else 'Left: equal MB; right: equal ADM. Lower panels: 99% of the common causal limit, matched separately.',ha='center',fontsize=8)
 fig.text(.5,.085,'Minden különbség Yukawa − GR; nem fizikai átalakulási energia.' if hu else 'All differences are Yukawa − GR; they are not physical conversion energies.',ha='center',fontsize=8)
 save(fig,'mass_matching_contrasts_'+lang)
