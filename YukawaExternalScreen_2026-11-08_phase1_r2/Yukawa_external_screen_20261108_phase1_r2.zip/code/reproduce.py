#!/usr/bin/env python3
"""Offline analytic/numerical validation and weak-field geometry diagnostics.
No NS solver, no experimental likelihood, no claimed 10 km exclusion.
"""
from pathlib import Path
import csv,json,sys,platform
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from weak_field import *

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,actual,expected,rtol=2e-9,atol=1e-13):
    a=np.asarray(actual);e=np.asarray(expected)
    if np.any(~np.isfinite(a)) or np.any(~np.isfinite(e)):
        raise RuntimeError(name+': nonfinite')
    err=float(np.max(np.abs(a-e)))
    ok=bool(np.allclose(a,e,rtol=rtol,atol=atol))
    checks.append(dict(name=name,passed=ok,max_abs_error=err,rtol=rtol,atol=atol,
                       actual=a.tolist(),expected=e.tolist()))
    if not ok:raise RuntimeError(name+': failed '+str(checks[-1]))

def write_csv(path,rows):
    if not rows:raise RuntimeError('empty table')
    for r in rows:
        for v in r.values():
            if isinstance(v,(int,float,np.floating)) and not np.isfinite(v):raise RuntimeError('nonfinite table')
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run():
    for p in ['data','figures','checks']:(ROOT/p).mkdir(exist_ok=True)
    q=alpha(1.);g=g_ratio(1.)
    check('action_normalization',q,1/(4*np.pi),0,1e-16)
    check('r4_ideal_calibration',g,.9262883177508389,0,1e-15)
    check('legacy_k_not_sqrt_k',alpha(.04),.04/(4*np.pi),0,1e-16)
    for L in [1000.,10000.]:
        for r,R in [(220.,100.),(1700.,1000.),(10000.,1000.)]:
            FN,P,FY=sphere_quadrature(r,R,L)
            check(f'sphere_Newton_L{L}_r{r}',FN*r*r,1.)
            check(f'sphere_potential_L{L}_r{r}',P*r,sphere_yukawa(r,R,L)*r)
            check(f'sphere_force_L{L}_r{r}',FY*r*r,sphere_yukawa(r,R,L,True)*r*r)
            h=r*1e-4
            # Fourth-order derivative of positive potential magnitude: -dP/dr.
            Pm2=sphere_yukawa(r-2*h,R,L);Pm=sphere_yukawa(r-h,R,L)
            Pp=sphere_yukawa(r+h,R,L);Pp2=sphere_yukawa(r+2*h,R,L)
            dnum=-(Pm2-8*Pm+8*Pp-Pp2)/(12*h)
            check(f'sphere_numeric_derivative_L{L}_r{r}',dnum*r*r,FY*r*r,rtol=2e-9)
        for R in [1e-7,1.,1000.]:
            r=10000.
            if R==1e-7:
                check(f'point_limit_L{L}',sphere_yukawa(r,R,L,True)*r*r,force_kernel(r/L))
        pair=(3000.,900.,700.,L)
        check(f'two_finite_spheres_L{L}',sphere_pair_kappa(*pair),sphere_pair_quadrature(*pair))
        for z,t,A in [(100.,300.,1500.),(1000.,1000.,2000.)]:
            N,Y=cylinder_fields(z,t,A,L);Nq,Yq=cylinder_quadrature(z,t,A,L)
            check(f'finite_cylinder_Newton_L{L}_z{z}',N,Nq,atol=1e-9)
            check(f'finite_cylinder_Yukawa_L{L}_z{z}',Y,Yq,atol=1e-9)
            N2,Y2=cylinder_quadrature(z,t,A,L,150)
            check(f'quadrature_convergence_N_L{L}_z{z}',N2,Nq,atol=1e-9)
            check(f'quadrature_convergence_Y_L{L}_z{z}',Y2,Yq,atol=1e-9)
        z=100.;t=1000.;A=100*L
        _,Y=cylinder_fields(z,t,A,L)
        check(f'halfspace_radius_limit_L{L}',Y,slab_y(z,t,L),atol=1e-9)
        check(f'slab_infinite_thickness_L{L}',slab_y(z,100*L,L),L*np.exp(-z/L))
        for h,d in [(454.,1000.),(300.,5000.)]:
            v=tower_fourier_point(h,d,L)
            check(f'Poisson_vs_Helmholtz_L{L}_h{h}',v,tower_fourier_separate(h,d,L),atol=1e-12)
        check(f'zero_height_tower_L{L}',tower_fourier_point(0,1000,L),0.,0,1e-15)
        check(f'ideal_short_distance_G_L{L}',pair_ratio(.001,L),1.,atol=1e-12)
        check(f'distant_G_star_L{L}',pair_ratio(100*L,L),g,0,1e-15)
        check(f'GR_coupling_zero_L{L}',pair_ratio(3000,L,0),1.,0,1e-15)
        check(f'coupling_to_zero_L{L}',pair_ratio(3000,L,1e-10),1.,0,8e-12)
    check('sphere_long_range_Newton',sphere_yukawa(10000,1000,1e12,True)*1e8,1.,atol=1e-12)
    check('sphere_short_range',sphere_yukawa(10000,1000,1.,True),0.,0,1e-300)
    N,Y=cylinder_fields(100,1000,2000,1e10)
    check('finite_cylinder_long_range',Y,N,rtol=2e-7,atol=1e-8)
    check('tower_massless_limit',tower_fourier_point(454,1000,1e12),0.,0,1e-16)
    # Normalization and varying-density feedback size, not a nonlinear screening solve.
    rho=5515.; eta=1*G_LAB*g*rho*10000**2/C**2
    check('Earth_density_linearization_small',float(eta<1e-12),1.,0,0)
    for bad in [float('nan'),float('inf'),-1.]:
        try:alpha(bad)
        except ValueError: checks.append(dict(name='reject_bad_coupling_'+str(bad),passed=True))
        else: raise RuntimeError('bad coupling accepted')
    rows=[]
    for L in [1000.,10000.]:
        for d in np.geomspace(.1,1e5,121):
            N,Y=cylinder_fields(float(d),1000.,10000.,L)
            kap=Y/N
            if not np.isfinite(kap) or kap<0 or kap>1+1e-10:raise RuntimeError('cylinder kappa invalid')
            for a in [1.,.001]:
                rows.append(dict(L_m=L,a=a,alpha=alpha(a),distance_m=float(d),
                    kappa_point=float(force_kernel(d/L)),kappa_cylinder=kap,
                    cylinder_radius_m=10000.,cylinder_thickness_m=1000.,
                    G_pair_over_ideal_Glab=pair_ratio(float(d),L,a),
                    G_cylinder_over_ideal_Glab=g_ratio(a)*(1+alpha(a)*kap),
                    Newton_cylinder_shape_m=N,Yukawa_unit_alpha_shape_m=Y,
                    Gstar_over_ideal_Glab=g_ratio(a),source_density_kg_m3=2000.,
                    Newton_Glab_acceleration_m_s2=2*np.pi*G_LAB*2000*N,
                    tensor_acceleration_m_s2=2*np.pi*G_LAB*g_ratio(a)*2000*N,
                    scalar_acceleration_m_s2=2*np.pi*G_LAB*g_ratio(a)*alpha(a)*2000*Y,
                    total_acceleration_m_s2=2*np.pi*G_LAB*g_ratio(a)*2000*(N+alpha(a)*Y)))
    for L in [1000.,10000.]:
        rr=[r for r in rows if r['L_m']==L]
        check(f'acceleration_normalization_L{L}',
            [r['total_acceleration_m_s2']/r['Newton_Glab_acceleration_m_s2'] for r in rr],
            [r['G_cylinder_over_ideal_Glab'] for r in rr],rtol=2e-15,atol=2e-15)
        check(f'force_additivity_L{L}',
            [r['total_acceleration_m_s2'] for r in rr],
            [r['tensor_acceleration_m_s2']+r['scalar_acceleration_m_s2'] for r in rr],rtol=2e-15,atol=2e-18)
    if len(rows)!=484:raise RuntimeError('diagnostic grid size')
    if len({(r['L_m'],r['a'],r['distance_m']) for r in rows})!=484:raise RuntimeError('duplicate grid')
    write_csv(ROOT/'data/geometry_diagnostics.csv',rows)
    cal=[]
    for L in [1000.,10000.]:
        for geometry,kap in [('point_1m',force_kernel(1/L)),('point_1000m',force_kernel(1000/L)),
                            ('point_10000m',force_kernel(10000/L)),
                            ('cylinder_R10km_t1km_z100m',cylinder_fields(100,1000,10000,L)[1]/cylinder_fields(100,1000,10000,L)[0])]:
            cal.append(dict(L_m=L,a=1.,alpha=q,geometry=geometry,kappa_cal=float(kap),
                Gstar_over_fittedG=g_ratio(1.,float(kap)),ideal_g=g,
                relative_g_change=g_ratio(1.,float(kap))/g-1))
    write_csv(ROOT/'data/calibration_geometry.csv',cal)
    compact=[]
    for L in [1000.,10000.]:
        for D in [1.,10.,100.,1000.]:
            upper=(1+q)/(1+q*force_kernel(D/L))-1
            check(f'positive_geometry_calibration_bound_L{L}_D{D}',
                  float(upper>=0 and upper<=q),1.,0,0)
            compact.append(dict(L_m=L,a=1.,max_pair_separation_m=D,
                max_relative_g_vs_ideal=float(upper),
                assumption='all_pair_separations_bounded_positive_force_weights_no_nuisance_projection'))
    write_csv(ROOT/'data/compact_calibration_bound.csv',compact)
    screen=[dict(a=1.,L_m=1000.,alpha=q,ideal_g=g,physical_lambda_m=1000.,
        source='Cruz1991_primary_abstract',reported_abs_alpha_bound=.001,ratio_to_reported_bound=q/.001,
        classification='incompatible_with_reported_bound_CL_unspecified',
        formal_category='unresolved_primary_confidence_and_fulltext_convention_gap',
        confidence='not_stated_in_consulted_primary_abstract',
        assumptions='universal_unscreened_weak_dust_standard_Yukawa_convention',
        applicability='published_inequality_not_new_likelihood; full_text_geometry_not_reconstructed'),
        dict(a=1.,L_m=10000.,alpha=q,ideal_g=g,physical_lambda_m=10000.,
        source='primary_10km_transfer_missing',reported_abs_alpha_bound='',ratio_to_reported_bound='',
        classification='unresolved_primary_range_and_response_gap',formal_category='unresolved_mapping_source_gap',confidence='none_assigned',
        assumptions='universal_unscreened_weak_dust_standard_Yukawa_convention',
        applicability='no_1km_to_10km_extrapolation; no_primary_likelihood')]
    write_csv(ROOT/'data/parameter_screen.csv',screen)
    write_csv(ROOT/'data/necessary_not_sufficient_window.csv',[
        dict(L_m=1000.,alpha_min=0.,alpha_upper_open=.001,a_min=0.,a_upper_open=4*np.pi*.001,
             status='necessary_only_from_Cruz_abstract_not_verified_allowed_region',confidence='unspecified')])
    tower=[]
    for L in [1000.,10000.]:
        for d in [100.,1000.,5000.,10000.]:
            tower.append(dict(L_m=L,depth_m=d,height_m=454.,normalized_residual=tower_fourier_point(454,d,L),
                              normalization='Gstar_alpha_M_divided_by_depth_squared',
                              status='synthetic_source_not_BREN_fit'))
    write_csv(ROOT/'data/synthetic_tower_operator.csv',tower)
    fig,ax=plt.subplots(1,2,figsize=(10,4),sharey=True)
    for i,L in enumerate([1000.,10000.]):
        for a,sty in [(1.,'-'),(.001,'--')]:
            rr=[r for r in rows if r['L_m']==L and r['a']==a]
            d=[r['distance_m'] for r in rr]
            ax[i].semilogx(d,[r['G_pair_over_ideal_Glab']-1 for r in rr],sty,label=f'pont, a={a:g}')
            ax[i].semilogx(d,[r['G_cylinder_over_ideal_Glab']-1 for r in rr],sty,label=f'henger, a={a:g}',alpha=.6)
        ax[i].axhline(0,color='k',lw=.5);ax[i].set_title(f'L = {L/1000:g} km')
        ax[i].set_xlabel('távolság / m');ax[i].grid(alpha=.2)
    ax[0].set_ylabel('gyorsulás / Newton(rövidtávú G_lab) − 1')
    ax[1].legend(fontsize=7);fig.suptitle('Szintetikus geometria; nem kísérleti kizárás')
    fig.tight_layout();fig.savefig(ROOT/'figures/geometry_contrast.png',dpi=170);plt.close(fig)
    # Calibration is a separate diagnostic, not confidence or error bars.
    fig,ax=plt.subplots(figsize=(8,4))
    for L in [1000.,10000.]:
        rr=[r for r in rows if r['L_m']==L and r['a']==1.]
        ax.semilogx([r['distance_m'] for r in rr],
                    [g_ratio(1.,r['kappa_point']) for r in rr],label=f'pontkalibráció L={L/1000:g} km')
    ax.axhline(g,color='k',ls=':',label='ideális d ≪ L')
    ax.set(xlabel='kalibrációs távolság / m',ylabel='G* / illesztett G')
    ax.legend();ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(ROOT/'figures/calibration_scale.png',dpi=170);plt.close(fig)
    report=dict(scope='weak_field_analytic_and_synthetic_geometry_only',passed=all(c['passed'] for c in checks),
        count=len(checks),checks=checks,constants=dict(G_lab_SI=G_LAB,c_SI=C,Msun_kg=MSUN,
        alpha_for_a1=q,ideal_g_for_a1=g,lambda_equals_L=True,Earth_density_eta_L10km=eta),
        environment=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,platform=platform.platform()),
        excluded_tests=['actual_experimental_likelihood','real_terrain_tower_estimator','NS_reintegration',
                        'GR_mimic_search','radial_stability','screened_model'])
    (ROOT/'checks/validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(dict(passed=report['passed'],count=len(checks),alpha=q,g=g,eta=eta)))

if __name__=='__main__':run()
