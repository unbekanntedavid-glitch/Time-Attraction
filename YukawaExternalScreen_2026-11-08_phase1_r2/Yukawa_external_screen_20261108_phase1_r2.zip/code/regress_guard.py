#!/usr/bin/env python3
"""Mutated copies only; the real data are not edited. Tests run the packer's gate."""
from pathlib import Path
import tempfile,shutil,csv,subprocess,json,sys
R=Path(__file__).resolve().parents[1]
(R/'delivery').mkdir(parents=True,exist_ok=True)
cases=[
 ('NaN_acceleration','geometry_diagnostics.csv',0,'total_acceleration_m_s2','nan'),
 ('Inf_g','geometry_diagnostics.csv',0,'Gstar_over_ideal_Glab','inf'),
 ('finite_wrong_g','geometry_diagnostics.csv',0,'Gstar_over_ideal_Glab','.95'),
 ('finite_wrong_alpha','geometry_diagnostics.csv',0,'alpha','.1'),
 ('wrong_density_units','geometry_diagnostics.csv',0,'source_density_kg_m3','2'),
 ('wrong_length_units','geometry_diagnostics.csv',0,'cylinder_radius_m','10'),
 ('wrong_scalar_acceleration','geometry_diagnostics.csv',0,'scalar_acceleration_m_s2','1'),
 ('missing_grid','geometry_diagnostics.csv',None,None,None),
 ('duplicate_grid','geometry_diagnostics.csv',None,None,'duplicate'),
 ('finite_wrong_control','geometry_diagnostics.csv',0,'Newton_cylinder_shape_m','999'),
 ('invented_10km_bound','parameter_screen.csv',1,'reported_abs_alpha_bound','.001'),
 ('invented_confidence','parameter_screen.csv',0,'confidence','95_percent'),
 ('allowed_window_overclaim','necessary_not_sufficient_window.csv',0,'status','verified_allowed'),
 ('tower_data_overclaim','synthetic_tower_operator.csv',0,'status','experimental_likelihood'),
 ('NaN_scientific_control',None,None,None,float('nan')),
 ('finite_wrong_scientific_control',None,None,None,.95),
]
results=[]
for opt in [[],['-O']]:
    p=subprocess.run([sys.executable]+opt+[str(R/'code/data_gate.py')],capture_output=True,text=True)
    if p.returncode:raise RuntimeError('clean data rejected: '+p.stderr)
    results.append(dict(mode='optimized' if opt else 'normal',case='clean_positive',exit_code=p.returncode,passed=True))
    for name,filename,index,key,value in cases:
        with tempfile.TemporaryDirectory(prefix='guard_',dir=R/'delivery') as td:
            W=Path(td);shutil.copytree(R/'data',W/'data');shutil.copytree(R/'checks',W/'checks')
            if filename is None:
                cf=W/'checks/validation.json';c=json.loads(cf.read_text());c['checks'][0]['actual']=value;cf.write_text(json.dumps(c))
            else:
                f=W/'data'/filename
                with f.open(newline='') as h:
                    reader=csv.DictReader(h);fields=reader.fieldnames;rr=list(reader)
                if index is None:
                    if value=='duplicate':rr[-1]=dict(rr[0])
                    else:rr.pop()
                else:rr[index][key]=value
                with f.open('w',newline='') as h:
                    w=csv.DictWriter(h,fieldnames=fields);w.writeheader();w.writerows(rr)
            invocation="import sys;sys.path.insert(0,"+repr(str(R/'code'))+");import pack;from pathlib import Path;pack.R=Path("+repr(str(W))+")\ntry: pack.main()\nexcept ValueError as e: print(e);sys.exit(23)\nexcept Exception as e: print(type(e).__name__,e);sys.exit(24)\n"
            p=subprocess.run([sys.executable]+opt+['-c',invocation],capture_output=True,text=True)
            if p.returncode!=23:raise RuntimeError('wrong corruption rejection '+name+': '+p.stdout+p.stderr)
            results.append(dict(mode='optimized' if opt else 'normal',case=name,exit_code=p.returncode,passed=True,reason=p.stdout.strip()))
report=dict(passed=True,count=len(results),positive=2,negative=2*len(cases),checks=results,
    scope='actual_CSV_publication_guard_only_not_new_physical_validation')
(R/'checks/data_gate_regression.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'}))
