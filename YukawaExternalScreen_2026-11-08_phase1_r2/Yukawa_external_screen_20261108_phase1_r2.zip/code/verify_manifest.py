#!/usr/bin/env python3
"""Verify archive payload files against a non-self-referential SHA-256 manifest."""
from pathlib import Path,PurePosixPath
import hashlib,json,sys
R=Path(__file__).resolve().parents[1]
def verify(root=R):
    m=json.loads((root/'MANIFEST.json').read_text())
    seen=set()
    for rec in m['files']:
        rel=rec['path']; p=PurePosixPath(rel)
        if p.is_absolute() or '..' in p.parts or rel in seen:raise RuntimeError('unsafe or duplicate manifest path')
        seen.add(rel);f=root/rel
        if f.is_symlink() or not f.is_file():raise RuntimeError('not a regular payload file: '+rel)
        b=f.read_bytes()
        if len(b)!=rec['bytes'] or hashlib.sha256(b).hexdigest()!=rec['sha256']:
            raise RuntimeError('checksum mismatch: '+rel)
    print(json.dumps(dict(verified=True,count=len(seen),manifest_self_hash_in_external_handoff=True)))
    return len(seen)
if __name__=='__main__':verify()
