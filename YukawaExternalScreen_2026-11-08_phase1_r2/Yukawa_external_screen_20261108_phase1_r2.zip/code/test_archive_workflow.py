#!/usr/bin/env python3
"""Cold-archive helper and documented-chain tests; evidence is outside the input ZIP.
Usage: python3 code/test_archive_workflow.py ARCHIVE.zip OUTPUT.json
"""
from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,sys,tempfile,zipfile,stat
R=Path(__file__).resolve().parents[1]

def digest(b):return hashlib.sha256(b).hexdigest()
def verify_zip(path):
    with zipfile.ZipFile(path) as z:
        infos=z.infolist();names=[i.filename for i in infos]
        if len(names)!=len(set(names)) or len(names)>1000 or sum(i.file_size for i in infos)>50_000_000:raise RuntimeError('unsafe archive size/duplicates')
        for i in infos:
            p=PurePosixPath(i.filename)
            if p.is_absolute() or '..' in p.parts or stat.S_ISLNK(i.external_attr>>16):raise RuntimeError('unsafe archive member')
        if z.testzip() is not None:raise RuntimeError('CRC failure')
        m=json.loads(z.read('MANIFEST.json'))
        if set(names)!={r['path'] for r in m['files']}|{'MANIFEST.json'}:raise RuntimeError('manifest coverage')
        for rec in m['files']:
            b=z.read(rec['path'])
            if len(b)!=rec['bytes'] or digest(b)!=rec['sha256']:raise RuntimeError('payload checksum')
        return len(names)
def extract(path,w):
    verify_zip(path)
    with zipfile.ZipFile(path) as z:
        for i in z.infolist():
            f=w/i.filename;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z.read(i))
def science(w):
    return {str(p.relative_to(w)):digest(p.read_bytes()) for d in ['data','figures'] for p in (w/d).iterdir() if p.is_file()}
def run(w,flags,script):
    p=subprocess.run([sys.executable]+flags+[str(w/'code'/script)],cwd=w,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(script+': '+p.stdout+p.stderr)
    try:out=json.loads(p.stdout)
    except json.JSONDecodeError:out=dict(stdout=p.stdout)
    return out

def main(archive,outpath):
    (R/'delivery').mkdir(parents=True,exist_ok=True)
    count=verify_zip(archive);records=[]
    for flags in [[],['-O']]:
        mode='optimized' if flags else 'normal'
        for scenario in ['archived_pack_without_reproduce','archived_regress_without_reproduce','documented_chain']:
            with tempfile.TemporaryDirectory(prefix='cold_',dir=R/'delivery') as td:
                w=Path(td);extract(archive,w)
                if (w/'delivery').exists():raise RuntimeError('archive unexpectedly provides delivery directory')
                before=science(w)
                record=dict(mode=mode,scenario=scenario,delivery_initially_absent=True)
                record['verify_before']=run(w,flags,'verify_manifest.py')
                # Gate archived bytes before any regeneration, in every scenario.
                record['archived_data_gate']=run(w,flags,'data_gate.py')
                if scenario=='archived_pack_without_reproduce':
                    record['pack']=run(w,flags,'pack.py')
                    record['pack'].pop('archive',None)
                    nz=w/'delivery/Yukawa_external_screen_20261108_phase1_r2.zip'
                    record['selfpacked_archive_members']=verify_zip(nz)
                    record['verify_after_pack']=run(w,flags,'verify_manifest.py')
                    record['delivery_created_automatically']=(w/'delivery').is_dir()
                elif scenario=='archived_regress_without_reproduce':
                    record['regression']=run(w,flags,'regress_guard.py')
                    record['delivery_created_automatically']=(w/'delivery').is_dir()
                    if record['regression'].get('count')!=34:raise RuntimeError('original regression scope')
                else:
                    archived_validation_hash=digest((w/'checks/validation.json').read_bytes())
                    record['reproduce']=run(w,flags,'reproduce.py')
                    record['fresh_validation_sha256']=digest((w/'checks/validation.json').read_bytes())
                    record['fresh_validation_byte_identical_to_archived']=(archived_validation_hash==record['fresh_validation_sha256'])
                    if record['reproduce'].get('count')!=85 or record['reproduce'].get('passed') is not True:raise RuntimeError('numeric scope')
                    record['data_gate_after_reproduce']=run(w,flags,'data_gate.py')
                after=science(w)
                same={k:(v==after[k]) for k,v in before.items()}
                record['CSV_byte_identical_count']=sum(v for k,v in same.items() if k.startswith('data/'))
                record['plot_byte_identical_count']=sum(v for k,v in same.items() if k.startswith('figures/'))
                record['science_hash_comparison']=same
                if scenario!='documented_chain' and not all(same.values()):raise RuntimeError('helper changed archived science bytes')
                # Environment-dependent regenerated floats are judged by the unchanged
                # science controls and actual-data gate, not by a new fit tolerance.
                record['passed']=True;records.append(record)
    report=dict(passed=True,archive_path=str(archive),archive_bytes=archive.stat().st_size,
                archive_sha256=digest(archive.read_bytes()),safe_manifest_verified_members=count,
                cold_scenarios=records,science_inputs_not_regenerated_in_archived_helper_tests=True,
                scope='technical_portability_and_publication_helpers_no_new_physical_evidence')
    outpath.parent.mkdir(parents=True,exist_ok=True)
    outpath.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(passed=True,scenarios=len(records),archive_sha256=report['archive_sha256'])))
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('usage: test_archive_workflow.py ARCHIVE.zip OUTPUT.json')
    main(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve())
