#!/usr/bin/env python3
"""Explicit data-integrity gate for this synthetic phase-1 payload, not a physics audit."""
from pathlib import Path
import csv,sys,json
import numpy as np
from weak_field import alpha,g_ratio,force_kernel,cylinder_fields,G_LAB,tower_fourier_point
ROOT=Path(__file__).resolve().parents[1]

def reject(msg):raise ValueError(msg)
def read(root,name):
    with (root/'data'/name).open(newline='') as f:r=list(csv.DictReader(f))
    if not r:reject('empty '+name)
    return r

def num(row,key):
    try:v=float(row[key])
    except (KeyError,ValueError,TypeError):reject('missing/non-numeric '+key)
    if not np.isfinite(v):reject('nonfinite '+key)
    return v

def close(x,y,name):
    if not np.isfinite(x) or not np.isfinite(y) or not np.isclose(x,y,rtol=3e-12,atol=1e-18):reject('wrong value '+name)

# At most four binary64 spacings of each prescribed coordinate. This is a
# coordinate serialization/geomspace portability allowance, NOT a physics tolerance.
GRID_MAX_ULPS=4

def grid(rows,cols,expected,name):
    keys=[tuple(num(r,k) for k in cols) for r in rows]
    prescribed=[tuple(float(v) for v in key) for key in expected]
    if len(keys)!=len(prescribed):reject('wrong/missing grid count '+name)
    if not prescribed or any(len(k)!=len(cols) for k in prescribed):reject('invalid prescribed grid '+name)
    E=np.asarray(prescribed,dtype=float)
    if np.any(~np.isfinite(E)):reject('nonfinite prescribed grid '+name)
    if len(prescribed)!=len(set(prescribed)):reject('duplicate prescribed grid '+name)
    if len(keys)!=len(set(keys)):reject('duplicate '+name)
    tolerance=GRID_MAX_ULPS*np.spacing(np.abs(E))
    if np.any(~np.isfinite(tolerance)):reject('invalid coordinate spacing '+name)
    assigned=set();canonical=[]
    for key in keys:
        # Finite input was checked by num(); no assert-dependent integrity checks.
        with np.errstate(over='ignore',invalid='ignore'):
            candidates=np.flatnonzero(np.all(np.abs(E-np.asarray(key))<=tolerance,axis=1))
        if len(candidates)!=1:reject('unmatched/ambiguous grid cell '+name)
        index=int(candidates[0])
        if index in assigned:reject('double assigned grid cell '+name)
        assigned.add(index);canonical.append(prescribed[index])
    if len(assigned)!=len(prescribed):reject('missing grid cell '+name)
    return canonical

def gate(root=ROOT):
    rr=read(root,'geometry_diagnostics.csv')
    ds=[float(x) for x in np.geomspace(.1,1e5,121)]
    grid(rr,['L_m','a','distance_m'],[(L,a,d) for L in [1000.,10000.] for a in [1.,.001] for d in ds],'geometry')
    for r in rr:
        # Every field in this table is numeric and must be finite, including controls.
        for k in r:num(r,k)
        L,a,d=(num(r,k) for k in ['L_m','a','distance_m'])
        q=alpha(a);g=g_ratio(a);N,Y=cylinder_fields(d,1000.,10000.,L)
        expected=dict(alpha=q,kappa_point=float(force_kernel(d/L)),kappa_cylinder=Y/N,
            cylinder_radius_m=10000.,cylinder_thickness_m=1000.,
            G_pair_over_ideal_Glab=g*(1+q*force_kernel(d/L)),
            G_cylinder_over_ideal_Glab=g*(1+q*Y/N),
            Newton_cylinder_shape_m=N,Yukawa_unit_alpha_shape_m=Y,Gstar_over_ideal_Glab=g,
            source_density_kg_m3=2000.,Newton_Glab_acceleration_m_s2=2*np.pi*G_LAB*2000*N,
            tensor_acceleration_m_s2=2*np.pi*G_LAB*g*2000*N,
            scalar_acceleration_m_s2=2*np.pi*G_LAB*g*q*2000*Y,
            total_acceleration_m_s2=2*np.pi*G_LAB*g*2000*(N+q*Y))
        for k,v in expected.items():close(num(r,k),v,k)
    rr=read(root,'calibration_geometry.csv')
    names=['point_1m','point_1000m','point_10000m','cylinder_R10km_t1km_z100m']
    keys=[(num(r,'L_m'),r['geometry']) for r in rr]
    if len(keys)!=8 or len(set(keys))!=8 or set(keys)!={(L,n) for L in [1000.,10000.] for n in names}:reject('calibration grid')
    for r in rr:
        L=num(r,'L_m');n=r['geometry']
        if n.startswith('point_'):k=float(force_kernel(float(n[6:-1])/L))
        else:
            N,Y=cylinder_fields(100,1000,10000,L);k=Y/N
        expected=dict(a=1.,alpha=alpha(1),kappa_cal=k,Gstar_over_fittedG=g_ratio(1,k),ideal_g=g_ratio(1),relative_g_change=g_ratio(1,k)/g_ratio(1)-1)
        for key,val in expected.items():close(num(r,key),val,key)
    rr=read(root,'compact_calibration_bound.csv')
    grid(rr,['L_m','max_pair_separation_m'],[(L,D) for L in [1000.,10000.] for D in [1.,10.,100.,1000.]],'compact')
    for r in rr:
        L=num(r,'L_m');D=num(r,'max_pair_separation_m');close(num(r,'a'),1.,'a')
        close(num(r,'max_relative_g_vs_ideal'),(1+alpha(1))/(1+alpha(1)*force_kernel(D/L))-1,'compact bound')
    rr=read(root,'parameter_screen.csv')
    screen_keys=grid(rr,['a','L_m'],[(1.,1000.),(1.,10000.)],'screen')
    for r,canonical_key in zip(rr,screen_keys):
        L=canonical_key[1]
        for k,v in [('alpha',alpha(1)),('ideal_g',g_ratio(1)),('physical_lambda_m',L)]:close(num(r,k),v,k)
        if L==1000.:
            close(num(r,'reported_abs_alpha_bound'),.001,'Cruz published bound')
            close(num(r,'ratio_to_reported_bound'),alpha(1)/.001,'ratio')
            expected=('Cruz1991_primary_abstract','incompatible_with_reported_bound_CL_unspecified','unresolved_primary_confidence_and_fulltext_convention_gap','not_stated_in_consulted_primary_abstract')
        else:
            if r['reported_abs_alpha_bound'] or r['ratio_to_reported_bound']:reject('invented 10km bound')
            expected=('primary_10km_transfer_missing','unresolved_primary_range_and_response_gap','unresolved_mapping_source_gap','none_assigned')
        if tuple(r[k] for k in ['source','classification','formal_category','confidence'])!=expected:reject('changed source/qualification')
    rr=read(root,'necessary_not_sufficient_window.csv')
    if len(rr)!=1:reject('window rows')
    for k,v in dict(L_m=1000.,alpha_min=0.,alpha_upper_open=.001,a_min=0.,a_upper_open=4*np.pi*.001).items():close(num(rr[0],k),v,k)
    if rr[0]['status']!='necessary_only_from_Cruz_abstract_not_verified_allowed_region':reject('window overclaim')
    rr=read(root,'synthetic_tower_operator.csv')
    grid(rr,['L_m','depth_m','height_m'],[(L,d,454.) for L in [1000.,10000.] for d in [100.,1000.,5000.,10000.]],'tower')
    for r in rr:
        close(num(r,'normalized_residual'),tower_fourier_point(num(r,'height_m'),num(r,'depth_m'),num(r,'L_m')),'tower operator')
        if r['status']!='synthetic_source_not_BREN_fit':reject('synthetic status')
    report=json.loads((root/'checks/validation.json').read_text())
    cc=report.get('checks',[])
    if report.get('passed') is not True or report.get('count')!=85 or len(cc)!=85:reject('scientific control report scope/status')
    if len({c.get('name') for c in cc})!=85:reject('duplicate scientific control')
    for c in cc:
        if c.get('passed') is not True:reject('failed scientific control')
        if 'actual' not in c:
            if not c.get('name','').startswith('reject_bad_coupling_'):reject('control values missing')
            continue
        a=np.asarray(c['actual'],dtype=float);e=np.asarray(c['expected'],dtype=float)
        rt=float(c['rtol']);at=float(c['atol']);er=float(c['max_abs_error'])
        if np.any(~np.isfinite(a)) or np.any(~np.isfinite(e)) or not np.all(np.isfinite([rt,at,er])):reject('nonfinite scientific control')
        if a.shape!=e.shape or rt<0 or rt>2e-7 or at<0 or at>1e-8 or not np.allclose(a,e,rtol=rt,atol=at):reject('invalid scientific control data')
    result=dict(passed=True,CSV_tables=6,geometry_rows=484,scope='finite_grid_units_calibration_normalization_source_qualification_only')
    return result
if __name__=='__main__':
    try: print(json.dumps(gate(Path(sys.argv[1]) if len(sys.argv)>1 else ROOT)))
    except Exception as e: print('DATA GATE REJECTED: '+str(e),file=sys.stderr);sys.exit(1)
