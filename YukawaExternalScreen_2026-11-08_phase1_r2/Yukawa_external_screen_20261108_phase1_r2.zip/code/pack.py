#!/usr/bin/env python3
"""Generate the distributable payload and noncircular manifest. No upload."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
def main():
    from data_gate import gate
    gate(R)
    payload=[]
    for name in ['README_HU.md','LICENSE.txt','requirements.txt']:
        payload.append(R/name)
    for name in ['code','notes','sources','data','figures','checks']:
        for f in sorted((R/name).iterdir()):
            if f.is_file() and not f.name.startswith('.'):
                payload.append(f)
    if not json.loads((R/'checks/validation.json').read_text())['passed']:raise RuntimeError('validation not passed')
    if not json.loads((R/'checks/replay_controls.json').read_text())['passed']:raise RuntimeError('replay controls not passed')
    files=[]
    for f in payload:
        if f.is_symlink():raise RuntimeError('symlink payload')
        b=f.read_bytes();files.append(dict(path=f.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
    m=dict(algorithm='SHA256',exclusion='MANIFEST.json excludes itself; its hash and archive hash are in external handoff.json',files=files)
    (R/'MANIFEST.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
    out=R/'delivery/Yukawa_external_screen_20261108_phase1_r2.zip'
    out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in payload+[R/'MANIFEST.json']:
            zi=zipfile.ZipInfo(f.relative_to(R).as_posix(),date_time=(2026,11,8,12,0,0))
            zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
            z.writestr(zi,f.read_bytes())
    print(json.dumps(dict(archive=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),files=len(files)+1)))
if __name__=='__main__':main()
