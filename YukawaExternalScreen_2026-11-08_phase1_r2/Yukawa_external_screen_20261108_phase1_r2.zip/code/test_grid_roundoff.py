#!/usr/bin/env python3
"""Narrow coordinate-portability tests; no physical coefficients or data are fitted."""
from pathlib import Path
import csv,json,shutil,subprocess,sys,tempfile
import numpy as np
from data_gate import grid,gate,GRID_MAX_ULPS
R=Path(__file__).resolve().parents[1]

def worker():
    results=[]
    base=[1.25,2.5,5.]
    def steps(x,n,direction=np.inf):
        for _ in range(n):x=float(np.nextafter(x,direction))
        return x
    def direct(name,values,expected,accept,reason=None):
        try:grid([dict(x=v) for v in values],['x'],[(v,) for v in expected],name)
        except ValueError as e:
            if accept or (reason and reason not in str(e)):raise RuntimeError(name+': unexpected rejection '+str(e))
            results.append(dict(name=name,expected='reject',passed=True,reason=str(e)))
        else:
            if not accept:raise RuntimeError(name+': invalid grid accepted')
            results.append(dict(name=name,expected='accept',passed=True))
    direct('prescribed_grid',base,base,True)
    direct('row_reordering',list(reversed(base)),base,True)
    direct('one_ULP_up',[steps(x,1) for x in base],base,True)
    direct('one_ULP_down',[steps(x,1,0.) for x in base],base,True)
    direct('four_ULP_boundary',[steps(x,4) for x in base],base,True)
    direct('five_ULP_outside',[steps(x,5) for x in base],base,False,'unmatched')
    direct('finite_real_shift',[base[0]*(1+1e-8)]+base[1:],base,False,'unmatched')
    direct('near_duplicate_double_assignment',[base[0],steps(base[0],1),base[2]],base,False,'double assigned')
    direct('exact_duplicate',[base[0],base[0],base[2]],base,False,'duplicate')
    direct('missing_row',base[:-1],base,False,'count')
    direct('extra_row',base+[10.],base,False,'count')
    direct('NaN_coordinate',[float('nan')]+base[1:],base,False,'nonfinite')
    direct('Inf_coordinate',[float('inf')]+base[1:],base,False,'nonfinite')
    direct('nonfinite_prescribed_grid',base,[float('nan')]+base[1:],False,'nonfinite')
    direct('duplicate_prescribed_grid',base,[base[0],base[0],base[2]],False,'duplicate prescribed')
    overlap=[1.25,steps(1.25,1),5.]
    direct('ambiguous_prescribed_cells',overlap,overlap,False,'ambiguous')
    ds=[float(x) for x in np.geomspace(.1,1e5,121)]
    direct('all_121_coordinates_one_ULP',[steps(x,1) for x in ds],ds,True)
    def end_to_end(name,mutation,accept,reason=None):
        (R/'delivery').mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='roundoff_',dir=R/'delivery') as td:
            w=Path(td);shutil.copytree(R/'data',w/'data');shutil.copytree(R/'checks',w/'checks')
            mutation(w)
            try:gate(w)
            except ValueError as e:
                if accept or (reason and reason not in str(e)):raise RuntimeError(name+': '+str(e))
                results.append(dict(name=name,expected='reject',passed=True,reason=str(e)))
            else:
                if not accept:raise RuntimeError(name+': invalid dataset accepted')
                results.append(dict(name=name,expected='accept',passed=True))
    def mutate_csv(w,name,fn):
        p=w/'data'/name
        with p.open(newline='') as f:r=csv.DictReader(f);fields=r.fieldnames;rows=list(r)
        fn(rows)
        with p.open('w',newline='') as f:t=csv.DictWriter(f,fieldnames=fields);t.writeheader();t.writerows(rows)
    selected={1,13,27,39,54,71,96,119}
    def roundoff(w):
        def f(rows):
            for i,r in enumerate(rows):
                if (i//2)%121 in selected:r['distance_m']=repr(steps(float(r['distance_m']),1))
        mutate_csv(w,'geometry_diagnostics.csv',f)
    end_to_end('archived_eight_distinct_distances_one_ULP',roundoff,True)
    def near(w):
        def f(rows):rows[-1]['distance_m']=repr(steps(float(rows[-3]['distance_m']),1))
        mutate_csv(w,'geometry_diagnostics.csv',f)
    end_to_end('archived_near_duplicate_cell',near,False,'double assigned')
    def shift(w):
        def f(rows):rows[0]['distance_m']=repr(float(rows[0]['distance_m'])*(1+1e-8))
        mutate_csv(w,'geometry_diagnostics.csv',f)
    end_to_end('archived_finite_real_shift',shift,False,'unmatched')
    def nan(w):
        mutate_csv(w,'geometry_diagnostics.csv',lambda rows:rows[0].update(distance_m='nan'))
    end_to_end('archived_NaN_coordinate',nan,False,'nonfinite')
    def missing(w):mutate_csv(w,'geometry_diagnostics.csv',lambda rows:rows.pop())
    end_to_end('archived_missing_row',missing,False,'count')
    def screen(w):
        mutate_csv(w,'parameter_screen.csv',lambda rows:rows[0].update(L_m=repr(steps(1000.,1))))
    end_to_end('canonical_screen_branch_one_ULP',screen,True)
    return dict(passed=True,count=len(results),max_coordinate_ULPs=GRID_MAX_ULPS,
                physics_tolerances_changed=False,checks=results)

if __name__=='__main__':
    if '--worker' in sys.argv:print(json.dumps(worker()))
    else:
        reports=[]
        for flags in [[],['-O']]:
            p=subprocess.run([sys.executable]+flags+[__file__,'--worker'],capture_output=True,text=True)
            if p.returncode:raise RuntimeError(p.stderr)
            r=json.loads(p.stdout);r['mode']='optimized' if flags else 'normal';reports.append(r)
        out=dict(passed=True,count=sum(r['count'] for r in reports),modes=reports,
                 scope='machine_precision_bijective_grid_acceptance_and_rejection_only')
        (R/'checks/grid_roundoff.json').write_text(json.dumps(out,indent=2)+'\n')
        print(json.dumps(dict(passed=True,total=out['count'],per_mode=[r['count'] for r in reports])))
