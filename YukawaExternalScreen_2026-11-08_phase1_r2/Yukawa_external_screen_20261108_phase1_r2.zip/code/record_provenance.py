"""Used once for provenance. Not needed by the offline reproduction."""
from pathlib import Path
import hashlib,json,urllib.request
R=Path(__file__).resolve().parents[1]
P=Path('/workspace/yukawa_tidal_pilot_20261108_r4')
rows=[]
for f in ['sources/binding_energy_EN.tex','sources/ns_yukawa_EN_r3.tex','sources/step27_rederivation_method_en.md','notes/levezetes_HU.md']:
    b=(P/f).read_bytes()
    rows.append(dict(relative_path=f,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(R/'sources/r4_inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
private=[]
for n in ['osti_6190822.pdf','osti_7173840.pdf','murata2014.pdf','adelberger2003.pdf','fischbach1996.pdf','march2019.pdf']:
    b=(Path('/workspace/step27_refs')/n).read_bytes()
    if not b.startswith(b'%PDF-'):raise ValueError('not a PDF')
    private.append(dict(filename=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),
        distribution='not_in_research_archive; local read-only evidence',source='prior Step27 local reference'))
(R/'sources/consulted_private_documents.json').write_text(json.dumps(private,indent=2)+'\n')
u='https://api.crossref.org/works/10.1029/91JB01756'
req=urllib.request.Request(u,headers={'User-Agent':'YukawaWeakFieldResearch/1.0 (public bibliographic metadata)'})
b=urllib.request.urlopen(req,timeout=40).read()
(R/'private_sources/cruz_crossref.json').write_bytes(b)
m=json.loads(b)['message']
if m['DOI'].lower()!='10.1029/91jb01756':raise ValueError('DOI mismatch')
rec=dict(source='publisher-deposited primary abstract via public Crossref record',url=u,
         retrieved_local_date='2026-11-08 Europe/Zurich',raw_record_bytes=len(b),raw_record_sha256=hashlib.sha256(b).hexdigest(),
         title=m['title'][0],doi=m['DOI'],location='abstract, last sentence',
         paraphrased_fact='At lambda=1000 m the reported absolute Yukawa alpha bound is 0.001.',
         confidence='not stated in the abstract',full_text_obtained=False,
         retained_excerpt='the absolute value of α must be less than 0.001 for λ = 1000 m')
(R/'sources/cruz_primary_record.json').write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n')
print('Provenance recorded; copyrighted documents excluded from distribution.')
