"""SI weak dust limit of the r4 epsilon-source action; no experimental likelihood."""
import numpy as np
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss

G_LAB = 6.67430e-11
C = 299792458.0
MSUN = 1.988409870698051e30

def positive(x, name):
    if not np.isfinite(x) or x <= 0:
        raise ValueError(name + ' must be finite and positive')
    return float(x)

def alpha(a):
    if not np.isfinite(a) or a < 0: raise ValueError('a must be finite and nonnegative')
    return float(a)/(4*np.pi)

def force_kernel(x):
    x=np.asarray(x,dtype=float)
    if np.any(~np.isfinite(x)) or np.any(x<0): raise ValueError('x invalid')
    return (1+x)*np.exp(-x)

def g_ratio(a, kappa_cal=1.):
    q=alpha(a)
    if not np.isfinite(kappa_cal) or 1+q*kappa_cal<=0: raise ValueError('calibration invalid')
    return 1/(1+q*kappa_cal)

def pair_ratio(d, L, a=1., kappa_cal=1.):
    return g_ratio(a,kappa_cal)*(1+alpha(a)*force_kernel(positive(d,'d')/positive(L,'L')))

def sphere_scaled(x):
    """exp(-x)*F(x), avoids overflow when R/L is large."""
    if not np.isfinite(x) or x<0: raise ValueError('x invalid')
    if x<.05:
        return np.exp(-x)*(1+x*x/10+x**4/280+x**6/15120+x**8/1330560)
    return 1.5*((x-1)+(x+1)*np.exp(-2*x))/x**3

def sphere_yukawa(r, R, L, derivative=False):
    """Positive potential magnitude per G*M, or inward force per G*M."""
    positive(r,'r'); positive(R,'R'); positive(L,'L')
    if r<R: raise ValueError('outside sphere only')
    s=sphere_scaled(R/L)*np.exp(-(r-R)/L)
    return s*(1+r/L)/r**2 if derivative else s/r

def sphere_quadrature(r,R,L,n=96):
    """Independent volume quadrature: Newton force, Yukawa potential, force per GM."""
    if r<=R: raise ValueError('strictly outside')
    x,w=leggauss(n); s=R*(x+1)/2; ws=R*w/2
    S=s[:,None]; mu=x[None,:]
    D=np.sqrt(r*r+S*S-2*r*S*mu)
    W=3/(2*R**3)*S*S*ws[:,None]*w[None,:]
    P=np.sum(W*np.exp(-D/L)/D)
    FN=np.sum(W*(r-S*mu)/D**3)
    FY=np.sum(W*(r-S*mu)/D**3*force_kernel(D/L))
    return float(FN),float(P),float(FY)

def sphere_pair_kappa(d,R1,R2,L):
    if d<=R1+R2: raise ValueError('spheres must not overlap')
    return sphere_scaled(R1/L)*sphere_scaled(R2/L)*np.exp(-(d-R1-R2)/L)*(1+d/L)

def sphere_pair_quadrature(d,R1,R2,L,n=96):
    """Integrate exact source-sphere field over the finite receiving sphere."""
    x,w=leggauss(n); s=R2*(x+1)/2; ws=R2*w/2
    S=s[:,None]; mu=x[None,:]; rt=np.sqrt(d*d+S*S-2*d*S*mu)
    W=3/(2*R2**3)*S*S*ws[:,None]*w[None,:]
    scale=sphere_scaled(R1/L)*np.exp(-(rt-R1)/L)
    fy=np.sum(W*scale*(1+rt/L)*(d-S*mu)/rt**3)
    return float(fy*d*d)

def cylinder_fields(z,t,A,L):
    """Downward N and unit-alpha Y accelerations per 2*pi*G*rho.
    Cylinder top z=0, bottom=-t, receiver at z>0; radius A. Units m.
    """
    for name,val in [('z',z),('t',t),('A',A),('L',L)]: positive(val,name)
    r0=np.hypot(A,z); r1=np.hypot(A,z+t)
    # Rationalization prevents loss in the Newtonian thin/small-source limit.
    N=t-t*(2*z+t)/(r0+r1)
    # expm1 retains short slab and large-L behavior.
    Y=L*(-np.exp(-z/L)*np.expm1(-t/L)
         +np.exp(-r0/L)*np.expm1(-(r1-r0)/L))
    return N,Y

def cylinder_quadrature(z,t,A,L,n=100):
    x,w=leggauss(n); b=A*(x+1)/2; wb=A*w/2; s=t*(x+1)/2; ws=t*w/2
    B=b[:,None]; Z=z+s[None,:]; D=np.hypot(B,Z)
    W=wb[:,None]*ws[None,:]*B*Z/D**3
    return float(np.sum(W)),float(np.sum(W*force_kernel(D/L)))

def slab_y(z,t,L):
    return L*np.exp(-z/L)*(-np.expm1(-t/L))

def tower_fourier_point(h,d,L):
    """Observed-minus-Newton-upward-continued scalar force at axis,
    normalized by G*alpha*M/d^2. Source at depth d below continuation plane.
    Infinite plane, NOT the BREN survey estimator.
    """
    positive(d,'d');positive(L,'L')
    if h<0 or not np.isfinite(h):raise ValueError('h invalid')
    x=d/L; H=h/d
    def f(t):
        p=np.hypot(t,x)
        dp=x*x/(p+t) if p+t else 0.
        return t*np.exp(-p-H*t)*np.expm1(-H*dp)
    return quad(f,0,np.inf,epsabs=2e-13,epsrel=2e-11,limit=300)[0]

def tower_fourier_separate(h,d,L):
    x=d/L;H=h/d
    true=force_kernel((d+h)/L)/(1+H)**2
    pred=quad(lambda t:t*np.exp(-np.hypot(t,x)-H*t),0,np.inf,epsabs=2e-13,epsrel=2e-11)[0]
    return float(true-pred)
