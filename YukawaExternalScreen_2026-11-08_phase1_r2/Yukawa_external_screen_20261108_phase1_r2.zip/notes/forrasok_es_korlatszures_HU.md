# Forráslánc és az alkalmazott korlátszűrés

Az alábbiakban külön szerepel az eredeti mérési közlés, az áttekintő görbe és a saját szintetikus diagnosztika. A kutatási ZIP nem tartalmazza a folyóiratcikkek vagy könyvek másolatát. A helyben olvasott PDF-ek hash-e a `sources/consulted_private_documents.json` fájlban van.

## Közvetlenül ellenőrzött elsődleges absztraktusok

**Cruz és munkatársai (1991)**, JGR 96(B12), 20073–20092, DOI [10.1029/91JB01756](https://doi.org/10.1029/91JB01756). Ellenőrzött hely: a kiadó által Crossrefbe letett absztraktus utolsó mondata; nyilvános [rekord](https://api.crossref.org/works/10.1029/91JB01756), hash/lekérés a `sources/cruz_primary_record.json` fájlban. Nyolc magasság a 300 m-es Erie-tornyon; a felszíni adatok Newtoni felfelé folytatásával hasonlítanak össze. Az absztraktus λ=1000 m esetén |α|<0.001 értéket közöl. Az ott közölt hibák és 10 μGal rms nem saját likelihoodunk. Az absztraktus nem ad konfidenciaszintet. A cikk geometriai és statisztikai részletei nem voltak hozzáférhetők; ezért nem rendelünk hozzá utólag 95%-ot. A tábla az egyértelműen megadott 1 km-es egyenlőtlenséget használja, standard univerzális Yukawa-normalizálás feltételével, nem továbbskálázott 10 km-es görbét.

**Jekeli, Eckhardt, Romaides (1990)**, PRL 64, 1204–1206, DOI [10.1103/PhysRevLett.64.1204](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.64.1204). Ellenőrzött hely: kiadói absztraktus. A korábbi toronyanomália topográfiai korrekció után eltűnik, α<0.001 szerepel. A λ-tartomány és konfidenciaszint nem szerepel az olvasott absztraktusban. Ezért a számot sem az 1 km, sem a 10 km pont további független kizárására nem alkalmazzuk.

**Zumberge és munkatársai (1991)**, PRL 67, 3051–3054, DOI [10.1103/PhysRevLett.67.3051](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.67.3051). Ellenőrzött hely: kiadói absztraktus. Négy profil 5000 m-ig, G=(6.677±0.013)×10⁻¹¹ SI, 0.1 mGal felbontás. Az absztraktus önmagában nem közöl α(λ) likelihoodot. Egyetlen effektív távolsággal és a mostani G_lab számmal nem reprodukálható ez a véges óceánkísérlet. A March-cikkből örökölt 10 km-es meghosszabbítást nem tekintjük elsődleges adatból ellenőrzött korlátnak.

**Romaides és munkatársai (1994)**, PRD 50, 3608–3613, DOI [10.1103/PhysRevD.50.3608](https://journals.aps.org/prd/abstract/10.1103/PhysRevD.50.3608). Ellenőrzött hely: kiadói absztraktus. WABG 610 m-es torony, 8 km-es helyi és 300 km-ig gyűjtött felszíni adatok; −33±30 μGal eltérés 493 m-en. A ± jel statisztikai értelmét és az α–λ átvitelt nem állapítjuk meg pusztán ebből.

**Romaides, Sands, Fischbach, Talmadge (1997)**, PRD 55, 4532–4536, DOI [10.1103/PhysRevD.55.4532](https://journals.aps.org/prd/abstract/10.1103/PhysRevD.55.4532). Ellenőrzött hely: kiadói absztraktus. Az új, 568 m-es pont eltérése 32±32 μGal. A 610 m a torony mérete, nem egy megállapított Yukawa-λ felső határ. E maradékok nem önmagukban pont-pont erőkorlátok.

## Elsődleges nyílt jelentés: BREN

P. Kasameyer, J. Thomas és munkatársai, **UCRL-101001**, 1989. május 22., „A Test of Newton's Law of Gravity Using the BREN Tower, Nevada”, [OSTI 6190822](https://www.osti.gov/biblio/6190822). A helyi valódi PDF-et olvastuk; a dokumentum címlapja szerint előzetes konferenciajelentés, nem azonos az alábbi folyóiratcikkel.

Pontos PDF-helyek: 3. oldal absztraktus: 12 mérési magasság 454 m-ig, 91 közeli felszíni pont és 60 000 regionális adat 300 km-ig; 93±95 μGal. A 6–7. oldali (4)–(7) egyenletek a Laplace/Poisson felfelé folytatást írják le. A 11. oldalon a 95 μGal mintavételi szórásként szerepel, a 12. oldalon az azonos magasságú gömbi közelítés mintegy 100 μGal szisztematikus hatásáról van szó. A 13. oldali regionális síklevonás is része az operátornak.

Ez elegendő a mérési elv és a szükséges átviteli egyenlet azonosításához, nem elegendő a valódi kísérlet 10 km-es Yukawa-likelihoodjának kiszámításához. A `synthetic_tower_operator.csv` nem az ő adataikra illesztés. A folyóiratos utód Thomas és munkatársai, PRL 63, 1902 (1989), DOI 10.1103/PhysRevLett.63.1902; a korábbi jelentés számait nem nevezzük át annak adataivá.

## Áttekintések és régi saját szcenáriók: csak tájékozódás

* Murata–Tanaka, arXiv:1408.3588, Fig. 1: pozitív α, áttekintő 95%-os burkoló; az eredeti kilométeres mérések ellenőrzése nélkül nem digitizálunk belőle új elsődleges kizárást.
* Adelberger–Heckel–Nelson, arXiv:hep-ph/0307284, Fig. 4: összefoglaló 95%-os görbe. Nem helyettesíti az adott forrás válaszfüggvényét és konvencióját.
* Fischbach–Talmadge, arXiv:hep-ph/9606249, Fig. 1: a negatív α ábrája; előjelváltással nem alkalmazzuk a jelen pozitív skalárra.
* March és munkatársai, PRD 100, 042002 (2019), arXiv:1904.12789: másik NMC-modell, többek közt Zumberge-adatok másodlagos idézésével. Nem azonos az itt vizsgált hatással.

Az r4-ben őrzött `step27_rederivation_method_en.md` kifejezetten ellenőrizetlen, feltételes saját újralevezetésnek nevezi a 10 km-es óceán- és sík-féltér toronyhatárokat. Rögzíti a sűrűség-, terep-, adatsúlyozási és hibastatisztikai réseket, valamint az óceán rétegformula eltérését. E szcenáriókat ez a csomag nem emeli publikált kísérleti korláttá. A 0.079577… itt az a=1 modell erőssége; nem egy önállóan ellenőrzött külső α-felsőhatár.

## A két pilot pont státusza

| a | L | Alkalmazott evidencia | Státusz |
|---|---|---|---|
| 1 | 1 km | Cruz elsődleges absztraktus: abs(α)<0.001 λ=1 km-nél; q=0.07957747 | A közölt korlát szerint összeférhetetlen, a standard univerzális, árnyékolatlan dust-Yukawa leképezés mellett. A hányados 79.58, **nem σ-szignifikancia**. A forrás absztraktusában CL nincs megadva; nem állítunk 95%-os új kizárást. |
| 1 | 10 km | A vizsgált elsődleges absztraktusokból nincs ellenőrzött 10 km-es átviteli függvény/α-limit | Nyitott elsődleges forrás- és operátorrés. Nem „engedélyezett” pont, és nem igazolt „nem kizárt” tartomány. |

A formális, megadott CL-hez kötött kizárási kategóriába az 1 km-es pontot sem emeljük az absztraktuson túl: a `formal_category` oszlop ott az elsődleges konfidencia-/részletes normalizálásrésre utal, míg a külön `classification` a közölt egyenlőtlenséggel való összeférhetetlenséget őrzi. A két szintet nem mossuk össze.

A 1 km-es pontot nem javasoljuk GR-utánzási fő célpontnak e közölt korláttal szemben. L=1 km-nél a 0≤a<4π×0.001=0.0125663706 pusztán **szükséges, nem elégséges** feltétel a most olvasott egyetlen egyenlőtlenség alapján. Más kísérletek szűkíthetik; a konfidenciaszint és a részletes kísérleti konvenció további forrásellenőrzést igényel. A grafikonon szereplő a=0.001 csak kis-csatolású érzékenységi példa, nem igazolt megengedett pont, különösen nem 10 km-nél.

## A következő, még ebbe a fázisba tartozó szükséges lépés

Elsődleges, λ=10 km-re alkalmazható pozitív/univerzális Yukawa-görbe és annak normalizálása/CL-je, vagy a valódi felszíni-torony adatfeldolgozó operátor és forrásmodell szükséges. A hiány nem új, a felhasználótól választandó paraméter; forrás- és adatbeszerzési feladat. A kiadói absztraktusokat és a helyi nyílt jelentést ellenőriztük; több folyóiratszöveg hozzáférési korlátos, a Cruz oldala nem adott olvasható szöveget. A Semantic Scholar dokumentált nyilvános metaadat-API-jában a Cruz-, Jekeli- és 1997-es WABG-cikkhez nem szerepelt nyílt PDF-link (CLOSED rekord; `sources/open_access_checks.json`). Ez nem bizonyítja, hogy nincs szerzői példány. Jogosult könyvtári hozzáféréssel vagy szerzői kézirattal pótolható; a fizetős hozzáférést nem kerültük meg.

Nem helyettesítjük ezt mikrométeres Eöt-Wash-korláttal, pont-Nap PPN-becsléssel, összetételfüggő ötödikerő-teszttel vagy egy mesterségesen árnyékolt új modellel.
