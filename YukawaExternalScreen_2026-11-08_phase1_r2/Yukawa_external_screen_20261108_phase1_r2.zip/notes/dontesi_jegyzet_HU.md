# Döntési jegyzet — külső szűrés, 1. fázis

**Az r4 a=1 pontja q=a/(4π)=0.07957747, λ=L.** A g=0.92628831775 kizárólag az ideális, rövid távolságú dust-kalibrációé. Véges forrásra és más mérési operátorra G*/G_fit=1/(1+qκ), nem általánosan ugyanaz a szám.

* **L=1 km:** a Cruz (1991) elsődleges absztraktusban közölt |α|<0.001 egyenlőtlenséggel összeférhetetlen, a deklarált univerzális, árnyékolatlan dust-Yukawa értelmezésben. A 79.58-as arány nem szignifikancia. Az absztraktus nem közöl CL-t; nincs saját 95%-os likelihood-kizárás. Formális konfidenciaszintű kizárásként a szükséges forrásrészletek pótlásáig ezt sem címkézzük.
* **L=10 km:** az itt ellenőrzött elsődleges anyagokból még nincs alkalmazható tartomány-/geometria-/CL-leképezés. A korábbi feltételes félteres és óceáni újralevezetések ezt nem pótolják. A pont nem kap „megengedett” minősítést.

**Megtörtént:** hatásból levezetett gyenge végesforrás-erő, teszttöltés és G-kalibráció; gömb-/henger-/lemezformák; Newton- és Helmholtz-felfeléfolytatás megkülönböztetése; két L külön numerikus ellenőrzése. Az offline futás tesztadatai és ábrái a csomagban vannak. A görbék szintetikus geometriafüggést mutatnak, nem kísérleti illesztést.

**Nem történt:** valódi kísérleti likelihood vagy 10 km-es terepoperátor-rekonstrukció; új NS-minta; GR-utánzó EOS-keresés; radiális stabilitás. Az új munka az r4 csillagszámait nem módosította.

**Sorrendi döntés:** a 10 km-es elsődleges forrás-/válaszrés rendezése és a kisebb csatolású szükséges feltételek további szűrése marad az 1. fázisban. Ezután a megtartott paraméterhalmazban ugyanaz az egy fizikailag megengedett GR-EOS legyen illesztve több M_K-hoz egyszerre: R(M_K), Λ(M_K), közös tömegkonvencióval. A minimumreziduumot megadott pontossági skálán kell vizsgálni, széles EOS-családban; véges sikertelen keresés nem nemlétezési bizonyítás. Ezt a 2. fázist és a kapcsolt radiális stabilitást most nem indítottuk el.

Nincs EOS-függetlenségi, megfigyelési bizonyíték-, stabilitási vagy elsőbbségi állítás; az órás H1-ágra és más TAL-változatokra nem általánosítunk.

A majdani közös-EOS feladatban egyetlen θ paramétervektor írja le p(ε)-t minden M_K-nál, termodinamikai konzisztenciával és 0≤dp/dε≤1 kauzalitási feltétellel. Az R és Λ együttes eltérését több közös tömeghez egy választott pontossági mátrixszal lehet normálni: D²=Δ(θ)^T C_precision⁻¹Δ(θ). Ez tervezési távolságfüggvény, nem megfigyelési likelihood. A megengedett közös tömegtartomány és a kauzalitás külön ellenőrzendő; a radiális stabilitást nem helyettesíti egy fordulópont vagy egy növekvő egyensúlyi ág.
