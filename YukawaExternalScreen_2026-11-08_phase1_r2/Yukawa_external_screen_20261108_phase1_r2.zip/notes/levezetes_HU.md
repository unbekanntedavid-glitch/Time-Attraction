# Az ε-forrású ág gyenge tere: véges forrás és mérési kalibráció

Dátum: 2026-11-08, Europe/Zurich. Hatókör: az r4 hatás feltételes, árnyékolatlan, nemrelativisztikus dust-határa. A csillagok számítását ez a munkafázis nem futtatja újra. Nem az órás H1-ág vizsgálata.

## 1. A kiinduló hatás és a paraméterek

Az r4-ben ténylegesen használt hatás, c=1 mellett, G* visszaállításával:

S = ∫√−g [R/(16πG*) − ((∇φ)²+φ²/L²)/(2aG*) − exp(−φ) ε(n)] d⁴x.

A sűrűséget g méri; ∇μ(nuμ)=0; p=n dε/dn−ε. A variáció:

T^m_μν = exp(−φ)[(ε+p)uμuν+p gμν],

(□−L⁻²)φ = −aG* exp(−φ) ε,

∇μ T_m^{μν} = exp(−φ) ε ∇νφ.

A skalár forrása energia-sűrűség, nem ε−3p. A fluidvariáció az Euler-egyenletben a bare változókkal a_μ+P_μν∇νp/(ε+p)=P_μν∇νφ alakot adja. A dust-rész ugyanaz, mint −m₀∫exp(−φ)ds. Nem helyettesítjük általános konformális trace-csatolással a hatást.

Az eredeti források hash-e a `sources/r4_inputs.json` fájlban van. A `binding_energy_EN.tex` 37–52. sorai és az `ns_yukawa_EN_r3.tex` 46–63. sorai rögzítik a normalizálást. Az r4 `notes/levezetes_HU.md` kiegészíti a G-kalibrációt. Ezeket csak olvastuk.

Az itt használt a a kinetikus nevező csatolása, a régebbi k-val azonos. Nem a korábbi solver egyes felirataiban szereplő √k. A változóhíd φ=k u, φ′=k v volt; ez nem új paraméterezés. A gyenge pontpotenciál erőssége

q ≡ α_Yukawa = a/(4π),     λ = L = μ⁻¹.

A λ itt exponenciális lecsengési hossz, nem 2πL. A képletekben a→0 határértéket veszünk; a=0-nál nem a szinguláris kinetikus nevezőt értékeljük közvetlenül, hanem φ=0 GR-ágat értünk.

## 2. Tömegek, töltés, feltevések

Legyen ρ_s=ε/c² a bare skalárforrás tömegsűrűsége. Dust-szinten ρ_s=ρ_I=ρ_g: a tehetetlen sűrűség és az aktív tenzori gravitációs sűrűség ugyanaz. Ez vezető gyenge-térbeli azonosság, nem erősen önkötött testekre szóló tétel. Elhanyagoljuk p/ε, v²/c², gravitációs önkötés/c² és a mezőenergia metrikus visszahatásának magasabb rendjét. A mag- és szilárdtest-mikrofizikából új összetételfüggő töltést nem konstruálunk.

A gyenge teszttest m_I(φ)=m₀exp(−φ) tömege mellett

ζ_T ≡ −∂ln m_I/∂φ = 1,

és gyorsulása −∇Φ*+c²∇φ. Egy összetett/önkötött testnél a tényleges ζ_T a test energiájának külső φ szerinti deriváltja lenne; itt a feladat szerinti gyenge dust-feltevést használjuk. A laboratóriumban megadott sűrűségek és tömegek a helyi tehetetlen tömegek. A referencia φ∞=0; a földi kis környezeti mező miatti exp(−φ_env) különbség a most megtartott rend alatt marad.

M_I a tehetetlen tömeg. A vezető metrikus monopólus G*M_g, ahol M_g≈M_I. A skalár monopólus véges testnél λ-függő formával súlyozott integrál, nem automatikusan M_g. Neutroncsillagnál az ADM-tömeg tartalmazza a külső mező energiáját; nem azonos a baryontömeggel. Az r4 konvenciója M_K=(G*/G_lab)M_ADM a skalárfaroktól távoli Kepler-tömeghez. Ezt nem alkalmazzuk úgy, mintha a gyenge forrás q-ja a csillag erős-térbeli effektív skalártöltése volna.

## 3. Véges forrás, potenciál, erő

Az SI gyenge-térbeli egyenletek:

∇²Φ* = 4πG*ρ_g,

(∇²−L⁻²)φ = −aG*ρ_s/c².

A vákuumban lecsengő Green-függvény a pozitív mezőt adja:

φ(x)=aG*/(4πc²)∫ρ_s(x′)exp(−s/L)/s d³x′,   s=|x−x′|.

A tesztpotenciál egységnyi tehetetlen tömegre:

Ψ_T(x)=Φ*(x)−ζ_T c²φ(x)
      =−G*∫[ρ_g(x′)+q ζ_T ρ_s(x′)exp(−s/L)]/s d³x′.

A gyorsulás ennek negatív gradiense; dust esetén

a(x)=−G*∫ρ(x′)(x−x′)/s³ [1+q(1+s/L)exp(−s/L)] d³x′.

Két véges, gyengén kötött test kölcsönhatási energiájához a kettős térfogati integrál kell:

U_N=−G*∬ρ_gA(x)ρ_IB(y)/|x−y| d³x d³y,

U_Y=−G*q∬ρ_sA(x)ρ_sB(y)exp(−|x−y|/L)/|x−y| d³x d³y.

Előírt merev eltolás/elfordítás szerinti −∂U adja a mért erőt/nyomatékot. Forrásmoduláció esetén az adott állapotok különbségét kell venni; a differenciális súlyok előjelesek lehetnek. Nem egy középponttávolság behelyettesítése helyettesíti a véges geometriát.

## 4. Kalibráció: mi azonos és mi nem?

Két pont-dust részecskére a tényleges erőből becsült G:

G_pair(d)=G*[1+q f(d/L)],    f(x)=(1+x)exp(−x).

Az ideális, rövid távolságú kalibráció: G_lab=G*(1+q). Ekkor a=1 esetén q=0.07957747154594767, g=G*/G_lab=0.9262883177508389. Ez az r4 feltételes g-je, nem egy tetszőleges geofizikai kísérlet geometriától független G-je.

Ha a mérés lineáris erő-/nyomaték-kiértékelője W, és a Newton- illetve egységnyi-q Yukawa-előrejelzés K_N, K_Y, akkor

G_fit=G*[1+q κ],    κ=W[K_Y]/W[K_N].

Ez az egyszerű alak rögzített tömeg/geometria és egyetlen amplitúdó illesztése esetén érvényes. Több nuisance paraméter esetén a megfelelő projektált design-mátrixból kell κ-t képezni; ha az osztó nulla vagy a design ranghiányos, az egy-amplitúdós formula nem alkalmazható. Előjeles nyomatékbecslőnél κ nem szükségképpen [0,1]. A kódban csak pozitív súlyú, egyértelműen definiált erőgeometriák szerepelnek.

Két kalibráció összevetése:

G_fit,exp/G_fit,cal = [1+qκ_exp]/[1+qκ_cal],

G*/G_fit,cal = 1/[1+qκ_cal].

Ezért a G_lab=6.67430×10⁻¹¹ SI szám önmagában nem írja le egy történeti mérés méretét, távolságait vagy adatfeldolgozását. A tényleges r4 ugyan a rövidtávú ideált rögzítette, de egy másik κ_cal esetén más g és más azonos-M_K csillagroot tartozna hozzá; a régi NS-számokat nem címkézzük át új kalibrációra.

Pozitív erősúlyú, legfeljebb D_max páronkénti távolságú kalibrációnál f(D_max/L)≤κ_cal≤1, mert f′(x)=−x exp(−x)≤0. Ez egzakt geometriai korlát ebben az osztályban; előjeles nyomatékra nem vonatkozik. D_max=1 m mellett az ideális g relatív eltérésének felső korlátja 3.6831×10⁻⁸ (L=1 km), illetve 3.6853×10⁻¹⁰ (L=10 km). A `compact_calibration_bound.csv` további távolságokat ad. Ez megmagyarázza a kompakt rövidtávú idealizáció jó közelítését, miközben nem azonosít tetszőleges történeti G-mérést ezzel a geometriával.

Példa, a=1: pontkalibráció d=L mellett κ=2/e, így g_fit=0.9446886393, nem 0.9262883178. Az R=10 km, t=1 km henger z=100 m pontján: L=1 km-nél κ=0.6083542971 és g_fit=0.9538241367; L=10 km-nél κ=0.9787658303 és g_fit=0.9277404230. Ezek szintetikus geometriák, nem rekonstruált kísérletek.

Gyakori másik normalizálás β=q/(1+q), amelynél

Ψ=−G_lab M/r [1+β(exp(−r/L)−1)]

az ideális rövidtávú G_lab mellett. Ekkor a=4πβ/(1−β), nem 4πβ. Az egyszerű −G∞M[1+αexp(−r/λ)]/r publikációs alakban viszont G∞=G*, α=q. A force-kernelben az (1+r/L) tényező kötelező; a potenciál „G(r)” függvényét nem azonosítjuk az erőből mért G-vel.

## 5. Gömb, henger, lemez

Homogén, R sugarú gömbön kívül:

Ψ=−G*M/r [1+q F(R/L)exp(−r/L)],

F(x)=3[x cosh x−sinh x]/x³ = 1+x²/10+x⁴/280+… .

Általános gömbi sűrűségnél F helyére (1/M)∫4πs²ρ(s)sinh(s/L)/(s/L)ds kerül. Két nem átfedő homogén gömbnél a Yukawa-erő/Newton-erő arány q F(R_A/L)F(R_B/L)f(d/L). Ez a külön véges teszttest-formafaktort is tartalmazza. Nagy R/L-nél a kód exp(−x)F(x)=3[(x−1)+(x+1)exp(−2x)]/(2x³) skálázott alakot használ, és nem képez exponenciálisan túlcsorduló köztes értéket.

Henger: sugara A, sűrűsége ρ, vastagsága t, felső síkja z=0; a tesztpont a tengelyen, z>0. A lefelé mutató erő komponensei:

N/(2πG*ρ)=t+√(A²+z²)−√(A²+(z+t)²),

Y/(2πG*qρ)=L[exp(−z/L)−exp(−(z+t)/L)
 −exp(−√(A²+z²)/L)+exp(−√(A²+(z+t)²)/L)].

A→∞ esetén N/(2πG*ρ)→t és Y/(2πG*qρ)→L exp(−z/L)(1−exp(−t/L)). Ezután t→∞ a skalár félteret adja; az infinite Newton-féltér abszolút tere divergál, így azt nem használjuk véges Newton-normalizálásként. A kód független kétdimenziós térfogati kvadratúrával ellenőrzi a gömb- és hengerformulát.

## 6. A torony nem pont-pont erőteszt

A sík felszín alatti tetszőleges forrás skalárterének horizontális Fourier-komponense a forrásmentes z>0 tartományban exp(−p z)-vel csökken, p=√(k²+L⁻²). A Newton/Laplace felfelé folytatás exp(−k z)-t alkalmaz ugyanarra a mért felszíni gyorsuláskomponensre. Az ideális, végtelen síkon:

δg_Y(k,z)=g_Y(k,0)[exp(−p z)−exp(−k z)].

A felszíni adat is tartalmazza a skalárt. Nem szabad azt tiszta Newtoni adatnak venni, majd csak a torony teteji Yukawa-teret hozzáadni. A k=0 sík-féltér maradéka −2πG*qρL(1−exp(−h/L)). A tényleges véges felmérési ablak, topográfia és a regionális trendlevonás e formulán túl mérési operátort igényel.

A kód egy d mélységű pontforrásra az on-axis maradékot is számolja:

δg_Y/(G*qM/d²)=∫₀∞ t exp(−√(t²+x²))
 [exp(−H√(t²+x²))−exp(−Ht)]dt,

ahol x=d/L, H=h/d. Két külön numerikus alak és a z=0, L→∞ határok ellenőrzöttek. Ez szintetikus operátorteszt, nem BREN- vagy Erie-adatillesztés.

## 7. Környezet és peremek

A számítás aszimptotikusan φ→0 mezőt, szuperpozíciót és gyenge, statikus forrásokat használ. Vákuumban a lecsengő módot választjuk; anyaghatáron φ és normális deriváltja folytonos, ha nincs felületi δ-forrás. Egy árnyékoló lemez saját tömege új forrás. Elektromágneses árnyékolásból nem következik φ=0 peremfeltétel. A levegő, épület, környező föld és víz tömege a tényleges kísérlet modelljébe tartozik; statikus részük moduláció esetén részben kieshet, mozgó részük nem automatikusan.

A hatásnak van sűrűségfüggő linearizált tömege: μ_eff²=L⁻²+aG*ρ/c²+O(φ), mert exp(−φ)=1−φ+… . Ez nem egy külön bevezetett árnyékolási modell. A kis paraméter η=aG*ρL²/c². a=1, L=10 km, ρ=5515 kg/m³ mellett η=3.7936391749×10⁻¹⁶. A földi gyenge forrásokra ez nem kínál százalékos elnyomást. E becslés nem nemlineáris környezeti BVP-futtatás. Idegen sűrűségfüggő csatolást, tetszőleges pajzsot vagy új kozmológiai hátteret nem illesztettünk hozzá.

A metrikus gyenge-térbeli potenciál, a skalár teszterő és az órajel definíciója külön kérdés. Naprendszeri PPN- és összetételfüggő Eötvös-korlátokat nem alkalmazunk e sűrűségforrású ágra egy trace-forrású vagy mikro-fizikai csatolás azonosítása nélkül. Kilométeres λ-nál a kiterjedt égitest formája és a felszín feletti magasság exponenciálisan számít; a pont-Nap formula nem általános helyettesítés.

## 8. Mit igazolnak a mostani tesztek?

A `checks/validation.json` a ténylegesen végrehajtott ellenőrzéseket és hibákat tárolja. Pont- és kétgömb-határok, Newton-héjtétel kontroll, L→0 és L→∞ kernelhatár, a→0 erőhatár, numerikus potenciálderivált, henger térfogati integrál, két kvadratúrarend, síklemez-határ, két Fourier-operátoralak és a kalibrációs konstans szerepelnek. A numerikus toleranciák algoritmusellenőrzések, nem kísérleti bizonytalanságok. A gyenge hosszú-hatótávú Newton-erőhatár nem állítja az összes relativisztikus obszervábilis GR-egyezését.

Nem futott valódi terep-/tornyoperátor, kísérleti likelihood, NS-újraintegrálás, GR-utánzó EOS-keresés vagy radiális stabilitási számítás. A forrásbizonytalanságot nem helyettesíti a kvadratúra kis numerikus hibája.
