# Tényleges numerikus ellenőrzések

Normál és `python3 -O` futás: 85–85 sikeres programellenőrzés; 6 CSV byte-azonos. Ezek nem független fizikai vagy kísérleti bizonyítások.

| Ellenőrzési csoport | Esetszám | Legnagyobb relatív eltérés |
|---|---:|---:|
| Gömb: negyedrendű numerikus potenciálderivált | 6 | 1.40709e-12 |
| Gömb: térfogati erőintegrál | 6 | 1.018e-13 |
| Gömb: térfogati potenciálintegrál | 6 | 9.93866e-14 |
| Henger: térfogati Yukawa-erőintegrál | 4 | 1.26959e-15 |
| 100 és 150 pontos hengerkvadratúra | 8 | 1.00298e-14 |
| Két Fourier-maradékalak | 4 | 2.37613e-14 |

A határértékek, normalizálás, SI gyorsulás-összeadás, pozitív kalibrációs geometria-korlátok és három hibás-csatolás bemenet elutasítása is a JSON-ban szerepel. A hibák a deklarált szintetikus konfigurációkra vonatkoznak; nem globális hibabecslések minden lehetséges forrásra.

Nincs kísérleti adatillesztés, terepoperátor-rekonstrukció, új csillagfuttatás, GR-utánzó keresés vagy stabilitási ellenőrzés.

Adat-/csomagolókapu: 34 tényleges regressziós eset (2 tiszta pozitív, 32 sérült másolat), normál és `-O` módban. NaN/Inf, véges hibás g/q, hiányzó/duplikált rács, hibás hosszegység/sűrűség/gyorsulás, kitalált 10 km-es határ vagy CL, és hibás numerikus kontrolladat elutasítva. Ez adatintegritás-ellenőrzés, nem új fizikai validáció. Részletek: `checks/data_gate_regression.json`.
