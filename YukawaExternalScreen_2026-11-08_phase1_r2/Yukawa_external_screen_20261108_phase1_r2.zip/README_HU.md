# Külső korlátszűrés az r4 ε-forrású skalár-fluid ágához

Csak az engedélyezett 1. fázis. A `notes/dontesi_jegyzet_HU.md` a rövid eredmény; a `notes/levezetes_HU.md` a hatásból kiinduló képletek; a `notes/forrasok_es_korlatszures_HU.md` az evidencia és korlátai. A `data_gate.py` a csomagoló előtt a tényleges CSV-k rácsát, véges értékeit, SI normalizálását, kalibrációját, forrásminősítéseit és a numerikus kontrolladatokat is ellenőrzi; nem pusztán a passed jelzőt olvassa. A `regress_guard.py` elkülönített másolatokon normál és optimalizált Pythonban futtatott negatív teszteket tartalmaz.

A kód és a szintetikus ábrák nem neutroncsillag-számítások és nem megfigyelési likelihood.

## Offline futtatás

Python 3, NumPy, SciPy és Matplotlib szükséges. A kipróbált verziók a `checks/validation.json` környezeti rekordjában szerepelnek.

```sh
python3 code/verify_manifest.py
python3 code/reproduce.py
python3 code/data_gate.py
```

A manifestet változatlan kibontásban, a generátor futtatása előtt ellenőrizd. A reprodukció szándékosan újragenerál fájlokat. Más könyvtárverzióval a numerikus toleranciák döntenek az analitikus tesztekben; a PNG vagy környezeti JSON byte-azonossága nem elvárás. A kész csomag eredeti fájljainak integritását a manifest ellenőrzi.

A futás a `data/`, `figures/`, `checks/validation.json` fájljait hozza létre. Nincs hálózati lépés, korábbi munkakönyvtár vagy fizetős cikk a reprodukcióban. A `record_provenance.py` az eredeti környezetben egyszer végrehajtott forrásrögzítő segédprogram, nem része az offline futási láncnak. Korábbi csomagokra csak ez a provenance-segéd hivatkozik.

## Adatok és ábrák

* `parameter_screen.csv`: a két a=1 pilotpont, forrás, feltételek és CL-rés.
* `necessary_not_sufficient_window.csv`: csak a Cruz-egyenlőtlenség szükséges feltétele 1 km-nél; nem engedélyezett tartomány.
* `geometry_diagnostics.csv`: két L × két a × 121 távolság = 484 szintetikus sor, minden hossz méterben; a henger sugara 10 km, vastagsága 1 km, szemléltető sűrűsége 2000 kg/m³. A CSV külön SI gyorsulásként adja a G_lab szerinti Newton-referenciát, a G* tenzori és a skalár hozzájárulást is. G_lab az ideális rövidtávú referencia. Az a=0.001 szemléltető érzékenységi pont, nem külső korlátokkal igazolt paraméter.
* `compact_calibration_bound.csv`: pozitív erősúlyok és megadott legnagyobb páronkénti távolság mellett az ideális g eltérésének matematikai korlátja.
* `calibration_geometry.csv`: ugyanaz a csatolás eltérő kalibrációs geometriákban; nem kísérleti mérés.
* `synthetic_tower_operator.csv`: pontforrás a folytatási sík alatt; nem BREN-adat.
* `figures/geometry_contrast.png`, `calibration_scale.png`: a fenti szintetikus adatokból.

A q=α=a/(4π) és λ=L konvenciót nem szabad a legacy √k felirattal vagy β=q/(1+q) normalizálással összekeverni. A numerikus validáció nem a hiányzó 10 km-es elsődleges kísérleti átvitelt igazolja.

Nincs PDF, így PDF-oldalláb nélküli dokumentum sem keletkezett. A korábbi r4 és más kutatási bemenetek változatlanok maradtak. A ZIP nem tartalmazza a privát olvasási forrásokat és az eredeti folyóiratcikkeket.

Licenc: ©2026 Szabolcsi Dávid, ORCID 0009-0005-6300-074X, CC BY-NC 4.0 International. Kereskedelmi felhasználás csak a szerző írásos engedélyével; részletek `LICENSE.txt`.

## Technikai hordozhatóság — phase1_r2

A tudományos CSV-k, a két ábra, a `weak_field.py`, a `reproduce.py` és a levezetés az eredeti archívum bájtjait őrzik. A numerikus rácsillesztő koordinátánként legfeljebb négy, az előírt binary64 koordinátához tartozó reprezentálható lépésnyi (ULP) eltérést fogad el, kölcsönösen egyértelmű hozzárendeléssel. A fizikai értékek ellenőrzési toleranciája nem változott. A `delivery/` segédkönyvtárat a regresszió és a csomagoló saját maga hozza létre.

Kiegészítő, offline technikai tesztek:

```sh
python3 code/regress_guard.py
python3 code/test_grid_roundoff.py
python3 code/pack.py
python3 code/test_archive_workflow.py delivery/Yukawa_external_screen_20261108_phase1_r2.zip delivery/workflow.json
```

A `regress_guard.py` az eredeti 34 esetet, a rácsteszt további 23–23 esetet futtat normál és `-O` módban. A hideg archívumteszt külön munkapéldányokban, előzetes mkdir nélkül ellenőrzi a csomagolót és a regressziót az archivált, nem újragenerált CSV-kkel; továbbá a verify → reproduce → data_gate főutat mindkét módban. A munkapéldányok ideiglenesek, nem átadott kutatási fájlok.

Az átadott külső `handoff.json` beágyazva hordozza a pontos ZIP-bájtra vonatkozó hideg-archívum teszteredményt. Nincs külön, be nem csatolt archive_smoke-függőség. A ZIP manifestje saját magát nem hash-eli; a ZIP és a manifest hash-e a külső handoffban szerepel.
