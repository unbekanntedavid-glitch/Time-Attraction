#!/usr/bin/env python3
"""Negative controls for window_signal.py. Works only on temporary copies of the inputs; the originals are read-only.
Inputs as in window_signal.py: --subcm-zip / TAL_SUBCM_ZIP, --kv2 / TAL_KV2 (same relative defaults).
Acceptance: clean input -> exit 0; each of the 5 corrupted inputs -> non-zero exit. Exit 0 here only if 6/6."""
import argparse, io, json, os, subprocess, sys, tempfile, zipfile
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ap = argparse.ArgumentParser()
ap.add_argument("--subcm-zip", default=os.environ.get("TAL_SUBCM_ZIP", os.path.join(ROOT, "inputs_r4", "subcm_yukawa_window_zenodo_r4.zip")))
ap.add_argument("--kv2", default=os.environ.get("TAL_KV2", os.path.join(HERE, "..", "map_r3", "key_values_r3.json")))
a = ap.parse_args()
P = "subcm_yukawa_window/outputs/"
HUST = P + "digitized/Lee2020_fig5__HUST_2020.csv"
def copy_zip(dst, edit):
    with zipfile.ZipFile(a.subcm_zip) as zi, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            data = zi.read(it.filename)
            data = edit(it.filename, data)
            zo.writestr(it, data)
def hust_val(token):
    def ed(n, d):
        if n != HUST: return d
        lines = d.decode().splitlines(True)
        hdr = lines[0].strip().split(","); c = hdr.index("alpha_abs_lim"); row = lines[len(lines) // 2].rstrip("\n").split(",")
        row[c] = token; lines[len(lines) // 2] = ",".join(row) + "\n"
        return "".join(lines).encode()
    return ed
def drop_alpha0(n, d):
    if n != P + "results.json": return d
    j = json.loads(d); del j["alpha0"]; return json.dumps(j).encode()
def env_set(i, v):
    def ed(n, d):
        if n != P + "envelopes.npz": return d
        z = np.load(io.BytesIO(d)); arrs = {k: np.array(z[k]) for k in z.files}
        assert np.isfinite(arrs["combined_abs"][i]), "control target is not finite in the clean input"
        arrs["combined_abs"][i] = v; b = io.BytesIO(); np.savez(b, **arrs); return b.getvalue()
    return ed
cases = [("clean", lambda n, d: d, True), ("HUST curve NaN", hust_val("nan"), False), ("HUST curve Inf", hust_val("inf"), False),
         ("results.json alpha0 missing", drop_alpha0, False), ("combined_abs[10911]=NaN", env_set(10911, np.nan), False),
         ("combined_abs[10912]=Inf", env_set(10912, np.inf), False)]
ok = 0
with tempfile.TemporaryDirectory() as td:
    for name, ed, expect_ok in cases:
        z = os.path.join(td, "in.zip"); out = os.path.join(td, "out"); copy_zip(z, ed)
        r = subprocess.run([sys.executable, os.path.join(HERE, "window_signal.py"), "--subcm-zip", z, "--kv2", a.kv2, "--out", out], capture_output=True, text=True)
        good = (r.returncode == 0) == expect_ok
        ok += good
        last = (r.stderr.strip().splitlines() or [""])[-1]
        print(f"{'PASS' if good else 'FAIL'}  {name:30s} exit={r.returncode}  {last[:100]}")
print(f"{ok}/{len(cases)}")
sys.exit(0 if ok == len(cases) else 1)
