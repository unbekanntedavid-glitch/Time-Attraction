#!/usr/bin/env python3
"""alpha_Y = 1 branch in the not-excluded micron window (r2 map: 2 um <= lambda < 75.877 um):
R_e(lambda) = alpha_TAL / alpha_lim,e(lambda), alpha_TAL = 1/(4 pi), for each packaged experiment curve/table.
R is a conditional ratio to a published 95% CL bound, NOT sigma. 'not excluded' is not confirmation.
Improvement factor F_e = 1/R_e = alpha_lim,e / alpha_TAL (factor by which that bound must tighten to reach alpha_TAL).
Inputs are read directly from the sub-cm r4 zip (read-only) and from map_r3/key_values_r3.json (map r3: same values as map r2;
only the default path of this input changed in this copy, the computation is unchanged)."""
import csv, io, json, math, os, sys, zipfile, hashlib
import numpy as np
import argparse
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
# Inputs: CLI arguments > environment variables > defaults relative to this script's folder.
#   --subcm-zip / TAL_SUBCM_ZIP : subcm_yukawa_window_zenodo_r4.zip (default ../inputs_r4/subcm_yukawa_window_zenodo_r4.zip)
#   --kv2       / TAL_KV2       : map_r3/key_values_r3.json        (default ../map_r3/key_values_r3.json)
#   --out       / TAL_OUT       : output folder                    (default: this script's folder)
ap = argparse.ArgumentParser()
ap.add_argument("--subcm-zip", default=os.environ.get("TAL_SUBCM_ZIP", os.path.join(ROOT, "inputs_r4", "subcm_yukawa_window_zenodo_r4.zip")))
ap.add_argument("--kv2", default=os.environ.get("TAL_KV2", os.path.join(HERE, "..", "map_r3", "key_values_r3.json")))
ap.add_argument("--out", default=os.environ.get("TAL_OUT", HERE))
ARGS = ap.parse_args()
ZIP, KV2, OUT = ARGS.subcm_zip, ARGS.kv2, ARGS.out
os.makedirs(OUT, exist_ok=True)
P = "subcm_yukawa_window/outputs/"
class StrictError(Exception): pass
def finite(x, what):
    if not np.all(np.isfinite(np.asarray(x, float))): raise StrictError(f"non-finite in {what}")
    return x
def need(d, *path):
    for k in path:
        if not isinstance(d, dict) or k not in d: raise StrictError(f"missing key {path}")
        d = d[k]
    return d
for p in (ZIP, KV2):
    if not os.path.isfile(p): raise StrictError(f"missing {p}")
Z = zipfile.ZipFile(ZIP)
def member(name): return Z.read(P + name)
res = json.loads(member("results.json")); env = np.load(io.BytesIO(member("envelopes.npz")))
kv2 = json.load(open(KV2))
HBARC_eVm = 1.054571817e-34 * 299792458.0 / 1.602176634e-19      # CODATA 2018 exact-defined + hbar
A_TAL = 1.0 / (4 * math.pi)
if not math.isclose(float(need(res, "alpha0")), A_TAL, rel_tol=1e-12): raise StrictError("alpha0 != 1/4pi")

# ---- curves (all drawn |alpha| curves used by the package envelope) ----
CURVES = {}
for k in need(res, "curves"):
    fig, name = k.split("/")
    raw = member(f"digitized/{fig}__{name}.csv").decode()
    rows = list(csv.DictReader(io.StringIO(raw)))
    if not rows: raise StrictError(f"empty {k}")
    lam = np.array([float(need(r, "lambda_m")) for r in rows]); al = np.array([float(need(r, "alpha_abs_lim")) for r in rows])
    finite(lam, k); finite(al, k)
    if np.any(np.diff(lam) <= 0): raise StrictError(f"curve {k} not strictly increasing in lambda")
    rng = need(res, "curves", k, "lambda_range_m")
    if not (math.isclose(lam[0], rng[0], rel_tol=1e-6) and math.isclose(lam[-1], rng[1], rel_tol=1e-6)): raise StrictError(f"range {k}")
    CURVES[k] = (lam, al)
def loglog(lam, al, x):   # same as sub-cm scripts/analyze_window.py loglog: NaN outside drawn range
    if x < lam[0] or x > lam[-1]: return None
    return float(10 ** np.interp(math.log10(x), np.log10(lam), np.log10(al)))
# ---- thesis table (Eot-Wash 2020 data) ----
trows = [r for r in csv.reader(io.StringIO(member("digitized/Lee2020_thesis_table11_4.csv").decode())) if r and not r[0].startswith("#")]
hdr = trows[0]; T = [dict(zip(hdr, r)) for r in trows[1:]]
tl = np.array([float(need(r, "lambda_mm")) * 1e-3 for r in T])
tcols = {c: np.array([float(need(r, c)) for r in T]) for c in ("alpha_star", "sigma_alpha", "alpha95_pos", "alpha95_abs")}
for c, v in tcols.items(): finite(v, c)
if np.any(np.diff(tl) <= 0): raise StrictError("thesis not increasing")
def thesis(col, x):
    if x < tl[0] or x > tl[-1]: return None
    v = tcols[col]
    if np.any(v <= 0): raise StrictError(f"non-positive {col}")
    return float(10 ** np.interp(math.log10(x), np.log10(tl), np.log10(v)))
# ---- envelope ----
LG = np.asarray(env["log10_lambda"], float); E = np.asarray(env["combined_abs"], float)
# strict envelope validation before any filtering or interpolation
if LG.ndim != 1 or E.shape != LG.shape: raise StrictError("envelope shape")
finite(LG, "envelope log10_lambda")
if np.any(np.diff(LG) <= 0): raise StrictError("envelope grid not strictly increasing")
covered = np.zeros(LG.shape, dtype=bool)
for lam_c, _al in CURVES.values():
    covered |= (LG >= math.log10(lam_c[0])) & (LG <= math.log10(lam_c[-1]))
finite(E[covered], "envelope inside curve coverage")
if np.any(np.isinf(E)) or np.any(E[np.isfinite(E)] <= 0): raise StrictError("invalid envelope value (Inf or non-positive)")
N_CURVES = len(CURVES)
if N_CURVES != len(need(res, "curves")): raise StrictError("curve count mismatch")
def env_at(x):
    v = float(10 ** np.interp(math.log10(x), LG[np.isfinite(E)], np.log10(E[np.isfinite(E)])))
    return finite(v, "env")

# ---- PREFLIGHT ----
pre = {"tolerances": {"edge_rel": 1e-6, "edge_stated_um_abs": 5e-4, "r2_alphaYmax_rel": 1e-9, "envelope_vs_min_of_curves_rel": 1e-9}}
ok = np.isfinite(E); i = int(np.where(ok & (np.log10(np.where(ok, E, np.inf)) < math.log10(A_TAL)))[0][0])
x0, x1, y0, y1 = LG[i-1], LG[i], math.log10(E[i-1]), math.log10(E[i])
edge = float(10 ** (x0 + (math.log10(A_TAL) - y0) / (y1 - y0) * (x1 - x0)))
cr = [c for c in need(res, "curves", "Lee2020_fig5/HUST_2020", "crossings") if c["direction"] == "enters_excluded"]
if len(cr) != 1: raise StrictError("HUST crossing")
pre["edge"] = {"recomputed_m": edge, "results_json_HUST_2020_crossing_m": cr[0]["lambda_m"], "stated_um": 75.877,
               "pass": bool(math.isclose(edge, cr[0]["lambda_m"], rel_tol=1e-6) and abs(edge * 1e6 - 75.877) <= 5e-4)}
kvl = need(kv2, "key_lambda"); pre["r2_alphaY_max"] = {}
for lam_t in (5e-5, 7.587709630440307e-05):
    m = [r for r in kvl if math.isclose(r["lambda_m"], lam_t, rel_tol=1e-9)]
    if len(m) != 1: raise StrictError("r2 key missing")
    ref = float(m[0]["alphaY_max"]); mine = 4 * math.pi * env_at(lam_t)
    pre["r2_alphaY_max"][f"{lam_t:.6e}"] = {"recomputed": mine, "r2": ref, "pass": bool(math.isclose(mine, ref, rel_tol=1e-9))}
# envelope = min over curves (independent re-derivation on the window part of the package grid)
dev = 0.0; n = 0
for lg in LG[(LG >= math.log10(2.0e-6)) & (LG <= math.log10(edge))][::50]:
    x = 10 ** lg; vals = [v for v in (loglog(*CURVES[k], x) for k in CURVES) if v is not None]
    if not vals: raise StrictError("no curve in window")
    j = int(round((lg - LG[0]) / (LG[1] - LG[0]))); dev = max(dev, abs(min(vals) / E[j] - 1)); n += 1
pre["envelope_vs_min_of_curves"] = {"n": n, "max_rel_dev": dev, "pass": bool(dev <= 1e-9)}
pre["n_curves"] = N_CURVES; pre["n_envelope_points_covered"] = int(covered.sum())
pre["inputs"] = {"subcm_zip": os.path.basename(ZIP), "kv2": "map_r3/" + os.path.basename(KV2)}
pre["zip_sha256"] = hashlib.sha256(open(ZIP, "rb").read()).hexdigest()
pre["member_sha256"] = {m: hashlib.sha256(member(m)).hexdigest() for m in ("results.json", "envelopes.npz", "digitized/Lee2020_thesis_table11_4.csv")}
pre["pass"] = bool(pre["edge"]["pass"] and all(v["pass"] for v in pre["r2_alphaY_max"].values()) and pre["envelope_vs_min_of_curves"]["pass"])
json.dump(pre, open(os.path.join(OUT, "preflight.json"), "w"), indent=1); print(json.dumps(pre, indent=1))
if not pre["pass"]: print("PREFLIGHT FAILED"); sys.exit(2)

# ---- window scan ----
LAMS = np.logspace(math.log10(2.0e-6), math.log10(edge), 300)[:-1]   # strictly below the edge
keys = sorted(CURVES)
rows = []
for x in LAMS:
    r = {"lambda_m": float(x), "mc2_eV": HBARC_eVm / x, "alpha_lim_envelope": env_at(x)}
    r["R_envelope"] = A_TAL / r["alpha_lim_envelope"]
    best = None
    for k in keys:
        v = loglog(*CURVES[k], x); r[f"R|{k}"] = None if v is None else A_TAL / v
        if v is not None and (best is None or v < best[1]): best = (k, v)
    if not math.isclose(best[1], r["alpha_lim_envelope"], rel_tol=1e-3): raise StrictError(f"best curve vs envelope at {x}")
    r["best_curve"] = best[0]
    for c, lab in (("alpha95_pos", "R|thesis_plus_alpha95"), ("alpha95_abs", "R|thesis_abs_alpha95")):
        v = thesis(c, x); r[lab] = None if v is None else A_TAL / v
    s = thesis("sigma_alpha", x); r["alpha_TAL_over_sigma_alpha_thesis"] = None if s is None else A_TAL / s
    for k_, v_ in r.items():
        if isinstance(v_, float): finite(v_, k_)
    rows.append(r)
cols = list(rows[0].keys())
with open(os.path.join(OUT, "window_scan.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(cols)
    for r in rows: w.writerow(["NA" if r[c] is None else (f"{r[c]:.6e}" if isinstance(r[c], float) else r[c]) for c in cols])

# ---- representative lambda ----
REP = [2e-6, 5e-6, 10e-6, 20e-6, 30e-6, 38.6e-6, 50e-6, 70e-6, 75e-6]
tab = []
for x in REP:
    e = {"lambda_um": x * 1e6, "mc2_eV": HBARC_eVm / x, "alpha_TAL": A_TAL, "per_bound": {}}
    for k in keys:
        v = loglog(*CURVES[k], x)
        if v is not None: e["per_bound"][k] = {"alpha_lim": v, "R": A_TAL / v, "improvement_factor": v / A_TAL}
    for c, lab in (("alpha95_pos", "Lee2020_thesis_Table11.4/+alpha95"), ("alpha95_abs", "Lee2020_thesis_Table11.4/|alpha95|")):
        v = thesis(c, x)
        if v is not None: e["per_bound"][lab] = {"alpha_lim": v, "R": A_TAL / v, "improvement_factor": v / A_TAL}
    s = thesis("sigma_alpha", x)
    if s is not None:
        e["thesis_sigma_alpha"] = s; e["alpha_TAL_over_sigma_alpha"] = A_TAL / s
        row = [j for j in range(len(tl)) if math.isclose(tl[j], x, rel_tol=1e-6)]   # alpha_star only at an exact table row (no interpolation, sign varies)
        e["thesis_alpha_star_at_row"] = float(tcols["alpha_star"][row[0]]) if row else None
    ea = env_at(x); bk = min(((k, v["alpha_lim"]) for k, v in e["per_bound"].items() if "/" in k and not k.startswith("Lee2020_thesis")), key=lambda t: t[1])
    e["envelope"] = {"alpha_lim": ea, "R": A_TAL / ea, "improvement_factor": ea / A_TAL, "set_by": bk[0]}
    for k_, v_ in e["per_bound"].items(): finite([v_["alpha_lim"], v_["R"]], k_)
    tab.append(e)
json.dump({"definition": "R = alpha_TAL/alpha_lim (conditional ratio to a published 95% CL bound, not sigma); improvement_factor = alpha_lim/alpha_TAL; alpha_TAL = 1/(4 pi) (alpha_Y = 1)",
           "edge_m": edge, "representative": tab,
           "force_torque": "not computed: experiment geometry, source/test-mass parameters and torque noise are not in the packaged inputs"},
          open(os.path.join(OUT, "window_key_table.json"), "w"), indent=1)
KEYTAB_PATH = os.path.join(OUT, "window_key_table.json")
for e in tab:
    print(f"{e['lambda_um']:6.1f} um  mc2={e['mc2_eV']:.3e} eV  env R={e['envelope']['R']:.3e} F={e['envelope']['improvement_factor']:.3e} ({e['envelope']['set_by']})",
          " thesis+:", f"{e['per_bound'].get('Lee2020_thesis_Table11.4/+alpha95',{}).get('improvement_factor',float('nan')):.3e}",
          " a/sig:", f"{e.get('alpha_TAL_over_sigma_alpha', float('nan')):.3e}")

# ---- continuous log-log root finding on the drawn curves (min over curves) and the thesis sigma column ----
def bisect(f, a, b, tol=1e-15, it=200):
    fa, fb = f(a), f(b)
    if fa == 0: return a
    if fb == 0: return b
    if fa * fb > 0: raise StrictError("root not bracketed")
    for _ in range(it):
        m = math.sqrt(a * b); fm = f(m)
        if fm == 0 or (b / a - 1) < tol: return m
        if fa * fm < 0: b, fb = m, fm
        else: a, fa = m, fm
    return math.sqrt(a * b)
def best_of(x):
    vals = [(k, loglog(*CURVES[k], x)) for k in keys]
    vals = [(k, v) for k, v in vals if v is not None]
    if not vals: raise StrictError("no curve")
    return min(vals, key=lambda t: t[1])
def F_curves(x): return best_of(x)[1] / A_TAL
G = np.logspace(math.log10(2.0e-6), math.log10(edge), 20001)
owner = [best_of(x)[0] for x in G]
trans = []
for j in range(1, len(G)):
    if owner[j] != owner[j - 1]:
        a_, b_ = owner[j - 1], owner[j]
        r = bisect(lambda x: math.log10(loglog(*CURVES[a_], x)) - math.log10(loglog(*CURVES[b_], x)), G[j - 1], G[j])
        trans.append({"from": a_, "to": b_, "lambda_um": r * 1e6})
cross = {}
for Fv in (10.0, 100.0, 1000.0):
    cross[f"F_env={Fv:g}"] = bisect(lambda x: math.log10(F_curves(x)) - math.log10(Fv), 2.0e-6, edge * (1 - 1e-12)) * 1e6
sig_root = bisect(lambda x: math.log10(A_TAL / thesis("sigma_alpha", x)), 40e-6, edge) * 1e6
Fpts = {f"{u:g}": F_curves(u * 1e-6) for u in (50, 75, 75.8)}
Fpts["edge"] = F_curves(edge)
ref = {"transitions_um": [7.457633, 60.742381], "F=10": 41.093082, "F=100": 23.937559, "F=1000": 16.100117, "sigma_ratio_1": 62.485668,
       "F50": 5.26433898203, "F75": 1.05316382104, "F75.8": 1.00453929327}
TOL_UM = 1e-5   # relative tolerance vs the independent check's printed values (6-7 significant digits)
chk = {"transitions": len(trans) == 2 and all(math.isclose(t["lambda_um"], r_, rel_tol=TOL_UM) for t, r_ in zip(trans, ref["transitions_um"])),
       "F=10": math.isclose(cross["F_env=10"], ref["F=10"], rel_tol=TOL_UM), "F=100": math.isclose(cross["F_env=100"], ref["F=100"], rel_tol=TOL_UM),
       "F=1000": math.isclose(cross["F_env=1000"], ref["F=1000"], rel_tol=TOL_UM), "sigma_ratio_1": math.isclose(sig_root, ref["sigma_ratio_1"], rel_tol=TOL_UM),
       "F50": math.isclose(Fpts["50"], ref["F50"], rel_tol=1e-9), "F75": math.isclose(Fpts["75"], ref["F75"], rel_tol=1e-9),
       "F75.8": math.isclose(Fpts["75.8"], ref["F75.8"], rel_tol=1e-9), "F_edge_is_1": math.isclose(Fpts["edge"], 1.0, rel_tol=1e-9)}
outc = {"method": "continuous log-log piecewise-linear interpolation of each drawn curve inside its range; envelope = min over the curves; bisection in log lambda",
        "n_curves": N_CURVES, "edge_um": edge * 1e6, "best_bound_transitions": trans, "F_env_crossings_um": cross,
        "alpha_TAL_over_sigma_alpha_thesis_equals_1_um": sig_root, "F_env_at": Fpts,
        "reference_values_independent_check": ref, "tolerance_rel": {"crossings": TOL_UM, "F": 1e-9}, "agreement": chk,
        "note": "F is a bound-tightening factor, not an experimental sensitivity; R and F are not sigma"}
json.dump(outc, open(os.path.join(OUT, "window_crossings.json"), "w"), indent=1)
print(json.dumps(outc, indent=1))
if not all(chk.values()): print("CROSSING CHECK FAILED"); sys.exit(3)
