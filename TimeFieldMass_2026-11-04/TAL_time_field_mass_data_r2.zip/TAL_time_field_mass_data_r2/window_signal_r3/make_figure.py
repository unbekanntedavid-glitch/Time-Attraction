#!/usr/bin/env python3
"""PNG: R_e(lambda) = alpha_TAL/alpha_lim,e in the micron window, from window_scan.csv (no recomputation)."""
import csv, os, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
D = os.path.dirname(os.path.abspath(__file__))
rows = list(csv.DictReader(open(os.path.join(D, "window_scan.csv"))))
lam = np.array([float(r["lambda_m"]) for r in rows]) * 1e6
def col(c): return np.array([np.nan if r[c] == "NA" else float(r[c]) for r in rows])
fig, ax = plt.subplots(figsize=(10.5, 6.2), dpi=150)
curves = [c for c in rows[0] if c.startswith("R|")]
style = {"Lee2020_fig5/HUST_2020": ("tab:red", "-"), "Lee2020_fig5/Eot-Wash_2020": ("tab:blue", "-"), "Lee2020_fig5/Eot-Wash_2007": ("tab:cyan", "-"),
         "Lee2020_fig5/HUST_2016": ("tab:orange", "-"), "Lee2020_fig5/unattributed_2to20um": ("tab:brown", "-"), "Lee2020_fig5/Stanford_a": ("tab:olive", "-"),
         "Lee2020_fig5/Colorado_2003": ("tab:purple", "-"), "thesis_plus_alpha95": ("navy", "--"), "thesis_abs_alpha95": ("navy", ":")}
for c in curves:
    k = c[2:]; y = col(c)
    if not np.any(np.isfinite(y)): continue
    colr, ls = style.get(k, ("0.75", "-"))
    lab = k.replace("Lee2020_fig5/", "Lee 2020 Fig.5: ").replace("AHN2003_fig5/", "AHN 2003 Fig.5: ").replace("thesis_", "Lee 2020 thesis T11.4 ")
    ax.plot(lam, y, color=colr, ls=ls, lw=1.6 if k in style else 0.8, label=lab if k in style else None)
ax.plot(lam, col("R_envelope"), color="k", lw=5, alpha=0.3, zorder=1, label="envelope = best bound (combined_abs)")
ax.plot([], [], color="0.75", lw=0.8, label="other packaged curves (AHN 2003 Fig.5, Stanford b/c, ...)")
ax.axhline(1, color="k", ls="-.", lw=0.8); ax.text(2.2, 1.25, "R = 1 (TAL value at the bound)", fontsize=8)
ax.axvline(75.877, color="gray", ls="--", lw=0.8); ax.text(70, 2e-3, "edge 75.877 um", rotation=90, fontsize=8, color="gray")
for x in (5, 10, 20, 50, 70): ax.axvline(x, color="0.85", lw=0.6, zorder=0)
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(2, 80); ax.set_ylim(1e-9, 3)
ax.set_xlabel(r"$\lambda$ [$\mu$m]"); ax.set_ylabel(r"$R_e=\alpha_{TAL}/\alpha_{lim,e}$  ($\alpha_{TAL}=1/4\pi$, $\alpha_Y=1$)")
sec = ax.secondary_yaxis("right", functions=(lambda r: 1 / np.clip(r, 1e-30, None), lambda f: 1 / np.clip(f, 1e-30, None)))
sec.set_ylabel("improvement factor needed  F = 1/R")
top = ax.secondary_xaxis("top", functions=(lambda l: 0.1973269804 / np.clip(l, 1e-30, None), lambda m: 0.1973269804 / np.clip(m, 1e-30, None)))
top.set_xlabel(r"$mc^2=\hbar c/\lambda$ [eV]")
ax.legend(fontsize=7, loc="lower right", framealpha=0.9)
ax.set_title("alpha_Y = 1 branch in the not-excluded window 2-75.877 um: ratio to each packaged 95% CL bound\nR is a conditional ratio, not sigma; R < 1 = below present bound (not excluded, not confirmed)", fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(D, "window_ratio.png")); print("ok")
