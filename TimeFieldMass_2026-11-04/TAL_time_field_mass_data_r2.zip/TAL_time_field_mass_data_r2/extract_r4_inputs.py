#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi David (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Verify and extract the three r4 module zips used as inputs (read-only).

The zips are inside TAL_publication_set_2026-11-04_r2.zip of the record https://doi.org/10.5281/zenodo.23960821.
Put them in inputs_r4/ (default) or pass their locations:
  python3 extract_r4_inputs.py [--clock-zip P] [--subcm-zip P] [--bren-zip P] [--out DIR]
or set TAL_CLOCK_ZIP / TAL_SUBCM_ZIP / TAL_BREN_ZIP / TAL_R4_EXTRACTED.
Each zip is checked against its SHA-256 before extraction; a mismatch stops the run."""
import argparse, hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.abspath(__file__))
IN = os.path.join(ROOT, "inputs_r4")
EXPECTED = {
    "tal_branch_clock_accel_test_r4.zip": "6ba806210d557189fc77777a29d3e9964b0b75f81fd185230a62eedfc0daa105",
    "subcm_yukawa_window_zenodo_r4.zip": "e3f027587b7462900d607d858315668bc65346eada7489f34f3a06d31096ae46",
    "bren_continuation_zenodo_r4.zip": "5f217dc47b6f91756cda9a5b1765930be82e32c5f77a80456825cfe5168edf25",
}
ap = argparse.ArgumentParser()
ap.add_argument("--clock-zip", default=os.environ.get("TAL_CLOCK_ZIP", os.path.join(IN, "tal_branch_clock_accel_test_r4.zip")))
ap.add_argument("--subcm-zip", default=os.environ.get("TAL_SUBCM_ZIP", os.path.join(IN, "subcm_yukawa_window_zenodo_r4.zip")))
ap.add_argument("--bren-zip", default=os.environ.get("TAL_BREN_ZIP", os.path.join(IN, "bren_continuation_zenodo_r4.zip")))
ap.add_argument("--out", default=os.environ.get("TAL_R4_EXTRACTED", os.path.join(IN, "extracted")))
a = ap.parse_args()
for path in (a.clock_zip, a.subcm_zip, a.bren_zip):
    name = os.path.basename(path)
    if name not in EXPECTED: raise SystemExit(f"unexpected zip name {name}")
    if not os.path.isfile(path): raise SystemExit(f"missing {path} (see README.md, section 'Inputs')")
    h = hashlib.sha256(open(path, "rb").read()).hexdigest()
    if h != EXPECTED[name]: raise SystemExit(f"SHA-256 mismatch for {name}: {h}")
    dst = os.path.join(a.out, name[:-4])
    if os.path.exists(dst): raise SystemExit(f"{dst} exists; remove it first")
    with zipfile.ZipFile(path) as z:
        for m in z.namelist():
            if m.startswith("/") or ".." in m.split("/"): raise SystemExit(f"unsafe member {m}")
        z.extractall(dst)
    print("ok", name, h)
