# Mass of the TAL time scalar field — data and code package (r2, 2026-11-04)

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 International (https://creativecommons.org/licenses/by-nc/4.0/) · commercial use only with the author's written permission. See `LICENSE.txt`.

Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.

*Magyar összefoglaló a fájl végén.*

## What this package contains
Code and outputs behind the article "Mass of the TAL time scalar field: (λ, α_Y) exclusion map and the micron window" (EN and HU PDFs in the same set). The modules are:

| folder | content |
|---|---|
| `theory_checks/` | sympy checks (`checks.py` → `sympy_checks.json`) and numbers (`theory_numbers.py` → `numbers.json`): effective potential, matter-era drift as a linearized test-field solution on a prescribed GR dust background (with a residual test), conformal map, 1−γ = 2α_Y/(α_Y+4π), density-mass scales L_eff and Cassini ratios |
| `cassini_gamma_input.json` | Bertotti et al. 2003 value γ − 1 = (2.1 ± 2.3)·10⁻⁵ with citation and verification record |
| `map_r3/` | (λ, α_Y) exclusion map: sub-cm r4 envelope, AHN 2003 Fig. 4 digitized bound (from the clock r4 module), BREN r4 and Cassini; `map_cells.csv`, `map_grid.npz`, `map_summary.json`, `key_values_r3.json`, `preflight.json`, `crosscheck_ahn4_impl.json`, figure `map_lambda_alphaY_r3.png`; envelope check `envelope_guard.py` with negative controls `test_envelope_guard.py` → `test_envelope_guard.json`; Cassini threshold stability control `control_cassini_threshold.py` → `control_cassini_threshold.json` |
| `window_signal_r3/` | micron window below 75.877096 µm on the α_Y = 1 branch: `window_scan.csv`, `window_key_table.json`, `window_crossings.json`, `preflight.json`, negative controls `test_negative_controls.py`, figure `window_ratio.png` |
| `source_model_r3/` | reduced Fourier–Bessel source model of Eöt-Wash 2020 (thesis hdl:1773/45542): inputs with quotes, torque grids, derivative test, Newton fit and validation, envelope check `envelope_guard.py` (identical to the map copy) with negative controls `test_envelope_guard.py` → `test_envelope_guard.json`; **validation failed (0/7), no TAL torque prediction** — see `source_model_r3/time_field_source_model_note.md` |
| `extract_r4_inputs.py`, `run_all.sh`, `inputs_r4/README.txt` | input handling and full re-run |

Conventions: α = α_Y/(4π); V = −G m₁m₂/r · (1 + α e^(−r/λ)); mc² = ħc/λ. R = α/α_lim (or (1−γ)/bound for Cassini) is a conditional ratio and F = 1/R is a bound-tightening factor. Neither R nor F is a sigma or a sensitivity. "Not excluded" is not confirmation.

## Inputs (not contained here)
Three r4 module zips from the record **https://doi.org/10.5281/zenodo.23960821** (inside `TAL_publication_set_2026-11-04_r2.zip`):

| zip | SHA-256 |
|---|---|
| `tal_branch_clock_accel_test_r4.zip` (clock r4) | 6ba806210d557189fc77777a29d3e9964b0b75f81fd185230a62eedfc0daa105 |
| `subcm_yukawa_window_zenodo_r4.zip` (sub-cm r4) | e3f027587b7462900d607d858315668bc65346eada7489f34f3a06d31096ae46 |
| `bren_continuation_zenodo_r4.zip` (BREN r4) | 5f217dc47b6f91756cda9a5b1765930be82e32c5f77a80456825cfe5168edf25 |

Either copy them into `inputs_r4/`, or point to them:

```
python3 extract_r4_inputs.py --clock-zip PATH --subcm-zip PATH --bren-zip PATH
# or: export TAL_CLOCK_ZIP=PATH TAL_SUBCM_ZIP=PATH TAL_BREN_ZIP=PATH; python3 extract_r4_inputs.py
```

The script checks each SHA-256 and extracts to `inputs_r4/extracted/<zip name>/` (override with `--out` or `TAL_R4_EXTRACTED`). The map scripts read the extracted folders (`TAL_R4_EXTRACTED`); the window and source-model scripts read the sub-cm zip directly (`TAL_SUBCM_ZIP`, default `inputs_r4/subcm_yukawa_window_zenodo_r4.zip`). All paths are relative to the package; no absolute working path is needed.

## How to run
Python 3 with numpy, scipy, sympy, matplotlib (tested: Python 3.13.5, numpy 2.5.4, scipy 1.18.1, sympy 1.14.0, matplotlib 3.11.2).

```
python3 extract_r4_inputs.py
./run_all.sh
python3 source_model_r3/test_derivative.py     # separately runnable derivative test
python3 map_r3/test_envelope_guard.py          # negative controls of the envelope check (map)
python3 source_model_r3/test_envelope_guard.py # negative controls of the envelope check (source-model preflight)
```

`run_all.sh` stops at the first error. What the scripts check:
* every script stops with a non-zero exit on a missing input file or key and on a failed preflight;
* the map and window scripts also stop on a non-finite value in the bounds and curves they read;
* before use, the sub-cm envelope (`envelopes.npz`) is checked by `envelope_guard.py` (identical copies in `map_r3/` and `source_model_r3/`; `run_all.sh` checks that they are identical): one-dimensional arrays of equal length; a finite, strictly increasing log10_lambda grid; no Inf; only positive finite values; no NaN at a grid point covered by one of the packaged curves (`results.json`, `lambda_range_m`); no finite value outside that coverage. A failure names the index and λ;
* negative controls: `map_r3/test_envelope_guard.py` and `source_model_r3/test_envelope_guard.py` each run one clean and five corrupted envelopes (NaN at combined_abs[10911], Inf at combined_abs[10912], NaN at log10_lambda[10911], 0 and −1 at combined_abs[10911]); the clean case must exit 0 and reproduce the shipped outputs (map: rel 1e-12; source-model preflight: rel 1e-12), each corrupted case must exit non-zero with an envelope-check message. Result: 6/6 for both. The window module has its own controls (`window_signal_r3/test_negative_controls.py`, 6/6);
* the article value script (`article_source/src/make_values.py` of the publication set, not part of this package) stops on a missing or non-finite value.

Rerun agreement: re-running the article value script on the JSON files of this package regenerates its 15 generated files byte-identically. A fresh full recomputation with `run_all.sh` on the tested versions above reproduced every numerical output of the previous package version (largest relative deviation 0; only the new keys listed below and the figure titles differ). On other platforms or library versions, small differences in optimizer results are expected (up to about 1e-7 relative for a nuisance parameter and below 1e-9 for |alpha95| have been observed); they stay within the tolerances of the package tests (e.g. relative 1e-6 for the Newton χ² cross-check and the window edge). `SHA256SUMS` lists every file of the package.

## Changes in r2 (map r3, source model r3)
* Input check only: the shared envelope check and its negative controls (above). The numbers are unchanged within tolerance.
* New keys: `map_r3/map_summary.json` → `bounds_used/cassini/condition`; `source_model_r3/model_results.json` → `labels/alpha95_definitions`; `theory_checks/sympy_checks.json` → `matter_era_definition`, `matter_era_ode_solved`, `matter_era_residual_linearized_ode` (= 0, the residual test), `matter_era_residual_with_exp_factor_restored`, `matter_era_residual_test_pass`.
* New files: `map_r3/envelope_guard.py`, `map_r3/test_envelope_guard.py`(`.json`), `map_r3/control_cassini_threshold.py`(`.json`), `source_model_r3/envelope_guard.py`, `source_model_r3/test_envelope_guard.py`(`.json`). `fit_validate_predict.py` has a `--preflight-only` option (stops after the preflight, writes nothing).
* `window_signal_r3/window_signal.py` and `test_negative_controls.py`: only the default path of the key-value input changed to `map_r3/key_values_r3.json`.
* Text: the failed source-model validation is attributed most likely to the reduced source model, not to missing per-run positions (no new fit; numbers unchanged).
* Figure titles: map title now states the Cassini assumption (and r3); source-model panel (b) reads "validation (r3)".

## Definitions and assumptions
* **α95.** The signed alpha95_pos and alpha95_neg profile thresholds use the fixed Δχ² = 6.17 rule (fixed comparison recipe, not a separately proven 95% test). The absolute A = |alpha95| used in the validation instead satisfies P(−A ≤ α ≤ A) = 0.95 under the Gaussian approximation with mean alpha_star and sigma_alpha from the Δχ² = 1 profile width: Φ((A − α*)/σ) − Φ((−A − α*)/σ) = 0.95. Example at 50 µm: A = 0.5591, alpha95_pos = 0.7011, alpha95_neg = −0.0949.
* **Matter era.** Linearized test-field solution on a prescribed matter-era GR dust background (H = 2/(3t), e^(−φ) ≈ 1, negligible scalar backreaction; bare mass and non-minimal term off). The residual of the solution in the solved equation g'' + 2g'/t = α_Y/(6π t²) is 0; with e^(−φ) restored in the source the residual is α_Y/(6π t²)·[1 − e^(−φ)]. Not the full nonlinear solution.
* **Cassini layer.** For the Cassini layer we use the long-range PPN relation, operationally from lambda>=1 AU. We did not compute the finite-lambda radio-link response or the error of this approximation; this is an assumption of the map layer. Moving the threshold to 100 AU changes 0 of the 34 000 cells with λ ≥ 1 AU (`map_r3/control_cassini_threshold.json`); this is a stability control of the threshold rule, not a physical validation.
* **γ prior.** Changing the prior centre to 1.000 shifts the absolute limits by only 1–3% at the two tested lambda values and does not bring them within ±20%. This checks one prior variant, not all possible causes of the discrepancy.

## Main results (with the file that holds them)
* Vacuum mass: V″(0) = 1/L² cannot be fixed without a new dimensional constant (`theory_checks/sympy_checks.json`). The density mass m_eff² = α_Y G ρ e^(−φ)/c² is a hypothesis (H-noV), giving weak screening; on α_Y = 1 it conflicts with Cassini: 1 − γ = 0.14742, R = 5.90·10³ against the 2.5·10⁻⁵ reading (`theory_checks/numbers.json`, `cassini_gamma_input.json`).
* Map: cell counts and α_Y,max(λ) in `map_r3/map_summary.json` and `map_r3/key_values_r3.json`.
* Window: on α_Y = 1, 2 µm ≤ λ < 75.877096 µm is not excluded by the drawn bounds; F_env = 5.26434 at 50 µm, 1.05316 at 75 µm, → 1 at the edge (`window_signal_r3/window_crossings.json`).
* Source model r3: Newton χ² = 291.1403 (N_data = 285, ν_eff ≈ 284), validation 0/7 within ±20%, no TAL prediction (`source_model_r3/model_results.json`). The failure most likely lies in our reduced source model (the fitted r_P = 65 µm is far larger than the few-micrometre offsets typical of the experiment).

## Sources
* Lee, J. G. et al., Phys. Rev. Lett. 124, 101101 (2020), https://doi.org/10.1103/PhysRevLett.124.101101; arXiv:2002.11761, https://arxiv.org/abs/2002.11761
* Lee, J. G., PhD thesis, University of Washington (2020), https://hdl.handle.net/1773/45542
* Tan, W.-H. et al., Phys. Rev. Lett. 124, 051301 (2020), https://doi.org/10.1103/PhysRevLett.124.051301
* Adelberger, E. G., Heckel, B. R., Nelson, A. E., Annu. Rev. Nucl. Part. Sci. 53, 77–121 (2003), https://doi.org/10.1146/annurev.nucl.53.041002.110503
* Bertotti, B., Iess, L., Tortora, P., Nature 425, 374–376 (2003), https://doi.org/10.1038/nature01997
* TAL branch and r4 modules: https://doi.org/10.5281/zenodo.23960821

Digitized bounds come from the r4 modules of that record (each with its own source list). No third-party PDF is included.

---

## Magyar összefoglaló
Ez a csomag a „Mass of the TAL time scalar field: (λ, α_Y) exclusion map and the micron window” cikk (EN és HU PDF) kódját és kimeneteit tartalmazza: elméleti ellenőrzések (`theory_checks/`), Cassini-bemenet, kizárási térkép (`map_r3/`), mikrométeres ablak (`window_signal_r3/`) és az Eöt-Wash 2020 redukált forrásmodellje (`source_model_r3/`; a validáció sikertelen, 0/7, TAL-nyomatékjóslat nincs; a sikertelenség oka legvalószínűbben a redukált forrásmodellünkben van, mert az illesztett r_P = 65 µm jóval nagyobb a kísérletre jellemző néhány mikrométeres eltolódásnál). Az r2 csomagban csak a bemenet-ellenőrzés változott (közös `envelope_guard.py` negatív kontrollokkal, 6/6 a térképre és a forrásmodellre); a számok a toleranciákon belül változatlanok. A Cassini-rétegben a nagy hatótávolságú PPN-relációt alkalmazzuk, operatívan lambda>=1 CsE-től. A véges lambda melletti rádiós jelátvitelt és e közelítés hibáját nem számoltuk; ez a térképréteg feltételes modellfeltevése. Az előjeles alpha95_pos és alpha95_neg profilhatárokat a rögzített Delta chi2=6,17 metszéspontokból számítjuk. A validációban használt abszolút A=|alpha95| viszont a normális közelítés P(-A<=alpha<=A)=0,95 feltételéből származik, a profilminimum alpha_star és a Delta chi2=1 profilból becsült sigma_alpha felhasználásával. Az anyagdominált megoldás linearizált próbatér-megoldás az előírt GR-por háttérben (H=2/3t, e^(-phi)≈1, elhanyagolt skalár-visszahatás).

Bemenetek: a https://doi.org/10.5281/zenodo.23960821 rekord három r4 zipje (lásd a fenti SHA-256 táblát). Másold őket az `inputs_r4/` mappába, vagy add meg az útvonalukat (`--clock-zip`, `--subcm-zip`, `--bren-zip`, illetve `TAL_CLOCK_ZIP`, `TAL_SUBCM_ZIP`, `TAL_BREN_ZIP`, `TAL_R4_EXTRACTED`). Futtatás: `python3 extract_r4_inputs.py`, majd `./run_all.sh`; a deriválttesztet külön a `python3 source_model_r3/test_derivative.py`, a negatív kontrollokat a `python3 map_r3/test_envelope_guard.py` és a `python3 source_model_r3/test_envelope_guard.py` futtatja.

R és F feltételes arányok, nem szigma és nem érzékenység; a „nem kizárt” nem megerősítés.

Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); nem szakmai lektorálás.

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X) · CC BY-NC 4.0 Nemzetközi (https://creativecommons.org/licenses/by-nc/4.0/deed.hu) · kereskedelmi hasznosítás kizárólag a szerző írásos engedélyével.
