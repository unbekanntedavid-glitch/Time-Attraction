import math, json, os
HERE = os.path.dirname(os.path.abspath(__file__))
hbar=1.054571817e-34; c=299792458.0; e=1.602176634e-19; G=6.67430e-11
AU=1.495978707e11; kpc=3.085677581e19; Mpc=kpc*1e3; H0=67.4e3/Mpc
GM_E,R_E=3.986004418e14,6.3710e6; GM_S,R_S=1.3271244e20,6.957e8
rhoE=3*GM_E/(4*math.pi*G*R_E**3); rhoS=3*GM_S/(4*math.pi*G*R_S**3)
envs=[("lab granite (clock r4 setup_declared.json)",2700.0,None),
 ("Earth mean (GM_E, R_E; external standard values)",rhoE,(GM_E,R_E)),
 ("Sun mean (IAU 2015 nominal GM, R; external)",rhoS,(GM_S,R_S)),
 ("interplanetary at 1 AU (external order estimate, n~5 cm^-3)",5e6*1.6726e-27,None),
 ("galactic disk, illustrative upper density 1e-21 (input value; not used in the article)",1e-21,None),
 ("galactic enclosed median density, illustrative input value (not used in the article)",7.926199753809567e-22,None),
 ("galactic threshold density 1e-23, illustrative input value (not used in the article)",1e-23,None),
 ("cosmic mean matter density rho_m0, illustrative input value (not used in the article)",2.686310e-27,None)]
rows=[]
for aY in (1.0,1/3):
  for n,rho,body in envs:
    k=math.sqrt(aY*G*rho)/c; L=1/k
    r={"alpha_Y":aY,"env":n,"rho_kg_m3":rho,"L_eff_m":L,"L_eff_AU":L/AU,"mc2_eV":hbar*c*k/e,"m_kg":hbar*k/c}
    if body:
      GM,R=body; Phi=GM/(R*c**2); r.update(Phi=Phi,R_over_L_sq=(R/L)**2,p_needed_Hexp=1/((R/L)**2)-1)
    rows.append(r)
res={"rows":rows,"rhoE":rhoE,"rhoS":rhoS}
res["cosmo_m_over_H_matter_era_aY1"]=math.sqrt(3/(8*math.pi))
res["drift_dphi_dlna_aY1"]=1/(4*math.pi)
res["drift_Delta_phi_a1100_to_1_aY1"]=math.log(1100)/(4*math.pi)
res["phidot_today_matter_approx_per_yr"]=H0/(4*math.pi)*3.15576e7
def omg(aY): return 2*aY/(aY+4*math.pi)
cas={}
for name,b in [("round_bound_1e-5",1e-5),("Bertotti_1sigma_lower |2.1-2.3|e-5",abs(2.1e-5-2.3e-5)),("Bertotti_2sigma_lower |2.1-4.6|e-5",abs(2.1e-5-4.6e-5))]:
  cas[name]={"bound_on_1_minus_gamma":b,"R_aY1":omg(1)/b,"R_aY1_3":omg(1/3)/b,"alphaY_max":4*math.pi*b/(2-b)}
res["one_minus_gamma_aY1"]=omg(1); res["one_minus_gamma_aY1_3"]=omg(1/3); res["cassini"]=cas
json.dump(res,open(os.path.join(HERE,'numbers.json'),'w'),indent=1)
for r in rows: print({k:(f"{v:.4e}" if isinstance(v,float) else v) for k,v in r.items()})
print({k:v for k,v in res.items() if k not in("rows",)})
