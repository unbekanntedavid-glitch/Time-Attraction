import sympy as sp, json, math, os
HERE = os.path.dirname(os.path.abspath(__file__))
out={}
# 1) static EL equation and effective potential for the TAL branch, record doi:10.5281/zenodo.23960821 (G=c=1), with optional bare mass and xi R term (R=8*pi*rho for dust)
phi,aY,L,rho,xi,x=sp.symbols('phi alpha_Y L rho xi x',positive=True)
f=sp.Function('phi')(x)
Lag=-(1/(2*aY))*(sp.diff(f,x)**2+f**2/L**2)-sp.exp(-f)*rho-(xi/(16*sp.pi))*f**2*(8*sp.pi*rho)
EL=sp.euler_equations(Lag,f,x)[0].lhs
# EL: d/dx(dL/df') - dL/df = 0  -> rearrange to f'' = U'(f)
fpp=sp.solve(EL,sp.diff(f,x,2))[0]
U=sp.integrate(fpp.subs(f,phi),phi)
U2=sp.simplify(sp.diff(U,phi,2))
out['static_fpp']=str(sp.simplify(fpp.subs(f,phi)))
out['U_doubleprime']=str(sp.expand(U2))
# 2) matter era: linearized test-field solution on a prescribed matter-era GR dust background.
#    Solved ODE: phi'' + 3H phi' = alpha_Y*G*rho with H = 2/(3t) and G rho = 3H^2/(8 pi) prescribed (GR dust),
#    e^(-phi) ~ 1 in the source, scalar backreaction on H neglected, bare mass (1/L^2) and non-minimal (xi R) term off.
#    This is NOT the full nonlinear (backreacting, e^(-phi)-coupled) cosmological solution.
t=sp.symbols('t',positive=True); g=sp.Function('g')(t); H=2/(3*t)
ode=sp.Eq(sp.diff(g,t,2)+3*H*sp.diff(g,t), aY*3*H**2/(8*sp.pi))
sol=sp.dsolve(ode,g)
out['matter_era_solution']=str(sol.rhs)
out['matter_era_definition']=("linearized test-field solution on a prescribed matter-era GR dust background "
    "(H = 2/(3t), G rho = 3H^2/(8 pi), e^(-phi) ~ 1 in the source, negligible scalar backreaction, bare mass and non-minimal term off); "
    "not the full nonlinear cosmological solution")
out['matter_era_ode_solved']=str(sp.simplify(ode.lhs-ode.rhs))+" = 0"
# residual test: substitute the solution into the ODE actually solved -> must simplify to exactly 0
res_lin=sp.simplify((ode.lhs-ode.rhs).subs(g,sol.rhs).doit())
out['matter_era_residual_linearized_ode']=str(res_lin)
# information only: the same solution in the same prescribed background with the factor e^(-phi) restored in the source
res_exp=sp.simplify((sp.diff(g,t,2)+3*H*sp.diff(g,t)-aY*3*H**2/(8*sp.pi)*sp.exp(-g)).subs(g,sol.rhs).doit())
out['matter_era_residual_with_exp_factor_restored']=str(sp.factor(res_exp))
out['matter_era_residual_test_pass']=bool(res_lin==0)
if res_lin!=0: raise SystemExit("matter-era residual test failed: "+str(res_lin))
# 3) FRW minisuperspace check of conformal map F(phi)R -> Einstein frame (G=c=1, 16pi factor dropped)
N,a=sp.Function('N')(t),sp.Function('a')(t); p=sp.Function('p')(t)
def LR(N,a):  # sqrt(-g) R for ds^2=-N^2dt^2+a^2dx^2 (flat), up to nothing
    ad=sp.diff(a,t); add=sp.diff(a,t,2); Nd=sp.diff(N,t)
    R=6*(add/(a*N**2)-ad*Nd/(a*N**3)+ad**2/(a**2*N**2))
    return N*a**3*R
F=sp.exp(2*p)   # Jordan-frame F such that matter metric g = g_E/F gives A = F^{-1/2} = e^{-phi}
LJ=F*LR(N,a)
# Einstein frame variables: aE = sqrt(F) a, NE = sqrt(F) N
aE,NE=sp.Function('aE')(t),sp.Function('NE')(t)
LE=LR(NE,aE) - sp.Rational(3,2)*NE*aE**3*(-(sp.diff(F,t)/F)**2/NE**2)  # sqrt(-gE)[R_E - (3/2) gE^{mn} d lnF d lnF], gE^{tt}=-1/NE^2
LE_sub=LE.subs({aE:sp.exp(p)*a,NE:sp.exp(p)*N}).doit()
diff=sp.simplify(sp.expand(LJ-LE_sub))
# check total derivative: Euler operator wrt a, N, p must vanish
from sympy.calculus.euler import euler_equations
eqs=euler_equations(diff,[N,a,p],t)
out['conformal_map_total_derivative']=all(sp.simplify(e.lhs)==0 for e in eqs)
# 4) exponential potential + e^{-q phi} coupling: mass at minimum
A_,B_,P_,Q_=sp.symbols('A B p q',positive=True)
Uexp=A_*sp.exp(P_*phi)+B_*sp.exp(-Q_*phi)
pmin=sp.solve(sp.diff(Uexp,phi),phi)[0]
out['exp_min_U2']=str(sp.simplify(sp.diff(Uexp,phi,2).subs(phi,pmin)/(B_*sp.exp(-Q_*pmin))))
# 5) gamma_PPN with alpha=alpha_Y/4pi
al=aY/(4*sp.pi); gam=(1-al)/(1+al)
out['one_minus_gamma']=str(sp.simplify(1-gam))
json.dump(out,open(os.path.join(HERE,'sympy_checks.json'),'w'),indent=1)
print(json.dumps(out,indent=1))
