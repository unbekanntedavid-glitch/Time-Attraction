#!/usr/bin/env python3
"""r3 (same as r2 apart from the panel label): panel titles separate N_data from the approximate effective degrees of freedom; the verdict is read from the results.
Figure: (a) published Eot-Wash 2020 run torques / reduced FB Newton model (nominal r_P = 0 and fitted nuisances);
(b) |alpha95| from the reduced model vs thesis Table 11.4 with the pre-declared +-20% band (validation result)."""
import json, math, os, sys
sys.dont_write_bytecode = True
import numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline
H = os.path.dirname(os.path.abspath(__file__))
I = json.load(open(os.path.join(H, "experiment_inputs.json")))["eot_wash_2020"]; R = json.load(open(os.path.join(H, "model_results.json")))
G = np.load(os.path.join(H, "torque_grids.npz")); runs = I["runs"]["rows"]; C = I["offcenter_empirical"]["coeffs"]; RA = 7.5e-3
s = np.array([r[1] for r in runs]) * 1e-6
def Rf(h, rp, smm):
    c0, c1, c2, c3 = C[h][:4]; f = c1 + c2 * np.exp(c3 * smm); rg, rl = max(rp, RA), min(rp, RA)
    return c0 + (1 - c0) * np.cos(f * rg) * (1 - (rl * f) ** 2 / 4)
nf = R["newton_fit"]
fig, ax = plt.subplots(1, 2, figsize=(13, 5.2))
for h, col, k in (("120", "C0", 3), ("18", "C1", 5)):
    y = np.array([r[k] for r in runs]); e = np.array([r[k + 1] for r in runs]); sp = CubicSpline(np.log(G["s_m"]), G[f"N_{h}"] * 1e15)
    m0 = 1.012 * Rf(h, 0.0, s * 1e3) * sp(np.log(s)); m1 = nf["gamma"] * Rf(h, nf["r_P_mm"], s * 1e3) * sp(np.log(s + nf["ds_um"] * 1e-6))
    g = (e / np.abs(y) < 0.05) & (y > 0.2)
    ax[0].errorbar(s[g] * 1e6, y[g] / m0[g], e[g] / m0[g], fmt="o", ms=3, color=col, alpha=0.35, label=f"{h}ω  data / model, nominal (r_P = 0, γ = 1.012)")
    ax[0].errorbar(s[g] * 1e6, y[g] / m1[g], e[g] / m1[g], fmt="s", ms=3, color=col, label=f"{h}ω  data / model, fitted nuisances")
ax[0].axhline(1, color="k", lw=0.8); ax[0].set_xscale("log"); ax[0].set_xlabel("face-to-face separation s [µm]"); ax[0].set_ylabel("measured torque / model")
ax[0].set_title(f"(a) Newton: χ² nominal {nf['chi2_nominal_rP0_no_fit']:.0f}, fitted {nf['chi2_fit']:.1f} (N_data = {nf['N_data']}, ν_eff ≈ {nf['nu_effective_approx']}); fitted r_P = {nf['r_P_mm']*1e3:.0f} µm", fontsize=9)
ax[0].legend(fontsize=7); ax[0].set_ylim(0.85, 1.12)
P = R["validation"]["points"]; lam = np.array([p["lambda_m"] for p in P]) * 1e6
mod = np.array([p["alpha95_abs"] for p in P]); th = np.array([p["thesis"]["alpha95_abs"] for p in P])
ax[1].fill_between(lam, th * 0.8, th * 1.2, color="0.85", label="thesis Table 11.4 |α95| ±20% (pre-declared tolerance)")
ax[1].plot(lam, th, "k-o", ms=4, label="thesis Table 11.4 |α95|"); ax[1].plot(lam, mod, "r-s", ms=4, label="reduced FB model |α95| (this work)")
ax[1].axhline(1 / (4 * math.pi), color="C2", ls="--", label="α_TAL = 1/(4π) (hypothesis)")
ax[1].set_xscale("log"); ax[1].set_yscale("log"); ax[1].set_xlabel("λ [µm]"); ax[1].set_ylabel("|α| 95% CL")
verdict = "passed (pre-declared rule)" if R["validation"]["pass"] else "FAILED, no TAL prediction"
ax[1].set_title(f"(b) validation (r3): {R['validation']['n_within_tol']}/{len(P)} points within ±20%  →  {verdict}", fontsize=9)
ax[1].legend(fontsize=7)
fig.suptitle("Eöt-Wash 2020 source model (thesis hdl:1773/45542 inputs) — validation only; model estimate, not a detection claim", fontsize=10)
fig.tight_layout(); fig.savefig(os.path.join(H, "source_model_validation.png"), dpi=130)
