#!/usr/bin/env python3
"""Reduced Eot-Wash 2020 model (thesis hdl:1773/45542, sec. 11.2.4, eq. 11.1) shared by fit_validate_predict.py and
test_derivative.py. Prediction m_h(s) = gamma [R_N(s) N_h(s+ds) + alpha R_Y(s) Y_h(s+ds)], R = empirical off-center
correction (thesis Table 2.1 / App. B.2) evaluated at the physical separation s (in mm), N and Y spline tables in fN m.
r2: the returned derivative is the full separation derivative (product rule), with the analytic dR/ds below."""
import math
import numpy as np
from scipy.interpolate import CubicSpline
SPY = {}
def setup(EW, GR, runs):
    g = globals()
    g["s_j"] = np.array([r[1] for r in runs]) * 1e-6; g["ds_j"] = np.array([r[2] for r in runs]) * 1e-6
    g["Y"] = {"120": (np.array([r[3] for r in runs]), np.array([r[4] for r in runs])),
              "18": (np.array([r[5] for r in runs]), np.array([r[6] for r in runs])),
              "54": (np.array([r[7] for r in runs]), np.array([r[8] for r in runs]))}
    g["SG"] = GR["s_m"]; g["LAMS"] = GR["lam_m"]; g["lsg"] = np.log(GR["s_m"]); g["GR"] = GR
    g["SPN"] = {h: CubicSpline(np.log(GR["s_m"]), GR[f"N_{h}"] * 1e15) for h in g["Y"]}
    g["C"] = EW["offcenter_empirical"]["coeffs"]
    an = EW["alignment_and_nuisance"]
    g["RA"] = float(an["r_A"]["value"]) * 1e-3          # mm
    g["G0"] = float(an["gamma"]["value"]); g["GE"] = float(an["gamma_err"]); g["SE"] = float(an["s0_err"])   # SE in um
def spY(h, li): return CubicSpline(lsg, GR[f"Y_{h}"][li] * 1e15)
def _y(h, s_mm, lam_mm):
    c0, c1, c2, c3, c4, c5, c6 = C[h]
    if lam_mm is None: return s_mm, 1.0
    return (1 - math.exp(c6 * lam_mm)) * s_mm + c4 * math.exp(c5 * lam_mm), (1 - math.exp(c6 * lam_mm))
def Rfun(h, rp, s_mm, lam_mm):
    c0, c1, c2, c3 = C[h][:4]
    y, _ = _y(h, s_mm, lam_mm)
    f = c1 + c2 * np.exp(c3 * y)
    rg, rl = max(rp, RA), min(rp, RA)
    return c0 + (1 - c0) * np.cos(f * rg) * (1 - (rl * f) ** 2 / 4)
def dRfun_ds_m(h, rp, s_mm, lam_mm):
    """dR/ds per metre: dR/ds_mm = (1-c0) f' [-r> sin(r> f) q - cos(r> f) r<^2 f/2], f' = c2 c3 exp(c3 y) dy/ds_mm,
    q = 1 - (r< f)^2/4; times 1000 for mm -> m."""
    c0, c1, c2, c3 = C[h][:4]
    y, dy = _y(h, s_mm, lam_mm)
    e = np.exp(c3 * y); f = c1 + c2 * e; fp = c2 * c3 * e * dy
    rg, rl = max(rp, RA), min(rp, RA)
    q = 1 - (rl * f) ** 2 / 4
    return 1000.0 * (1 - c0) * fp * (-rg * np.sin(rg * f) * q - np.cos(rg * f) * rl ** 2 * f / 2)
def pred_at(theta, li, s, spy=None):
    """m_h and dm_h/ds (per metre) at physical separations s [m] for all harmonics."""
    a, gam, dsu, rp = theta; rp = abs(rp)
    out = {}
    for h in Y:
        sx = np.log(s + dsu * 1e-6)
        n = SPN[h](sx); dn = SPN[h](sx, 1) / (s + dsu * 1e-6)
        RN = Rfun(h, rp, s * 1e3, None); dRN = dRfun_ds_m(h, rp, s * 1e3, None)
        m = gam * RN * n; dm = gam * (dRN * n + RN * dn)
        if li is not None and a != 0.0:
            sy = (spy or SPY)[h]; lam_mm = LAMS[li] * 1e3
            yv = sy(sx); dyv = sy(sx, 1) / (s + dsu * 1e-6)
            RY = Rfun(h, rp, s * 1e3, lam_mm); dRY = dRfun_ds_m(h, rp, s * 1e3, lam_mm)
            m = m + a * gam * RY * yv; dm = dm + a * gam * (dRY * yv + RY * dyv)
        out[h] = (m, dm)
    return out
def pred(theta, li, gamma_prior=None):
    return pred_at(theta, li, s_j)
