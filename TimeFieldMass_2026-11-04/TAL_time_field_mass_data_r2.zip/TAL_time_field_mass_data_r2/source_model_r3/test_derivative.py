#!/usr/bin/env python3
"""Separately runnable check: the analytic separation derivative returned by reduced_model.pred_at equals a central
finite difference of the prediction itself, for all three harmonics, Newton (alpha = 0) and Yukawa (alpha = 1/(4 pi),
lambda = 50 um), at the 95 published separations, with nuisances near the Newton fit. Acceptance: rtol <= 1e-6.
Two step sizes are used; their agreement is reported. Exit 0 only if every case passes."""
import json, math, os, sys
sys.dont_write_bytecode = True
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import reduced_model as RM
INP = json.load(open(os.path.join(HERE, "experiment_inputs.json")))["eot_wash_2020"]
GR = np.load(os.path.join(HERE, "torque_grids.npz"))
RM.setup(INP, GR, INP["runs"]["rows"])
RTOL = 1e-6
li = int(np.where(np.isclose(RM.LAMS, 50e-6, rtol=1e-9))[0][0])
spy = {h: RM.spY(h, li) for h in RM.Y}
rep = {"rtol": RTOL, "cases": []}
for name, theta, l in (("Newton", [0.0, 0.9966, 0.93, 0.0653], None), ("Yukawa alpha=1/(4pi), lambda=50um", [1 / (4 * math.pi), 0.9966, 0.93, 0.0653], li),
                       ("Yukawa alpha=1, lambda=50um, r_P < r_A", [1.0, 1.01, -0.5, 0.004], li)):
    s = RM.s_j
    an = RM.pred_at(theta, l, s, spy)
    for h in RM.Y:
        res = {}
        for step in (1e-9, 2e-10):
            mp = RM.pred_at(theta, l, s + step, spy)[h][0]; mm = RM.pred_at(theta, l, s - step, spy)[h][0]
            res[step] = (mp - mm) / (2 * step)
        rel = np.max(np.abs(an[h][1] - res[1e-9]) / np.abs(res[1e-9]))
        steps = np.max(np.abs(res[1e-9] - res[2e-10]) / np.abs(res[1e-9]))
        # size of the term that r1 omitted (dR/ds part), relative to the full derivative
        a, gam, dsu, rp = theta; sx = np.log(s + dsu * 1e-6)
        part = gam * RM.dRfun_ds_m(h, abs(rp), s * 1e3, None) * RM.SPN[h](sx)
        if l is not None: part = part + a * gam * RM.dRfun_ds_m(h, abs(rp), s * 1e3, RM.LAMS[l] * 1e3) * spy[h](sx)
        rep["cases"].append({"case": name, "harmonic": h, "max_rel_dev_analytic_vs_fd": float(rel), "fd_step_agreement": float(steps),
                             "max_rel_size_of_dR_term": float(np.max(np.abs(part / an[h][1]))), "pass": bool(rel <= RTOL)})
rep["pass"] = all(c["pass"] for c in rep["cases"])
json.dump(rep, open(os.path.join(HERE, "test_derivative.json"), "w"), indent=1)
for c in rep["cases"]: print(c)
print("PASS" if rep["pass"] else "FAIL"); sys.exit(0 if rep["pass"] else 1)
