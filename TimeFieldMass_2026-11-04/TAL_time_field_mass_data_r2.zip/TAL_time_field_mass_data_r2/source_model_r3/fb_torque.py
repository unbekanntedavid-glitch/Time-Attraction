#!/usr/bin/env python3
"""Fourier-Bessel torque between two coaxial N-fold wedge-hole patterns (Eot-Wash 2020 geometry).

Source of the formalism: J. G. Lee, PhD thesis, Univ. of Washington (2020), hdl:1773/45542, sec. 2.1
(Green's function G = sum_m e^{im(phi-phi')} int dk k J_m(kr) J_m(kr') e^{-kappa|z-z'|}/kappa, kappa = sqrt(k^2+mu^2),
mu = 0 Newton, mu = 1/lambda Yukawa; tau = -dU/dphi). Re-derived here for full-thickness wedge holes:

  tau_m(s) = m * 8 G drho_p drho_a sin(m b_p) sin(m b_a) / l^2
             * int_0^inf dk k Q_m^p(k) Q_m^a(k) (1-e^{-kappa t_p})(1-e^{-kappa t_a}) e^{-kappa s} / kappa^3

  m = N l (harmonic of the attractor rotation), b = half subtended wedge angle, Q_m(k) = int_{ri}^{ro} J_m(kr) r dr,
  drho = (mass removed)/(wedge volume) - rho_glue  (holes are filled with epoxy, thesis sec. 4.4),
  s = face-to-face separation of the two foils. Yukawa torque for strength alpha is alpha * tau_m(s; mu = 1/lambda).

Q_m is computed exactly as (F_m(k ro) - F_m(k ri))/k^2 with F_m(X) = int_0^X x J_m(x) dx tabulated once
(cumulative trapezoid, step dx); accuracy is self-tested against adaptive quadrature in selftest()."""
import math, sys
import numpy as np
from scipy.special import jv
from scipy.integrate import cumulative_trapezoid, quad
sys.dont_write_bytecode = True
G = 6.67430e-11            # CODATA 2018, m^3 kg^-1 s^-2
DX = 0.004
_TAB = {}

def ftable(m, xmax):
    if m in _TAB and _TAB[m][0][-1] >= xmax: return _TAB[m]
    x = np.arange(0.0, xmax + 20 * DX, DX)
    F = cumulative_trapezoid(x * jv(m, x), x, initial=0.0)
    if not np.all(np.isfinite(F)): raise ValueError(f"non-finite F table m={m}")
    _TAB[m] = (x, F); return _TAB[m]

def Q(m, k, ri, ro):
    x, F = _TAB[m]
    if k[-1] * ro > x[-1]: raise ValueError("F table too short")
    return (np.interp(k * ro, x, F) - np.interp(k * ri, x, F)) / k ** 2

def layer(g, N, eps_m, rho_glue):
    """g: dict with ri, ro [m], beta_full_deg, t [m], mass [kg]. Overcut eps (thesis sec. 11.2.1): ri-eps, ro+eps, beta+2 atan(2eps/(ri+ro))."""
    ri, ro = g["ri"] - eps_m, g["ro"] + eps_m
    beta = math.radians(g["beta_full_deg"]) + 2 * math.atan(2 * eps_m / (g["ri"] + g["ro"]))
    V = N * 0.5 * beta * (ro ** 2 - ri ** 2) * g["t"]
    return {"ri": ri, "ro": ro, "bh": 0.5 * beta, "t": g["t"], "drho": g["mass"] / V - rho_glue, "rho_pt_inferred": g["mass"] / V}

def torque(p, a, N, l, s, lam=None, dk=4.0, kfac=60.0):
    """Amplitude [N m] of the m = N*l harmonic for layers p (pendulum) and a (attractor). lam=None: Newton (alpha=1 Yukawa otherwise)."""
    m = N * l
    kmax = kfac / s
    k = np.arange(dk, kmax + dk, dk)
    ftable(m, kmax * max(p["ro"], a["ro"]) * 1.01)
    kap = k if lam is None else np.sqrt(k * k + 1.0 / lam ** 2)
    I = k * Q(m, k, p["ri"], p["ro"]) * Q(m, k, a["ri"], a["ro"]) * (-np.expm1(-kap * p["t"])) * (-np.expm1(-kap * a["t"])) * np.exp(-kap * s) / kap ** 3
    K = float(np.trapezoid(I, k))
    pref = m * 8.0 * G * p["drho"] * a["drho"] * math.sin(m * p["bh"]) * math.sin(m * a["bh"]) / l ** 2
    v = pref * K
    if not math.isfinite(v): raise ValueError("non-finite torque")
    return v

def selftest(p120, a120, p18):
    """Q vs adaptive quadrature, and k-grid convergence (dk 4 vs 1, kfac 60 vs 120)."""
    out = {"Q_vs_quad": [], "kgrid": []}
    ftable(120, 1e5 * 0.027); ftable(18, 1e5 * 0.027)
    for m, ly in ((120, p120), (18, p18)):
        for k in (5e3, 2e4, 8e4):
            ref = quad(lambda r: jv(m, k * r) * r, ly["ri"], ly["ro"], limit=4000)[0]
            val = float(Q(m, np.array([k]), ly["ri"], ly["ro"])[0])
            scale = max(abs(ref), 1e-9)
            out["Q_vs_quad"].append({"m": m, "k": k, "quad": ref, "table": val, "abs_dev": abs(val - ref), "rel_dev": abs(val - ref) / scale})
    for lam in (None, 50e-6):
        t1 = torque(p120, a120, 120, 1, 60e-6, lam, dk=4.0, kfac=60.0); t2 = torque(p120, a120, 120, 1, 60e-6, lam, dk=1.0, kfac=120.0)
        out["kgrid"].append({"lam_m": lam, "dk4_kfac60": t1, "dk1_kfac120": t2, "rel": abs(t1 / t2 - 1)})
    return out
