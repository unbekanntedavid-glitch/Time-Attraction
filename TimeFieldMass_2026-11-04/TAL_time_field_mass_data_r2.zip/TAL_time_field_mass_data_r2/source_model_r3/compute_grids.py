#!/usr/bin/env python3
"""Tabulate Eot-Wash 2020 Fourier-Bessel torques (Newton and alpha=1 Yukawa) on a separation grid.
Inputs: experiment_inputs.json (quoted thesis values). Output: torque_grids.npz, selftest.json.
Harmonics: 120w = 120-fold pattern l=1; 18w = 18-fold l=1; 54w = 18-fold l=3 (thesis sec. 11.1)."""
import json, math, os, sys, time
sys.dont_write_bytecode = True
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import fb_torque as fb
D = json.load(open(os.path.join(HERE, "experiment_inputs.json")))["eot_wash_2020"]
g = D["geometry"]
def val(x): return float(x["value"])
EPS = val(g["overcut_eps"]) * 1e-6; RG = val(g["glue_density"]) * 1000.0
def mk(side, n):
    s = g[side]
    return fb.layer({"ri": val(s[f"ri{n}"]) * 1e-3, "ro": val(s[f"ro{n}"]) * 1e-3, "beta_full_deg": val(s[f"beta{n}_full_deg"]),
                     "t": val(s[f"t{n}"]) * 1e-6, "mass": val(s[f"m{n}"]) * 1e-3}, int(n), EPS, RG)
L = {(side, n): mk(side, n) for side in ("pendulum", "attractor") for n in ("120", "18")}
HARM = {"120": ("120", 1), "18": ("18", 1), "54": ("18", 3)}
SG = np.logspace(math.log10(40e-6), math.log10(3.2e-3), 160)
LAMS = np.array([40e-6, 50e-6, 60e-6, 63e-6, 70e-6, 71e-6, 75e-6, 75.87709630440307e-6, 79e-6, 100e-6, 250e-6])
if __name__ == "__main__":
    t0 = time.time()
    st = fb.selftest(L[("pendulum", "120")], L[("attractor", "120")], L[("pendulum", "18")])
    st["layers"] = {f"{a}_{b}": v for (a, b), v in L.items()}
    st["pass"] = bool(all(q["abs_dev"] < 1e-11 for q in st["Q_vs_quad"]) and all(x["rel"] < 1e-6 for x in st["kgrid"]))
    st["tolerances"] = {"Q_abs_dev_m2": 1e-11, "kgrid_rel": 1e-6}
    json.dump(st, open(os.path.join(HERE, "selftest.json"), "w"), indent=1)
    if not st["pass"]: raise SystemExit("selftest failed")
    out = {"s_m": SG, "lam_m": LAMS}
    for h, (n, l) in HARM.items():
        p, a = L[("pendulum", n)], L[("attractor", n)]
        out[f"N_{h}"] = np.array([fb.torque(p, a, int(n), l, s) for s in SG])
        out[f"Y_{h}"] = np.array([[fb.torque(p, a, int(n), l, s, lam) for s in SG] for lam in LAMS])
        print(h, "done", round(time.time() - t0, 1), "s", flush=True)
    for k, v in out.items():
        if not np.all(np.isfinite(v)): raise SystemExit(f"non-finite {k}")
    np.savez(os.path.join(HERE, "torque_grids.npz"), **out)
    print("selftest", st["pass"], "elapsed", round(time.time() - t0, 1))
