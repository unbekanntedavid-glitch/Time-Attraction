#!/usr/bin/env python3
"""r3 (2026-11-04): input guard only. The sub-cm envelope (log10_lambda, combined_abs) is checked by
envelope_guard.validate_envelope (coverage-aware, strict) before it is used for the edge; --preflight-only stops after
the preflight (used by test_envelope_guard.py). Fit, validation, rules, tolerances and the gate are unchanged from r2.
r2 (2026-11-04): the separation derivative in the chi2 error term now uses the full product rule
dm/ds = gamma[R'_N N + R_N N'] + alpha gamma[R'_Y Y + R_Y Y'] (analytic dR/ds, see dRfun; tested by test_derivative.py);
N_data = 285 and nu_effective_approx = 284 are reported separately. Rules, tolerances and the gate are unchanged.
Step B for Eot-Wash 2020 (Lee et al., PRL 124, 101101; thesis hdl:1773/45542):
 (0) preflight: 75.877 um edge from the sub-cm r4 zip (read-only); thesis Table 11.4 rows vs packaged csv;
 (1) Newtonian fit of the reduced published model (thesis sec. 11.2.4, eq. 11.1) to the 95 published runs;
 (2) validation: alpha*, sigma_alpha, +-alpha95, |alpha95| vs thesis Table 11.4 at pre-declared lambda points;
 (3) only if (2) passes: TAL Yukawa torque for alpha = 1/(4 pi) at 50, 60, 70, 75 um and S/N vs published noise.
S/N and alpha_TAL/sigma_alpha are model-estimate ratios, not detection claims and not sigma of any observed effect.
Reduced model: Ntilde_m = gamma * [R_m(r>,r<,s,inf) N_m(s+ds) + alpha R_m(r>,r<,s,lam) Y_m(s+ds)],
nuisances gamma (prior 1.012 +- 0.005), ds (prior 0 +- 1.4 um, = s0 uncertainty), r_P (free: per-run pendulum x_j,y_j
are not published), r_A = 7.5 um fixed; thicknesses, masses, rho_g, eps fixed at measured values; tilt term omitted
(Delta s_rms < 1 um, second order)."""
import argparse, csv, io, json, math, os, sys, zipfile, hashlib
sys.dont_write_bytecode = True
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.optimize import minimize, brentq
from scipy.stats import norm
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from envelope_guard import validate_envelope, coverage_ranges, EnvelopeError
_ap = argparse.ArgumentParser()
_ap.add_argument("--preflight-only", action="store_true", help="stop with exit 0 after a passed preflight; writes no file")
ARGS = _ap.parse_args()
ZIP = os.environ.get("TAL_SUBCM_ZIP", os.path.join(ROOT, "inputs_r4", "subcm_yukawa_window_zenodo_r4.zip"))   # see README
P = "subcm_yukawa_window/outputs/"
A_TAL = 1.0 / (4 * math.pi)
# ---- pre-declared rules (fixed before any fit was run) ----
RULES = {"newton_gate": "chi2_newton <= N_data + 3*sqrt(2*N_data) (pre-declared N_data-based technical benchmark)",
         "validation_lambdas_mm": [0.040, 0.050, 0.063, 0.071, 0.079, 0.100, 0.250],
         "validation_tol_rel_alpha95_abs": 0.20,
         "validation_pass": ">= 2 lambda points with |alpha95_abs(model)/alpha95_abs(thesis) - 1| <= 0.20",
         "delta_chi2_95": 6.17}
LOG = []
def log(*a):
    s = " ".join(str(x) for x in a); LOG.append(s); print(s, flush=True)
class StrictError(Exception): pass
INP = json.load(open(os.path.join(HERE, "experiment_inputs.json")))
EW = INP["eot_wash_2020"]
GR = np.load(os.path.join(HERE, "torque_grids.npz"))

# ---------------- (0) preflight ----------------
Z = zipfile.ZipFile(ZIP)
res = json.loads(Z.read(P + "results.json")); env = np.load(io.BytesIO(Z.read(P + "envelopes.npz")))
LG = np.asarray(env["log10_lambda"], float); E = np.asarray(env["combined_abs"], float)
try:   # strict, coverage-aware validation before any filtering or interpolation (envelope_guard.py)
    validate_envelope(LG, E, coverage_ranges(res), what=P + "envelopes.npz:combined_abs")
except EnvelopeError as e:
    raise StrictError(f"envelope check failed: {e}") from None
ok = np.isfinite(E)   # after the check: NaN only outside the curve coverage
i = int(np.where(ok & (np.log10(np.where(ok, E, np.inf)) < math.log10(A_TAL)))[0][0])
x0, x1, y0, y1 = LG[i-1], LG[i], math.log10(E[i-1]), math.log10(E[i])
edge = float(10 ** (x0 + (math.log10(A_TAL) - y0) / (y1 - y0) * (x1 - x0)))
cr = [c for c in res["curves"]["Lee2020_fig5/HUST_2020"]["crossings"] if c["direction"] == "enters_excluded"]
if len(cr) != 1: raise StrictError("HUST crossing count")
pre = {"edge": {"recomputed_m": edge, "results_json_m": cr[0]["lambda_m"], "stated_um": 75.877, "tol_rel": 1e-6, "tol_um_abs": 5e-4,
                "pass": bool(math.isclose(edge, cr[0]["lambda_m"], rel_tol=1e-6) and abs(edge * 1e6 - 75.877) <= 5e-4)}}
rows = [r for r in csv.reader(io.StringIO(Z.read(P + "digitized/Lee2020_thesis_table11_4.csv").decode())) if r and not r[0].startswith("#")]
hdr = rows[0]; PK = {round(float(r[0]), 6): dict(zip(hdr, r)) for r in rows[1:]}
cols = EW["published_alpha_table"]["columns"]; dev = 0.0
for r in EW["published_alpha_table"]["rows_used_for_validation"]:
    pk = PK.get(round(r[0], 6))
    if pk is None: raise StrictError(f"lambda {r[0]} not in packaged table")
    for c, v in zip(cols, r):
        dev = max(dev, abs(v - float(pk[c])) / max(abs(float(pk[c])), 1e-300))
pre["table11_4_vs_package"] = {"max_rel_dev": dev, "tol_rel": 1e-9, "pass": dev <= 1e-9}
runs = EW["runs"]["rows"]
pre["runs"] = {"n": len(runs), "expected": 95, "pass": len(runs) == 95}
pre["zip_sha256"] = hashlib.sha256(open(ZIP, "rb").read()).hexdigest()
pre["pass"] = all(v["pass"] for k, v in pre.items() if isinstance(v, dict))
log("PREFLIGHT", json.dumps(pre))
if not pre["pass"]: raise StrictError("preflight failed")
if ARGS.preflight_only:
    log("PREFLIGHT-ONLY: stop after the passed preflight (no fit, no file written)"); sys.exit(0)

# ---------------- data and model (reduced_model.py) ----------------
sys.path.insert(0, HERE)
import reduced_model as RM
RM.setup(EW, GR, runs)
s_j, ds_j, Y, LAMS, SPN, spY, Rfun, pred, SPY = RM.s_j, RM.ds_j, RM.Y, RM.LAMS, RM.SPN, RM.spY, RM.Rfun, RM.pred, RM.SPY
G0, GE, SE = RM.G0, RM.GE, RM.SE
def chi2(theta, li, gamma_prior=G0):
    pr = pred(theta, li, gamma_prior); c = 0.0
    for h, (y, e) in Y.items():
        m, dm = pr[h]; c += float(np.sum((y - m) ** 2 / (e ** 2 + (ds_j * dm) ** 2)))
    return c + ((theta[1] - gamma_prior) / GE) ** 2 + (theta[2] / SE) ** 2
def fit_nuis(a, li, start, gamma_prior=G0):
    best = None
    for rp0 in (start[2], 0.03, 0.07, 0.12):
        x0 = [start[0], start[1], rp0]
        f = lambda x: chi2([a, x[0], x[1], x[2]], li, gamma_prior)
        r = minimize(f, x0, method="Nelder-Mead", options={"xatol": 1e-7, "fatol": 1e-7, "maxiter": 6000, "maxfev": 12000})
        if best is None or r.fun < best.fun: best = r
    return best.fun, best.x
def interp_lam(lam):
    w = np.where(np.isclose(LAMS, lam, rtol=1e-9))[0]
    if len(w) != 1: raise StrictError(f"lambda {lam} not tabulated")
    return int(w[0])

# ---------------- (1) Newtonian fit ----------------
n_data = 3 * len(runs)                 # number of torque values (95 runs x 3 harmonics)
nu_eff = n_data + 2 - 3                # 3 fitted nuisances, 2 of them with Gaussian measurement priors (gamma, delta_s); r_P free
c_nom = chi2([0.0, G0, 0.0, 0.0], None)
cN, xN = fit_nuis(0.0, None, [G0, 0.0, 0.05])
newton = {"chi2_nominal_rP0_no_fit": c_nom, "chi2_fit": cN, "N_data": n_data, "nu_effective_approx": nu_eff,
          "gamma": xN[0], "ds_um": xN[1], "r_P_mm": abs(xN[2]),
          "gate": RULES["newton_gate"], "gate_value": n_data + 3 * math.sqrt(2 * n_data),
          "gate_label": "pre-declared N_data-based technical benchmark (not a formal chi2 test with 285 degrees of freedom)",
          "reference_nu_eff": {"formula": "nu_eff + 3*sqrt(2*nu_eff)", "value": nu_eff + 3 * math.sqrt(2 * nu_eff)},
          "thesis_quoted_nu": 285,
          "thesis_quoted_nu_note": "nu = 285 as quoted in the thesis for the published fit (measured, constrained nuisances); not this model's degrees of freedom",
          "check_value_independent": {"chi2_fit": 291.14030018, "tol_rel": 1e-6}}
newton["reference_nu_eff"]["pass"] = bool(cN <= newton["reference_nu_eff"]["value"])
newton["check_value_independent"]["agree"] = bool(math.isclose(cN, 291.14030018, rel_tol=1e-6))
newton["pass"] = bool(cN <= newton["gate_value"])
cN1, xN1 = fit_nuis(0.0, None, [1.0, 0.0, 0.05], gamma_prior=1.0)
newton["variant_gamma_prior_1.000"] = {"chi2_fit": cN1, "gamma": xN1[0], "ds_um": xN1[1], "r_P_mm": abs(xN1[2])}
log("NEWTON", json.dumps(newton))
if not newton["pass"]: raise StrictError("Newton gate failed: no validation, no prediction")
NUIS0 = [xN[0], xN[1], abs(xN[2])]

def profile(li, gamma_prior=G0):
    for h in Y: SPY[h] = spY(h, li)
    # scale for alpha grid from linearised Fisher estimate
    pr0 = pred([0.0] + NUIS0, None, gamma_prior); F = 0.0
    for h, (y, e) in Y.items():
        yk = NUIS0[0] * Rfun(h, NUIS0[2], s_j * 1e3, LAMS[li] * 1e3) * SPY[h](np.log(s_j + NUIS0[1] * 1e-6))
        F += float(np.sum(yk ** 2 / (e ** 2 + (ds_j * pr0[h][1]) ** 2)))
    sig0 = 1 / math.sqrt(F)
    width = 8 * sig0
    for _ in range(5):                      # widen until both ends exceed the 95% threshold by margin
        grid = np.linspace(-width, width, 41)
        vals = []; start = list(NUIS0)
        for a in grid:
            c, x = fit_nuis(float(a), li, start, gamma_prior); vals.append(c); start = [x[0], x[1], abs(x[2])]
        vals = np.array(vals)
        if vals[0] - vals.min() > RULES["delta_chi2_95"] + 2 and vals[-1] - vals.min() > RULES["delta_chi2_95"] + 2: break
        width *= 2
    else:
        raise StrictError("profile range did not bracket the 95% threshold")
    cs = CubicSpline(grid, vals); fine = np.linspace(grid[0], grid[-1], 20001); cf = cs(fine)
    k = int(np.argmin(cf)); amin, cmin = float(fine[k]), float(cf[k])
    if k == 0 or k == len(fine) - 1: raise StrictError("profile minimum at grid edge")
    g = lambda a, d: float(cs(a)) - cmin - d
    lo1 = brentq(g, grid[0], amin, args=(1.0,)); hi1 = brentq(g, amin, grid[-1], args=(1.0,))
    lo95 = brentq(g, grid[0], amin, args=(RULES["delta_chi2_95"],)); hi95 = brentq(g, amin, grid[-1], args=(RULES["delta_chi2_95"],))
    sig = 0.5 * (hi1 - lo1)
    a95abs = brentq(lambda A: norm.cdf(A, amin, sig) - norm.cdf(-A, amin, sig) - 0.95, 1e-12, abs(amin) + 10 * sig)
    return {"lambda_m": float(LAMS[li]), "alpha_star": amin, "sigma_alpha": sig, "alpha95_pos": hi95, "alpha95_neg": lo95,
            "alpha95_abs": a95abs, "chi2_min": cmin, "fisher_sigma_linear": sig0}

# ---------------- (2) validation ----------------
TH = {round(r[0], 6): dict(zip(cols, r)) for r in EW["published_alpha_table"]["rows_used_for_validation"]}
val = []
for lam_mm in RULES["validation_lambdas_mm"]:
    li = interp_lam(lam_mm * 1e-3); r = profile(li); t = TH[round(lam_mm, 6)]
    r["thesis"] = {c: t[c] for c in ("alpha_star", "sigma_alpha", "alpha95_pos", "alpha95_neg", "alpha95_abs")}
    r["ratio_alpha95_abs"] = r["alpha95_abs"] / t["alpha95_abs"]; r["ratio_sigma"] = r["sigma_alpha"] / t["sigma_alpha"]
    r["within_tol"] = bool(abs(r["ratio_alpha95_abs"] - 1) <= RULES["validation_tol_rel_alpha95_abs"])
    val.append(r); log("VAL", json.dumps(r))
n_ok = sum(r["within_tol"] for r in val)
validation = {"rules": RULES, "points": val, "n_within_tol": n_ok, "pass": n_ok >= 2}
# sensitivity: gamma prior centred on 1.000 (data already scaled by gamma per thesis App. A.1) at two lambdas
sens = []
for lam_mm in (0.050, 0.071):
    li = interp_lam(lam_mm * 1e-3); r = profile(li, gamma_prior=1.0); sens.append({k: r[k] for k in ("lambda_m", "alpha_star", "sigma_alpha", "alpha95_abs")})
validation["sensitivity_gamma_prior_1.000"] = sens
log("VALIDATION pass", validation["pass"], "n_within_tol", n_ok)

# ---------------- (3) TAL prediction ----------------
predict = None
if validation["pass"]:
    predict = []
    tal_th = {round(float(k), 6): v for k, v in PK.items()}
    for lam in (50e-6, 60e-6, 70e-6, 75e-6):
        li = interp_lam(lam); pr = profile(li)
        for h in Y: SPY[h] = spY(h, li)
        gam, dsu, rp = NUIS0
        tq = {}
        for s_um in (52.0, 60.0, 75.0):
            s = s_um * 1e-6
            tq[f"{s_um:g}um"] = {h: {"TAL_Yukawa_fNm": A_TAL * gam * float(Rfun(h, rp, s * 1e3, lam * 1e3)) * float(SPY[h](math.log(s))),
                                     "Newton_fNm": gam * float(Rfun(h, rp, s * 1e3, None)) * float(SPN[h](math.log(s)))} for h in Y}
        pr0 = pred([0.0] + NUIS0, None, G0)
        snr2 = 0.0; best = {}
        for h, (y, e) in Y.items():
            sig_tal = A_TAL * gam * Rfun(h, rp, s_j * 1e3, lam * 1e3) * SPY[h](np.log(s_j + dsu * 1e-6))
            den = np.sqrt(e ** 2 + (ds_j * pr0[h][1]) ** 2)
            r_ = sig_tal / den; snr2 += float(np.sum(r_ ** 2)); k = int(np.argmax(r_))
            best[h] = {"run": runs[k][0], "s_um": runs[k][1], "TAL_fNm": float(sig_tal[k]), "published_err_fNm": float(e[k]), "single_run_ratio": float(r_[k])}
        thesis_sig = None
        lk = round(lam * 1e3, 6)
        if lk in tal_th: thesis_sig = float(tal_th[lk]["sigma_alpha"])
        predict.append({"lambda_m": lam, "alpha_TAL": A_TAL, "torques": tq, "best_single_run": best,
                        "fisher_ratio_all_runs_no_nuisance": math.sqrt(snr2),
                        "alpha_TAL_over_sigma_alpha_model": A_TAL / pr["sigma_alpha"],
                        "alpha_TAL_over_alpha95_abs_model": A_TAL / pr["alpha95_abs"],
                        "model_profile": pr,
                        "alpha_TAL_over_sigma_alpha_thesis_row": (A_TAL / thesis_sig) if thesis_sig else "no exact thesis row"})
        log("PRED", json.dumps(predict[-1]))
else:
    log("VALIDATION FAILED: no TAL prediction is given")
out = {"preflight": pre, "newton_fit": newton, "validation": validation, "tal_prediction": predict,
       "labels": {"alpha95_definitions": "alpha95_pos and alpha95_neg: signed profile thresholds where the spline of the profile chi2 crosses chi2_min + delta_chi2_95 (= 6.17, the fixed comparison recipe of the rules); alpha95_abs: A with P(-A <= alpha <= A) = 0.95 under the Gaussian approximation with mean alpha_star and sigma_alpha from the delta_chi2 = 1 profile width; the validation uses alpha95_abs",
                  "ratio": "model-estimate ratios; not a detection claim; not sigma of an observed effect; 'not excluded' is not confirmation",
                  "alpha_convention": "V = -G m1 m2/r (1 + alpha exp(-r/lambda)), alpha_TAL = 1/(4 pi) (hypothesis, TAL branch with alpha_Y = 1, record doi:10.5281/zenodo.23960821)"}}
json.dump(out, open(os.path.join(HERE, "model_results.json"), "w"), indent=1)
open(os.path.join(HERE, "run_log.txt"), "w").write("\n".join(LOG) + "\n")
