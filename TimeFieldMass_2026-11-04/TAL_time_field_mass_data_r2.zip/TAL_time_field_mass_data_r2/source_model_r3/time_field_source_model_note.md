# Time-field TAL branch — source model r3 for the micron window (Eöt-Wash 2020, HUST 2020)

Date: 2026-11-04 (Europe/Zurich). Scope: the not-excluded window below the 75.877 µm edge, starting with 50–75.877 µm.
Hypothesis under test: α_TAL = 1/(4π) = 0.0795775 (TAL branch with α_Y = 1, record doi:10.5281/zenodo.23960821), with V = −G m₁m₂/r · (1 + α e^(−r/λ)).
All ratios here are model-estimate ratios. They are not sigma of an observed effect, and "not excluded" is not confirmation.
Numerical cross-checks with Academia Co-scientist (AI-assisted); not peer review.

## What changed in r3
* **Input check only.** Before the sub-cm envelope is used, `envelope_guard.py` (an identical copy is in `map_r3/` of the data and code package `TAL_time_field_mass_data_r2.zip`) checks it against the coverage of the packaged curves: 1-D arrays of equal length; finite, strictly increasing log10_lambda; no Inf; every finite value > 0; no NaN at a grid point covered by a curve; no finite value outside the coverage. Any failure stops the run with a non-zero exit and names the index and λ.
* **Negative controls** (`test_envelope_guard.py`, writes `test_envelope_guard.json`): the preflight (`fit_validate_predict.py --preflight-only`) accepts the clean input and rejects five corrupted copies of the envelope (NaN, Inf, NaN in log10_lambda, 0 and −1 at one covered point): 6/6 pass.
* **Labels.** `model_results.json` now states the two α95 definitions explicitly (`labels.alpha95_definitions`); see the validation section.
* The fit code, rules, tolerances and inputs are unchanged; the numbers are unchanged within the stated tolerances.
* **Interpretation of the failed validation.** The 0/7 failure is now attributed most likely to the reduced source model (the fitted r_P = 65 µm is far larger than the few-micrometre offsets typical of the experiment), not to the missing per-run positions. No new fit; all numbers unchanged.

## What changed in r2 (kept in r3)
* **Separation derivative in the χ² error term.** The error term of thesis eq. 11.1 uses the separation derivative of the full prediction. r1 differentiated only the torque splines and omitted the s-dependence of the empirical off-center correction R. r2 uses the full product rule
  dm/ds = γ [R′_N N + R_N N′] + α γ [R′_Y Y + R_Y Y′],
  with N, Y evaluated at s + δs and R, R′ at the physical separation s. The analytic derivative (in `reduced_model.py`) is, with f = c1 + c2 e^(c3 y), q = 1 − (r_< f)²/4:
  dR/ds_mm = (1 − c0) f′ [−r_> sin(r_> f) q − cos(r_> f) r_<² f/2], f′ = c2 c3 e^(c3 y) dy/ds_mm,
  where dy/ds_mm = 1 for Newton and 1 − e^(c6 λ_mm) for Yukawa; the result is multiplied by 1000 (mm → m).
* **Derivative test** (`test_derivative.py`, separately runnable, writes `test_derivative.json`): central finite differences at the 95 separations, all three harmonics, Newton and two non-zero Yukawa cases (λ = 50 µm). Maximum relative deviation 6.0e-10 (acceptance rtol ≤ 1e-6): pass. The omitted r1 term is at most 0.235% (120ω), 0.267% (18ω) and 0.122% (54ω) of the full derivative.
* **Degrees of freedom.** N_data = 285 torque values. The reduced Newton model fits three nuisances (γ, δs with Gaussian measurement priors; r_P free), so the approximate effective count is ν_eff ≈ 284. The thesis value ν = 285 refers to the published fit and is quoted unchanged.
* **Gate.** The pre-declared Newton gate χ² ≤ N_data + 3√(2 N_data) = 356.624 is kept unchanged and is labelled as a pre-declared N_data-based technical benchmark, not as a formal χ² test. The ν_eff-based reference value is 355.49825173.
* All rules, tolerances and inputs are unchanged. The Newton fit, the 7 validation profiles and both γ-prior variants were re-run. Numbers changed slightly (see below); the validation result did not.

## Result in one line
Step A: the inputs suffice to **construct** the reduced Eöt-Wash 2020 model (open thesis); they are **missing** for HUST 2020. Step B (r2, unchanged in r3): the reduced Fourier–Bessel model was fitted, but the **validation failed**: 0 of 7 pre-declared λ points are within ±20% of the published |α95| (ratios 1.203–2.118). Per the rule, **no TAL torque prediction is given**. The 0/7 statement refers to this specific implementation; the failure most likely lies in our reduced source model (fitted r_P = 65 µm, far larger than the few-micrometre offsets typical of the experiment).

## Missing inputs (listed first)
* **HUST 2020** (Tan et al., PRL 124, 051301, doi:10.1103/PhysRevLett.124.051301): no open full text was found (no arXiv version; APS full text and Supplemental Material not open). Only the abstract is open. Missing: geometry, materials/densities, separation, membrane/shield parameters, torque noise, calibration, signal model equations, data points. The HUST model was not built. This records what was found, not that the data exist nowhere.
* **Eöt-Wash 2020 PRL Supplemental Material**: not retrieved. In arXiv:2002.11761v1 the reference to it is a placeholder ("XXXX"), and the sub-cm r4 package (record doi:10.5281/zenodo.23960821) records HTTP 403 for the APS file. The open thesis (the same data set) was used instead.
* **Eöt-Wash 2020, per-run pendulum positions (x_j, y_j)**: missing. Thesis sec. 11.2.2 says these were recorded, but App. A.1 lists only s, N120, N18 and N54. They are not treated as the cause of the failed validation (see Validation): the failure most likely lies in our reduced source model.
* **Eöt-Wash 2020 torque noise as a spectral number**: missing (the PRL shows the PSD as a figure only). The per-run torque uncertainties are published (thesis App. A.1) and serve as the published noise.

## Sources (open, primary; no PDF stored)
* Thesis: J. G. Lee, PhD thesis, University of Washington (2020), hdl:1773/45542, https://hdl.handle.net/1773/45542. Its SHA-256 00d13a46…924a equals the thesis hash recorded in the sub-cm r4 zip (inputs/SHA256SUMS_pdfs.txt).
* PRL: Lee et al., PRL 124, 101101 (2020), doi:10.1103/PhysRevLett.124.101101, arXiv:2002.11761.
* Every value used carries a source, a location (table, section or equation) and a quote in `experiment_inputs.json`.

## Model (equation and source)
Thesis sec. 2.1 (Fourier–Bessel Green's function and wedge sources) was re-derived for full-thickness wedge holes filled with epoxy:

τ_m(s) = m · 8G Δρ_p Δρ_a sin(m b_p) sin(m b_a) / l² · ∫₀^∞ dk k Q_m^p(k) Q_m^a(k) (1−e^(−κ t_p))(1−e^(−κ t_a)) e^(−κ s) / κ³

with m = N·l, b the half subtended angle, κ = √(k² + λ⁻²) (κ = k for Newton), Q_m(k) = ∫ J_m(kr) r dr over the ring, Δρ = (mass removed)/(wedge volume) − ρ_glue. Self-tests (`selftest.json`): Q against adaptive quadrature ≤ 3.9e-5 relative; k-grid convergence ≤ 5.3e-9. Harmonics: 120ω (120-fold, l = 1), 18ω (18-fold, l = 1), 54ω (18-fold, l = 3).

The published fit model is thesis sec. 11.2.4: Ñ_m = γ · R_m(r,s,λ) · [FB torque] (+ tilt term), χ² from thesis eq. 11.1. **Reductions in this model:**
* r_P is a single free parameter, because the per-run positions are not in the open data set;
* thicknesses, masses, ρ_g = 1.162 g/cm³ and other measured parameters are fixed at the measured values (Tables 4.2–4.5, 11.3);
* ε = 0.2 µm is fixed, not fitted;
* the tilt term is omitted (Δs_rms ≈ 0.8 µm, second order);
* γ prior 1.012 ± 0.005 and separation-shift prior 0 ± 1.4 µm (Table 11.3); r_A = 7.5 µm (Table 11.3).

Data: the 95 runs of thesis App. A.1 (in-phase, calibrated, systematics subtracted), i.e. 285 torque values.

## Preflight
* 75.877 µm edge recomputed from the sub-cm r4 zip envelope: 75.877096 µm (relative tolerance 1e-6): pass.
* Thesis Table 11.4 rows vs the packaged csv: maximum relative deviation 0 (tolerance 1e-9): pass.
* Run count 95: pass.
* Sub-cm envelope check (`envelope_guard.py`, see above): pass.

## Newtonian fit (r3; same values as r2)
* Nominal model (r_P = 0, γ = 1.012, no fit): χ² = 1236.6375 for N_data = 285. The 120ω data sit ≈5% below the model from 54 to 200 µm, while 18ω and 54ω agree within ≈1%; this is the pattern expected from a radial pendulum offset (thesis Table 2.1).
* Fitted nuisances: χ² = 291.14030018, r_P = 65.29 µm, γ = 0.996582, δs = 0.9271 µm. Cross-check value from Academia Co-scientist (AI-assisted), 291.14030018: agrees (relative tolerance 1e-6). Pre-declared benchmark ≤ 356.624: pass; ν_eff reference ≤ 355.498: also below. The thesis reports χ² = 274.99 for ν = 285 for the published fit.
* Variant with the γ prior centred at 1.000: χ² = 281.3456.

## Validation against the published α bound (r3; same values as r2)
The rule was fixed before the r1 fit and is unchanged: |α95| within ±20% of thesis Table 11.4 at ≥ 2 of the 7 λ points. Two α95 definitions are used and kept apart:
* the signed alpha95_pos and alpha95_neg profile thresholds use the fixed Δχ² = 6.17 rule (where the profile χ² crosses χ²_min + 6.17); 6.17 is the fixed comparison recipe of the rule, not a separately proven 95% test;
* the absolute A = |α95| used in the table below and in the validation instead satisfies P(−A ≤ α ≤ A) = 0.95 under the Gaussian approximation with mean α* and σ_α estimated from the Δχ² = 1 profile width, i.e. Φ((A − α*)/σ_α) − Φ((−A − α*)/σ_α) = 0.95 (thesis sec. 11.4).

| λ [µm] | α* model | σ_α model | |α95| model | α* thesis | σ_α thesis | |α95| thesis | |α95| ratio | σ_α ratio | within ±20% |
|---|---|---|---|---|---|---|---|---|---|
| 40 | 0.5587 | 0.3016 | 1.055 | 0.394 | 0.286 | 0.877 | 1.2027 | 1.055 | no |
| 50 | 0.2959 | 0.16 | 0.5591 | 0.179 | 0.142 | 0.419 | 1.3344 | 1.127 | no |
| 63 | 0.1736 | 0.09586 | 0.3313 | 0.0862 | 0.078 | 0.218 | 1.5197 | 1.229 | no |
| 71 | 0.1376 | 0.07762 | 0.2653 | 0.0601 | 0.06 | 0.162 | 1.6377 | 1.294 | no |
| 79 | 0.1141 | 0.06618 | 0.223 | 0.0437 | 0.0485 | 0.126 | 1.7696 | 1.365 | no |
| 100 | 0.07878 | 0.05074 | 0.1622 | 0.021 | 0.0326 | 0.0766 | 2.1180 | 1.556 | no |
| 250 | -0.01704 | 0.0254 | 0.05916 | -0.00471 | 0.0137 | 0.029 | 2.0400 | 1.854 | no |

**Result: FAILED (0/7).** The closest point is λ = 40 µm, ratio 1.2027, outside the tolerance. Relative to r1 the |α95| ratios moved by less than 0.1%.
* At 40–50 µm σ_α is reproduced to within 6–13%, but α* is shifted upward.
* From 63 to 250 µm the model bound is weaker by a factor 1.5–2.1. A free common r_P can partly mimic a Yukawa term at larger λ (both rescale mainly the 120ω torque).
* The failure most likely lies in our reduced source model: the fitted r_P = 65 µm is far larger than the few-micrometre pendulum offsets typical of the experiment, so it is most likely not a physical offset but a sign of an error or a missing ingredient in the model. The 0/7 result is attributed to the model, not to missing data.

Sensitivity (γ prior 1.000): λ = 50 µm: |α95| = 0.5648, σ_α = 0.1587; λ = 71 µm: |α95| = 0.2733, σ_α = 0.0774. Changing the prior centre to 1.000 shifts the absolute limits by only 1–3% at the two tested λ values and does not bring them within ±20%. This checks one prior variant, not all possible causes of the discrepancy.

**Consequence:** no TAL torque, S/N or α_TAL/σ_α value is given from this model. The α = 1 Yukawa grids in `torque_grids.npz` are model intermediates only. The failed validation is kept as a negative validation result.

## Next necessary check step
Locating the error or missing ingredient in the reduced source model is the next necessary check step, for example by reproducing the published α constraints from the torques of the Eöt-Wash 2020 Supplemental Material. The reductions (single free r_P, fixed measured parameters, ε not fitted, no tilt term) remain to be tested. For HUST 2020, an open full text with geometry, noise and model is needed.

The window ratios of the window module (`window_signal_r3/` in the data and code package `TAL_time_field_mass_data_r2.zip`; α_TAL/σ_α of the thesis table: 0.56 at 50 µm, 1.29 at 70 µm, 1.48 at 75 µm) are ratios to a published table, not a source-model prediction.

## Files
* `experiment_inputs.json`: quoted inputs with sources.
* `fb_torque.py`: the Fourier–Bessel model; `compute_grids.py`: builds `torque_grids.npz` and `selftest.json`.
* `reduced_model.py`: reduced prediction, off-center correction R and its analytic separation derivative.
* `test_derivative.py`: finite-difference test of the derivative; writes `test_derivative.json`.
* `fit_validate_predict.py`: preflight, Newtonian fit and validation; writes `model_results.json` and `run_log.txt`. Input zip: environment variable TAL_SUBCM_ZIP or `../inputs_r4/subcm_yukawa_window_zenodo_r4.zip`. With `--preflight-only` it stops after the preflight and writes nothing.
* `envelope_guard.py`: the shared envelope check (identical to `map_r3/envelope_guard.py` of the data and code package).
* `test_envelope_guard.py`: negative controls of the envelope check; writes `test_envelope_guard.json`.
* `make_figure.py`: builds `source_model_validation.png`.
