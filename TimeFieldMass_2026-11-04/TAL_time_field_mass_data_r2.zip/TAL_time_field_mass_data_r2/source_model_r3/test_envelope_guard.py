#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# (c) 2026 Szabolcsi David (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Negative controls for the envelope check in the preflight of fit_validate_predict.py (run with --preflight-only,
which stops after the preflight and writes no file). Corrupted inputs are temporary zip copies; the sub-cm r4 zip and
the shipped outputs are read-only. Input: TAL_SUBCM_ZIP (default ../inputs_r4/subcm_yukawa_window_zenodo_r4.zip).
Cases: 1 clean input (expected exit 0; its preflight block must equal the one in model_results.json within rel 1e-12)
and 5 corrupted envelopes (expected non-zero exit with an envelope-check message):
  combined_abs[10911] = NaN, combined_abs[10912] = Inf, log10_lambda[10911] = NaN, combined_abs[10911] = 0, combined_abs[10911] = -1.
Only the preflight is exercised here; the full fit is run by run_all.sh. Writes test_envelope_guard.json; exit 0 only if 6/6."""
import io, json, math, os, subprocess, sys, tempfile, zipfile
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
ZIP = os.environ.get("TAL_SUBCM_ZIP", os.path.join(ROOT, "inputs_r4", "subcm_yukawa_window_zenodo_r4.zip"))
MEMBER = "subcm_yukawa_window/outputs/envelopes.npz"
RTOL = 1e-12
def mutate(arr_key, i, v):
    def f(arrs):
        if not np.isfinite(arrs[arr_key][i]): raise SystemExit(f"control target {arr_key}[{i}] is not finite in the clean input")
        arrs[arr_key][i] = v
    return f
CASES = [("clean", None, True), ("combined_abs[10911]=NaN", mutate("combined_abs", 10911, np.nan), False),
         ("combined_abs[10912]=Inf", mutate("combined_abs", 10912, np.inf), False),
         ("log10_lambda[10911]=NaN", mutate("log10_lambda", 10911, np.nan), False),
         ("combined_abs[10911]=0", mutate("combined_abs", 10911, 0.0), False),
         ("combined_abs[10911]=-1", mutate("combined_abs", 10911, -1.0), False)]
def copy_zip(dst, mut):
    with zipfile.ZipFile(ZIP) as zi, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            d = zi.read(it.filename)
            if it.filename == MEMBER:
                z = np.load(io.BytesIO(d)); arrs = {k: np.array(z[k]) for k in z.files}; mut(arrs)
                b = io.BytesIO(); np.savez(b, **arrs); d = b.getvalue()
            zo.writestr(it, d)
def close(a, b, where, errs):
    if isinstance(a, dict):
        if set(a) != set(b): errs.append(f"{where}: keys"); return
        for k in a: close(a[k], b[k], f"{where}/{k}", errs)
    elif isinstance(a, bool) or isinstance(a, str) or a is None:
        if a != b: errs.append(where)
    elif isinstance(a, (int, float)):
        if not (isinstance(b, (int, float)) and math.isclose(a, b, rel_tol=RTOL)): errs.append(where)
    else: errs.append(f"{where}: type")
shipped = json.load(open(os.path.join(HERE, "model_results.json")))["preflight"]
rep = {"rtol_clean_vs_shipped": RTOL, "cases": []}; ok = 0
with tempfile.TemporaryDirectory() as td:
    for name, mut, expect_ok in CASES:
        z = ZIP
        if mut is not None:
            z = os.path.join(td, "in.zip"); copy_zip(z, mut)
        r = subprocess.run([sys.executable, os.path.join(HERE, "fit_validate_predict.py"), "--preflight-only"], capture_output=True, text=True,
                           env=dict(os.environ, TAL_SUBCM_ZIP=z, PYTHONDONTWRITEBYTECODE="1"))
        msg = (r.stderr.strip().splitlines() or [""])[-1]
        good = (r.returncode == 0) == expect_ok
        if not expect_ok: good = good and "envelope check failed" in msg
        cmp_errs = None
        if expect_ok and r.returncode == 0:
            line = [l for l in r.stdout.splitlines() if l.startswith("PREFLIGHT ")]
            cmp_errs = []
            if len(line) != 1: cmp_errs.append("no PREFLIGHT line")
            else: close(shipped, json.loads(line[0][len("PREFLIGHT "):]), "preflight", cmp_errs)
            good = good and not cmp_errs
        ok += good
        rep["cases"].append({"case": name, "expected": "exit 0" if expect_ok else "non-zero exit", "exit_code": r.returncode,
                             "message": msg if r.returncode else "", "clean_preflight_mismatches": cmp_errs, "pass": bool(good)})
        print(f"{'PASS' if good else 'FAIL'}  {name:28s} exit={r.returncode}  {msg[:150] if r.returncode else ''}", flush=True)
rep["n_pass"] = ok; rep["n_cases"] = len(CASES); rep["pass"] = ok == len(CASES)
json.dump(rep, open(os.path.join(HERE, "test_envelope_guard.json"), "w"), indent=1)
print(f"{ok}/{len(CASES)}"); sys.exit(0 if rep["pass"] else 1)
