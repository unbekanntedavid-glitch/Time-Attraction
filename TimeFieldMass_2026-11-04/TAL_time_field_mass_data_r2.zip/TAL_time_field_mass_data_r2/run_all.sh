#!/usr/bin/env bash
# Re-run every module from the package root. Needs Python 3 with numpy, scipy, sympy and matplotlib,
# and the r4 zips extracted by extract_r4_inputs.py (see README.md). Stops at the first error.
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
cmp map_r3/envelope_guard.py source_model_r3/envelope_guard.py   # the shared envelope check must be identical in both folders
python3 theory_checks/checks.py
python3 theory_checks/theory_numbers.py
python3 map_r3/build_map_r3.py > map_r3/run_log.txt
python3 map_r3/crosscheck_ahn4_impl.py
python3 map_r3/key_values_r3.py
python3 map_r3/make_figure_r3.py
python3 map_r3/control_cassini_threshold.py
python3 map_r3/test_envelope_guard.py
python3 window_signal_r3/window_signal.py
python3 window_signal_r3/make_figure.py
python3 window_signal_r3/test_negative_controls.py
python3 source_model_r3/compute_grids.py
python3 source_model_r3/test_derivative.py
python3 source_model_r3/fit_validate_predict.py
python3 source_model_r3/test_envelope_guard.py
python3 source_model_r3/make_figure.py
