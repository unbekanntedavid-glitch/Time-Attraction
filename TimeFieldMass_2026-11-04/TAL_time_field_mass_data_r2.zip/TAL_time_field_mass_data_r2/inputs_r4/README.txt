Place the three r4 module zips here (or pass their paths, see ../README.md, section "Inputs"):
  tal_branch_clock_accel_test_r4.zip
  subcm_yukawa_window_zenodo_r4.zip
  bren_continuation_zenodo_r4.zip
They are contained in TAL_publication_set_2026-11-04_r2.zip, https://doi.org/10.5281/zenodo.23960821
Then run, from the package root: python3 extract_r4_inputs.py
