#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# (c) 2026 Szabolcsi David (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Stability control of the operational Cassini entry threshold (map r3). The map applies the long-range PPN relation
from lambda >= 1 AU. Here the threshold is moved to 100 AU and every cell of the map grid is re-categorised with the
bound functions of build_map_r3.py (bound section exec'd only, same envelope check). Output:
control_cassini_threshold.json with the number of cells whose category changes.
This is a control of the threshold rule only. It is NOT a physical validation of the finite-lambda Cassini
approximation (the finite-lambda radio-link response is not computed anywhere in this package)."""
import json, math, os, sys
import numpy as np
D = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(D, "build_map_r3.py")).read().split("# ---------- PREFLIGHT ----------")[0]
ns = {"__file__": os.path.join(D, "build_map_r3.py")}; exec(src, ns)
AU = ns["AU"]; b2 = ns["CASS_B"]["2sigma_lower"]; omg = ns["one_minus_gamma"]
H0 = 67.4e3 / 3.085677581e22; c = 299792458.0          # same grid as build_map_r3.py
LAM = np.logspace(-9, math.log10(c / H0), 400); AY = np.logspace(-6, 1, 200)
def category(lam, aY, thr):
    alpha = aY / (4 * math.pi); prim = []
    for f in (ns["alim_subcm"], ns["alim_ahn4"], ns["alim_bren"]):
        v = f(lam)
        if v is not None:
            if not math.isfinite(v): raise SystemExit("non-finite bound")
            prim.append(alpha / v)
    if lam >= thr: prim.append(omg(aY) / b2)
    if not prim: return "not_computed"
    return "b_excluded" if max(prim) > 1 else "not_excluded"
summ = json.load(open(os.path.join(D, "map_summary.json")))
if not math.isclose(float(summ["bounds_used"]["cassini"]["applied_for_lambda_ge_m"]), AU, rel_tol=1e-12): raise SystemExit("threshold in map_summary.json is not 1 AU")
n_changed = 0; changed = []; n_cmp = 0
for lam in LAM:
    if lam < AU: continue                     # cells below 1 AU are identical under both thresholds by construction
    for aY in AY:
        a, b = category(lam, aY, AU), category(lam, aY, 100 * AU); n_cmp += 1
        if a != b: n_changed += 1; changed.append([float(lam), float(aY), a, b])
# consistency: the 1 AU categories recomputed here equal the counts of the map over all 80 000 cells
cnt = {k: 0 for k in ("b_excluded", "not_excluded", "not_computed")}
for lam in LAM:
    for aY in AY: cnt[category(lam, aY, AU)] += 1
out = {"purpose": "stability control of the operational Cassini threshold rule (1 AU -> 100 AU); not a physical validation of the finite-lambda Cassini approximation",
       "threshold_map_m": AU, "threshold_control_m": 100 * AU, "n_cells_grid": int(LAM.size * AY.size),
       "n_cells_compared_lambda_ge_1AU": n_cmp, "n_cells_changed": n_changed, "changed_cells": changed[:50],
       "counts_1AU_recomputed": cnt, "counts_map_summary": summ["counts"],
       "counts_match_map": cnt == summ["counts"]}
out["pass"] = bool(out["counts_match_map"])
json.dump(out, open(os.path.join(D, "control_cassini_threshold.json"), "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "changed_cells"}, indent=1))
if not out["pass"]: sys.exit(2)
