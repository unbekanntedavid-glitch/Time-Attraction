#!/usr/bin/env python3
"""r3: alpha_Y,max at key lambda with the bound functions of build_map_r3.py (bound section exec'd only, including the
envelope check of envelope_guard.py); unchanged from r2 apart from file names.
alphaY_max = min over covering bounds (R_max rule, used for the map); per-bound values and the
min-R rule (clock r4 R_conservative style) listed for transparency."""
import json, math, os
D = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(D, "build_map_r3.py")).read().split("# ---------- PREFLIGHT ----------")[0]
ns = {"__file__": os.path.join(D, "build_map_r3.py")}; exec(src, ns)
AU = ns["AU"]; b2 = ns["CASS_B"]["2sigma_lower"]; b1 = ns["CASS_B"]["1sigma_lower"]
key = [1e-6, 2.0e-6, 1e-5, 5e-5, 7.587709630440307e-05, 1e-4, 1e-3, 2e-3, 1e-2, 0.1, 1.0, 10.0, 100.0, 300.0, 1e3, 1e4, 5e4,
       1e5, 1e6, 1e7, 1e8, 1e9, 1e10, AU, 1e12, 1e13, 1e14, 1e15, 1e20, 1.3724968347232662e+26]
out = []
for lam in key:
    per = {}
    for n, f in (("subcm", ns["alim_subcm"]), ("ahn4", ns["alim_ahn4"]), ("bren", ns["alim_bren"])):
        v = f(lam)
        if v is not None:
            if not math.isfinite(v): raise SystemExit("non-finite")
            per[n] = 4 * math.pi * v
    if lam >= AU: per["cassini"] = 4 * math.pi * b2 / (2 - b2)
    r = {"lambda_m": lam, "mc2_eV": 1.054571817e-34 * 299792458.0 / lam / 1.602176634e-19,
         "coverage": "+".join(per) if per else "not_computed", "alphaY_max_per_bound": per,
         "alphaY_max": min(per.values()) if per else None, "binding_bound": min(per, key=per.get) if per else None,
         "alphaY_max_min_R_rule": max(per.values()) if per else None}
    if lam >= AU: r["alphaY_max_cassini_1sigma_lower"] = 4 * math.pi * b1 / (2 - b1)
    out.append(r)
json.dump({"key_lambda": out}, open(os.path.join(D, "key_values_r3.json"), "w"), indent=1)
for r in out:
    print(f"{r['lambda_m']:.4g}\t{r['mc2_eV']:.3g}\t{r['coverage']}\t{r['alphaY_max'] if r['alphaY_max'] is None else format(r['alphaY_max'],'.4g')}\t{r['binding_bound']}\t{'' if r['alphaY_max_min_R_rule'] is None else format(r['alphaY_max_min_R_rule'],'.4g')}")
