#!/usr/bin/env python3
"""r3 PNG of the (lambda, alpha_Y) map from map_grid.npz and map_summary.json (no recomputation)."""
import json, os, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
D = os.path.dirname(os.path.abspath(__file__))
g = np.load(os.path.join(D, "map_grid.npz")); s = json.load(open(os.path.join(D, "map_summary.json")))
L, A, R, cov = g["lambda_m"], g["alpha_Y"], g["R_max"], g["covered"]
if not (np.all(np.isfinite(R)) and np.all(np.isfinite(L)) and np.all(np.isfinite(A))): raise SystemExit("non-finite")
cls = np.where(~cov, 0, np.where(R > 1, 2, 1)).T          # 0 not computed, 1 not excluded, 2 excluded
fig, ax = plt.subplots(figsize=(11, 6.2), dpi=150)
cmap = ListedColormap(["#d9d9d9", "#a6dba0", "#f4a582"]); norm = BoundaryNorm([-0.5, 0.5, 1.5, 2.5], 3)
ax.pcolormesh(L, A, cls, cmap=cmap, norm=norm, shading="nearest", rasterized=True)
lr = np.log10(np.where(cov, np.maximum(R, 1e-300), np.nan)).T
cs = ax.contour(L, A, np.ma.masked_invalid(lr), levels=[0], colors="k", linewidths=1.2)
cv = s["alphaY_max_curve"]
x = np.array([c["lambda_m"] for c in cv]); y = np.array([c["alphaY_max"] if c["alphaY_max"] is not None else np.nan for c in cv])
ax.plot(x, y, color="navy", lw=1.6, label=r"$\alpha_{Y,\max}(\lambda)$ (R = 1)")
for pid, Lp, aY in (("P1", 1e4, 1.0), ("P2", 1e4, 1/3), ("P3", 1e3, 1.0)):
    ax.plot(Lp, aY, "k*", ms=9); ax.annotate(pid, (Lp, aY), textcoords="offset points", xytext=(5, 4), fontsize=8)
ax.axhline(1.0, color="gray", ls=":", lw=1); ax.axvline(1.495978707e11, color="purple", ls="--", lw=0.8)
ax.text(1.6e11, 3e-6, "1 AU", color="purple", fontsize=8)
for xl, t in ((2e-3, "AHN Fig.4 from 2 mm"), (s["bounds_used"]["ahn4"]["polygon_lambda_max_m"], "AHN Fig.4 end")):
    ax.axvline(xl, color="saddlebrown", ls="-.", lw=0.8); ax.text(xl * 1.4, 1.5e-6, t, color="saddlebrown", fontsize=7, rotation=90, va="bottom")
for b in s["coverage_bands"]:
    if b["coverage"] == "not_computed":
        xm = np.sqrt(b["lambda_from_m"] * b["lambda_to_m"])
        ax.text(xm, 2e-3, "not computed", rotation=90, ha="center", va="center", fontsize=8, color="#555555")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(L[0], L[-1]); ax.set_ylim(A[0], A[-1])
ax.set_xlabel(r"$\lambda = L$ [m]"); ax.set_ylabel(r"$\alpha_Y$  ($\alpha=\alpha_Y/4\pi$)")
sec = ax.secondary_xaxis("top", functions=(lambda l: 1.97326980e-7 / l, lambda m: 1.97326980e-7 / m)); sec.set_xlabel(r"$mc^2=\hbar c/\lambda$ [eV]")
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color="#f4a582", label="R_max > 1 (excluded, cat. b)"), Patch(color="#a6dba0", label="R_max <= 1 (not excluded)"),
                   Patch(color="#d9d9d9", label="not computed (no input)"), ax.lines[0]], loc="lower right", fontsize=8, framealpha=0.9)
ax.text(1.2e8, 1.3e-6, "alpha_Y,max < 1e-6 here\n(min 7.6e-10 at 2.7e8 m)", fontsize=7, ha="center", va="bottom", color="navy")
ax.set_title("TAL branch: (lambda, alpha_Y) map r3: sub-cm r4 + AHN 2003 Fig. 4 (digitized, clock r4) + BREN r4 + Cassini 2003 (2-sigma lower edge)\nCassini layer: long-range PPN relation applied from lambda >= 1 AU (assumption); R is a conditional ratio to the bound, not sigma", fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(D, "map_lambda_alphaY_r3.png")); print("ok")
