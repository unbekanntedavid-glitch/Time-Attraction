#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# (c) 2026 Szabolcsi David (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Negative controls for the envelope check of build_map_r3.py. Works only on temporary copies; the inputs and the
shipped outputs are read-only. Input: the extracted r4 folders (TAL_R4_EXTRACTED, default ../inputs_r4/extracted).
Cases: 1 clean input (expected exit 0; its outputs must equal the outputs in this folder within rel 1e-12) and
5 corrupted envelopes (expected non-zero exit with an envelope-check message):
  combined_abs[10911] = NaN, combined_abs[10912] = Inf, log10_lambda[10911] = NaN, combined_abs[10911] = 0, combined_abs[10911] = -1.
Writes test_envelope_guard.json; exit 0 only if 6/6."""
import csv, io, json, math, os, shutil, subprocess, sys, tempfile
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
R4 = os.environ.get("TAL_R4_EXTRACTED", os.path.join(ROOT, "inputs_r4", "extracted"))
SUB = ("subcm_yukawa_window_zenodo_r4", "subcm_yukawa_window")
ENV_REL = os.path.join("outputs", "envelopes.npz")
RTOL = 1e-12
def mutate(arr_key, i, v):
    def f(arrs):
        if not np.isfinite(arrs[arr_key][i]): raise SystemExit(f"control target {arr_key}[{i}] is not finite in the clean input")
        arrs[arr_key][i] = v
    return f
CASES = [("clean", None, True), ("combined_abs[10911]=NaN", mutate("combined_abs", 10911, np.nan), False),
         ("combined_abs[10912]=Inf", mutate("combined_abs", 10912, np.inf), False),
         ("log10_lambda[10911]=NaN", mutate("log10_lambda", 10911, np.nan), False),
         ("combined_abs[10911]=0", mutate("combined_abs", 10911, 0.0), False),
         ("combined_abs[10911]=-1", mutate("combined_abs", 10911, -1.0), False)]
def same_outputs(d):
    """clean temporary outputs vs the outputs in this folder (numbers within RTOL; package-path strings excluded)."""
    errs = []
    a = list(csv.reader(open(os.path.join(HERE, "map_cells.csv")))); b = list(csv.reader(open(os.path.join(d, "map_cells.csv"))))
    if a != b: errs.append("map_cells.csv differs")
    za, zb = np.load(os.path.join(HERE, "map_grid.npz")), np.load(os.path.join(d, "map_grid.npz"))
    if set(za.files) != set(zb.files): errs.append("map_grid.npz keys")
    for k in za.files:
        x, y = za[k], zb[k]
        if x.shape != y.shape or not (np.array_equal(x, y) if x.dtype.kind not in "fc" else np.allclose(x, y, rtol=RTOL, atol=0)): errs.append(f"map_grid.npz {k}")
    sa, sb = json.load(open(os.path.join(HERE, "map_summary.json"))), json.load(open(os.path.join(d, "map_summary.json")))
    for k in ("counts", "counts_min_R_rule", "coverage_bands", "alphaY1_column"):
        if sa[k] != sb[k]: errs.append(f"map_summary.json {k}")
    for ca, cb in zip(sa["alphaY_max_curve"], sb["alphaY_max_curve"]):
        for k in ("alphaY_max", "alphaY_max_min_R_rule"):
            if (ca[k] is None) != (cb[k] is None) or (ca[k] is not None and not math.isclose(ca[k], cb[k], rel_tol=RTOL)): errs.append("alphaY_max_curve"); break
    pa, pb = json.load(open(os.path.join(HERE, "preflight.json"))), json.load(open(os.path.join(d, "preflight.json")))
    if pa["pass"] is not True or pb["pass"] is not True: errs.append("preflight pass")
    if not math.isclose(pa["edge"]["lambda_edge_recomputed_m"], pb["edge"]["lambda_edge_recomputed_m"], rel_tol=RTOL): errs.append("edge")
    return errs
rep = {"rtol_clean_vs_shipped": RTOL, "cases": []}; ok = 0
with tempfile.TemporaryDirectory() as td:
    for name, mut, expect_ok in CASES:
        pkg = os.path.join(td, name.replace("[", "_").replace("]", "").replace("=", "_"), "pkg"); ext = os.path.join(os.path.dirname(pkg), "ext")
        os.makedirs(os.path.join(pkg, "map_r3")); os.makedirs(ext)
        for f in ("build_map_r3.py", "envelope_guard.py"): shutil.copy2(os.path.join(HERE, f), os.path.join(pkg, "map_r3", f))
        shutil.copy2(os.path.join(ROOT, "cassini_gamma_input.json"), pkg)
        for dname in os.listdir(R4):
            if dname != SUB[0]: os.symlink(os.path.abspath(os.path.join(R4, dname)), os.path.join(ext, dname))
        shutil.copytree(os.path.join(R4, SUB[0]), os.path.join(ext, SUB[0]))
        if mut is not None:
            p = os.path.join(ext, *SUB, ENV_REL); z = np.load(p); arrs = {k: np.array(z[k]) for k in z.files}; z.close()
            mut(arrs); np.savez(p, **arrs)
        r = subprocess.run([sys.executable, os.path.join(pkg, "map_r3", "build_map_r3.py")], capture_output=True, text=True,
                           env=dict(os.environ, TAL_R4_EXTRACTED=ext, PYTHONDONTWRITEBYTECODE="1"))
        msg = (r.stderr.strip().splitlines() or [""])[-1]
        good = (r.returncode == 0) == expect_ok
        if not expect_ok: good = good and "envelope check failed" in msg
        cmp_errs = None
        if expect_ok and r.returncode == 0:
            cmp_errs = same_outputs(os.path.join(pkg, "map_r3")); good = good and not cmp_errs
        ok += good
        rep["cases"].append({"case": name, "expected": "exit 0" if expect_ok else "non-zero exit", "exit_code": r.returncode,
                             "message": msg if r.returncode else "", "clean_output_mismatches": cmp_errs, "pass": bool(good)})
        print(f"{'PASS' if good else 'FAIL'}  {name:28s} exit={r.returncode}  {msg[:150] if r.returncode else ''}", flush=True)
rep["n_pass"] = ok; rep["n_cases"] = len(CASES); rep["pass"] = ok == len(CASES)
json.dump(rep, open(os.path.join(HERE, "test_envelope_guard.json"), "w"), indent=1)
print(f"{ok}/{len(CASES)}"); sys.exit(0 if rep["pass"] else 1)
