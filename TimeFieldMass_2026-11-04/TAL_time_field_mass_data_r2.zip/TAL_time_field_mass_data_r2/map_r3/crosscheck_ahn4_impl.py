#!/usr/bin/env python3
"""Cross-check: r3 (same as r2) AHN Fig. 4 alpha_lim on all 400 grid lambda vs the clock r4 class talcheck.bounds.Bounds.alpha_lim_ahn4 (read-only import)."""
import json, math, os, sys, numpy as np
sys.dont_write_bytecode = True
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R4 = os.environ.get("TAL_R4_EXTRACTED", os.path.join(ROOT, "inputs_r4", "extracted"))   # see README: extract_r4_inputs.py
CLOCK = os.path.join(R4, "tal_branch_clock_accel_test_r4", "tal_branch_clock_accel_test")
sys.path.insert(0, CLOCK); from talcheck.bounds import Bounds
B = Bounds(os.path.join(CLOCK, "inputs"), json.load(open(os.path.join(CLOCK, "inputs/setup_declared.json")))["bounds"])
D = os.path.dirname(os.path.abspath(__file__)); s = json.load(open(os.path.join(D, "map_summary.json")))
dev = 0.0; n = 0; mism = 0
for cv in s["alphaY_max_curve"]:
    ref = B.alpha_lim_ahn4(cv["lambda_m"]); mine = cv["alphaY_max_per_bound"].get("ahn4")
    if (mine is None) != (not np.isfinite(ref)): mism += 1; continue
    if mine is not None: dev = max(dev, abs(mine / (4 * math.pi) / ref - 1)); n += 1
out = {"n_compared": n, "coverage_mismatches": mism, "max_rel_dev": dev, "tolerance_rel": 1e-12, "pass": bool(mism == 0 and n > 0 and dev <= 1e-12)}
json.dump(out, open(os.path.join(D, "crosscheck_ahn4_impl.json"), "w"), indent=1); print(out)
if not out["pass"]: sys.exit(2)
