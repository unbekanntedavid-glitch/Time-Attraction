#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# (c) 2026 Szabolcsi David (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Coverage-aware strict validation of the sub-cm r4 envelope (outputs/envelopes.npz, key combined_abs) before any
filtering or interpolation. The same file is shipped in map_r3/ and source_model_r3/ (byte-identical copies).

Checks, in this order (each failure raises EnvelopeError with the index and lambda of the first offending point):
 1. log10_lambda (LG) is 1-D, has the same shape as the envelope E and at least two points;
 2. every LG value is finite and LG is strictly increasing;
 3. E contains no +-Inf anywhere, and every finite E value is > 0;
 4. coverage = union of the curve ranges lambda_range_m of results.json (each range: two finite values, 0 < lo < hi);
    E is finite on every covered grid point;
 5. NaN is allowed only on grid points outside that coverage, and a finite E value outside the coverage is rejected
    (an envelope value without a drawn curve behind it).
Returns the boolean masks (covered, finite) for information; the callers keep their own interpolation unchanged."""
import math
import numpy as np


class EnvelopeError(Exception):
    pass


def coverage_ranges(results):
    """[(lo, hi), ...] in metres from results.json curves/<name>/lambda_range_m (strict: missing key -> error)."""
    if not isinstance(results, dict) or "curves" not in results or not isinstance(results["curves"], dict):
        raise EnvelopeError("results.json: missing key 'curves'")
    out = []
    for name, cv in results["curves"].items():
        if not isinstance(cv, dict) or "lambda_range_m" not in cv:
            raise EnvelopeError(f"results.json: curve {name}: missing key 'lambda_range_m'")
        r = cv["lambda_range_m"]
        if not isinstance(r, (list, tuple)) or len(r) != 2:
            raise EnvelopeError(f"results.json: curve {name}: lambda_range_m must have two values")
        lo, hi = float(r[0]), float(r[1])
        if not (math.isfinite(lo) and math.isfinite(hi) and 0.0 < lo < hi):
            raise EnvelopeError(f"results.json: curve {name}: invalid lambda_range_m {r}")
        out.append((lo, hi))
    if not out:
        raise EnvelopeError("results.json: no curves, coverage is empty")
    return out


def validate_envelope(LG, E, ranges, what="sub-cm envelope combined_abs"):
    LG = np.asarray(LG, dtype=float)
    E = np.asarray(E, dtype=float)
    if LG.ndim != 1:
        raise EnvelopeError(f"{what}: log10_lambda must be 1-D, got shape {LG.shape}")
    if E.shape != LG.shape:
        raise EnvelopeError(f"{what}: shape {E.shape} differs from log10_lambda shape {LG.shape}")
    if LG.size < 2:
        raise EnvelopeError(f"{what}: fewer than two grid points")
    bad = np.where(~np.isfinite(LG))[0]
    if bad.size:
        raise EnvelopeError(f"{what}: non-finite log10_lambda at index {int(bad[0])} ({bad.size} point(s))")
    dif = np.where(np.diff(LG) <= 0)[0]
    if dif.size:
        raise EnvelopeError(f"{what}: log10_lambda not strictly increasing at index {int(dif[0]) + 1}")
    inf = np.where(np.isinf(E))[0]
    if inf.size:
        i = int(inf[0]); raise EnvelopeError(f"{what}: Inf at index {i} (lambda = {10 ** LG[i]:.6e} m)")
    fin = np.isfinite(E)
    nonpos = np.where(fin & (E <= 0))[0]
    if nonpos.size:
        i = int(nonpos[0]); raise EnvelopeError(f"{what}: non-positive value {float(E[i])!r} at index {i} (lambda = {10 ** LG[i]:.6e} m)")
    covered = np.zeros(LG.shape, dtype=bool)
    for lo, hi in ranges:
        covered |= (LG >= math.log10(lo)) & (LG <= math.log10(hi))
    if covered.sum() < 2:
        raise EnvelopeError(f"{what}: fewer than two grid points inside the curve coverage")
    gap = np.where(covered & ~fin)[0]
    if gap.size:
        i = int(gap[0]); raise EnvelopeError(f"{what}: NaN inside the curve coverage at index {i} (lambda = {10 ** LG[i]:.6e} m; {gap.size} point(s))")
    extra = np.where(~covered & fin)[0]
    if extra.size:
        i = int(extra[0]); raise EnvelopeError(f"{what}: finite value outside the curve coverage at index {i} (lambda = {10 ** LG[i]:.6e} m)")
    return covered, fin
