#!/usr/bin/env python3
"""r3 (2026-11-04): the sub-cm envelope is checked by envelope_guard.validate_envelope (coverage-aware, strict) before
any filtering or interpolation; the map computation, rules and outputs are unchanged from r2 within tolerance.
Cassini layer: the long-range PPN relation is applied operationally from lambda >= 1 AU (an assumption of the map
layer; the finite-lambda radio-link response and the error of this approximation are not computed).
r2: adds the AHN 2003 Fig. 4 digitized bound (clock r4 bounds/AHN2003_fig4__fill_polygons.csv, lambda >= 2 mm),
used exactly as clock r4 talcheck/bounds.py alpha_lim_ahn4 / alpha_lim_combined.
(lambda, alpha_Y) exclusion map for the V26 Branch II-Fluid Yukawa (alpha = alpha_Y/4pi, lambda = L).
Research computation, read-only inputs. R = alpha/alpha_lim (lab) or (1-gamma)/bound (Cassini): a conditional
ratio to a bound, NOT sigma. Strict: missing input or key, invalid envelope (see envelope_guard.py), non-finite
value in a used bound or result -> error. Matching by tolerance, no exact-float merges."""
import json, math, os, sys, csv, hashlib
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.dont_write_bytecode = True
from envelope_guard import validate_envelope, coverage_ranges, EnvelopeError

OUT = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # package root
R4 = os.environ.get("TAL_R4_EXTRACTED", os.path.join(ROOT, "inputs_r4", "extracted"))   # see README: extract_r4_inputs.py
CLOCK = os.path.join(R4, "tal_branch_clock_accel_test_r4", "tal_branch_clock_accel_test")   # extracted clock r4 zip
SUBCM = os.path.join(R4, "subcm_yukawa_window_zenodo_r4", "subcm_yukawa_window")   # extracted sub-cm r4 zip
BREN = os.path.join(R4, "bren_continuation_zenodo_r4", "bren_continuation")   # extracted BREN r4 zip
CASS = os.path.join(ROOT, "cassini_gamma_input.json")
F_REF = f"{CLOCK}/reference/reference_results.json"
F_SET = f"{CLOCK}/inputs/setup_declared.json"
F_SUBRES = f"{SUBCM}/outputs/results.json"
F_ENV = f"{SUBCM}/outputs/envelopes.npz"          # same bytes as clock r4 inputs/bounds/subcm_envelopes.npz
F_BREN = f"{BREN}/outputs/bren_continuation_results.json"
F_AHN4 = f"{CLOCK}/inputs/bounds/AHN2003_fig4__fill_polygons.csv"

class StrictError(Exception): pass
def need(d, *path):
    for k in path:
        if not isinstance(d, dict) or k not in d: raise StrictError(f"missing key {path}")
        d = d[k]
    return d
def finite(x, what):
    a = np.asarray(x, dtype=float)
    if not np.all(np.isfinite(a)): raise StrictError(f"non-finite value in {what}")
    return x
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def rel(p): return os.path.relpath(p, ROOT)   # paths recorded relative to the package root

for p in (F_REF, F_SET, F_SUBRES, F_ENV, F_BREN, CASS, F_AHN4):
    if not os.path.isfile(p): raise StrictError(f"missing input {p}")
ref = json.load(open(F_REF)); setup = json.load(open(F_SET)); subres = json.load(open(F_SUBRES))
bren = json.load(open(F_BREN)); cass = json.load(open(CASS))
env = np.load(F_ENV)

# ---------- bound functions ----------
sub_cfg = need(setup, "bounds")
key = need(sub_cfg, "subcm_envelope_key")                      # "combined_abs"
logL_env = np.asarray(env["log10_lambda"], float); a_env = np.asarray(env[key], float)
try:   # strict, coverage-aware validation before any filtering or interpolation (envelope_guard.py)
    validate_envelope(logL_env, a_env, coverage_ranges(subres), what=f"envelopes.npz:{key}")
except EnvelopeError as e:
    raise StrictError(f"envelope check failed: {e}") from None
ok_env = np.isfinite(a_env)   # after the check: NaN only outside the curve coverage
SUB_LO = float(10 ** logL_env[ok_env][0]); SUB_HI = float(min(10 ** logL_env[ok_env][-1], need(sub_cfg, "subcm_range_m")[1]))
le_f, la_f = logL_env[ok_env], np.log10(a_env[ok_env])
def alim_subcm(lam):
    if not (SUB_LO <= lam <= SUB_HI): return None
    return float(10 ** np.interp(math.log10(lam), le_f, la_f))

variants = need(sub_cfg, "bren_variants")                     # A, B, C (as in clock r4)
scan = need(bren, "lambda_scan")
bren_L = sorted({float(k) for v in variants for k in need(scan, v).keys()})
def bren_alims_at(lam_key_float):
    out = {}
    for v in variants:
        for k, val in need(scan, v).items():
            if math.isclose(float(k), lam_key_float, rel_tol=1e-9):
                out[v] = float(finite(need(val, "rho_2000", "B89", "alpha_lim_cont"), "bren"))
    if set(out) != set(variants): raise StrictError(f"BREN variants missing at {lam_key_float}")
    return out
BREN_LOGL = np.log10(bren_L)
BREN_CONS = np.log10([max(bren_alims_at(L).values()) for L in bren_L])   # conservative = largest alpha_lim (smallest R)
BREN_LO, BREN_HI = bren_L[0], bren_L[-1]
def alim_bren(lam):
    if not (BREN_LO * (1 - 1e-12) <= lam <= BREN_HI * (1 + 1e-12)): return None
    return float(10 ** np.interp(math.log10(lam), BREN_LOGL, BREN_CONS))

AU = 1.495978707e11                     # IAU 2012 Resolution B2 (exact definition)
g_val, g_sig = float(need(cass, "value")), float(need(cass, "sigma"))
CASS_B = {"2sigma_lower": abs(g_val - 2 * g_sig), "1sigma_lower": abs(g_val - g_sig)}
for k, b in CASS_B.items():
    rec = need(cass, "derived_one_sided_readings_for_TAL", f"lower_edge_{k.split('_')[0]}_bound_on_1_minus_gamma")
    if not math.isclose(b, rec, rel_tol=1e-9): raise StrictError("cassini bound mismatch")
# AHN 2003 Fig. 4: lower edge of the digitized excluded fill, same algorithm as clock r4 bounds.py alpha_lim_ahn4:
# for x = log10(lambda), the minimum over all polygon edges spanning x of the log-log linear edge value.
AHN_MIN = float(need(sub_cfg, "ahn_fig4_min_lambda_m"))
if need(sub_cfg, "ahn_fig4_file") != "bounds/AHN2003_fig4__fill_polygons.csv": raise StrictError("ahn file key")
_polys = {}
with open(F_AHN4, newline="") as f:
    for row in csv.DictReader(f):
        for k_ in ("polygon", "vertex", "lambda_m", "alpha"):
            if k_ not in row or row[k_] in ("", None): raise StrictError(f"AHN csv missing {k_}")
        lm, al_ = float(row["lambda_m"]), float(row["alpha"])
        finite([lm, al_], "AHN csv")
        if lm <= 0 or al_ <= 0: raise StrictError("AHN csv non-positive")
        _polys.setdefault(int(row["polygon"]), []).append((float(row["vertex"]), lm, al_))
AHN_EDGES = []
for k_ in sorted(_polys):
    v_ = sorted(_polys[k_]); X = np.log10([q[1] for q in v_]); Y = np.log10([q[2] for q in v_])
    AHN_EDGES.append((X, Y, np.roll(X, -1), np.roll(Y, -1)))
def alim_ahn4(lam):
    if lam < AHN_MIN: return None
    x = math.log10(lam); best = math.inf
    for X, Y, X2, Y2 in AHN_EDGES:
        for a, b, c_, d in zip(X, Y, X2, Y2):
            if (a - x) * (c_ - x) <= 0 and a != c_:
                best = min(best, b + (d - b) * (x - a) / (c_ - a))
    return float(10 ** best) if math.isfinite(best) else None
AHN_LAM_MAX = max(q[1] for v_ in _polys.values() for q in v_)

def one_minus_gamma(aY): return 2 * aY / (aY + 4 * math.pi)   # Brans-Dicke PPN relation, alpha = alpha_Y/4pi (article sec. 4)

# ---------- PREFLIGHT ----------
pre = {"tolerances": {"R_cons_vs_stated_3dp_abs": 5e-4, "R_cons_vs_reference_rel": 1e-9,
                      "edge_vs_reference_rel": 1e-6, "edge_vs_stated_um_abs": 5e-4,
                      "bound_only_R_vs_reference_rel": 1e-9}}
stated = {"P1": 9.580, "P2": 3.193, "P3": 8.355}
pre["R_cons"] = {}
for ps in need(ref, "parameter_sets"):
    pid = need(ps, "id"); L = float(need(ps, "L_m")); aY = float(need(ps, "alpha_Y"))
    alpha = aY / (4 * math.pi)
    R = alpha / max(bren_alims_at(L).values())
    Rref = float(need(ps, "bounds", "R_conservative"))
    ok = abs(R - stated[pid]) <= 5e-4 and math.isclose(R, Rref, rel_tol=1e-9)
    pre["R_cons"][pid] = {"L_m": L, "alpha_Y": aY, "R_recomputed": R, "R_reference": Rref, "R_stated": stated[pid], "pass": bool(ok)}
alpha1 = 1 / (4 * math.pi)
i = int(np.where(np.log10(np.where(ok_env, a_env, np.inf)) < math.log10(alpha1))[0][0])
x0, x1 = logL_env[i - 1], logL_env[i]; y0, y1 = math.log10(a_env[i - 1]), math.log10(a_env[i])
edge = float(10 ** (x0 + (math.log10(alpha1) - y0) / (y1 - y0) * (x1 - x0)))
edge_ref = float(need(ref, "edge", "lambda_edge_m"))
pre["edge"] = {"lambda_edge_recomputed_m": edge, "reference_m": edge_ref, "stated_um": 75.877,
               "pass": bool(math.isclose(edge, edge_ref, rel_tol=1e-6) and abs(edge * 1e6 - 75.877) <= 5e-4)}
# extra: sub-cm R on the clock bound_only grid below 2 mm (pure envelope region there)
bo = need(ref, "bound_only"); dev = 0.0; n = 0
for L, Rr in zip(need(bo, "L_m"), need(bo, "R")):
    if L < float(need(sub_cfg, "ahn_fig4_min_lambda_m")) and L >= SUB_LO:
        R = alpha1 / alim_subcm(L); dev = max(dev, abs(R / Rr - 1)); n += 1
pre["bound_only_check"] = {"n_points": n, "max_rel_dev": float(dev), "pass": bool(n > 0 and dev <= 1e-9)}
# AHN cross-check: R_lab_compilation of clock r4 = alpha / min(alpha_lim_ahn4, alpha_lim_subcm)
xc = {"tolerance_rel": 1e-9, "parameter_sets": {}, "scan": []}; xdev = 0.0
def r_lab(alpha, lam):
    v = [q for q in (alim_ahn4(lam), alim_subcm(lam)) if q is not None]
    return alpha / min(v) if v else None
for ps in need(ref, "parameter_sets"):
    L = float(need(ps, "L_m")); alpha = float(need(ps, "alpha_Y")) / (4 * math.pi)
    Rr = float(need(ps, "bounds", "R_lab_compilation")); Rm = r_lab(alpha, L); d = abs(Rm / Rr - 1); xdev = max(xdev, d)
    xc["parameter_sets"][need(ps, "id")] = {"L_m": L, "R_lab_recomputed": Rm, "R_lab_reference": Rr, "rel_dev": d}
sc_ = need(ref, "scan"); aYs = 1.0
for j, (L, Rr) in enumerate(zip(need(sc_, "L_m"), need(sc_, "R"))):
    finite([L, Rr], "scan")
    Rm = r_lab(aYs / (4 * math.pi), float(L)); d = abs(Rm / Rr - 1); xdev = max(xdev, d)
    xc["scan"].append({"L_m": float(L), "R_lab_recomputed": Rm, "R_lab_reference": float(Rr), "rel_dev": d})
xc["n_points"] = len(xc["scan"]) + len(xc["parameter_sets"]); xc["max_rel_dev"] = xdev
xc["pass"] = bool(xdev <= 1e-9 and len(xc["scan"]) > 0)
pre["ahn4_vs_clock_r4_lab_compilation"] = xc
pre["input_sha256"] = {rel(p): sha(p) for p in (F_REF, F_SET, F_SUBRES, F_ENV, F_BREN, CASS, F_AHN4)}
pre["pass"] = bool(all(v["pass"] for v in pre["R_cons"].values()) and pre["edge"]["pass"] and pre["bound_only_check"]["pass"] and pre["ahn4_vs_clock_r4_lab_compilation"]["pass"])
json.dump(pre, open(os.path.join(OUT, "preflight.json"), "w"), indent=1)
print(json.dumps(pre, indent=1))
if not pre["pass"]:
    print("PREFLIGHT FAILED - stopping"); sys.exit(2)

# ---------- GRID ----------
H0 = 67.4e3 / 3.085677581e22            # 67.4 km/s/Mpc: input value fixing the grid end c/H0
c = 299792458.0
LAM = np.logspace(-9, math.log10(c / H0), 400)
AY = np.logspace(-6, 1, 200)
rows = []; curve = []
for lam in LAM:
    a_sub, a_br, a_ah = alim_subcm(lam), alim_bren(lam), alim_ahn4(lam)
    cass_ok = lam >= AU
    covering = [n for n, f in (("subcm", a_sub is not None), ("ahn4", a_ah is not None), ("bren", a_br is not None), ("cassini", cass_ok)) if f]
    lims = []
    if a_sub is not None: lims.append(4 * math.pi * finite(a_sub, "subcm"))
    if a_ah is not None: lims.append(4 * math.pi * finite(a_ah, "ahn4"))
    if a_br is not None: lims.append(4 * math.pi * finite(a_br, "bren"))
    if cass_ok:
        b = CASS_B["2sigma_lower"]; lims.append(4 * math.pi * b / (2 - b))
    aYmax = min(lims) if lims else None
    aYmax_minrule = max(lims) if lims else None   # sensitivity: clock r4 R_conservative rule (min R over bounds)
    cv = {"lambda_m": float(lam), "mc2_eV": 1.054571817e-34 * c / lam / 1.602176634e-19,
          "coverage": "+".join(covering) if covering else "not_computed", "alphaY_max": aYmax,
          "alphaY_max_min_R_rule": aYmax_minrule, "alphaY_max_per_bound": {n_: v_ for n_, v_ in zip(covering, lims)}}
    if cass_ok:
        b1 = CASS_B["1sigma_lower"]; cv["alphaY_max_cassini_1sigma_lower"] = 4 * math.pi * b1 / (2 - b1)
    curve.append(cv)
    for aY in AY:
        alpha = aY / (4 * math.pi)
        r = {"lambda_m": lam, "alpha_Y": aY, "R_subcm": None, "R_ahn4": None, "R_bren": None, "R_cassini_2sig": None, "R_cassini_1sig": None}
        if a_sub is not None: r["R_subcm"] = alpha / a_sub
        if a_ah is not None: r["R_ahn4"] = alpha / a_ah
        if a_br is not None: r["R_bren"] = alpha / a_br
        if cass_ok:
            omg = one_minus_gamma(aY)
            r["R_cassini_2sig"] = omg / CASS_B["2sigma_lower"]; r["R_cassini_1sig"] = omg / CASS_B["1sigma_lower"]
        prim = [r[k] for k in ("R_subcm", "R_ahn4", "R_bren", "R_cassini_2sig") if r[k] is not None]
        for v in prim: finite(v, "R")
        r["R_max"] = max(prim) if prim else None
        r["R_min_over_bounds"] = min(prim) if prim else None
        r["coverage"] = cv["coverage"]
        r["category"] = "not_computed" if not prim else ("b_excluded" if r["R_max"] > 1 else "not_excluded")
        rows.append(r)

# ---------- STRICT CHECKS ----------
assert len(rows) == 400 * 200 and len(curve) == 400
for r in rows:
    for k in ("lambda_m", "alpha_Y", "R_subcm", "R_ahn4", "R_bren", "R_min_over_bounds", "R_cassini_2sig", "R_cassini_1sig", "R_max", "coverage", "category"):
        if k not in r: raise StrictError(f"missing {k}")
    if r["coverage"] == "not_computed":
        if r["R_max"] is not None or r["category"] != "not_computed": raise StrictError("claim in uncovered cell")
    else:
        finite(r["R_max"], "R_max")
for cv in curve:
    if cv["coverage"] != "not_computed":
        finite(cv["alphaY_max"], "alphaY_max")
        if len(cv["alphaY_max_per_bound"]) != len(cv["coverage"].split("+")): raise StrictError("per-bound list mismatch")
    elif cv["alphaY_max"] is not None: raise StrictError("curve value in uncovered band")

# ---------- OUTPUT ----------
with open(os.path.join(OUT, "map_cells.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["lambda_m", "alpha_Y", "alpha", "R_subcm", "R_ahn4", "R_bren", "R_cassini_2sigma_lower", "R_cassini_1sigma_lower", "R_max", "R_min_over_bounds", "category", "coverage"])
    fmt = lambda v: "NA" if v is None else f"{v:.6e}"
    for r in rows:
        w.writerow([f"{r['lambda_m']:.6e}", f"{r['alpha_Y']:.6e}", f"{r['alpha_Y']/(4*math.pi):.6e}", fmt(r["R_subcm"]), fmt(r["R_ahn4"]), fmt(r["R_bren"]),
                    fmt(r["R_cassini_2sig"]), fmt(r["R_cassini_1sig"]), fmt(r["R_max"]), fmt(r["R_min_over_bounds"]), r["category"], r["coverage"]])
# coverage bands
bands = []; cur = None
for cv in curve:
    if cur is None or cv["coverage"] != cur["coverage"]:
        cur = {"coverage": cv["coverage"], "lambda_from_m": cv["lambda_m"], "lambda_to_m": cv["lambda_m"]}; bands.append(cur)
    else: cur["lambda_to_m"] = cv["lambda_m"]
summary = {
  "definition": "R = alpha/alpha_lim (lab) or (1-gamma)/bound (Cassini); conditional ratio, not sigma; R>1 -> b_excluded; R<=1 -> not_excluded (not confirmed; resolvability not computed)",
  "grid": {"lambda_m": [float(LAM[0]), float(LAM[-1]), 400, "log"], "alpha_Y": [1e-6, 10, 200, "log"], "c_over_H0_m": c / H0},
  "bounds_used": {
    "subcm": {"file": rel(F_ENV), "key": key, "lambda_range_m": [SUB_LO, SUB_HI], "interp": "linear in log10-log10"},
    "ahn4": {"file": rel(F_AHN4), "source": need(sub_cfg, "ahn_fig4_source"), "digitized_from_figure": True,
             "applied_for_lambda_ge_m": AHN_MIN, "finite_up_to_m_on_grid": None, "polygon_lambda_max_m": AHN_LAM_MAX,
             "algorithm": "clock r4 talcheck/bounds.py alpha_lim_ahn4: min over polygon edges spanning log10(lambda) of log-log linear edge value",
             "normalization": "alpha = alpha_Y/4pi; R = alpha/alpha_lim"},
    "bren": {"file": rel(F_BREN), "path": "lambda_scan/{A,B,C}/<L>/rho_2000/B89/alpha_lim_cont", "rule": "max over variants (smallest R), as clock r4 R_conservative",
             "lambda_nodes_m": bren_L, "interp": "linear in log10-log10 between nodes (approximation between the 12 nodes)"},
    "cassini": {"file": rel(CASS), "applied_for_lambda_ge_m": AU, "formula": "1-gamma = 2 alpha_Y/(alpha_Y+4pi)",
                "condition": "long-range PPN relation applied operationally from lambda >= 1 AU, independent of lambda; the finite-lambda radio-link response and the error of this approximation were not computed; this is an assumption of the map layer, not a re-analysis of the Cassini measurement",
                "primary_bound": CASS_B["2sigma_lower"], "variant_bound": CASS_B["1sigma_lower"]}},
  "coverage_bands": bands, "alphaY_max_curve": curve,
  "combination_rule": "category from R_max = max over covering bounds (excluded by at least one bound); R_min_over_bounds and alphaY_max_min_R_rule (clock r4 R_conservative rule) given as sensitivity only",
  "counts": {c_: sum(1 for r in rows if r["category"] == c_) for c_ in ("b_excluded", "not_excluded", "not_computed")},
  "alphaY1_column": [{"lambda_m": cv["lambda_m"], "coverage": cv["coverage"],
                       "alphaY_max": cv["alphaY_max"], "alphaY1_excluded": (None if cv["alphaY_max"] is None else cv["alphaY_max"] < 1.0)} for cv in curve],
}
fin_ah = [cv["lambda_m"] for cv in curve if "ahn4" in cv["coverage"].split("+")]
summary["bounds_used"]["ahn4"]["finite_up_to_m_on_grid"] = [min(fin_ah), max(fin_ah)]
summary["counts_min_R_rule"] = {c_: sum(1 for r in rows if (r["R_min_over_bounds"] is not None) and ((r["R_min_over_bounds"] > 1) == (c_ == "b_excluded"))) for c_ in ("b_excluded", "not_excluded")}
json.dump(summary, open(os.path.join(OUT, "map_summary.json"), "w"), indent=1)
np.savez_compressed(os.path.join(OUT, "map_grid.npz"), lambda_m=LAM, alpha_Y=AY,
    R_max=np.array([r["R_max"] if r["R_max"] is not None else 0.0 for r in rows]).reshape(400, 200),
    covered=np.array([r["R_max"] is not None for r in rows]).reshape(400, 200))
print("counts", summary["counts"]); print("bands", json.dumps(bands, indent=0))
