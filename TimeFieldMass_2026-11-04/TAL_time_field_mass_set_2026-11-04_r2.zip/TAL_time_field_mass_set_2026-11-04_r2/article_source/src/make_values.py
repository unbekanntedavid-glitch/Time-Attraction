#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi David (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Read every number of the article from the data package outputs and write LaTeX value macros and tables (EN, HU).
Strict: a missing key or a non-finite value stops the build. usage: make_values.py <package_root> <article_dir>"""
import json, math, os, sys
PKG, ART = sys.argv[1], sys.argv[2]
def J(rel): return json.load(open(os.path.join(PKG, rel)))
class StrictError(Exception): pass
def need(d, *path):
    for k in path:
        if isinstance(d, list): d = d[k]; continue
        if not isinstance(d, dict) or k not in d: raise StrictError(f"missing key {path}")
        d = d[k]
    if isinstance(d, float) and not math.isfinite(d): raise StrictError(f"non-finite {path}")
    return d
SRC = {}   # value key -> source file / key path (written to generated/value_sources.json)
V = {}
def put(key, val, src, kind="sig", n=4):
    if val is None or (isinstance(val, float) and not math.isfinite(val)): raise StrictError(f"bad value {key}")
    V[key] = (val, kind, n); SRC[key] = src
def fmt(val, kind, n, lang):
    dec = "{,}" if lang == "hu" else "."
    if kind == "raw": return str(val)
    if kind == "fix": s = f"{val:.{n}f}"
    elif kind == "int":
        s = f"{int(round(val)):,}".replace(",", "\\," ); return s
    elif kind == "sig":
        if val == 0: return "0"
        e = math.floor(math.log10(abs(val)))
        if -3 <= e < 5: s = f"{val:.{max(n - 1 - e, 0)}f}"
        else:
            m = val / 10 ** e; ms = f"{m:.{n - 1}f}"
            if ms.startswith("10"): m /= 10; e += 1; ms = f"{m:.{n - 1}f}"
            return ms.replace(".", dec) + f"\\times10^{{{e}}}"
    elif kind == "sci":
        e = math.floor(math.log10(abs(val))); m = val / 10 ** e; ms = f"{m:.{n - 1}f}"
        if ms.startswith("10"): m /= 10; e += 1; ms = f"{m:.{n - 1}f}"
        return ms.replace(".", dec) + f"\\times10^{{{e}}}"
    return s.replace(".", dec)
# ---------------- theory ----------------
sy = J("theory_checks/sympy_checks.json")
EXPECT = {"static_fpp": "alpha_Y*phi*rho*xi - alpha_Y*rho*exp(-phi) + phi/L**2",
          "U_doubleprime": "alpha_Y*rho*xi + alpha_Y*rho*exp(-phi) + L**(-2)",
          "matter_era_solution": "C1 + C2/t + alpha_Y*log(t)/(6*pi)",
          "conformal_map_total_derivative": True, "exp_min_U2": "q*(p + q)",
          "one_minus_gamma": "2*alpha_Y/(alpha_Y + 4*pi)",
          "matter_era_residual_linearized_ode": "0", "matter_era_residual_test_pass": True}
for k, v in EXPECT.items():
    if need(sy, k) != v: raise StrictError(f"sympy check {k} differs: {sy[k]}")
nb = J("theory_checks/numbers.json")
put("omgOne", need(nb, "one_minus_gamma_aY1"), "theory_checks/numbers.json:one_minus_gamma_aY1", "sig", 5)
put("omgThird", need(nb, "one_minus_gamma_aY1_3"), "theory_checks/numbers.json:one_minus_gamma_aY1_3", "sig", 4)
c2 = need(nb, "cassini", "Bertotti_2sigma_lower |2.1-4.6|e-5"); c1 = need(nb, "cassini", "Bertotti_1sigma_lower |2.1-2.3|e-5")
cas = J("cassini_gamma_input.json")
if not (need(cas, "value") == 2.1e-5 and need(cas, "sigma") == 2.3e-5 and need(cas, "citation", "doi") == "10.1038/nature01997"): raise StrictError("cassini input")
put("casTwo", need(c2, "bound_on_1_minus_gamma"), "numbers.json:cassini/2sigma_lower/bound", "sci", 2)
put("casOne", need(c1, "bound_on_1_minus_gamma"), "numbers.json:cassini/1sigma_lower/bound", "sci", 2)
put("RcasTwo", need(c2, "R_aY1"), "numbers.json:cassini/2sigma_lower/R_aY1", "sci", 2)
put("RcasTwoThird", need(c2, "R_aY1_3"), "numbers.json:cassini/2sigma_lower/R_aY1_3", "sci", 2)
put("aYmaxCasTwo", need(c2, "alphaY_max"), "numbers.json:cassini/2sigma_lower/alphaY_max", "sci", 4)
put("aYmaxCasOne", need(c1, "alphaY_max"), "numbers.json:cassini/1sigma_lower/alphaY_max", "sci", 4)
rows = need(nb, "rows")
def envrow(prefix, aY):
    r = [x for x in rows if x["env"].startswith(prefix) and abs(x["alpha_Y"] - aY) < 1e-12]
    if len(r) != 1: raise StrictError(f"env row {prefix} {aY}")
    return r[0]
ENVS = [("lab", "lab granite"), ("earth", "Earth mean"), ("sun", "Sun mean"), ("ipm", "interplanetary at 1 AU")]
for key, pre in ENVS:
    r1 = envrow(pre, 1.0); r3 = envrow(pre, 1 / 3)
    put(f"rho{key}", need(r1, "rho_kg_m3"), f"numbers.json:rows[{pre}]/rho_kg_m3", "sig", 3)
    put(f"Leff{key}", need(r1, "L_eff_m"), f"numbers.json:rows[{pre},aY=1]/L_eff_m", "sci", 3)
    put(f"LeffAU{key}", need(r1, "L_eff_AU"), f"numbers.json:rows[{pre},aY=1]/L_eff_AU", "sig", 3)
    put(f"mcsq{key}", need(r1, "mc2_eV"), f"numbers.json:rows[{pre},aY=1]/mc2_eV", "sci", 3)
    put(f"LeffT{key}", need(r3, "L_eff_m"), f"numbers.json:rows[{pre},aY=1/3]/L_eff_m", "sci", 3)
    if key in ("earth", "sun"):
        put(f"RL{key}", need(r1, "R_over_L_sq"), f"numbers.json:rows[{pre},aY=1]/R_over_L_sq", "sci", 3)
        put(f"pneed{key}", need(r1, "p_needed_Hexp"), f"numbers.json:rows[{pre},aY=1]/p_needed_Hexp", "sci", 2)
put("aTAL", 1 / (4 * math.pi), "definition alpha=alpha_Y/(4 pi), alpha_Y=1", "fix", 7)
# ---------------- map r3 ----------------
ms = J("map_r3/map_summary.json"); mp = J("map_r3/preflight.json"); kv = J("map_r3/key_values_r3.json")
if need(mp, "pass") is not True: raise StrictError("map preflight not passed")
cx = J("map_r3/crosscheck_ahn4_impl.json")
if need(cx, "pass") is not True: raise StrictError("ahn4 crosscheck")
put("ahnXdev", need(cx, "max_rel_dev"), "map_r3/crosscheck_ahn4_impl.json:max_rel_dev", "sci", 1)
put("ahnXn", need(cx, "n_compared"), "map_r3/crosscheck_ahn4_impl.json:n_compared", "raw")
cnt = need(ms, "counts")
for k, n in (("b_excluded", "cntB"), ("not_excluded", "cntNE"), ("not_computed", "cntNC")): put(n, need(cnt, k), f"map_r3/map_summary.json:counts/{k}", "int")
put("cntTot", sum(cnt.values()), "sum of map_summary counts", "int")
for p in ("P1", "P2", "P3"):
    put(f"Rcons{p}", need(mp, "R_cons", p, "R_recomputed"), f"map_r3/preflight.json:R_cons/{p}", "fix", 3)
    put(f"Rlab{p}", need(mp, "ahn4_vs_clock_r4_lab_compilation", "parameter_sets", p, "R_lab_recomputed"), f"map_r3/preflight.json:ahn4_vs_clock_r4_lab_compilation/{p}", "fix", 2)
edge = need(mp, "edge", "lambda_edge_recomputed_m")
put("edgeUm", edge * 1e6, "map_r3/preflight.json:edge/lambda_edge_recomputed_m", "fix", 6)
put("edgeUmShort", edge * 1e6, "map_r3/preflight.json:edge", "fix", 3)
bands = need(ms, "coverage_bands")
if bands[0]["coverage"] != "not_computed": raise StrictError("first band")
put("gapGridTo", need(bands[0], "lambda_to_m") * 1e6, "map_r3/map_summary.json:coverage_bands[0]/lambda_to_m", "fix", 2)
sublo = need(ms, "bounds_used", "subcm", "lambda_range_m")[0]
put("subLo", sublo * 1e6, "map_r3/map_summary.json:bounds_used/subcm/lambda_range_m[0]", "fix", 5)
put("ahnMax", need(ms, "bounds_used", "ahn4", "polygon_lambda_max_m"), "map_r3/map_summary.json:bounds_used/ahn4/polygon_lambda_max_m", "sci", 4)
nc_other = [b for b in bands[1:] if b["coverage"] == "not_computed"]
put("nNCother", len(nc_other), "map_r3/map_summary.json:coverage_bands (not_computed after the first band)", "raw")
cv = need(ms, "alphaY_max_curve")
cov = [c for c in cv if c["alphaY_max"] is not None]
mn = min(cov, key=lambda c: c["alphaY_max"])
put("aYminVal", mn["alphaY_max"], "map_summary.json:alphaY_max_curve min", "sci", 2)
put("aYminLam", mn["lambda_m"], "map_summary.json:alphaY_max_curve argmin", "sci", 2)
def _bind(c):
    pb = need(c, "alphaY_max_per_bound")
    k = min(pb, key=pb.get)
    if abs(pb[k] - c["alphaY_max"]) > 1e-12 * abs(c["alphaY_max"]): raise StrictError("alphaY_max != min per bound")
    return k
cas_bind = [c for c in cov if _bind(c) == "cassini"]
if not cas_bind: raise StrictError("no cassini-binding lambda")
put("casBindFrom", cas_bind[0]["lambda_m"], "map_summary.json:alphaY_max_curve first binding=cassini", "sci", 2)
hnov = [c for c in cov if 4.9e11 <= c["lambda_m"] <= 9.8e11]
put("hnovLo", min(c["alphaY_max"] for c in hnov), "map_summary.json:alphaY_max_curve, 4.9e11..9.8e11 m", "sci", 2)
put("hnovHi", max(c["alphaY_max"] for c in hnov), "map_summary.json:alphaY_max_curve, 4.9e11..9.8e11 m", "sci", 2)
col = need(ms, "alphaY1_column")
ne = [c["lambda_m"] for c in col if c["coverage"] != "not_computed" and c["alphaY1_excluded"] is False]
ex = [c["lambda_m"] for c in col if c["alphaY1_excluded"] is True]
if not ne or max(ne) >= edge or min(ex) <= edge or min(ex) < max(ne): raise StrictError("alpha_Y=1 column not consistent with edge")
put("aYoneNEfirst", min(ne) * 1e6, "map_summary.json:alphaY1_column first not-excluded grid lambda", "fix", 3)
# alpha_Y,max table
SEL = [(2e-6, r"2\um"), (1e-5, r"10\um"), (5e-5, r"50\um"), (7.587709630440307e-05, r"\V{edgeUmShort}\um"), (1e-4, r"100\um"),
       (1e-3, r"1\mmu"), (1e-2, r"1\cmu"), (1.0, r"1\mU"), (100.0, r"100\mU"), (1e3, r"1\kmu"), (1e4, r"10\kmu"), (1e5, r"100\kmu"),
       (1e8, r"$10^{8}$\mU"), (1.495978707e11, "1 AU"), (1e14, r"$10^{14}$\mU"), (1.3724968347232662e+26, r"$c/H_0$")]
NAMES = {"subcm": "sub-cm", "ahn4": "AHN Fig.~4", "bren": "BREN", "cassini": "Cassini"}
klist = need(kv, "key_lambda")
def NM(k, lang): return "AHN 4.~ábra" if (lang == "hu" and k == "ahn4") else NAMES[k]
def tab_amax(lang):
    out = []
    for lam, lab in SEL:
        r = [x for x in klist if math.isclose(x["lambda_m"], lam, rel_tol=1e-9)]
        if len(r) != 1: raise StrictError(f"key lambda {lam}")
        r = r[0]
        if r["alphaY_max"] is None: raise StrictError("null alphaY_max in selected rows")
        others = [f"{NM(k, lang)}: ${fmt(v, 'sig', 3, lang)}$" for k, v in r["alphaY_max_per_bound"].items() if k != r["binding_bound"]]
        out.append(f"{lab} & ${fmt(r['mc2_eV'], 'sci', 2, lang)}$ & ${fmt(r['alphaY_max'], 'sig', 3, lang)}$ & {NM(r['binding_bound'], lang)} & {'; '.join(others) if others else '--'}\\\\")
    return "\n".join(out) + "\n"
# ---------------- window r3 ----------------
wc = J("window_signal_r3/window_crossings.json"); wk = J("window_signal_r3/window_key_table.json"); wp = J("window_signal_r3/preflight.json")
if need(wp, "pass") is not True or not all(need(wc, "agreement").values()): raise StrictError("window checks")
tr = need(wc, "best_bound_transitions")
put("trOne", tr[0]["lambda_um"], "window_crossings.json:best_bound_transitions[0]", "fix", 6)
put("trTwo", tr[1]["lambda_um"], "window_crossings.json:best_bound_transitions[1]", "fix", 6)
put("wEdge", need(wc, "edge_um"), "window_crossings.json:edge_um", "fix", 6)
for k, n in (("F_env=10", "Fx10"), ("F_env=100", "Fx100"), ("F_env=1000", "Fx1000")):
    put(n, need(wc, "F_env_crossings_um", k), f"window_crossings.json:F_env_crossings_um/{k}", "fix", 3)
put("Ffifty", need(wc, "F_env_at", "50"), "window_crossings.json:F_env_at/50", "fix", 5)
put("Fsevfive", need(wc, "F_env_at", "75"), "window_crossings.json:F_env_at/75", "fix", 5)
put("Fsevfiveeight", need(wc, "F_env_at", "75.8"), "window_crossings.json:F_env_at/75.8", "fix", 5)
put("sigOne", need(wc, "alpha_TAL_over_sigma_alpha_thesis_equals_1_um"), "window_crossings.json:alpha_TAL_over_sigma_alpha_thesis_equals_1_um", "fix", 3)
put("nCurves", need(wp, "n_curves"), "window_signal_r3/preflight.json:n_curves", "raw")
put("envDev", need(wp, "envelope_vs_min_of_curves", "max_rel_dev"), "window_signal_r3/preflight.json", "sci", 1)
hbarc = 1.054571817e-34 * 299792458.0 / 1.602176634e-19
put("mcFifty", hbarc / 50e-6 * 1e3, "hbar c / lambda, CODATA 2018", "fix", 2)
put("mcEdge", hbarc / edge * 1e3, "hbar c / lambda_edge, CODATA 2018", "fix", 2)
rep = need(wk, "representative")
def rowat(l):
    r = [x for x in rep if math.isclose(x["lambda_um"], l, rel_tol=1e-9)]
    if len(r) != 1: raise StrictError(f"window row {l}")
    return r[0]
for l, n in ((50.0, "Fifty"), (70.0, "Seventy"), (75.0, "SevFive")):
    put(f"sig{n}", need(rowat(l), "alpha_TAL_over_sigma_alpha"), f"window_key_table.json:representative[{l}]/alpha_TAL_over_sigma_alpha", "fix", 2)
SETBY = {"Lee2020_fig5/unattributed_2to20um": {"en": "unattributed 2--20\\um\\ curve", "hu": "forrás nélküli 2--20\\um-es görbe"},
         "Lee2020_fig5/Eot-Wash_2020": {"en": "E\\\"ot-Wash 2020", "hu": "E\\\"ot-Wash 2020"},
         "Lee2020_fig5/HUST_2020": {"en": "HUST 2020", "hu": "HUST 2020"}}
def tab_window(lang):
    out = []
    for l in (2.0, 5.0, 10.0, 20.0, 30.0, 38.6, 50.0, 70.0, 75.0):
        r = rowat(l); e = need(r, "envelope"); pb = need(r, "per_bound")
        def f(k):
            return f"${fmt(pb[k]['improvement_factor'], 'sig', 3, lang)}$" if k in pb else "--"
        lab = f"{l:g}".replace(".", "{,}" if lang == "hu" else ".")
        out.append(f"{lab} & ${fmt(r['mc2_eV'] * 1e3, 'sig', 3, lang)}$ & {SETBY[e['set_by']][lang]} & ${fmt(e['improvement_factor'], 'sig', 3, lang)}$ & "
                   f"{f('Lee2020_fig5/Eot-Wash_2020')} & {f('Lee2020_fig5/HUST_2020')} & {f('Lee2020_thesis_Table11.4/+alpha95')}\\\\")
    return "\n".join(out) + "\n"
# ---------------- source model r3 ----------------
mr = J("source_model_r3/model_results.json")
val = need(mr, "validation"); nf = need(mr, "newton_fit")
if need(val, "pass") is not False:
    raise StrictError("validation passed: the article text assumes a failed validation; stop and report before writing")
if need(mr, "tal_prediction") is not None: raise StrictError("tal_prediction must be null (validation failed)")
put("nWithin", need(val, "n_within_tol"), "source_model_r3/model_results.json:validation/n_within_tol", "raw")
pts = need(val, "points"); put("nPts", len(pts), "model_results.json:validation/points", "raw")
rat = [p["ratio_alpha95_abs"] for p in pts]
put("ratLo", min(rat), "model_results.json:validation/points/ratio_alpha95_abs min", "fix", 3)
put("ratHi", max(rat), "model_results.json:validation/points/ratio_alpha95_abs max", "fix", 3)
put("chiNom", need(nf, "chi2_nominal_rP0_no_fit"), "model_results.json:newton_fit/chi2_nominal_rP0_no_fit", "fix", 1)
put("chiFit", need(nf, "chi2_fit"), "model_results.json:newton_fit/chi2_fit", "fix", 4)
if need(nf, "check_value_independent", "agree") is not True: raise StrictError("Newton chi2 cross-check")
put("chiCheck", need(nf, "check_value_independent", "chi2_fit"), "model_results.json:newton_fit/check_value_independent/chi2_fit", "fix", 8)
put("chiFitOne", need(nf, "variant_gamma_prior_1.000", "chi2_fit"), "model_results.json:newton_fit/variant_gamma_prior_1.000/chi2_fit", "fix", 1)
put("nData", need(nf, "N_data"), "model_results.json:newton_fit/N_data", "raw")
put("nuEff", need(nf, "nu_effective_approx"), "model_results.json:newton_fit/nu_effective_approx", "raw")
put("gateBench", need(nf, "gate_value"), "model_results.json:newton_fit/gate_value", "fix", 3)
put("gateEff", need(nf, "reference_nu_eff", "value"), "model_results.json:newton_fit/reference_nu_eff/value", "fix", 3)
if need(nf, "pass") is not True or need(nf, "reference_nu_eff", "pass") is not True: raise StrictError("Newton gate")
put("rPfit", need(nf, "r_P_mm") * 1e3, "model_results.json:newton_fit/r_P_mm", "fix", 1)
put("gamFit", need(nf, "gamma"), "model_results.json:newton_fit/gamma", "fix", 4)
put("dsFit", need(nf, "ds_um"), "model_results.json:newton_fit/ds_um", "fix", 2)
td = J("source_model_r3/test_derivative.json")
if need(td, "pass") is not True: raise StrictError("derivative test")
put("fdDev", max(c["max_rel_dev_analytic_vs_fd"] for c in td["cases"]), "source_model_r3/test_derivative.json:cases max", "sci", 1)
put("fdTol", need(td, "rtol"), "test_derivative.json:rtol", "sci", 1)
put("dRmax", 100 * max(c["max_rel_size_of_dR_term"] for c in td["cases"]), "test_derivative.json:max_rel_size_of_dR_term max (percent)", "fix", 2)
def tab_val(lang):
    out = []
    for p in pts:
        t = need(p, "thesis")
        out.append(f"{p['lambda_m'] * 1e6:.0f} & ${fmt(p['sigma_alpha'], 'sig', 3, lang)}$ & ${fmt(t['sigma_alpha'], 'sig', 3, lang)}$ & "
                   f"${fmt(p['alpha95_abs'], 'sig', 3, lang)}$ & ${fmt(t['alpha95_abs'], 'sig', 3, lang)}$ & ${fmt(p['ratio_alpha95_abs'], 'fix', 2, lang)}$ & "
                   f"${fmt(p['ratio_sigma'], 'fix', 2, lang)}$ & {('igen' if p['within_tol'] else 'nem') if lang == 'hu' else ('yes' if p['within_tol'] else 'no')}\\\\")
    return "\n".join(out) + "\n"

# ---------------- additional values (r1 article, extended sections) ----------------
cmr = need(ms, "counts_min_R_rule")
put("cntBminR", need(cmr, "b_excluded"), "map_summary.json:counts_min_R_rule/b_excluded", "int")
put("cntNEminR", need(cmr, "not_excluded"), "map_summary.json:counts_min_R_rule/not_excluded", "int")
cb = need(ms, "bounds_used", "cassini")
put("casVar", need(cb, "variant_bound"), "map_summary.json:bounds_used/cassini/variant_bound", "sci", 1)
put("nBrenNodes", len(need(ms, "bounds_used", "bren", "lambda_nodes_m")), "map_summary.json:bounds_used/bren/lambda_nodes_m", "raw")
vo = need(nf, "variant_gamma_prior_1.000")
put("gamOne", need(vo, "gamma"), "model_results.json:newton_fit/variant_gamma_prior_1.000/gamma", "fix", 4)
put("dsOne", need(vo, "ds_um"), "model_results.json:newton_fit/variant_gamma_prior_1.000/ds_um", "fix", 2)
put("rPOne", need(vo, "r_P_mm") * 1e3, "model_results.json:newton_fit/variant_gamma_prior_1.000/r_P_mm", "fix", 1)
put("dchiNf", need(val, "rules", "delta_chi2_95"), "model_results.json:validation/rules/delta_chi2_95", "fix", 2)
sens = need(val, "sensitivity_gamma_prior_1.000")
def ptat(l):
    r = [x for x in pts if math.isclose(x["lambda_m"], l, rel_tol=1e-9)]
    if len(r) != 1: raise StrictError(f"validation point {l}")
    return r[0]
def tab_sens(lang):
    out = []
    for q in sens:
        b = ptat(q["lambda_m"]); t = need(b, "thesis")
        out.append(f"{q['lambda_m'] * 1e6:.0f} & ${fmt(need(b, 'alpha95_abs'), 'sig', 3, lang)}$ & ${fmt(need(q, 'alpha95_abs'), 'sig', 3, lang)}$ & ${fmt(need(t, 'alpha95_abs'), 'sig', 3, lang)}$ & "
                   f"${fmt(need(b, 'sigma_alpha'), 'sig', 3, lang)}$ & ${fmt(need(q, 'sigma_alpha'), 'sig', 3, lang)}$ & ${fmt(need(t, 'sigma_alpha'), 'sig', 3, lang)}$\\\\")
    return "\n".join(out) + "\n"
CASE = {"Newton": {"en": "Newton", "hu": "Newton"},
        "Yukawa alpha=1/(4pi), lambda=50um": {"en": r"Yukawa, $\alpha=1/(4\pi)$, $\lambda=50\um$", "hu": r"Yukawa, $\alpha=1/(4\pi)$, $\lambda=50\um$"},
        "Yukawa alpha=1, lambda=50um, r_P < r_A": {"en": r"Yukawa, $\alpha=1$, $\lambda=50\um$, $r_P<r_A$", "hu": r"Yukawa, $\alpha=1$, $\lambda=50\um$, $r_P<r_A$"}}
def tab_fd(lang):
    out = []
    for c in need(td, "cases"):
        ok = need(c, "pass")
        out.append(f"{CASE[c['case']][lang]} & {c['harmonic']}$\\omega$ & ${fmt(need(c, 'max_rel_dev_analytic_vs_fd'), 'sci', 2, lang)}$ & "
                   f"${fmt(need(c, 'fd_step_agreement'), 'sci', 2, lang)}$ & ${fmt(100 * need(c, 'max_rel_size_of_dR_term'), 'sig', 2, lang)}$ & "
                   f"{('igen' if ok else 'nem') if lang == 'hu' else ('yes' if ok else 'no')}\\\\")
    return "\n".join(out) + "\n"
BANDN = {"not_computed": {"en": "not computed", "hu": "nem számolt"}, "subcm": {"en": "sub-cm", "hu": "sub-cm"},
         "subcm+ahn4": {"en": "sub-cm + AHN Fig.~4", "hu": "sub-cm + AHN 4.~ábra"}, "ahn4": {"en": "AHN Fig.~4", "hu": "AHN 4.~ábra"},
         "ahn4+bren": {"en": "AHN Fig.~4 + BREN", "hu": "AHN 4.~ábra + BREN"}, "ahn4+cassini": {"en": "AHN Fig.~4 + Cassini", "hu": "AHN 4.~ábra + Cassini"},
         "cassini": {"en": "Cassini", "hu": "Cassini"}}
def tab_bands(lang):
    return "\n".join(f"{BANDN[b['coverage']][lang]} & ${fmt(need(b, 'lambda_from_m'), 'sci', 3, lang)}$ & ${fmt(need(b, 'lambda_to_m'), 'sci', 3, lang)}$\\\\" for b in bands) + "\n"
REFK = [("transitions", "trOne"), ("F=10", "Fx10"), ("F=100", "Fx100"), ("F=1000", "Fx1000"), ("F50", "Ffifty"), ("F75", "Fsevfive"), ("F75.8", "Fsevfiveeight"), ("sigma_ratio_1", "sigOne")]
rv = need(wc, "reference_values_independent_check")
put("tolCross", need(wc, "tolerance_rel", "crossings"), "window_crossings.json:tolerance_rel/crossings", "sci", 1)
put("tolF", need(wc, "tolerance_rel", "F"), "window_crossings.json:tolerance_rel/F", "sci", 1)
put("nAgree", sum(1 for v in need(wc, "agreement").values() if v is True), "window_crossings.json:agreement (count true)", "raw")
put("nAgreeTot", len(need(wc, "agreement")), "window_crossings.json:agreement (count)", "raw")
# ---------------- input checks and stability control (package r2) ----------------
for rel, key in (("map_r3/test_envelope_guard.json", "guardMap"), ("source_model_r3/test_envelope_guard.json", "guardSrc")):
    g = J(rel)
    if need(g, "pass") is not True or need(g, "n_pass") != need(g, "n_cases"): raise StrictError(f"{rel} did not pass")
    put(key, need(g, "n_pass"), f"{rel}:n_pass", "raw"); put(key + "Tot", need(g, "n_cases"), f"{rel}:n_cases", "raw")
cc = J("map_r3/control_cassini_threshold.json")
if need(cc, "pass") is not True or need(cc, "counts_match_map") is not True: raise StrictError("Cassini threshold control")
put("casCtlChanged", need(cc, "n_cells_changed"), "map_r3/control_cassini_threshold.json:n_cells_changed", "raw")
put("casCtlCells", need(cc, "n_cells_compared_lambda_ge_1AU"), "map_r3/control_cassini_threshold.json:n_cells_compared_lambda_ge_1AU", "int")
p50 = ptat(50e-6)
put("aAbsFifty", need(p50, "alpha95_abs"), "model_results.json:validation/points[50um]/alpha95_abs", "fix", 4)
put("aPosFifty", need(p50, "alpha95_pos"), "model_results.json:validation/points[50um]/alpha95_pos", "fix", 4)
put("aNegFifty", need(p50, "alpha95_neg"), "model_results.json:validation/points[50um]/alpha95_neg", "fix", 4)
put("aStarFifty", need(p50, "alpha_star"), "model_results.json:validation/points[50um]/alpha_star", "fix", 4)
put("sigFiftyModel", need(p50, "sigma_alpha"), "model_results.json:validation/points[50um]/sigma_alpha", "fix", 4)
s50 = [q for q in sens if math.isclose(q["lambda_m"], 50e-6, rel_tol=1e-9)]; s71 = [q for q in sens if math.isclose(q["lambda_m"], 71e-6, rel_tol=1e-9)]
if len(s50) != 1 or len(s71) != 1 or len(sens) != 2: raise StrictError("sensitivity points")
shifts = [abs(need(q[0], "alpha95_abs") / need(ptat(q[0]["lambda_m"]), "alpha95_abs") - 1) * 100 for q in (s50, s71)]
put("sensShiftLo", min(shifts), "sensitivity vs base alpha95_abs (percent, min)", "fix", 1)
put("sensShiftHi", max(shifts), "sensitivity vs base alpha95_abs (percent, max)", "fix", 1)
for q in (s50, s71):
    if abs(need(q[0], "alpha95_abs") / need(need(ptat(q[0]["lambda_m"]), "thesis"), "alpha95_abs") - 1) <= 0.20: raise StrictError("sensitivity variant within tolerance; text assumes outside")
# ---------------- write ----------------
os.makedirs(os.path.join(ART, "generated"), exist_ok=True)
for lang in ("en", "hu"):
    with open(os.path.join(ART, "generated", f"values_{lang}.tex"), "w") as f:
        f.write("% generated by src/make_values.py from the data package outputs; do not edit\n\\makeatletter\n")
        for k, (v, kind, n) in V.items(): f.write(f"\\@namedef{{val@{k}}}{{{fmt(v, kind, n, lang)}}}\n")
        f.write("\\makeatother\n")
    open(os.path.join(ART, "generated", f"tab_amax_{lang}.tex"), "w").write(tab_amax(lang))
    open(os.path.join(ART, "generated", f"tab_window_{lang}.tex"), "w").write(tab_window(lang))
    open(os.path.join(ART, "generated", f"tab_val_{lang}.tex"), "w").write(tab_val(lang))
    for nm, fn in (("sens", tab_sens), ("fd", tab_fd), ("bands", tab_bands)):
        open(os.path.join(ART, "generated", f"tab_{nm}_{lang}.tex"), "w").write(fn(lang))
json.dump({k: {"value": V[k][0], "source": SRC[k]} for k in V}, open(os.path.join(ART, "generated", "value_sources.json"), "w"), indent=1)
print(len(V), "values written")
