# Article source: Mass of the TAL time scalar field (package r2)

(c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). License: CC BY-NC 4.0 International,
https://creativecommons.org/licenses/by-nc/4.0/ . Commercial use only with the author's written permission.

Contents
- tex/article_en.tex, tex/article_hu.tex, tex/common.tex: LaTeX source of the EN and HU PDFs.
- src/make_values.py: reads every number of the article from the data package and writes generated/.
- generated/: values_*.tex, tab_*.tex and value_sources.json (value -> package file and key).
- figures/: copies of the three package figures (map_r3, source_model_r3, window_signal_r3).

Rebuild
1. Unzip TAL_time_field_mass_data_r2.zip next to this folder (folder TAL_time_field_mass_data_r2/).
2. python3 src/make_values.py ../TAL_time_field_mass_data_r2 .   (run inside article_source/)
3. cd tex && pdflatex article_en.tex (twice), pdflatex article_hu.tex (twice).

Step 2 on the shipped data package regenerates the 15 files in generated/ byte-identically.
The script stops if a value is missing or not finite, if a symbolic check (including the
matter-era residual test) differs from its expected result, if the envelope-check negative
controls or the Cassini threshold control do not pass, or if the source-model validation in the
package reports a pass while the text describes a failure.
