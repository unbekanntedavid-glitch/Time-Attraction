# TAL – törvényszéki audit: hol csúszott el a levezetési lánc?

*2026-11-01 (Europe/Zurich).*
*Ellenőrző kód: `audit/code/verify_sympy.py`, eredmény: `audit/results/verify.json`. Diagram: `audit/results/plots/fuggosegi_diagram.png`.*

Jelölések:
- **[OK]**: helyes.
- **[HIBA]**: hibás; a javított értéket megadjuk.
- **[NEM LEVEZETETT]**: posztulátum vagy kézzel választott érték.
- **[ELLENTMONDÁS]**: egy későbbi verzió vagy a kód mást mond.
- **[FELTEVÉS]**: saját, nem ellenőrzött feltevés.

---

## 0. Röviden

1. **A legkorábbi kritikus törés a v1–v7 „Time Attraction” szöveg 3.1. pontja, Eq. (9)–(10)** (`artifacts/movable_mass_clock_test/src_txt/Time_Attraction.txt`, 158–164. sor; Zenodo 10.5281/zenodo.23066993; a git-repó előtti).
   - Itt születik meg a γ_L = GL²/c² állandó, mégpedig úgy, hogy a **közönséges newtoni potenciált** (|Φ_L| ≈ GM/L = (4π/3)GρL²) a 4π/3-os faktor elhagyásával átcímkézik egy új „idővonzási” faktorrá: f_L ≈ 1 + Φ_L/c² ≈ 1 − γ_Lρ̄_L.
   - Ezután Eq. (11) ezt a faktort **az Einstein–Hilbert-tag mellé, másodszor is** beteszi a hatásba: S = ∫√−g [R/16πG + f_L L_m].
   - Ebből szükségszerűen egy **gravitációs erősségű, univerzális ötödik erő** lesz. Később ez az α_Y = 1, β_Yuk = 1/(4π), α = 1/(4π) = 0,0796 érték. A kód maga is kimondja: „Since 4π β_Yuk = 1”, vagyis β_Yuk-ot úgy választották, hogy visszaadja a γ_L-t.
   - Ez az α = 0,0796 az, amit az ötödik-erő mérések 10 km-en kb. 176-szoros szorzóval kizárnak.
2. **Másodlagos törések:**
   - a laborjóslat (v1 Eq. 3 és Eq. 13) számszerűen és előjelben is hibás;
   - L = 10 km sehol nincs levezetve: egy neutroncsillag-„illusztrációból” lett fix állandó, és ez ellentmond a v1 saját L0-posztulátumának;
   - a C(ρ) sötétanyag-ág (v8–v17) nincs levezetve, és ellentmond a v1-nek;
   - a H0/H1 óracsatolás (V23) belső ellentmondása;
   - az α_Y-konvenció kettéválása: V23-ban lineáris, a V27/V28 kódban kvadratikus;
   - az F3-maradvány a step2-ben;
   - a step15 ρ_B-forrása;
   - a V28 galaxismodul.
3. **Az F1–F5 errata mind a lánc alsó részén ülnek.** Valódi hibák, de egyik sem a gyökérok.
4. **Saját hibáink:**
   - (S1) „α = 0,08 mellett λ ≳ 1,5·10¹⁵ m nyitott”: ez **hibás**, mert a Cassini-féle γ_PPN már λ ≳ ~10⁸ m-től kizárja (becslés).
   - (S2) A „H1 = csak órákra ható csatolás” leképezés több dokumentumunkban ellentmond a V23-nak és a saját B7 eredményünknek.
   - (S3) Az α_Y = 1/3-ra skálázott számaink konvenciófüggők.
   - (S4) A pontforrás-közelítést kiterjedt korongokra örököltük.

---

## 1. Kronologikus idővonal

| # | Verzió / lépés | Dátum (forrás) | Forrás (fájl) | Mi került be | Jelölés |
|---|---|---|---|---|---|
| 1 | v1–v7 „Time Attraction” | 2026. okt. eleje [FELTEVÉS: a szövegben nincs pontos dátum], Zenodo 23066993 | `movable_mass_clock_test/src_txt/Time_Attraction.txt` | f_L = exp(−γ_Lρ̄_L), γ_L = GL²/c² (Eq. 9–10); hatás f_L·L_m (Eq. 11); laborjóslat (Eq. 3, 13); L0 fix posztulátum (1,2·10⁻¹¹ m favorizált); „10 km illusztr.”; „nem váltja ki a sötét anyagot” | **[HIBA]** Eq. 9–10, Eq. 3, Eq. 13; **[NEM LEVEZETETT]** L0 |
| 2 | v8.2 / v8.3 | 2026. okt. (szöveg) | `v8.2.1.txt` | Horndeski-alosztály, R = 2/3; „150 SPARC galaxy, χ² 1231 → 159” | **[ELLENTMONDÁS]**: az absztrakt (31. sor) SPARC-ot mond, a törzs (106. sor) „mock 150-galaxy analysis”-t; R = 2/3 nem ellenőrizve |
| 3 | v12.1 / v13 | 2026-10-06 (git 60fc38e) | `v12._.txt`, `v13.txt` | „tudatos koherencia” ρ_ψ = Ξε0Φ_t, Ξε0 = 10⁻²⁶ kg/m³ (EEG/HRV) | **[NEM LEVEZETETT]**; később elhagyva, a V28-ra nincs hatása |
| 4 | v14–v16 | 2026-10-08 (git bb409f2) | `Time-Attraction_v14_FULL.txt` 4., 55. sor; `v16.0.txt` 7., 13–15. sor | C(ρ) = 1 + C0·exp(−ρ/ρc), „Eliminating the Need for Dark Matter”; C0 = 5, ρc = 10⁻²³, L0 = 1 kpc | **[NEM LEVEZETETT]**; **[ELLENTMONDÁS]** a v1 233–234. sorával; a refit C0 = 2,776, χ²/pt ≈ 97 (`docs/C_derivation_status.md`) |
| 5 | v17 / V18–V19 (7. modell) | 2026-10-19 – 10-21 | `tal_manuscript_v17.md`, `V26/tal_factor_7th_model.py` | SPARC-alapvonal, C(ρ) fősík-erősítés | **[NEM LEVEZETETT]** (a spark_audit_osszesito.md §1.2 szerint a v14.1 ODE érvénytelen) |
| 6 | V20 | Zenodo 23540741 | gránitkamra + 8 tekercs, ρ_B = B²/(2µ0c²) | óralaborjóslat | **[HIBA]**: a jel ≤ 2,4·10⁻⁴⁸ (`solenoid_update/report_hu.md` 20. sor), ez mérhetetlen |
| 7 | V21 | 2026-10-23 (0478d66) | `V21/note_HU_EN.md` | NS TOV, L-szken {1, 367, 10³, 10⁴, 10⁵} m (90. sor); „a legnagyobb eltolódás L = 10 km-nél” (137. sor) | [OK] numerikusan; a 10 km itt csak szkenpont |
| 8 | V22–V23 | 2026-10-24/25 (1a48255) | `tal_covariant_closure_50aa2db0_*/…HU….tex` 59. sor | kovariáns Branch II hatás: L_φ = −c⁴/(8πGα̃)[…], (−□+L⁻²)φ = α_YGρ/c², α_Y = 8πα̃; H0/H1 | [OK] mint hatás; **α_Y = 1 a γ_L-ből öröklődik**; a H0/H1 **[ELLENTMONDÁS]** (lásd 3.5) |
| 9 | V24 – step1 | 2026-10-27 (1e12d6e) | `V26/step1_dilaton_form.md` 27., 31–33. sor | γ_L = GL²/c² „= CL²/4π”; S = …+f_L L_m | **[NEM LEVEZETETT]** (csak formai dilaton-analógia) |
| 10 | step2 | 2026-10-27 | `V26/step2_conformal_disformal.md` 58. sor | 2ω+3 = 1/α̃ = 1/(2β²) | **[HIBA]** (F3-maradvány): helyesen 2ω+3 = 1/(2α̃) = 1/α_std, ω = 4,78 |
| 11 | step3–step5 | 2026-10-27 | `step5_coupling_dictionary_ppn_screening.md` 30., 55., 57., 71. sor | α_std = α_Y/4π = 2β²; „α_Y = 1 ⇔ top-hat”; γ_PPN = (1−αe^{−r/L})/(1+αe^{−r/L}) | [OK] belsőleg (Yukawa-kernel ∫ = L², sympy); ω = 4,78 [OK]; az 1/(4π) a γ_L-ből jön |
| 12 | step6 | 2026-10-27 | `step6_sparc_galactic_ngc3198_consistency.md` 72–78. sor | NGC 3198 negatív kontroll: C_req = 2,72–4,31, C_pred ≤ 1,0796 | **[OK]**: őszinte; kimondja, hogy a V23 nem magyarázza a lapos görbéket |
| 13 | step7 | 2026-10-27 | NS TOV/stabilitás | – | nem vizsgált mélyebben |
| 14 | step8 | 2026-10-27 | `step8_…siriusb_lab_v20.md` 24., 53., 55. sor | H1 = **univerzális** diszform/konform óracsatolás; H0: atomok g-n | **[ELLENTMONDÁS]** (3.5) |
| 15 | step9–step14 | 2026-10-27 | H.E.S.S., árnyékolás, Hesse-mátrix, lencsézés | – | ebben az auditban nem újraszámolva |
| 16 | step15 | 2026-10-27 | `step15_…_v20.md` 42., 55. sor | konform csatolásnál az EM-forrás 0 (42. sor), de a diszform ág „kiválasztja” ρ_B-t (55. sor) | **[ELLENTMONDÁS]** a saját B7-ünkkel [FELTEVÉS: nincs teljesen újra levezetve]; nagyságrendje úgyis 10⁻⁴⁸ |
| 17 | V25 | 2026-10-27 (4abc740) | előjeljavítások, 4 komponensű BVP | – | – |
| 18 | V26 – step23–25 | 2026-10-28 (03dfbc0) | GW170817, lencsézés, Bullet, CMB | GW-korlát | **[HIBA]** F4 (+7·10⁻¹⁶) |
| 19 | V27 – step26 | 2026-10-29 (bf26b01) | `V27/step26_…_en.md` 97–102. sor; `hubble_desi_bao_test/tal_cosmology_common.py` 50–72. sor | A = e^{α_Yφ}, β_Yuk = 1/4π, **q = α_Y²β_Yuk**; G-szótár G_lab = G*(1+q), ξ = 0,926 | G-szótár [OK]; **[ELLENTMONDÁS]**: kvadratikus vs V23 lineáris; a kód a „B” olvasatot használja (F5, B3) |
| 20 | V28 – step27 | 2026-10-30/31 | `step27_yukawa_fixed_branch_test/step27_summary_hu.md` 5–12., 96–103. sor | fix ág: L = 10 km, α = 0,0796; „erős feszültség”, R ≈ 11–160 | [OK] (őszintén feltételes); az L = 10 km **[NEM LEVEZETETT]** |
| 21 | V28 szimulátor | 2026-10-31 | `simulator_v28/src/core.js` 415., 469–480. sor; `ui.js` 109. sor | geffRatio = 1+q(1+x)e^{−x} pontforrásra, korongra alkalmazva; alapértelmezésben L = 10 km | **[HIBA]**: a boost ≤ 1,08 a szükséges 2,7–4,3 helyett; kpc-es L_gal mellett α = 0,08 PPN-kizárt |
| 22 | step28 | – | nem található | – | – |
| 23 | step29 errata (saját) | 2026-11-01 (c75efda, helyi) | `errata/ERRATA_hu.md` | F1–F5 | lásd 4. fejezet |

---

## 2. Az örökölt mennyiségek nyomon követése

| Mennyiség | Eredet | Ellenőrzés (verify.json) | Jelölés |
|---|---|---|---|
| γ_L = GL²/c² | v1 Eq. (9)–(10) | Homogén gömb: \|Φ_felszín\| = (4π/3)GρL², \|Φ_centrum\| = 2πGρL². A γ_Lρ̄ ennek csak 0,239-szerese (C1). | **[HIBA]**: a konzisztens érték (4π/3)GL²/c² (felszín) vagy 2πGL²/c² (centrum). Maga a gondolat is hibás: ez a GR-potenciál, nem új hatás. |
| f_L·L_m a hatásban | v1 Eq. (11), step1 31–33. sor | Az R/16πG már tartalmazza Φ-t, az f_L a második példány. Univerzális konform csatolás ⇒ ötödik erő. | **[HIBA]** (kettős számolás) |
| α_Y = 1 | V23, step5 30. sor | A Yukawa-kernel integrálja L² (C2), így α_Y = 1 ⇔ γ_L. | [OK] a γ_L-hez képest, de **örökli** a C1 hibát. Ha a 4π/3 megmaradt volna, α_std = 1/3 (centrumban 1/2) lenne (C3b): még erősebben kizárt. |
| β_Yuk = 1/(4π) | V27 kód 66–72. sor („Since 4π β_Yuk = 1”) | visszafelé választva, hogy γ_L jöjjön ki | **[NEM LEVEZETETT]** |
| α = q = 1/(4π) = 0,0796 | V23 (lineáris) és V27 (kvadratikus) | α_Y = 1-nél egyezik; α_Y = 1/3-nál 0,0265 vs 0,00884 (C3) | **[ELLENTMONDÁS]** a konvenciók között |
| ω_BD | step2 58. sor, step5 57. sor | 1/(2α) − 3/2 = 4,783; α = 1/(12π) mellett 17,35; a step2 képletével 11,07 (C4) | step2: **[HIBA]** (F3) |
| L = 10 km | v1 109. sor („neutroncsillag 10km” mint L_avg-ablak), 145. sor („10km illusztr.”); V21 90. és 137. sor; V27/V28 | a v1 110–111. sora szerint L0 fix fundamentális állandó (1,2·10⁻¹¹ m) | **[NEM LEVEZETETT]** + **[ELLENTMONDÁS]** a v1-gyel |
| Laborjel | v1 Eq. (3) 115–118. sor, Eq. (13) 206. sor | Δρ̄ = 10⁴ kg/m³-hez L = 367 m-en 2,07·10¹² kg kellene. 10 t ólom: 4,8·10⁻²⁷ (L = 367 m), 1,8·10⁻²⁸ (10 km). A d ln f/dρ̄ előjele −γ (C6, C7). | **[HIBA]** |
| Óra = teljes potenciál | V23/step8 24. sor (H1 univerzális) | √(−g̃₀₀) = 1 + Φ/c² − φ (C5), ez ugyanaz a Φ_eff, ami a szabadesést hajtja | [OK] fizikailag, de akkor **nincs önálló órajel** (3.5) |
| G-szótár, ξ = 0,926 | step26 99–102. sor | 1/(1+q) = 0,92629 (C12) | **[OK]**; a kód viszont „B”-t használ: **[ELLENTMONDÁS]** (F5, B3) |
| Galaxis-boost | V28 `core.js` 415. sor | max 1+q = 1,0796 (C10) vs C_req = 2,72–4,31 (step6) | **[HIBA]** mint DM-magyarázat |
| Ötödik erő | – | α95(10 km) = 4,5·10⁻⁴ → 176,8-szoros kizárás (C11); masszív határeset: γ−1 = −0,147 (C9) | kizárt |

---

## 3. A törések bizonyítékokkal

### 3.1. LEGKORÁBBI KRITIKUS TÖRÉS – v1, 3.1. pont, Eq. (9)–(10) → Eq. (11)

`Time_Attraction.txt`, 158–164. sor:

> „Φ = −G_N ∫ ρ/|x − x′| d³x′, |Φ_L| ≈ GM/L = 4π/3 G_N ρ̄_L L² (9)
> f_L ≈ 1 + Φ_L/c² ≈ 1 − γ_L ρ̄_L ⇒ f_L = exp(−γ_L ρ̄_L) (10)”

186–191. sor:

> „S = ∫ d⁴x √−g [R/16πG_N + f_L(ρ̄_L) L_m] (11)
> G_µν = 8πG_N f_L T_µν …”

**Mi a hiba?**
1. Az Eq. (10) első lépése, f_L ≈ 1 + Φ_L/c², egyszerűen a **gyengetér-GR vöröseltolódás**. Az „idővonzás” tehát eredetileg a GR saját időlassulása.
2. A második lépésben (Φ_L/c² → −γ_Lρ̄_L) eltűnik a 4π/3 faktor. Helyesen γ_L = (4π/3)GL²/c² a felszínen, 2πGL²/c² a centrumban (C1).
3. Az Eq. (11) ezt a faktort **az R-tag mellé** teszi. A GR-időlassulás tehát kétszer szerepel: egyszer a metrikában, egyszer f_L-ként. A második példány ∇f_L-en keresztül **új erőt** ad a teljes anyagra.

**Miért kritikus?** Minden későbbi normálás ebből a γ_L-ből származik:
- step1 27. sor: „γ_L = GL²/c²”;
- step5 30. sor: „α_Y = 1 … visszaadja a homogén top-hat határesetet (φ_L = γ_Lρ_src)”;
- a V27 kód: `GAMMA_L = 4π β_Yuk G L²/c²`, „Since 4π β_Yuk = 1”.

Ezért lett a csatolás **gravitációs erősségű** (α = 1/4π). Ezt az α-t a 10 km-es ötödik-erő mérések kb. 177-szeres szorzóval kizárják. A 4π/3 megtartása sem segített volna: α = 1/3 lett volna.

**A javított változat.** Ha az Eq. (9)–(10)-et következetesen végigvisszük, f_L = e^{Φ/c²}. Ha f_L külön tényezőként megmarad az anyag hatásában (S_EH + f_L L_m), akkor Φ_eff = Φ + c² ln f_L = 2Φ, vagyis a kettős számolás megmarad, és ez kizárt. Csak ha f_L-t a g₀₀-ban már benne lévő órajárásként értelmezzük (nem külön tényezőként), esik egybe a GR-rel a statikus, gyenge tér első rendjében; ebben az olvasatban nincs új fizika. Új fizika csak akkor van, ha α és λ **szabad, a GR-től független** paraméterek. Ekkor a mérések korlátozzák őket (lásd 5. fejezet).

### 3.2. Másodlagos törés – a laborjóslat (v1 Eq. 3 és Eq. 13)

115–118. sor:

> „órák Δf/f < 10⁻¹⁸, Δρ̄ = 10⁴ … γ < 10⁻²², L = √(γc²/G_N) < 367m (3)”

206. sor:

> „Δf/f = γ_L Δρ̄ (13)”

- A Δρ̄ = 10⁴ kg/m³ egy laborban mozgatott tömeg lokális sűrűsége, nem az L sugarú gömbre vett átlag.
- L = 367 m-en ehhez 2,07·10¹² kg kellene (C7). Egy valódi 10 t-s tömeg jele 4,8·10⁻²⁷ (L = 367 m), illetve 1,8·10⁻²⁸ (10 km). Ez kisebb, mint ugyanannak a tömegnek a közönséges GR-vöröseltolódása 1 m-ről (7,4·10⁻²⁴).
- Eq. (13) előjele hibás (C6); ezt korábban a `movable_mass_clock_test/report_hu.md` is jelezte.
- Következmény: a V20 gránitkamra/tekercs és a Step 29 labor „H1-elvárása” sosem következett az elméletből. A tekercsjel ≤ 2,4·10⁻⁴⁸ (`solenoid_update/report_hu.md` 20. sor).

### 3.3. Másodlagos törés – L = 10 km eredete

- **v1 108–111. sor:** „Lavg: kísérleti ablak, szabad: labor 1m, **neutroncsillag 10km**, galaxis 1kpc. L0: fundamentális állandó… **Posztulátum L0 fix.**”; a 140. sor szerint „Favored 1.2×10⁻¹¹ m”.
- **v1 145. sor:** „10km illusztr.”. A v1 saját Eq. (3)-korlátja (L < 367 m) ezt már akkor kizárta volna.
- **V21 90. sor:** szkenpont; a 137. sor: „The largest shifts occur at L=10 km”.
- **V27/V28:** univerzális fix állandó.

**Jelölés: [NEM LEVEZETETT] + [ELLENTMONDÁS].** Az NS-specifikus *átlagolási ablakból* fundamentális hatótáv lett. Közben a v1 a hangolható L-ről azt írja (198. sor): „SEP: ha L hangolható ⇒ sérül”.

### 3.4. Másodlagos törés – a C(ρ) sötétanyag-ág (v8–v17)

- A v1 233–234. sora szerint „modell önmagában nem váltja ki sötét anyagot”.
- Ehhez képest:
  - v8.2 31. sor: „Using 150 SPARC galaxies … chi2 from 1231 to 159”, miközben a 106. sor szerint „mock 150-galaxy analysis”;
  - v14 4. sor: „Eliminating the Need for Dark Matter”;
  - v16 7. sor: „C0=5, rho_c=1e-23, L0=1 kpc”, kézzel választva.
- A refit (C0 = 2,776, χ²/pt ≈ 97) nem reprodukálja a v14.1-et (`docs/C_derivation_status.md`).
- A step6 (75–78. sor) később maga mondja ki, hogy a V23 hatás nem magyarázza a lapos forgási görbéket.
- A V28 szimulátor mégis tartalmaz galaxismodult (`core.js` 469–480. sor), amely a pontforrás-boostot kiterjedt korongra alkalmazza. A maximum 1,08.
- Explore módban L_gal = 0,1–300 kpc is választható. Ott α = 0,08 mellett γ_PPN − 1 = −0,147 adódik, ez Cassini-kizárt.

### 3.5. Másodlagos törés – H0/H1 (V23, step8)

- step8 24. sor: a H1 „univerzális diszform lapse- vagy konform Jordan-csatolás”. Univerzális csatolásnál az óra √(−g̃₀₀) = 1 + Φ/c² − φ (C5), vagyis **ugyanazt** a Φ_eff-et méri, ami a szabadesést hajtja.
  - Nincs tehát önálló órajel.
  - Minden H1-jel az α = 0,08-as ötödik erővel együtt jár, és azzal együtt kizárt.
- H0 (atomok g-n, a barionos anyag f²g-n): az atomok is barionokból állnak, így ez fajtafüggő csatolás, ami EP-sértés.
  - A step8 53. sora a H0-jelet „másodrendűnek (G²/c⁴)” mondja. Ez csak akkor igaz, ha az atomok tömege nem érzi φ-t.
- Saját B7 eredményünk (`open_items/disformal/…` 66. sor): „csak órához” csatolt H1 csak nem-univerzális csatolással lehetséges, az pedig EP-/LPI-sértő.

### 3.6. Másodlagos törés – konvenciók és kód

- **α_Y:** V23-ban α_std = α_Y/4π (lineáris); a V27/V28 kódban q = α_Y²β_Yuk (kvadratikus).
  - α_Y = 1-nél egyeznek.
  - Minden α_Y ≠ 1 állítás (például az „α_Y = 1/3 térfogatra illesztett” változat) konvenciófüggő: 0,0265 vs 0,00884.
- **step2 58. sor:** „2ω+3 = 1/α̃ = 1/(2β²)”. Helyesen 1/(2α̃) = 1/α_std, ω = 4,78 (F3-maradvány).
  - A step2 100. sora (β = √(α_std/2)) ellentmond az 58. sornak.
- **G-szótár:** a step26 99–102. sora helyes (ξ = 0,926), de a kód a CODATA G-t teszi G* helyére („B” olvasat).
- **step15:** a ρ_B mágneses forrás konform csatolásnál nulla (42. sor); a diszform „kiválasztás” (55. sor) ellentmond a B7-nek [FELTEVÉS]. A Step 29 laborra nézve irreleváns, mert a jel ~10⁻⁴⁸.

---

## 4. Az F1–F5 errata helye a láncban

| Errata | Hol ül | Gyökérok? |
|---|---|---|
| F1: a step2 Sirius B-tartománya | a H1 ág alsó része (V24 step2) | nem. A **„csak órákra ható” megfogalmazás saját félreképezés** (S2). |
| F2: Sirius B R = 0,00803 | adat-elírás (step8) | nem |
| F3: ω_BD = 4,78 / 17,35 | az α-normálás csomópontja (step2/step5) | nem, de a 2. fejezet α-konvenció-zűrzavarának tünete. Maradvány a step2 58. sorában. |
| F4: GW-korlát +7·10⁻¹⁶ | step23 (H1/diszform ág) | nem |
| F5: BBN G-szótár, ξ = 0,926 | step26; **az α = 0,0796 közvetlen következménye** | nem. Ez a gyökérhiba (3.1) **kozmológiai tünete**. |

---

## 5. Hogyan nézne ki egy javított elmélet?

1. **„A” – őszinte v1-olvasat:** f_L = e^{Φ/c²}, kettős számolás nélkül, vagyis f_L nem külön tényező az anyag hatásában, hanem a g₀₀-ban már benne lévő órajárás. Ez a gyenge tér első rendjében **a GR**: nincs új jel, nincs ötödik erő. (Ha f_L külön tényezőként megmarad, Φ_eff = 2Φ, és ez kizárt.) Kiszámolva: C1 és C5.
2. **„B” – szabad (α, λ) Yukawa-skalár, γ_L-normálás nélkül:**
   - Az α ≤ α95(λ) korlát az ISL/geofizika, a Cassini és a J1738 mérésekből jön.
   - α = 0,08 csak λ ≲ 72 µm-en maradhat; a hosszú hatótávú oldalon **nincs ablak** (S1, C9).
   - A gyenge csatolású refit (`weak_coupling_refit/`) szerint SPARC-on és DESI-n a járulék nullától megkülönböztethetetlen.
   - Nincs DM-magyarázat, nincs órára jellemző jel.
3. **„C” – csak sötét anyaghoz csatolt skalár (B8):** megengedett (α_DM < 0,0048), de semmi TAL-specifikus nem marad belőle: ξ = 1, az órák nem látnak semmit.
4. **„D” – órára jellemző jel nem-univerzális csatolással:** ez **nyitott és nincs kiszámolva**. Generikusan EP-sértő, így a MICROSCOPE és az Eöt-Wash korlátozza; a II-Conf ágat a B6 ~10⁶-szoros szorzóval kizárja.
5. **„E” – α_Y konvenció:** egyetlen definíciót kell rögzíteni (α ≡ G-erő-arány), és ezt a kódba és a dokumentumokba is be kell vezetni.

## 6. Az eredeti motiváció és a V28 konzisztenciája

| v1 motiváció | V28 | Konzisztens? |
|---|---|---|
| sűrűségfüggő időlassulás laborórákkal mérhető (Δf/f > 10⁻¹⁸) | labor/tekercs jel ≤ 10⁻²⁶ … 10⁻⁴⁸ | **nem** |
| L0 fix fundamentális állandó (1,2·10⁻¹¹ m favorizált); L_avg kísérletfüggő ablak | L = 10 km univerzális | **nem** |
| „nem váltja ki a sötét anyagot” | galaxismodul + Explore L_gal | **nem** (és a boost ≤ 1,08) |
| WEP OK, mert f_L anyagfüggetlen | univerzális csatolás ⇒ WEP OK, de ötödik erő | a WEP-állítás [OK]; az ISL-t a v1 nem vette figyelembe: **[HIBA]** |

---

## 7. Önaudit – a saját elemzéseink

| # | Hol | Mi a probléma | Hatás / javasolt javítás |
|---|---|---|---|
| S1 | `fifth_force_tests/docs/OTODIK_ERO_hu.md` 35., 251., 282. sor; `OSSZESITES_hu.md` 3. sor | „α = 0,08 mellett λ ≳ 1,5·10¹⁵ m nyitott”. Ez a csak ISL-ből álló kompiláció extrapolációja. Fényhez nem csatoló skalárra λ ≫ b esetén γ−1 = −2α/(1+α) = −0,147, míg Cassini \|γ−1\| < 2,3·10⁻⁵. | **[HIBA]**. Becslés (b = 1,6 R☉, egyskálás): α = 0,08 λ ≳ 1,3·10⁸ m-től kizárt (C9). A J1738 (sor 7) is kizárja L ≳ 1,5·10¹² m-en. **Nincs hosszú hatótávú ablak.** A végkövetkeztetés (V28 kizárt) nem változik. — **JAVÍTVA 2026-11-01, lásd 9. fejezet** |
| S2 | `optical_clock_tests/docs/OPTIKAI_ORAK_hu.md` 22., 170. sor; `galileo_reanalysis/docs/STEP6_hu.md` 9. sor; `further_tests/ep/docs/EKVIVALENCIA_ELV_hu.md` 7. sor; `errata/ERRATA_hu.md` 24. sor; `docs/clock_redshift_tests/README_hu.md` 63. sor | A „H1 = csak órákra ható” leképezés ellentmond a V23/step8 24. sorának (univerzális) és a B7-nek. Univerzális csatolásnál a geodéziai ΔU is tartalmazza a többletet, így az óra–geodézia összevetés jele 0. Az EP-dokumentum szerint „H1: EP-jel nincs”, a B7 szerint viszont a csak órához csatolt H1 fajtafüggő, tehát EP-sértő. | **[ELLENTMONDÁS]**. A H1-kizárási tartományok (14 km – 3,9·10⁷ m stb.) egy fenomenologikus, hatásból nem levezethető posztulátumra érvényesek. A „10 km-en H1 megengedett (1,4σ)” nem a V28 túlélése. — **JAVÍTVA 2026-11-01, lásd 9. fejezet** |
| S3 | `OPTIKAI_ORAK_hu.md` 22. sor és más α_Y = 1/3-skálázások | A lineáris (V23) konvenciót használtuk; V28 kvadratikus konvencióval a hatás 1/3 helyett 1/9. | címkézni kell; a következtetést nem változtatja meg — **JAVÍTVA 2026-11-01, lásd 9. fejezet** |
| S4 | `weak_coupling_refit/` (és a V28) | pontforrás-G_eff kiterjedt korongra (örökölt közelítés) | a következtetés robusztus (α ≤ α95, a jel ≪ hiba); a DM-only ág egzakt héjkernelt használ |
| S5 | `OSSZESITES_hu.md` 9. sor | BBN-proxy 2,5σ, a teljes futás (B1) 5σ | már jelezve; [OK] |
| S6 | G-szótár (B3), DEF ω (F3), BBN (F5), DM-only (B8) | újraellenőrizve: ξ = 0,92629, ω = 4,783, α0² = α_std | [OK] |

Az audit eredetileg nem módosított fájlt. David jóváhagyása után (2026-11-01 21:35) az S1–S3 javításait bevezettük; lásd a 9. fejezetet (Javítási napló). Az S4 nem igényelt javítást.

---

## 8. Függőségi diagram

![függőségi diagram](../results/plots/fuggosegi_diagram.png)

```mermaid
graph TD
  GR["GR redshift Φ≈−(4π/3)GρL²"] --> V1["v1 Eq.9–10: γ_L=GL²/c² [HIBA: 4π/3 elhagyva, GR átcímkézve]"]
  V1 --> ACT["v1 Eq.11: R/16πG + f_L L_m [HIBA: kettős számolás → ötödik erő]"]
  V1 --> LAB["v1 Eq.3/13: L<367 m, +γΔρ̄ [HIBA]"]
  V1 --> L10["L: '10 km illusztr.' → V21 szken → V28 fix [NEM LEV.]"]
  ACT --> C["v8–v17 C(ρ) DM [NEM LEV., ellentmond v1-nek]"]
  ACT --> V23["V23 Branch II: α_Y=1 ⇔ γ_L"]
  L10 --> V23
  V23 --> A["α=1/(4π)=0,0796"]
  V23 --> H["H0/H1 [ELLENTMONDÁS]"]
  A --> CONV["V27/V28 q=α_Y²β vs V23 α_Y/4π [ELLENTMONDÁS]"]
  A --> ISL["ötödik erő 176× kizárt; Cassini; BBN ξ=0,926 (F5)"]
  A --> GAL["V28 galaxis boost ≤1,08 vs 2,7–4,3 [HIBA]"]
  C --> GAL
  H --> S29["Step 29 labor: jel ≤1e−26…1e−48"]
  LAB --> S29
  A --> F3["step2 ω_BD (F3)"]
  H --> F1["F1 Sirius B / F2 / F4 GW"]
  ISL --> FIX["Javított út: α≤α95(λ) vagy λ≲72 µm; nincs DM, nincs órajel"]
  GAL --> FIX
  S29 --> FIX
```

## 9. Javítási napló (S1–S3, 2026-11-01, Europe/Zurich)

Minden szerkesztés előtt `*.pre_audit` biztonsági másolat készült ugyanabban a mappában. A TAL forrásanyagait (V2x, `scalar-tensor-yukawa-fit/`, `academia_v26/`) **nem érintettük**. Semmit nem küldtünk el, nem töltöttünk fel és nem publikáltunk. Gépi napló a pontos régi és új szövegekkel: `audit/results/s3/fix_log.json`. Szkriptek: `audit/code/apply_s1_s3_fixes.py`, `audit/code/apply_tex_fixes.py`, `audit/code/s3_quadratic.py`.

### S1 – a hosszú hatótávú ablak (Cassini γ_PPN)
| Fájl | Régi → új |
|---|---|
| `fifth_force_tests/code/run_fifth_force.py` | nincs Cassini-ellenőrzés → minden variánshoz `cassini_ppn_excluded_if_lambda_above_m_estimate`, `long_window_open = False`, `cassini_ppn_estimate` blokk; az ábrán kék Cassini-sáv |
| `fifth_force_tests/results/fifth_force_results.json`, `run_log.txt`, `exclusion_alpha_lambda.png` (újrafuttatva) | hosszú ablak „λ ≳ 1,5·10¹⁵ m” → nincs hosszú ablak. Cassini-él (saját egyskálás becslés, \|γ−1\| < 2,3·10⁻⁵, b = 1,6 R☉): α = 0,0796 → λ ≳ 1,26·10⁸ m kizárt; α = 0,0265 → 1,44·10⁸ m; α = 0,00884 → 1,68·10⁸ m. A többi kulcs és az `alpha95_vs_lambda_own.csv` változatlan |
| `fifth_force_tests/docs/OTODIK_ERO_hu.md` (0. fejezet, ablak-tábla, 6. fenntartás, fájllista) | „csak λ ≲ 72 µm vagy λ ≳ 1,5·10¹⁵ m nyitott” → „csak λ ≲ 72 µm nyitott”, a Cassini-élekkel |
| `further_tests/docs/OSSZESITES_hu.md` 3. sor | „λ ≲ 72 µm vagy λ ≳ 1,5·10¹⁵ m nyitott” → „csak λ ≲ 72 µm nyitott (Cassini: λ ≳ ~1,3·10⁸ m kizárt, saját becslés)” |

### S2 – a H1 „csak órákra ható” megfogalmazása
Egységes új szöveg (Audit-megjegyzés S2): a step8 H1 univerzális; a „csak óra” olvasat a hatásból nem levezethető posztulátum (B7); a H1-kizárások csak erre a posztulátumra érvényesek; a „H1 L = 10 km-en megengedett” nem jelenti a V28 túlélését.
| Fájl | Régi → új |
|---|---|
| `further_tests/docs/OSSZESITES_hu.md` | fejléc, 1., 2. és 6. sor, Összkép: „H1 órajel-csatolás … megengedett”, „L = 10 km-en a H1 megengedett” → „„csak óra” H1-posztulátum … megengedett; ez nem jelenti a V28 túlélését (3. sor: ~176× kizárt)” + S2 megjegyzés |
| `optical_clock_tests/docs/OPTIKAI_ORAK_hu.md` | 0. fejezet: S2/S3 megjegyzés; „Az L = 10 km nincs kizárva” → „a „csak óra” posztulátumban nincs kizárva”; 1. fejezet II. formuláció; 7. feltevés: + „univerzális H1-nél e teszt jele 0” |
| `galileo_reanalysis/docs/STEP6_hu.md` | 0. fejezet S2/S3 megjegyzés; „csak órák” / „csak az órákra ható olvasat” → „„csak óra” posztulátum (B7)” |
| `galileo_reanalysis/docs/OSSZEFOGLALO_hu.md` | eredménylista + 6. pont: S2 megjegyzés |
| `galileo_reanalysis/export/tex/report.tex` → PDF | címlap: „csak az órákra ható H1 hipotézist” → „a H1 hipotézis csak az órákra ható olvasatát”; Kivonat: keretes értelmezési megjegyzés; Motiváció: „a H1 univerzális, ennek „csak óra” olvasatát vizsgáljuk (posztulátum)”; kizárási tábla alatti megjegyzés; L = 10 km pont: „nem jelenti a V28 túlélését” |
| `galileo_reanalysis/export/README_hu.md` | + S2 bekezdés a fő eredményeknél |
| `further_tests/ep/docs/EKVIVALENCIA_ELV_hu.md` 7. sor | „csak az órák és fotonok frekvenciáját érinti, a szabadesést nem. EP-jel nincs.” → „step8: univerzális; η = 0, de a teljes ötödik erő jelen van; a „csak óra” olvasat posztulátum, és B7 szerint generikusan EP-jelet ad” |
| `errata/ERRATA_hu.md` (F1 hatás) | „A H1 (csak órákra ható csatolás) L=10 km-en nincs kizárva.” → + „ez posztulátum; nem jelenti a V28 túlélését” |
| `docs/clock_redshift_tests/README_hu.md` | (a) eset címe + Összegzés: S2 kiegészítés |
| `further_tests/wd_redshift/docs/FEHER_TORPE_hu.md`, `open_items/wd_catalogs/docs/WD_katalogus_H1_hu.md` | S2 megjegyzés; „V28, L = 10 km: megengedett” → „V28, L = 10 km („csak óra” posztulátum): megengedett” |
| `docs/clock_redshift_tests/clock_redshift_tal_h1.py`, `open_items/wd_catalogs/code/wd_catalog_h1.py` | csak docstring: „clock-only reading” → „clock-only reading = POSTULATE … (audit S2)”. Logika változatlan |

### S3 – az α_Y = 1/3 konvenció
Lineáris (V23): a jel ∝ α_Y → α_Y = 1 eredmény × 1/3, telítés 0,0265. Kvadratikus (V27/V28): a jel ∝ α_Y² → × 1/9, telítés 0,00884. Az új számok a meglévő α_Y = 1 sablonok 1/9-es skálázásával és ugyanazzal a likelihooddal készültek (`audit/results/s3/s3_quadratic.json`); a lineáris ellenőrzés a tárolt értékeket reprodukálja.
| Fájl | Mennyiség | Lineáris (eddigi) | Kvadratikus (új) |
|---|---|---|---|
| `OPTIKAI_ORAK_hu.md` | α_eff(Skytree, 10 km) | 3,05·10⁻⁵ | 1,02·10⁻⁵ |
| | feszültség 10 km-en | 0,18σ | −0,04σ |
| | kombinált 95%-os alsó él (DEM) | 51,18 km | 140,5 km |
| | egyoldali z > 1,645 él | 44,25 km | 120,0 km |
| | ACES-projekcióval, 10 km | 0,36σ | 0,05σ |
| `STEP6_hu.md`, `OSSZEFOGLALO_hu.md`, `report.tex`, export `README_hu.md` | Galileo 95%-os él (végső / konzerv. / E14) | 3 262 / 3 518 / 3 320 km | ≳ 3 910 / 4 280 / 4 000 km (rács-interpoláció, ±0,2%) |
| | telítés / 95%-os felső korlát | 0,0265 (~320×) | 0,00884 (~105×) |
| `STEP6_hu.md` 96. sor, `docs/clock_redshift_tests/README_hu.md` | Skytree-él | ≳ 53 km | ≳ 145 km (DEM) |
| `clock_redshift_tal_h1.py` docstring | konvenció-címke | – | „LINEAR V23 convention” |

**Következtetés-változás: nincs.** Az alsó élek ~2,7–2,8×-esen feljebb kerülnek; a nagy L továbbra is kizárt (0,00884 ≫ 8,4·10⁻⁵); a „csak óra” H1 L = 10 km-en továbbra sem tesztelhető. A `fifth_force_tests` már eddig is mindkét konvenciót megadta.

### A Galileo-csomag (Akadémia) változásai
| Fájl | Állapot |
|---|---|
| `galileo_reanalysis/export/TAL_Galileo56_H1_ujraelemzes_hu.pdf` | **újragenerálva** (XeLaTeX, 11 oldal, hibamentes, overfull nélkül); régi: `….pdf.pre_audit` |
| `galileo_reanalysis/export/TAL_Galileo56_H1_csomag.zip` | **újracsomagolva** (108 fájl): új PDF, `report_tex/report.tex`, `README_hu.md`, `docs/STEP6_hu.md`, `docs/OSSZEFOGLALO_hu.md`, `tal_reference/README_hu.md`, `tal_reference/clock_redshift_tal_h1.py`; `SHA256SUMS` frissítve (7 hash), `sha256sum -c` OK; régi: `….zip.pre_audit` |
| `galileo_reanalysis/export/preview_p-01.png`, `preview_p-05.png`, `tex/report.pdf` | újragenerálva; régiek: `*.pre_audit` |

