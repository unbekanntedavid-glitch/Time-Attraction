import os, shutil, json
LAB='/workspace/artifacts/tal-step29-lab'; F='galileo_reanalysis/export/tex/report.tex'; p=f'{LAB}/{F}'
LOGP=f'{LAB}/audit/results/s3/fix_log.json'; LOG=json.load(open(LOGP))
t=open(p,encoding='utf-8').read()
if not os.path.exists(p+'.pre_audit'): shutil.copy2(p,p+'.pre_audit')
E=[
(r"""megfogalmazott, csak az órákra ható H1 hipotézist (\(\Delta y_{\mathrm{H1}} \approx -\varphi_L\)) vetjük össze""",
 r"""megfogalmazott H1 hipotézis csak az órákra ható olvasatát (\(\Delta y_{\mathrm{H1}} \approx -\varphi_L\)) vetjük össze""",'S2 title page'),
(r"""95\%-os szinten kizárjuk a top-hat formulációt $17\,211\ \mathrm{km}\le L\le 38\,735\ \mathrm{km}$ között, a csak órákra ható
árnyékolt Yukawa-formulációt pedig $L\ge 2\,795$\,km-re ($\alpha_Y=1$), illetve $L\ge 3\,262$\,km-re ($\alpha_Y=1/3$).""",
 r"""95\%-os szinten kizárjuk a top-hat formulációt $17\,211\ \mathrm{km}\le L\le 38\,735\ \mathrm{km}$ között, a csak órákra ható
árnyékolt Yukawa-formulációt pedig $L\ge 2\,795$\,km-re ($\alpha_Y=1$), illetve $L\ge 3\,262$\,km-re ($\alpha_Y=1/3$, lineáris konvenció;
a V27/V28 kvadratikus konvenciójában $L\gtrsim 3\,910$\,km).""",'S3 abstract'),
(r"""Ez a pont nyitott marad. A V28 univerzális csatolású ága óratesztekben definíció szerint $\alpha=0$-t ad.""",
 r"""Ez a pont nyitott marad. A V28 univerzális csatolású ága óratesztekben definíció szerint $\alpha=0$-t ad.

\medskip\noindent\fbox{\parbox{0.96\linewidth}{\small\textbf{Fontos értelmezési megjegyzés (2026.\ 11.\ 1-i javítás).}
A TAL 8. lépésében a H1 \emph{univerzális} csatolásként van definiálva. Univerzális csatolásnál az óra ugyanazt a potenciált
($\Phi/c^2-\varphi$) méri, amely a szabadesést is hajtja, így önálló órajel nincs. A jel ekkor az $\alpha\approx0{,}08$-os
ötödik erővel jár együtt, amelyet a laboratóriumi és geofizikai tesztek $L=10$\,km-en mintegy 176-szorosan kizárnak.
Az itt tesztelt ,,csak az órákra ható'' olvasat a hatásból nem vezethető le; csak nem-univerzális (fajtafüggő) csatolással,
azaz ekvivalenciaelv-sértéssel valósítható meg. Ezért posztulátumnak tekintjük. A dolgozat kizárásai \emph{csak erre a posztulátumra}
érvényesek. Az, hogy $L=10$\,km itt nyitott, \emph{nem} jelenti azt, hogy a V28 túlél.}}""",'S2 abstract box'),
(r"""A TAL keretrendszer 8. lépésének feltételes H1 hipotézise szerint az órák egy további, $L$ skálájú tagot éreznek:""",
 r"""A TAL keretrendszer 8. lépésének feltételes H1 hipotézise univerzális csatolás. Az alábbiakban annak ,,csak az órákra ható''
olvasatát vizsgáljuk (posztulátum, lásd a Kivonat megjegyzését), amely szerint az órák egy további, $L$ skálájú tagot éreznek,
miközben a geodéziai és a pályából meghatározott potenciál változatlan:""",'S2 motivation'),
(r"""Az $\alpha_Y=1$ az egységkernel (a V28 rögzített ága), az $\alpha_Y=1/3$ a térfogatra illesztett változat.""",
 r"""Az $\alpha_Y=1$ az egységkernel (a V28 rögzített ága), az $\alpha_Y=1/3$ a térfogatra illesztett változat.
Az $\alpha_Y=1/3$ számokat a \emph{lineáris} (V23) konvencióban adjuk: a jel $\propto\alpha_Y$, tehát az $\alpha_Y=1$ eredmény harmada.
A V27/V28 kód \emph{kvadratikus} konvenciójában ($q=\alpha_Y^2\beta$, órafaktor $e^{\alpha_Y\varphi}$) a jel $\propto\alpha_Y^2$, tehát kilencede;
ahol számít, ezt az értéket is megadjuk.""",'S3 definition'),
(r"""II. Yukawa $\alpha_Y=1/3$ & $\ge3\,262$ km & $\ge3\,518$ km & $\ge3\,236$ km & –\\\bottomrule
\end{tabular}\end{table}""",
 r"""II. Yukawa $\alpha_Y=1/3$ (lin.) & $\ge3\,262$ km & $\ge3\,518$ km & $\ge3\,236$ km & –\\
II. Yukawa $\alpha_Y=1/3$ (kvadr.) & $\gtrsim3\,910$ km & $\gtrsim4\,280$ km & – & –\\\bottomrule
\end{tabular}\end{table}
{\small A kizárások a ,,csak az órákra ható'' H1-olvasatra vonatkoznak (lásd a Kivonat megjegyzését). Lin.: lineáris (V23) konvenció;
kvadr.: kvadratikus (V27/V28) konvenció, a sablon rács-interpolációjával ($\pm0{,}2\%$).}""",'S2+S3 table'),
(r"""(0,0795, ill.\ 0,0265)""", r"""(0,0795, ill.\ 0,0265 a lineáris, 0,00884 a kvadratikus konvencióban $\alpha_Y=1/3$-ra)""",'S3 saturation'),
(r"""\textbf{A Galileo erről a pontról nem mond semmit; a pont nyitott marad.}""",
 r"""\textbf{A Galileo erről a pontról nem mond semmit; a pont nyitott marad} (a ,,csak óra'' olvasatban; ez nem jelenti a V28 túlélését).""",'S2 L=10km'),
]
for old,new,note in E:
    assert t.count(old)==1,(note,t.count(old)); t=t.replace(old,new); LOG.append(dict(file=F,item=note,old=old,new=new))
open(p,'w',encoding='utf-8').write(t); json.dump(LOG,open(LOGP,'w'),ensure_ascii=False,indent=1); print('ok',len(E))
