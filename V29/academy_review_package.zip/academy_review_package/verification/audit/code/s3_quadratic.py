"""Audit S3: alpha_Y = 1/3 under the V27/V28 QUADRATIC convention.
V23/Step5 (linear):  clock/potential shift  ∝ alpha_Y      -> alpha_Y=1/3 = 1/3 x (alpha_Y=1)  (what our analyses used)
V27/V28 (quadratic): phi ∝ alpha_Y*beta, clock factor e^{alpha_Y phi} -> shift ∝ alpha_Y^2 beta -> alpha_Y=1/3 = 1/9 x (alpha_Y=1)
We rescale the stored alpha_Y=1 templates by 1/9 and re-apply the SAME likelihood/exclusion criteria as the original scripts.
No original result file is modified; output -> audit/results/s3/."""
import os, json, math, numpy as np, pandas as pd
LAB = '/workspace/artifacts/tal-step29-lab'; OUT = f'{LAB}/audit/results/s3'; SC9 = 1/9
res = {}
# ---------------- optical clocks: reuse definitions of analyze.py (lines 1-64 only define functions / load data)
src = open(f'{LAB}/optical_clock_tests/code/analyze.py').read().splitlines()
ns = {'__file__': f'{LAB}/optical_clock_tests/code/analyze.py'}
exec('\n'.join(src[:64]), ns)
GRID, combine, intervals, curves, SETS, Z95 = ns['GRID'], ns['combine'], ns['intervals'], ns['curves'], ns['SETS'], ns['Z95']
i10 = np.argmin(abs(GRID - 1e4))
def scaled(form, s, variant='dem'):
    return {k: (e * s, a, sg) for k, (e, a, sg) in curves(form, variant).items()}
opt = {}
for lab, form, s in (('linear_check_aY1/3 (=1/3 x aY1)', 'II_yukawa_aY1', 1/3), ('quadratic_aY1/3 (=1/9 x aY1)', 'II_yukawa_aY1', SC9)):
    for variant in ('dem', 'sphere'):
        c = scaled(form, s, variant); d = {}
        for name in ('Skytree2020', 'ground_all', 'GP-A1976', 'Galileo5/6(Step5)', 'COMBINED(ground+GP-A+Galileo)', '+ACES(PROJ)'):
            Ah, sA, z, dchi = combine(c, SETS[name])
            iv = intervals(z); iv1 = intervals(z, 1.644854)
            d[name] = dict(alpha_eff_10km=float(c['Skytree2020'][0][i10]) if name == 'Skytree2020' else None, z_10km=float(z[i10]),
                           excl95_two_sided=[[float(a) if not isinstance(a, str) else a for a in x] for x in iv],
                           excl95_one_sided=[[float(a) if not isinstance(a, str) else a for a in x] for x in iv1])
        opt[f'{lab}|{variant}'] = d
res['optical_clocks'] = opt
# ---------------- Galileo step6: same interval test (FINAL / CONSERVATIVE / E14only posterior 95% intervals)
S6 = f'{LAB}/galileo_reanalysis/results/step6'; SCN = pd.read_csv(f'{S6}/tal_h1_alpha_eff_scan.csv'); SUM = json.load(open(f'{S6}/step6_summary.json'))
g1 = SCN[SCN.formulation == 'II_yukawa_aY1'].sort_values('L_m')
gal = {}
for lab, s in (('linear_check_aY1/3', 1/3), ('quadratic_aY1/3', SC9)):
    d = {}
    for k, col in (('FINAL', 'alpha_eff'), ('CONSERVATIVE', 'alpha_eff'), ('E14only', 'alpha_eff_E14kernel')):
        lo, hi = SUM['intervals95'][k]; a = g1[col].values * s; L = g1.L_m.values; ex = (a < lo) | (a > hi)
        # first excluded L: log-linear interpolation of a(L) crossing hi
        j = int(np.argmax(ex)); 
        if ex.any() and j > 0:
            x0, x1 = math.log10(L[j-1]), math.log10(L[j]); f = (hi - a[j-1]) / (a[j] - a[j-1]); Lmin = 10**(x0 + f*(x1 - x0))
        else: Lmin = None
        d[k] = dict(L_min_excluded_m=Lmin, all_excluded_above=bool(ex[j:].all()) if ex.any() else None,
                    alpha_eff_10km=float(np.interp(4, np.log10(L), a)), alpha_eff_max=float(a.max()), interval95=[lo, hi])
    gal[lab] = d
res['galileo_step6'] = gal
res['galileo_original_aY1/3_edges_for_reference'] = [e for e in SUM['edges'] if e['formulation'] == 'II_yukawa_aY1/3']
# ---------------- clock README (older spherical scan): Skytree / GP-A / Galileo lower edges, 2 sigma
OLD = pd.read_csv(f'{LAB}/docs/clock_redshift_tests/clock_redshift_tal_h1_scan.csv')
old = {}
for lab, s in (('linear_check_aY1/3', 1/3), ('quadratic_aY1/3', SC9)):
    d = {}
    for exp in OLD.experiment.unique():
        t = OLD[(OLD.formulation == 'II_yukawa_aY1') & (OLD.experiment == exp)].sort_values('L_m')
        a = t.alpha_eff.values * s; ex = np.abs(a - t.alpha_mu.values) > 2 * t.alpha_sigma.values
        d[exp] = dict(first_excluded_L_m=float(t.L_m.values[np.argmax(ex)]) if ex.any() else None)
    old[lab] = d
res['clock_readme_scan_grid_resolution'] = old
res['convention_values'] = {'alpha_std_linear_aY1/3': 1/(12*math.pi), 'alpha_quadratic_aY1/3': 1/(36*math.pi)}
os.makedirs(OUT, exist_ok=True); json.dump(res, open(f'{OUT}/s3_quadratic.json', 'w'), indent=1, default=str)
print(json.dumps(res, indent=1, default=str))
