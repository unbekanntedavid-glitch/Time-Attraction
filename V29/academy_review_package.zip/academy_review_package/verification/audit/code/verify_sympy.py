"""TAL forensic audit: symbolic + numeric spot checks. Output: ../results/verify.json"""
import json, math, sympy as sp
from pathlib import Path
G=6.67430e-11; c=299792458.0; Rsun=6.957e8
out={}
r,Lr,rho,M,R,phi,Phi,cc,a,x=sp.symbols('r L rho M R phi Phi c alpha x',positive=True)

# C1: v1 Eq.(9)-(10): uniform sphere radius L, potential at surface and centre vs gamma_L*rho*c^2 = G L^2 rho
Ms=sp.Rational(4,3)*sp.pi*rho*Lr**3
Phi_surf=-sp.Symbol('G')*Ms/Lr; Phi_cent=sp.Rational(3,2)*Phi_surf
gL_rho=sp.Symbol('G')*Lr**2*rho
out['C1_v1_eq9_10']={'|Phi_surface|/(G rho L^2)':str(sp.simplify(-Phi_surf/gL_rho)),
 '|Phi_centre|/(G rho L^2)':str(sp.simplify(-Phi_cent/gL_rho)),
 'gamma_L*rho/(|Phi_surf|/c^2)':float(1/(4*math.pi/3)),
 'verdict':'Eq.(10) drops 4pi/3 (surface) or 2pi (centre); f_L is the GR potential relabelled'}

# C2: Yukawa kernel normalisation
rr=sp.symbols('rr',positive=True)
kern=sp.integrate(4*sp.pi*rr**2*sp.exp(-rr/Lr)/(4*sp.pi*rr),(rr,0,sp.oo))
out['C2_yukawa_kernel_integral']=str(kern)

# C3: alpha conventions
aY=sp.symbols('alpha_Y',positive=True)
V23=aY/(4*sp.pi); V28=aY**2/(4*sp.pi)
out['C3_alpha_conventions']={str(v):{'V23_linear':float(V23.subs(aY,v)),'V28_quadratic':float(V28.subs(aY,v))} for v in [1,sp.Rational(1,3)]}
# what alpha would follow if the 4pi/3 or 2pi factor had been kept: alpha_Y = gamma c^2/(G L^2)
out['C3b_alpha_if_factor_kept']={'surface 4pi/3 -> alpha_std':float((4*math.pi/3)/(4*math.pi)),'centre 2pi -> alpha_std':float(2*math.pi/(4*math.pi))}

# C4: DEF / Brans-Dicke
w=lambda al:1/(2*al)-1.5
out['C4_omega_BD']={'alpha=1/4pi':w(1/(4*math.pi)),'alpha=1/12pi':w(1/(12*math.pi)),'step2_l58_wrong_1/(2b^2)=1/alpha_tilde gives':1/(1/(8*math.pi))/2-1.5}

# C5: conformal coupling -> clocks and test masses see the same Phi_eff
f=sp.exp(-phi)
g00=-(f**2)*(1+2*Phi/cc**2)
clock=sp.series(sp.sqrt(-g00),phi,0,2).removeO()
clock=sp.series(clock,Phi,0,2).removeO()
out['C5_clock_rate_first_order']=str(sp.expand(clock).subs(phi*Phi,0))
out['C5_note']='sqrt(-g~00) = 1 + Phi/c^2 - phi to first order: Phi_eff = Phi - c^2 phi = same potential that drives free fall (Newtonian limit of g~). No clock-only signal under universal coupling.'

# C6: v1 Eq.(13) sign
out['C6_eq13_sign']=str(sp.diff(sp.log(sp.exp(-sp.Symbol('gamma')*rho)),rho))+' * Delta rho  (v1 writes +gamma*Delta rho)'

# C7: v1 Eq.(3) bound: mass needed for Delta rho_bar = 1e4 over L = 367 m; signal of real 1 t / 10 t masses
L367=sp.N(sp.sqrt(1e-22*c**2/G))
need=1e4*4/3*math.pi*float(L367)**3
def sig(Mkg,L): return 3*G*Mkg/(4*math.pi*c**2*L)
out['C7_eq3']={'L_from_gamma_1e-22_m':float(L367),'mass_needed_kg':need,
 'signal_10t_lead_L=367m':sig(1e4,float(L367)),'signal_10t_L=10km':sig(1e4,1e4),
 'GR_redshift_10t_at_1m':G*1e4/c**2}

# C8: gamma_L(10 km), NS example
gl=G*1e8/c**2
out['C8_gammaL_10km']={'gamma_L':gl,'gamma_rho_NS_4e17':gl*4e17}

# C9: PPN massless and Cassini window (estimate, b = 1.6 Rsun, single-scale)
q=1/(4*math.pi)
out['C9_ppn']={'gamma-1 (lambda>>r)':-2*q/(1+q),'Cassini |gamma-1|<2.3e-5 -> alpha<':2.3e-5/2}
b=1.6*Rsun; lam=b/math.log(2*q/2.3e-5)
out['C9_cassini_lambda_edge_estimate_m']=lam
out['C9_note']='[BECSLES] alpha=0.08 excluded by Cassini for lambda >~ 1e8 m, so "lambda >~ 1.5e15 m open" (fifth_force_tests) is wrong for a scalar that does not couple to light'

# C10: V28 galaxy boost
xs=[i/1000 for i in range(0,20001)]
out['C10_V28_boost_max']=max(1+q*(1+t)*math.exp(-t) for t in xs)
out['C10_step6_Creq_NGC3198']=[2.720,4.311]

# C11: fifth force ratio
ff=json.load(open('/workspace/artifacts/tal-step29-lab/fifth_force_tests/results/fifth_force_results.json'))
out['C11_fifth_force_json_keys']=list(ff.keys())[:20]
out['C11_alpha95_10km_vs_q']={'q':q,'alpha95':4.5e-4,'ratio':q/4.5e-4}

# C12: G-dictionary
out['C12_xi']=1/(1+q)
p=Path(__file__).resolve().parents[1]/'results'/'verify.json'
p.write_text(json.dumps(out,indent=1,default=str)); print(json.dumps(out,indent=1,default=str))
