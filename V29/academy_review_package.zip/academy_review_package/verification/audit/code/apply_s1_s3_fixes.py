"""Apply audit S1-S3 text fixes to OUR analysis docs. Backups *.pre_audit; log -> audit/results/s3/fix_log.json"""
import os, shutil, json
LAB = '/workspace/artifacts/tal-step29-lab'; LOG = []
def rep(rel, old, new, note):
    p = f'{LAB}/{rel}'; t = open(p, encoding='utf-8').read()
    n = t.count(old); assert n == 1, (rel, n, old[:80])
    if not os.path.exists(p + '.pre_audit'): shutil.copy2(p, p + '.pre_audit')
    open(p, 'w', encoding='utf-8').write(t.replace(old, new)); LOG.append(dict(file=rel, item=note, old=old, new=new))

NOTE = ("> **Audit-megjegyzés (S2, 2026-11-01).** A H1 a TAL step8 (24. sor) definíciója szerint **univerzális** csatolás. "
        "Univerzális csatolásnál az óra ugyanazt a potenciált (Φ/c² − φ) méri, amely a szabadesést is hajtja, így önálló órajel nincs; "
        "a jel az α = 0,0796-os ötödik erővel jár együtt, amely 10 km-en ~176×-osan kizárt. "
        "Az itt tesztelt „csak az órákra ható” olvasat (Δy_H1 ≈ −φ_L, a geodéziai/szabadesési potenciál változatlan) "
        "**a hatásból nem levezethető posztulátum** (B7: csak nem-univerzális, fajtafüggő, EP-sértő csatolással valósítható meg; "
        "`open_items/disformal/docs/DISZFORMALIS_levezetes_hu.md`). Az itt kapott H1-kizárási tartományok **csak erre a posztulátumra** érvényesek; "
        "a „H1 L = 10 km-en megengedett” állítás **nem jelenti a V28 túlélését**. Részletek: `audit/docs/AUDIT_hu.md`.\n")
S3NOTE = ("> **Audit-megjegyzés (S3, α_Y-konvenció).** Az α_Y = 1/3 számok a **lineáris (V23/step5) konvencióban** készültek: "
          "a jel ∝ α_Y, tehát az α_Y = 1 eredmény harmada (telítés α_Y/(4π) = 0,0265). A V27/V28 kód **kvadratikus konvenciójában** "
          "(q = α_Y²β, órafaktor e^{α_Y φ}, φ ∝ α_Y β) a jel ∝ α_Y², tehát az α_Y = 1 eredmény kilencede (telítés 0,00884). "
          "A kvadratikus értékeket zárójelben, „kvadr.” jelöléssel adjuk; forrás: `audit/code/s3_quadratic.py` → `audit/results/s3/s3_quadratic.json`. "
          "A következtetések nem változnak: az alsó kizárási élek feljebb kerülnek, a telítési érték (0,00884) a 95%-os korlát fölött marad, az L = 10 km nem tesztelhető/nem kizárt.\n")

# ---------------- S1 + S2: OSSZESITES
F = 'further_tests/docs/OSSZESITES_hu.md'
rep(F, 'H1: diszformális órajel-csatolás, g̃₀₀ = −f_L².*',
    'H1: diszformális órajel-csatolás, g̃₀₀ = −f_L²; a step8 szerint univerzális — a H1-oszlopokban tesztelt „csak óra” olvasat a hatásból nem levezethető posztulátum (B7, audit S2).*\n\n' + NOTE.rstrip('\n'), 'S2 header')
rep(F, 'α = 0,08 mellett csak λ ≲ 72 µm vagy λ ≳ 1,5·10¹⁵ m nyitott',
    'α = 0,08 mellett csak λ ≲ 72 µm nyitott (a korábbi „λ ≳ 1,5·10¹⁵ m” hosszú ablakot a Cassini γ_PPN zárja: saját egyskálás becslés, λ ≳ ~1,3·10⁸ m kizárt; audit S1)', 'S1 row 3')
rep(F, '| megengedett (H1-jel elhanyagolható) | H1 top-hat kizárt 17 211–38 735 km; Yukawa α_Y = 1: L ≥ 2 795 km |',
    '| megengedett (H1-jel elhanyagolható) — csak a „csak óra” posztulátumra; a V28-at a 3. sor kizárja | „csak óra” H1: top-hat kizárt 17 211–38 735 km; Yukawa α_Y = 1: L ≥ 2 795 km |', 'S2 row 1')
rep(F, '| **megengedett** (1,4σ) | top-hat kizárt 13,93 km – 38 891 km; Yukawa ≥ 19,5 km |',
    '| **megengedett** (1,4σ) — csak a „csak óra” posztulátumra; univerzális csatolásnál a teszt jele 0, a V28-at a 3. sor kizárja | „csak óra” H1: top-hat kizárt 13,93 km – 38 891 km; Yukawa α_Y = 1 ≥ 19,5 km |', 'S2 row 2')
rep(F, '| **megengedett, nem tesztelhető** | H1 top-hat',
    '| **megengedett, nem tesztelhető** (csak a „csak óra” posztulátumra) | „csak óra” H1: top-hat', 'S2 row 6')
rep(F, '* **A H1 órajel-csatolást** (L szabad) több, egymást átfedő tartományban zárják ki:',
    '* **A „csak óra” H1-posztulátumot** (L szabad; a hatásból nem levezethető, B7) több, egymást átfedő tartományban zárják ki:', 'S2 Összkép')
rep(F, '* **L = 10 km-en a H1 megengedett.** A legérzékenyebb teszt itt a Skytree óra (1,4σ).',
    '* **L = 10 km-en a „csak óra” H1-posztulátum megengedett** (legérzékenyebb teszt: Skytree, 1,4σ). Ez **nem jelenti a V28 túlélését**: a step8 szerinti univerzális H1-nél nincs önálló órajel, ugyanaz a φ_L pedig az ötödik-erő tesztekben (3. sor) ~176×-osan kizárt.', 'S2 Összkép L=10km')

# ---------------- optical clocks
F = 'optical_clock_tests/docs/OPTIKAI_ORAK_hu.md'
rep(F, '## 0. Rövid válasz\n', '## 0. Rövid válasz\n\n' + NOTE + '\n' + S3NOTE, 'S2+S3 notes')
rep(F, '**Az L = 10 km nincs kizárva.**', '**Az L = 10 km a „csak óra” H1-posztulátumban nincs kizárva** (ez nem jelenti a V28 túlélését, lásd fent).', 'S2 short answer')
rep(F, '| II. Yukawa α_Y = 1/3 | 3.05·10⁻⁵ | **0.18σ** (p = 0.43) | 0.18σ | 51.18 km |',
    '| II. Yukawa α_Y = 1/3, lineáris (V23) konvenció | 3.05·10⁻⁵ | **0.18σ** (p = 0.43) | 0.18σ | 51.18 km |\n'
    '| II. Yukawa α_Y = 1/3, kvadratikus (V27/V28) konvenció [audit S3] | 1.02·10⁻⁵ | −0.04σ | −0.04σ | 140.5 km |', 'S3 table row')
rep(F, '- II. formuláció (csak az órákra ható Yukawa): φ = α_Y·(G/c²)·∫ρ·e^{−r/L}/(4πr) d³y. Ez lineáris α_Y-ban, ezért α_Y = 1-re számolunk, és 1/3-ra skálázunk.',
    '- II. formuláció (Yukawa, a „csak az órákra ható” posztulátum szerint – B7, audit S2): φ = α_Y·(G/c²)·∫ρ·e^{−r/L}/(4πr) d³y. A lineáris (V23) konvencióban ez lineáris α_Y-ban, ezért α_Y = 1-re számolunk, és 1/3-ra skálázunk; a kvadratikus (V27/V28) konvencióban a skála 1/9 (audit S3).', 'S2+S3 def')
rep(F, '0.36σ (Yukawa 1/3).', '0.36σ (Yukawa 1/3, lineáris konvenció; kvadratikus: 0.05σ).', 'S3 ACES')
rep(F, '- egyoldali z > 1.645: 11.86 km (top-hat), 16.91 km (Yukawa 1), 44.25 km (Yukawa 1/3);',
    '- egyoldali z > 1.645: 11.86 km (top-hat), 16.91 km (Yukawa 1), 44.25 km (Yukawa 1/3, lineáris konvenció; kvadratikus: 120.0 km);', 'S3 one-sided')
rep(F, 'a TAL-többletet nem tartalmazza, és a többlet csak az órákra hat (H1, „clock-only”).',
    'a TAL-többletet nem tartalmazza, és a többlet csak az órákra hat (H1, „clock-only”). **Audit S2:** ez a hatásból nem levezethető posztulátum; a step8 szerinti univerzális H1-nél a geodéziai ΔU (gravimetria, szintezés) ugyanazt a potenciált tartalmazza, így e teszt jele 0, és a V28-at az ötödik-erő tesztek döntik el.', 'S2 assumption 7')

# ---------------- Galileo STEP6
F = 'galileo_reanalysis/docs/STEP6_hu.md'
rep(F, '## 0. Röviden\n', '## 0. Röviden\n\n' + NOTE + '\n' + S3NOTE, 'S2+S3 notes')
rep(F, '* **II. formuláció (árnyékolt Yukawa, csak órák):**', '* **II. formuláció (árnyékolt Yukawa, „csak óra” posztulátum – B7, audit S2):**', 'S2')
rep(F, '  * α_Y = 1/3: kizárva **L ≥ 3 262 km** (konzervatív: 3 518 km; E14: 3 320 km).',
    '  * α_Y = 1/3 (lineáris V23 konvenció): kizárva **L ≥ 3 262 km** (konzervatív: 3 518 km; E14: 3 320 km).\n'
    '  * α_Y = 1/3 (kvadratikus V27/V28 konvenció, audit S3): kizárva L ≳ 3 910 km (konzervatív: ~4 280 km; E14: ~4 000 km; rács-interpolációval, ±0,2%).', 'S3 edges')
rep(F, '~320-szorosa (α_Y = 1/3).', '~320-szorosa (α_Y = 1/3, lineáris; kvadratikus konvencióban a telítés 0,00884, ~105-szörös).', 'S3 saturation')
rep(F, '* **II. árnyékolt Yukawa (csak az órákra ható olvasat):**', '* **II. árnyékolt Yukawa (a „csak az órákra ható” posztulátum; a step8 H1 univerzális, lásd audit S2):**', 'S2 def')
rep(F, '  * A II. formuláció lineáris α_Y-ban, ezért az α_Y = 1/3 eredmény pontosan harmada az α_Y = 1-nek.',
    '  * A II. formuláció a lineáris (V23) konvencióban lineáris α_Y-ban, ezért az α_Y = 1/3 eredmény pontosan harmada az α_Y = 1-nek. A kvadratikus (V27/V28) konvencióban kilencede (audit S3).', 'S3 def')
rep(F, '| L | top-hat α_eff | Yukawa α_Y=1 | Yukawa α_Y=1/3 |', '| L | top-hat α_eff | Yukawa α_Y=1 | Yukawa α_Y=1/3 (lineáris; kvadr. = α_Y=1 oszlop / 9) |', 'S3 table')
rep(F, '| II. Yukawa α_Y=1/3 | ≥ 3 262 km |', '| II. Yukawa α_Y=1/3 (lineáris; kvadr.: ≳ 3 910 / 4 280 / 4 000 km) | ≥ 3 262 km |', 'S3 table')
rep(F, 'α_Y = 1/3-nál ≳ 53 km;', 'α_Y = 1/3-nál ≳ 53 km (lineáris konvenció; kvadratikus: ≳ 145 km, DEM-modell);', 'S3 Skytree')

# ---------------- Galileo OSSZEFOGLALO
F = 'galileo_reanalysis/docs/OSSZEFOGLALO_hu.md'
rep(F, '  * Yukawa α_Y = 1: **L ≥ 2 795 km**; α_Y = 1/3: **L ≥ 3 262 km**.',
    '  * Yukawa α_Y = 1: **L ≥ 2 795 km**; α_Y = 1/3: **L ≥ 3 262 km** (lineáris V23 konvenció; kvadratikus V27/V28 konvencióban ≳ 3 910 km – audit S3).\n'
    '  * **Audit S2:** ezek a kizárások a „csak óra” H1-posztulátumra vonatkoznak; a step8 szerinti H1 univerzális, és a „csak óra” olvasat a hatásból nem vezethető le (B7). A V28 L = 10 km „nyitott” státusza nem jelenti a V28 túlélését (az ötödik-erő tesztek ~176×-osan kizárják).', 'S2+S3')
rep(F, 'Yukawa α_Y = 1 és 1/3; 4 rétegű Föld);', 'Yukawa α_Y = 1 és 1/3 (lineáris konvenció); 4 rétegű Föld; „csak óra” posztulátum, lásd audit S2);', 'S2+S3')

# ---------------- export README
F = 'galileo_reanalysis/export/README_hu.md'
rep(F, '  * Yukawa α_Y = 1: L ≥ 2 795 km; α_Y = 1/3: L ≥ 3 262 km.',
    '  * Yukawa α_Y = 1: L ≥ 2 795 km; α_Y = 1/3: L ≥ 3 262 km (lineáris V23 konvenció; kvadratikus V27/V28 konvencióban ≳ 3 910 km).\n'
    '  * Ezek a kizárások a „csak az órákra ható” H1-olvasatra vonatkoznak. A TAL 8. lépés H1-e univerzális csatolás; a „csak óra” olvasat a hatásból nem vezethető le (posztulátum). Az L = 10 km nyitott státusza nem jelenti, hogy a V28 túlél (az ötödik-erő tesztek kizárják).', 'S2+S3')

# ---------------- EP
F = 'further_tests/ep/docs/EKVIVALENCIA_ELV_hu.md'
rep(F, '* **H1 (diszformális órakapcsolat):** csak az órák és fotonok frekvenciáját érinti, a szabadesést nem. EP-jel nincs.',
    '* **H1 (diszformális órakapcsolat):** a step8 definíciója szerint univerzális csatolás; ekkor az órák és a szabadesés ugyanazt a metrikát érzik, η = 0, de a teljes ötödik erő jelen van (az ötödik-erő tesztek kizárják). A korábbi „csak az órák és fotonok frekvenciáját érinti, a szabadesést nem; EP-jel nincs” olvasat **a hatásból nem levezethető posztulátum**, és B7 szerint csak nem-univerzális (fajtafüggő) csatolással valósítható meg, ami generikusan EP-jelet ad (audit S2).', 'S2')

# ---------------- ERRATA
F = 'errata/ERRATA_hu.md'
rep(F, '  - A H1 (csak órákra ható csatolás) $L=10$ km-en **nincs** kizárva.',
    '  - A „csak órákra ható” H1-olvasat $L=10$ km-en **nincs** kizárva. (Audit S2: ez az olvasat a hatásból nem levezethető posztulátum – a step8 H1 univerzális; a kizárás hiánya **nem** jelenti a V28 túlélését, amelyet az ötödik-erő tesztek ~176×-osan kizárnak.)', 'S2')

# ---------------- clock README
F = 'docs/clock_redshift_tests/README_hu.md'
rep(F, '- **(a) Csak az óra csatolódik (H1-szerű):**', '- **(a) Csak az óra csatolódik (H1-szerű; a hatásból nem levezethető posztulátum, B7 – audit S2):**', 'S2')
rep(F, 'α_Y = 1/3-nál a határ L ≳ 53 km.', 'α_Y = 1/3-nál a határ L ≳ 53 km (lineáris V23 konvenció; kvadratikus V27/V28 konvencióban ≳ 145 km a DEM-modellel – audit S3).', 'S3')
rep(F, 'A csak órához csatolt Yukawa H1-et L ≳ 20 km-re zárják ki. Nyitva marad L ≲ 14 km, ide tartozik a V28 L = 10 km is (Skytree: 1,4σ), valamint a nagyon nagy L.',
    'A csak órához csatolt Yukawa H1-et L ≳ 20 km-re zárják ki. Nyitva marad L ≲ 14 km, ide tartozik a V28 L = 10 km is (Skytree: 1,4σ), valamint a nagyon nagy L. **Audit S2:** mindez csak a „csak óra” posztulátumra érvényes; a step8 szerinti H1 univerzális, így a „nyitott” L = 10 km nem jelenti a V28 túlélését (az ötödik-erő tesztek ~176×-osan kizárják).', 'S2 summary')

# ---------------- WD docs
F = 'further_tests/wd_redshift/docs/FEHER_TORPE_hu.md'
rep(F, '## Ítélet\n', '## Ítélet\n\n' + NOTE + '\n', 'S2 note')
rep(F, '* **V28, L = 10 km: megengedett, de gyakorlatilag nem tesztelhető.**', '* **V28, L = 10 km („csak óra” posztulátum): megengedett, de gyakorlatilag nem tesztelhető.**', 'S2')
F = 'open_items/wd_catalogs/docs/WD_katalogus_H1_hu.md'
rep(F, '## Elérhetőség\n', NOTE + '\n## Elérhetőség\n', 'S2 note')

# ---------------- code docstrings (comments only; no logic change)
rep('docs/clock_redshift_tests/clock_redshift_tal_h1.py', '  Formulation II (screened Yukawa, clock-only reading):',
    '  Formulation II (screened Yukawa, clock-only reading = POSTULATE, not derivable from the action; step8 H1 is universal -- audit S2):', 'S2 docstring')
rep('docs/clock_redshift_tests/clock_redshift_tal_h1.py', 'alpha_Y=1/3 volume-matched)', 'alpha_Y=1/3 volume-matched; LINEAR V23 convention -- quadratic V27/V28 would be 1/9, audit S3)', 'S3 docstring')
rep('open_items/wd_catalogs/code/wd_catalog_h1.py', '(clock-only Yukawa shift)', '(clock-only Yukawa shift = postulate, not derivable from the action; audit S2)', 'S2 docstring')

json.dump(LOG, open(f'{LAB}/audit/results/s3/fix_log.json', 'w'), ensure_ascii=False, indent=1)
print(len(LOG), 'edits'); [print(l['file'], '|', l['item']) for l in LOG]
