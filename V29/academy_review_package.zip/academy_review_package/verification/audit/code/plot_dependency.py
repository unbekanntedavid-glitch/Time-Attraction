import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
col={'HIBA':'#f4a6a6','NEM':'#ffe08a','ELL':'#f7c58f','OK':'#b9e4b0','INFO':'#d6e2f5'}
N={ # key: (x,y,text,flag)
 'GR':(0.5,9.4,'GR redshift\nΦ ≈ −GM/L = −(4π/3)GρL²','INFO'),
 'v1':(0.5,8.1,'v1 Eq.(9)–(10): f_L = exp(−γ_L ρ̄_L), γ_L = GL²/c²\n4π/3 elhagyva; GR-potenciál átcímkézve  [HIBA]  ← LEGKORÁBBI TÖRÉS','HIBA'),
 'act':(0.5,6.8,'v1 Eq.(11): S = ∫√−g [R/16πG + f_L L_m]\nuniverzális konform csatolás = ötödik erő  (GR-hatás kétszer)','HIBA'),
 'lab':(-3.6,6.8,'v1 Eq.(3)/(13): L<367 m, Δf/f=+γΔρ̄\nátlagolatlan Δρ, rossz előjel  [HIBA]','HIBA'),
 'L':(4.6,6.8,'L: v1 „10 km illusztr.” (NS-ablak)\n→ V21 szkenpont → V27/V28 fix  [NEM LEV.]','NEM'),
 'C':(-3.6,5.4,'v8–v16: C(ρ)=1+C0 e^{−ρ/ρc}, sötét anyag\nC0, ρc, L0 kézi  [NEM LEV.]; v1-gyel ellentmond','NEM'),
 'V23':(0.5,5.4,'V23: Branch II hatás, (−□+L⁻²)φ = α_Y Gρ/c²\nα_Y=1 ⇔ top-hat γ_L (kernel ∫=L²)  [OK, de γ_L-t örökli]','ELL'),
 'alpha':(0.5,4.1,'α_std = 1/(4π) = 0,0796\n(ha a 4π/3 megmaradt volna: 1/3)','ELL'),
 'H':(-3.6,4.1,'H0 / H1 óracsatolás\nH0 EP-sértő; H1 = teljes potenciál, nincs külön órajel','ELL'),
 'conv':(4.6,4.1,'V27/V28 kód: q = α_Y²β (kvadratikus)\nvs V23 α_Y/4π (lineáris)  [ELLENTMONDÁS]','ELL'),
 'ISL':(0.5,2.7,'Ötödik erő: α95(10 km)=4,5e−4 → 176× kizárt\nCassini γ_PPN, BBN (G-szótár 0,926)','HIBA'),
 'gal':(4.6,2.7,'V28 galaxis: max boost 1+q = 1,08\nC_req = 2,7–4,3 (step6)  → nem magyaráz DM-et','HIBA'),
 'S29':(-3.6,2.7,'Step 29 labor (tekercs/OCXO)\njel ≤ 1e−48 … 1e−26  → mérhetetlen','HIBA'),
 'fix':(0.5,1.2,'Javított út: α ≤ α95(λ) gyenge csatolás vagy λ ≲ 72 µm;\nnincs DM-magyarázat, nincs óra-specifikus jel','OK'),
}
E=[('GR','v1'),('v1','act'),('v1','lab'),('v1','L'),('act','C'),('act','V23'),('L','V23'),('V23','alpha'),('V23','H'),('alpha','conv'),
   ('alpha','ISL'),('alpha','gal'),('C','gal'),('H','S29'),('lab','S29'),('ISL','fix'),('gal','fix'),('S29','fix')]
fig,ax=plt.subplots(figsize=(16,12)); ax.set_xlim(-5.6,6.6); ax.set_ylim(0.4,10.1); ax.axis('off')
W={'v1':5.2,'act':3.4,'fix':5.2,'V23':3.4,'alpha':3.0}
for k,(x,y,t,fl) in N.items():
    w=W.get(k,3.4); h=0.9
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.05',fc=col[fl],ec='k',lw=1.2))
    ax.text(x,y,t,ha='center',va='center',fontsize=8.6)
for a,b in E:
    xa,ya=N[a][:2]; xb,yb=N[b][:2]
    if abs(ya-yb)<0.01:
        ax.annotate('',xy=(xb-1.72,yb),xytext=(xa+1.52,ya),arrowprops=dict(arrowstyle='->',lw=1.1,color='#333'))
    else:
        ax.annotate('',xy=(xb,yb+0.47),xytext=(xa,ya-0.47),arrowprops=dict(arrowstyle='->',lw=1.1,color='#333'))
for i,(lab,cc) in enumerate([('HIBA / kizárt','HIBA'),('NEM LEVEZETETT','NEM'),('ELLENTMONDÁS / örökölt','ELL'),('OK','OK'),('forrás','INFO')]):
    ax.add_patch(plt.Rectangle((-5.5,9.7-i*0.3),0.3,0.2,fc=col[cc],ec='k')); ax.text(-5.1,9.8-i*0.3,lab,fontsize=8.5,va='center')
ax.set_title('TAL levezetési lánc – függőségi diagram és törések (audit, 2026-11-01)',fontsize=13)
plt.savefig('/workspace/artifacts/tal-step29-lab/audit/results/plots/fuggosegi_diagram.png',dpi=130,bbox_inches='tight')
