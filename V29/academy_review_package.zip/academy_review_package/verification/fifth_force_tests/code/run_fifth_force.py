"""Fifth-force (Yukawa) test of the V28 fixed universal-coupling branch.
All inputs are listed in EXPERIMENTS with their source; see docs/OTODIK_ERO_hu.md.
Outputs: results/*.json|csv, results/*.png
"""
import json, os, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from scipy.stats import norm
from kernels import *

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, 'results'); os.makedirs(RES, exist_ok=True)

# ------------------------------------------------------------- V28 parameters
LAM = 10_000.0
A_STD = 1 / (4 * np.pi)                 # alpha_Y = 1 (both conventions agree)
VARIANTS = {
    'V28 alpha_Y=1 (alpha=1/4pi)': A_STD,
    'alpha_Y=1/3, Step5 linear (alpha=1/12pi)': 1 / (12 * np.pi),
    'alpha_Y=1/3, V28 action quadratic (alpha=1/36pi)': (1 / 3)**2 / (4 * np.pi),
}

# ------------------------------------------------------------- data
# Towers: residual = observed - Newtonian prediction at top platform (uGal, 1 sigma)
TOWERS = [
  dict(id='Thomas1989_BREN', h=465., m=-60., s=95.,
       src='Thomas et al., PRL 63, 1902 (1989), doi:10.1103/PhysRevLett.63.1902 (abstract: -60 +- 95 uGal at top, 465 m)'),
  dict(id='BREN_OSTI6190822', h=454., m=-93., s=95.,
       src='Thomas, Kasameyer et al., LLNL report OSTI 6190822 (93 uGal, sign not stated -> conservative -93; sigma sampling only; Step 27 reading)'),
  dict(id='Romaides1994_WABG', h=493., m=-33., s=30.,
       src='Romaides et al., PRD 50, 3608 (1994), doi:10.1103/PhysRevD.50.3608 (abstract: -33 +- 30 uGal at 493 m)'),
  dict(id='Romaides1997_WABG', h=568., m=32., s=32.,
       src='Romaides et al., PRD 55, 4532 (1997), doi:10.1103/PhysRevD.55.4532 (abstract: 32 +- 32 uGal at 568 m)'),
  dict(id='Speake1990_Erie', h=300., m=0., s=float(np.hypot(14., 23.)),
       src='Speake et al., PRL 65, 1967 (1990) doi:10.1103/PhysRevLett.65.1967; Speake/Cruz et al. JGR 96 (1991) doi:10.1029/91JB01756 '
           '(rms residual 10 uGal; top-platform errors 14 uGal meas + 23 uGal prediction -> 27 uGal; residual taken as 0 +- 27)'),
]
RHO_BRACKET = (1800., 2670.)     # assumed effective density range (not from the papers)

# Ocean (Zumberge 1991); layered model from March et al. PRD 100, 042002 (2019) eq. (46),(79)
OCEAN_LAYERS = [(0., 1037.05), (5000., 2860.), (12000., 3400.)]
OCEAN_RHO_W = 1037.05
Z_FIT = np.linspace(500., 4800., 431)
OCEAN_SLOPE = dict(m=-0.060, s=0.172,   # mGal/km, March 2019 eq.(81) reading used in Step 27
                   src='Zumberge et al. PRL 67, 3051 (1991) via March et al. PRD 100, 042002 (2019) (Step 27 reading)')
ZUMB_G = dict(G=6.677e-11, s=0.013e-11,
              src='Zumberge et al. PRL 67, 3051 (1991) abstract: G = (6.677 +- 0.013)e-11, consistent with lab')

def g_to_ugal(x): return x / UGAL

# ------------------------------------------------------------- per-experiment model
def tower_model_ugal(t, rho, kind, a, lam):
    return g_to_ugal(tower_residual(t['h'], rho, kind, a, lam))

def ocean_slope_model(kind, a, lam, layers=OCEAN_LAYERS):
    r = ocean_profile_residual(Z_FIT, layers, OCEAN_RHO_W, kind, a, lam)
    return ls_slope(Z_FIT / 1000., r / MGAL)        # mGal/km

def zumberge_G_model(kind, a, lam, layers=OCEAN_LAYERS):
    """Effective G an ocean-profile fit would return: G_fit = G_lab - slope/(4 pi rho_w)."""
    s = ocean_slope_model(kind, a, lam, layers) * MGAL / 1000.   # s^-2
    return G_LAB - s / (4 * np.pi * OCEAN_RHO_W)

def alpha95(model_unit, m, s, sign=-1, k=1.96):
    """Conservative 95% bound: |alpha| s.t. model = sign*(max(sign*m,0) + k s)."""
    return (max(sign * m, 0.) + k * s) / abs(model_unit)

out = {'lambda_m': LAM, 'variants': VARIANTS, 'towers': [], 'ocean': {}, 'tophat': {}}

# ---- V28 point: z-scores
for t in TOWERS:
    row = dict(id=t['id'], h=t['h'], meas=t['m'], sigma=t['s'], src=t['src'])
    for rho in RHO_BRACKET:
        for vn, a in VARIANTS.items():
            mod = tower_model_ugal(t, rho, 'yukawa', a, LAM)
            row[f'model_uGal_rho{int(rho)}_{vn}'] = mod
            row[f'z_rho{int(rho)}_{vn}'] = (t['m'] - mod) / t['s']
        unit = tower_model_ugal(t, rho, 'yukawa', 1e-6, LAM) / 1e-6
        row[f'alpha95_rho{int(rho)}'] = alpha95(unit, t['m'], t['s'])
        # top-hat (alpha_Y = 1), Formulation-I kernel folded as a universal force
        th = tower_model_ugal(t, rho, 'tophat', 1.0, LAM)
        row[f'tophat_model_uGal_rho{int(rho)}'] = th
        row[f'tophat_z_rho{int(rho)}'] = (t['m'] - th) / t['s']
    out['towers'].append(row)

o = out['ocean']
for vn, a in VARIANTS.items():
    sl = ocean_slope_model('yukawa', a, LAM)
    Gm = zumberge_G_model('yukawa', a, LAM)
    o[vn] = dict(model_slope_mGal_per_km=sl,
                 z_slope=(OCEAN_SLOPE['m'] - sl) / OCEAN_SLOPE['s'],
                 model_G_fit=Gm, model_dG_over_G=Gm / G_LAB - 1,
                 z_G=(ZUMB_G['G'] - Gm) / ZUMB_G['s'])
unit = ocean_slope_model('yukawa', 1e-6, LAM) / 1e-6
o['slope_per_unit_alpha_mGal_per_km'] = unit
o['alpha95_slope'] = alpha95(unit, OCEAN_SLOPE['m'], OCEAN_SLOPE['s'], sign=+1)
o['zumberge_G_meas'] = ZUMB_G['G']; o['zumberge_dG_over_G_meas'] = ZUMB_G['G'] / G_LAB - 1
o['zumberge_dG_over_G_sigma'] = ZUMB_G['s'] / G_LAB
dGunit = (zumberge_G_model('yukawa', 1e-6, LAM) / G_LAB - 1) / 1e-6
o['alpha95_G'] = (max(-(ZUMB_G['G'] / G_LAB - 1), 0) + 1.96 * ZUMB_G['s'] / G_LAB) / abs(dGunit)
# ocean robustness: alternative crust density / water depth
alts = {}
for H in (5000., 5500., 6000.):
    for rc in (2670., 2860., 3000.):
        L_ = [(0., OCEAN_RHO_W), (H, rc), (H + 7000., 3400.)]
        alts[f'H{int(H)}_rhoc{int(rc)}'] = ocean_slope_model('yukawa', A_STD, LAM, L_)
o['alt_model_slopes_alphaV28'] = alts
o['tophat_slope_alphaY1'] = ocean_slope_model('tophat', 1.0, LAM)
o['tophat_z_slope'] = (OCEAN_SLOPE['m'] - o['tophat_slope_alphaY1']) / OCEAN_SLOPE['s']

# ---- supporting: ship vs altimetric gravity offset (Gulf of Mexico shelf/slope)
gulf = {}
for H in (200., 1000., 2000.):
    for rs in (2000., 2400.):
        iface = [(0., 1030.), (H, rs - 1030.)]
        Gi = G_LAB / (1 + A_STD)
        gulf[f'H{int(H)}_rhos{int(rs)}'] = float(g_extra(0., iface, lambda s: K_yuk(s, A_STD, LAM, Gi)) / MGAL)
out['gulf_offset_mGal'] = gulf
land = {}
for rho in (2000., 2670.):
    Gi = G_LAB / (1 + A_STD)
    land[f'rho{int(rho)}'] = float(K_yuk(0., A_STD, LAM, Gi) * rho / MGAL)
out['land_surface_offset_mGal'] = land
out['extra_vertical_gradient_mGal_per_m_rho2670'] = float(2 * np.pi * G_LAB / (1 + A_STD) * A_STD * 2670 / MGAL)

# ---- combined (independent stat errors only; most conservative density)
def combined_chi2(var_a, rho):
    chi2 = 0.
    for t in TOWERS:
        chi2 += ((t['m'] - tower_model_ugal(t, rho, 'yukawa', var_a, LAM)) / t['s'])**2
    chi2 += ((OCEAN_SLOPE['m'] - ocean_slope_model('yukawa', var_a, LAM)) / OCEAN_SLOPE['s'])**2
    chi2_0 = sum((t['m'] / t['s'])**2 for t in TOWERS) + (OCEAN_SLOPE['m'] / OCEAN_SLOPE['s'])**2
    return chi2, chi2_0
comb = {}
for vn, a in VARIANTS.items():
    c, c0 = combined_chi2(a, 1800.)
    comb[vn] = dict(chi2=c, chi2_null=c0, dchi2=c - c0, approx_sigma=float(np.sqrt(max(c - c0, 0))))
out['combined_rho1800'] = comb

# ---- error-inflation robustness: factor f by which all sigmas must grow for V28 to reach 2 sigma
inf = {}
for t in TOWERS:
    mod = tower_model_ugal(t, 1800., 'yukawa', A_STD, LAM)
    inf[t['id']] = abs(t['m'] - mod) / (1.96 * t['s'])
inf['ocean_slope'] = abs(OCEAN_SLOPE['m'] - o['V28 alpha_Y=1 (alpha=1/4pi)']['model_slope_mGal_per_km']) / (1.96 * OCEAN_SLOPE['s'])
inf['ocean_G'] = abs(o['V28 alpha_Y=1 (alpha=1/4pi)']['z_G']) / 1.96
out['sigma_inflation_needed_for_2sigma_rho1800'] = inf

# ------------------------------------------------------------- compiled envelopes
adel = json.load(open(os.path.join(ROOT, 'data', 'adelberger2003_fig4_pixel.json')))['data']
adel = np.array(adel)
lee = json.load(open(os.path.join(ROOT, 'data', 'lee2020_fig5_edges.json')))
def adel_at(lg): return 10**np.interp(lg, adel[:, 0], adel[:, 1])
env = {}
for lg in (2.0, 3.0, 3.5, 4.0, 4.5, 5.0, 6.0):
    env[str(lg)] = float(adel_at(lg))
out['adelberger2003_alpha95'] = env
out['ratio_V28_to_adelberger_10km'] = A_STD / adel_at(4.0)
# allowed lambda windows for fixed alpha: short side from Lee 2020 Fig.5 edges, long side from Adelberger Fig.4
win = {}
for vn, a in VARIANTS.items():
    lgA = np.log10(a)
    # long side: last crossing on the rising planetary branch (log lam > 12); extrapolate slope beyond 15
    br = adel[adel[:, 0] > 12.5]
    if lgA <= br[-1, 1]:
        lg_long = float(np.interp(lgA, br[:, 1], br[:, 0]))
        extrap = False
    else:
        slope = (br[-1, 1] - br[-11, 1]) / (br[-1, 0] - br[-11, 0])
        lg_long = float(br[-1, 0] + (lgA - br[-1, 1]) / slope); extrap = True
    short = float(np.interp(lgA, np.log10(lee['alpha'])[::-1], np.log10(lee['lambda_edge_m'])[::-1]))
    win[vn] = dict(alpha=a, allowed_if_lambda_below_m=10**short, allowed_if_lambda_above_m=10**lg_long,
                   long_edge_extrapolated=extrap)
# ---- S1 audit fix (2026-11-01): Cassini PPN gamma closes the long-range window for a scalar that does not couple to light
# Single-scale estimate (OUR approximation, not a published curve): |gamma-1| = 2 a e^{-b/lam}/(1 + a e^{-b/lam}) < 2.3e-5
# (Bertotti+2003), impact parameter b = 1.6 R_sun. Excluded for lam > b / ln(a / y), y = 2.3e-5/(2 - 2.3e-5).
CASSINI_GM1 = 2.3e-5; B_CASS = 1.6 * 6.957e8; Y_CASS = CASSINI_GM1 / (2 - CASSINI_GM1)
for vn, a in VARIANTS.items():
    lc = B_CASS / np.log(a / Y_CASS)
    win[vn]['cassini_ppn_excluded_if_lambda_above_m_estimate'] = float(lc)
    win[vn]['long_window_open'] = bool(win[vn]['allowed_if_lambda_above_m'] < lc)
    win[vn]['note'] = 'ISL/planetary long edge alone suggested a window above allowed_if_lambda_above_m; Cassini gamma_PPN (single-scale estimate) excludes lambda above the Cassini value, so no long-range window remains.'
out['cassini_ppn_estimate'] = dict(gamma_minus_1_bound=CASSINI_GM1, impact_parameter_m=B_CASS, alpha_max_massless=Y_CASS,
                                   method='single-scale estimate, OUR approximation; not a full Yukawa light-propagation fit')
out['allowed_lambda_windows'] = win

# ---- allowed alpha at 10 km
out['allowed_alpha_at_10km'] = {
    'compiled_Adelberger2003_95': float(adel_at(4.0)),
    'ocean_slope_95_conservative': o['alpha95_slope'],
    'ocean_G_95': o['alpha95_G'],
    'best_tower_95_rho1800': min(r['alpha95_rho1800'] for r in out['towers']),
}
a_lim = adel_at(4.0)
out['implied_alpha_Y_limits_at_10km'] = {
    'V28_action_quadratic_alphaY_max': float(np.sqrt(4 * np.pi * a_lim)),
    'Step5_linear_alphaY_max': float(4 * np.pi * a_lim)}

json.dump(out, open(os.path.join(RES, 'fifth_force_results.json'), 'w'), indent=1, default=float)

# ------------------------------------------------------------- alpha95(lambda) own curves
lams = np.logspace(1, 6.5, 221)
curves = {}
for t in TOWERS:
    curves[t['id']] = [alpha95(tower_model_ugal(t, 1800., 'yukawa', 1e-6, l) / 1e-6, t['m'], t['s']) for l in lams]
curves['Zumberge1991_ocean_slope'] = [alpha95(ocean_slope_model('yukawa', 1e-6, l) / 1e-6, OCEAN_SLOPE['m'], OCEAN_SLOPE['s'], sign=+1) for l in lams]
import csv
with open(os.path.join(RES, 'alpha95_vs_lambda_own.csv'), 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['lambda_m'] + list(curves))
    for i, l in enumerate(lams): w.writerow([l] + [curves[k][i] for k in curves])

# ------------------------------------------------------------- plots
fig, ax = plt.subplots(figsize=(9, 6.2))
ax.fill_between(10**adel[:, 0], 10**adel[:, 1], 1e3, color='#ffe680', alpha=.7, lw=0,
                label='Adelberger+2003 Fig.4 (95%), digitalizálva')
ax.plot(10**adel[:, 0], 10**adel[:, 1], 'k-', lw=1)
le = np.array(lee['curve_lambda_alpha']).T
ax.fill_between(le[0], le[1], 1e3, color='#b3e6b3', alpha=.8, lw=0, label='Lee+2020 Fig.5 (95%), digitalizálva')
for k, c in curves.items():
    ax.plot(lams, c, lw=1.2, label=f'saját újraszámolás: {k} (ρ=1800)')
for vn, a in VARIANTS.items():
    ax.plot([LAM], [a], 'o', ms=8, label=f'{vn}')
ax.axvline(LAM, color='grey', ls=':', lw=1)
ax.axvspan(1e-3, 1e-2, color='grey', alpha=.12, lw=0)
ax.text(1.2e-3, 3e-10, '1 mm–1 cm:\nnem digitalizált', fontsize=6)
lc_ = np.logspace(7.6, 16, 300); ac_ = Y_CASS * np.exp(np.minimum(B_CASS / lc_, 700))
ax.fill_between(lc_, ac_, 1e3, color='#9ecae1', alpha=.45, lw=0, label='Cassini γ_PPN (saját egyskálás becslés, b = 1,6 R☉)')
ax.plot(lc_, ac_, color='#3182bd', lw=1)
ax.axhline(A_STD, color='r', ls='--', lw=.8)
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlim(1e-5, 1e16); ax.set_ylim(1e-11, 10)
ax.set_xlabel('λ [m]'); ax.set_ylabel('|α| (95% felső korlát)')
ax.set_title('V28 univerzális Yukawa-ág vs. ötödik-erő korlátok')
ax.legend(fontsize=6.5, loc='lower left', ncol=1)
fig.tight_layout(); fig.savefig(os.path.join(RES, 'exclusion_alpha_lambda.png'), dpi=150)

fig, ax = plt.subplots(figsize=(8, 5.5))
m = (lams > 50) & (lams < 3e6)
for k, c in curves.items():
    ax.plot(lams[m], np.array(c)[m], lw=1.4, label=k)
sel = (adel[:, 0] > 1.7) & (adel[:, 0] < 6.5)
ax.plot(10**adel[sel, 0], 10**adel[sel, 1], 'k-', lw=2, label='Adelberger+2003 burkoló')
for vn, a in VARIANTS.items():
    ax.plot([LAM], [a], 'o', ms=8, label=vn)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('λ [m]'); ax.set_ylabel('α_95')
ax.set_title('Geofizikai tartomány (100 m – 1000 km)'); ax.legend(fontsize=7); ax.grid(alpha=.3, which='both')
fig.tight_layout(); fig.savefig(os.path.join(RES, 'exclusion_geophysical_zoom.png'), dpi=150)

# residual figure: tower model vs data
fig, ax = plt.subplots(figsize=(8, 5))
hh = np.linspace(0, 620, 200)
for rho, ls in ((1800., '-'), (2670., '--')):
    ax.plot(hh, [tower_residual(h, rho, 'yukawa', A_STD, LAM) / UGAL for h in hh], 'r' + ls, label=f'V28 Yukawa α=1/4π, ρ={int(rho)}')
    ax.plot(hh, [tower_residual(h, rho, 'tophat', 1.0, LAM) / UGAL for h in hh], 'b' + ls, label=f'top-hat α_Y=1 (aux.), ρ={int(rho)}')
for t in TOWERS:
    ax.errorbar(t['h'], t['m'], yerr=t['s'], fmt='ko', capsize=3)
    ax.annotate(t['id'], (t['h'], t['m']), fontsize=6, xytext=(3, 6), textcoords='offset points')
ax.axhline(0, color='k', lw=.5); ax.set_xlabel('magasság [m]'); ax.set_ylabel('mért − Newton [µGal]')
ax.set_title('Toronykísérletek: maradék a csúcson vs. modell (λ = L = 10 km)'); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(RES, 'tower_residuals.png'), dpi=150)
print(json.dumps({k: out[k] for k in ['ocean', 'combined_rho1800', 'sigma_inflation_needed_for_2sigma_rho1800',
                                      'adelberger2003_alpha95', 'ratio_V28_to_adelberger_10km', 'allowed_lambda_windows',
                                      'allowed_alpha_at_10km', 'implied_alpha_Y_limits_at_10km', 'gulf_offset_mGal',
                                      'land_surface_offset_mGal', 'extra_vertical_gradient_mGal_per_m_rho2670']}, indent=1, default=float))
for r in out['towers']:
    print(r['id'], {k: round(v, 3) if isinstance(v, float) else v for k, v in r.items() if k.startswith(('z_', 'alpha95', 'tophat_z', 'model_uGal_rho1800_V28'))})
