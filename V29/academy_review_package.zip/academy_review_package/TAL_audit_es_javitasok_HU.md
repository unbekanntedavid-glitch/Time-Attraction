# Time Attraction Law: az első kritikus törés helye a levezetésben, és a Step 29 elemzések S1–S3 javításai

**Szerző:** Szabolcsi Dávid, független kutató, Unterterzen, Svájc (ORCID 0009-0005-6300-074X)
**Dátum:** 2026. november 2.
**Licenc:** [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/)
**Szerzői jog:** © 2026 Szabolcsi Dávid
**Kapcsolódó rekordok:**
- TAL V28: 10.5281/zenodo.23814053 (koncepció-DOI: 10.5281/zenodo.22983681)
- *Time Attraction* v1–v7: 10.5281/zenodo.23066993

---

## Kivonat

A dokumentum a Time Attraction Law (TAL) levezetési láncának törvényszéki auditját ismerteti, az első cikktől (*Time Attraction*, v1–v7) a V28-ig. Az első kritikus törés az első cikk 3.1. szakaszában, a (9)–(11) egyenletben van:

- **A (9) egyenlet** helyesen írja fel a közönséges newtoni potenciált.
- **A (10) egyenlet** a közönséges, gyengetér-közelítésű általános relativisztikus (GR) vöröseltolódást (1 + Φ/c²) nevezi át új „idővonzási” f_L tényezővé, és közben elhagyja a 4π/3-os geometriai faktort.
- **A (11) egyenlet** ezt a tényezőt az Einstein–Hilbert-tag mellé másodszor is beteszi a hatásba, így a GR-idődilatációt kétszer számolja.

Ebből a kettős számolásból lesz a későbbi verziók univerzális, gravitációs erősségű ötödik ereje (α = 1/(4π) ≈ 0,0796, λ = L = 10 km). A laboratóriumi és geofizikai ötödikerő-mérések ezt kb. 177-szeres szorzóval kizárják. A kettős számolás az f_L = exp(Φ/c²) választásnál is megmarad, ha f_L külön tényezőként szerepel az anyag hatásában (Φ_eff = 2Φ); csak ha f_L-t a g₀₀-ban már benne lévő órajárásként értelmezzük, esik egybe a GR-rel a gyenge tér első rendjében, és csak ekkor nem ad új fizikát.

Az audit három hibát talált a saját Step 29 elemzéseinkben is (S1–S3). Ezeket és a javításukat a dokumentum ismerteti:

- **S1:** téves hosszú hatótávú megengedett ablak; a Cassini-korlát alapján eltávolítottuk.
- **S2:** helytelen „csak órákra ható H1” megfogalmazás; mindenhol kijavítottuk.
- **S3:** az α_Y = 1/3-os értékek jelöletlenül egyetlen csatolási konvencióra épültek; most mindkét konvencióban megadjuk őket.

A Galileo 5/6 újraelemzés jelentését (PDF) és a reprodukálhatósági csomagot (ZIP) ugyanazon a néven újraépítettük. **Egyik javítás sem változtatja meg a következtetéseket.**

---

## 1. Bevezetés

A TAL sok számozott verzióban fejlődött. A V28-as alakja skalár–tenzor elmélet, amelyben a Yukawa-típusú skalár hatótávja rögzített, L = 10 km, a csatolás α_Y = 1 és β_Yuk = 1/(4π). Ez α = 1/(4π) ≈ 0,0796 ötödikerő-erősséget ad.

A Step 29 programban ezt az elméletet a következőkkel vetettük össze:
- Galileo 5/6 óraadatok;
- optikai órás összehasonlítások;
- ötödikerő-mérések;
- árnyékolt változatok;
- galaxisok forgási görbéi és a barionikus akusztikus oszcillációk;
- fehér törpék, neutroncsillagok, gravitációs hullámok, az ősrobbanáskori nukleoszintézis és a kozmikus mikrohullámú háttér;
- ekvivalenciaelv-tesztek.

Minden konzisztens változat vagy megbukott, vagy olyan elméletre egyszerűsödött, amelynek nincs TAL-specifikus jóslata. Ezért magát a levezetési láncot auditáltuk, hogy megtaláljuk, hol romlik el először.

A módszer az volt, hogy minden örökölt mennyiséget (γ_L, α_Y, β_Yuk, α, L, ω_BD, a H0/H1 óracsatolás) visszakövettünk ahhoz a verzióhoz, ahol először megjelenik, és minden lépést szimbolikusan és numerikusan ellenőriztünk.

A dokumentum két dolgot ismertet:
- a legkorábbi törést, amelyet minden későbbi eredmény örököl (2. fejezet);
- a saját elemzéseinkben talált hibákat és javításukat (3–4. fejezet).

---

## 2. Az első kritikus törés: *Time Attraction* v1–v7, 3.1. szakasz, (9)–(11) egyenlet

### 2.1 Az egyenletek a publikált formában

> Φ = −G_N ∫ ρ(x′) / |x − x′| d³x′,  |Φ_L| ≈ G M / L = (4π/3) G_N ρ̄_L L²  (9)
>
> f_L ≈ 1 + Φ_L/c² ≈ 1 − γ_L ρ̄_L  ⇒  f_L = exp(−γ_L ρ̄_L),  γ_L = G_N L²/c²  (10)
>
> S = ∫ d⁴x √−g [ R / (16π G_N) + f_L(ρ̄_L) L_m ]  (11)

### 2.2 A (9) egyenlet helyes

A (9) egyenlet a közönséges newtoni potenciál. L sugarú, ρ̄_L átlagsűrűségű homogén gömbre:
- a potenciál a felszínen |Φ| = (4π/3) G ρ̄_L L²;
- a középpontban |Φ| = 2π G ρ̄_L L².

Itt még nem jelenik meg semmi új.

### 2.3 Hol csúszik el a (10) egyenlet

1. **Átcímkézés.** Az első lépés, f_L ≈ 1 + Φ_L/c², pontosan a gyengetér-közelítésű GR gravitációs vöröseltolódás (az idődilatációs tényező, √(−g₀₀) ≈ 1 + Φ/c²). Az „idővonzási” tényező tehát eredetileg a közönséges GR-idődilatáció új néven, nem új hatás.
2. **Elveszett geometriai faktor.** A második lépésben (Φ_L/c² → −γ_L ρ̄_L, γ_L = G L²/c²) eltűnik a 4π/3. A geometriát megtartva a konzisztens együttható a felszínen (4π/3) G L²/c², a középpontban 2π G L²/c². A γ_L ρ̄_L a valódi felszíni potenciálnak csak 0,239-szerese.

### 2.4 Hol csúszik el a (11) egyenlet: kettős számolás

A (11) egyenlet az anyag Lagrange-sűrűségét megszorozza f_L-lel, az R/(16πG_N) Einstein–Hilbert-tagot pedig változatlanul hagyja. Az S_EH + f_L L_m alak önmagában még nem kettős számolás; a kettős számolás a belőle következő dinamikában jelenik meg.

**Levezetés (gyenge tér, lassú mozgás, pontrészecske-határeset).** Pontrészecske-anyagra L_m → −Σ m c² ∫ dτ, így az anyag hatása −Σ m c² ∫ f_L dτ. Az S_EH-ból származó metrika már tartalmazza az órajárást, dτ ≈ (1 + Φ/c²) dt. Első rendben egy próbatest tehát a következő effektív potenciálban mozog:

  Φ_eff = Φ + c² ln f_L ≈ Φ + c² (f_L − 1).

A (10) egyenlet f_L − 1 ≈ Φ_L/c²-et ír elő, amiből Φ_eff ≈ Φ + Φ_L. A Φ a GR-ben már benne lévő potenciál; a Φ_L ugyanaz a newtoni potenciál még egyszer, L skálán simítva és a 4π/3-os faktor nélkül normálva. Ebben a határesetben tehát a hatás kétszer számolja a gravitációs potenciált: egyszer a metrikán, egyszer f_L-en keresztül. Mivel f_L univerzális, a többlettag minden anyagra gravitációs erősségű, L hatótávú ötödik erőként hat. Innen származik a későbbi verziók α = 1/(4π) értéke.

**Érvényességi kör.** A levezetés csak a gyenge tér, lassú mozgás, pontrészecske-határesetre érvényes. Mivel f_L a ρ̄_L simított sűrűségtől függ, amely maga is az anyagmezők függvénye, a (11) egyenlet teljes kovariáns téregyenleteiben további tagok is megjelennek. Ezeket az audit nem vezette le.

### 2.5 Miért kritikus ez a törés

Minden későbbi normálás ebből a γ_L-ből származik:

- **V24 step 1:** „γ_L = G L²/c²”.
- **V23 / step 5:** az α_Y = 1 azért lett a választás, mert „visszaadja a homogén top-hat határesetet (φ_L = γ_L ρ_src)”; a Yukawa-kernel integrálja L².
- **V27 kód:** `GAMMA_L = 4π β_Yuk G L²/c²`, a megjegyzés: „Since 4π β_Yuk = 1”. A β_Yuk = 1/(4π) értéket tehát visszafelé választották, hogy γ_L jöjjön ki.

Az eredmény gravitációs erősségű csatolás, α = 1/(4π) ≈ 0,0796. λ = 10 km-en a kompilált korlát α₉₅ ≈ 4,5·10⁻⁴, így ez az érték kb. 177-szeresen kizárt. A 4π/3 megtartása sem segített volna: α ≈ 1/3 jött volna ki, ami még erősebben kizárt.

### 2.6 A konzisztens változat

Következetesen végigvezetve a (9)–(10) egyenlet f_L = exp(Φ/c²)-t ad. Az, hogy ez a választás ad-e új fizikát, attól függ, hogyan szerepel f_L a hatásban; két esetet kell megkülönböztetni.

**(a) f_L külön tényezőként megmarad az anyag hatásában.** Ha a hatás megtartja a (11) egyenlet S_EH + f_L L_m alakját, akkor f_L = exp(Φ/c²)-t a 2.4. szakasz eredményébe helyettesítve Φ_eff = Φ + c² ln f_L = Φ + Φ = 2Φ adódik. A potenciált ekkor is kétszer számoljuk: a szabadesést a newtoni potenciál kétszerese határozza meg, a fény terjedését és az órajárást viszont a metrika, azaz Φ. Ez ugyanaz a kettős számolás, mint a 2.4. szakaszban, most egységnyi relatív erősséggel, és ugyanazon az alapon kizárt (vö. a 4.1. szakasz Cassini-korlátjával). Ez a választás tehát nem menti meg konzisztensen a (11) egyenletet.

**(b) f_L nem marad meg külön tényezőként.** Csak akkor, ha f_L nem szerepel önálló tényezőként az anyag hatásában, vagyis ha f_L-t pusztán a g₀₀-ban már benne lévő órajárásként (magaként a GR gravitációs vöröseltolódásaként) értelmezzük, esik egybe az f_L = exp(Φ/c²) statikus, gyenge térben a GR órajárásával, √(−g₀₀) ≈ 1 + Φ/c². Ebben az esetben nem ad új fizikát. Az állítás csak a gyenge tér első rendjében érvényes; nem jelenti azt, hogy az exp(Φ/c²) a gyengetér-közelítésen túl is visszaadja a GR-t.

Új fizikához α-nak és λ-nak a GR-től független, szabad paraméternek kellene lennie. Ekkor viszont a meglévő mérések korlátozzák őket, és semmilyen TAL-specifikus érték nem tüntethető ki.

### 2.7 Másodlagos törések (a teljesség kedvéért)

- **Laborjóslat (v1, 3. és 13. egyenlet).** Az L sugarú gömb átlaga helyett a labor lokális sűrűségét használja, és a 13. egyenlet előjele hibás. Egy 10 t-s tömeg jele kb. 5·10⁻²⁷ (L = 367 m), illetve kb. 2·10⁻²⁸ (L = 10 km), ami kisebb, mint ugyanannak a tömegnek a közönséges GR-vöröseltolódása. A Step 29 laborban várt jel tehát sosem következett az elméletből; a tekercsjel ≤ 2,4·10⁻⁴⁸.
- **L = 10 km.** Sehol nincs levezetve. A v1-ben szemléltető neutroncsillag-átlagolási ablakként indult, a V21-ben szkenpont lett, a V27/V28-ban rögzített univerzális állandó. Ez ellentmond a v1 saját posztulátumának, amely szerint az L₀ rögzített.
- **A C(ρ) sötétanyag-ág (v8–v17).** Nincs levezetve, és ellentmond a v1-nek („a modell önmagában nem váltja ki a sötét anyagot”). A V28 galaxis-erősítése legfeljebb 1,08, miközben 2,7–4,3 kellene.
- **A H0/H1 óracsatolás (V23, step 8).** A H1 definíció szerint univerzális, így az óra ugyanazt az effektív potenciált méri, amely a szabadesést hajtja. Önálló órajel így nincs.
- **Az α_Y konvenció kettéválása.** A V23-ban lineáris (α = α_Y/(4π)), a V27/V28 kódban kvadratikus (q = α_Y² β_Yuk). A kettő csak α_Y = 1-nél egyezik.

---

## 3. Hibajegyzék: hibák a saját Step 29 elemzéseinkben

| Jel | Hol | Hiba | Hatás a következtetésekre |
|---|---|---|---|
| S1 | Ötödikerő-elemzés (`fifth_force_tests/docs/OTODIK_ERO_hu.md`) és a további tesztek összesítése | Azt állította, hogy α = 0,08 mellett nyitva marad egy λ ≳ 1,5·10¹⁵ m-es hosszú hatótávú ablak. Ez egy négyzetes távolságtörvény-kompiláció extrapolációja volt, és figyelmen kívül hagyta a Cassini-féle PPN-korlátot. | Nincs. A V28 kizárt marad. |
| S2 | Az optikai órás, Galileo-, ekvivalenciaelv-, fehértörpe- és errata-dokumentumok; a Galileo-jelentés | A H1-et „csak órákra ható” csatolásként írta le, és „L = 10 km-en megengedettnek” nevezte. A step 8 a H1-et univerzálisnak definiálja, és saját levezetésünk (B7) szerint a „csak óra” olvasat a hatásból nem vezethető le. | Nincs. A korlátok számszerűen érvényesek maradnak, de csak a „csak óra” posztulátumra. |
| S3 | Optikai órás és Galileo-dokumentumok; a Galileo-jelentés | Az α_Y = 1/3-os számok jelöletlenül csak a lineáris (V23) konvenciót használták, a V27/V28 viszont kvadratikus konvenciót használ. | Nincs. Az élek kb. 2,7–2,8-szorosan eltolódnak, az ítéletek nem változnak. |

---

## 4. Javítások

Minden szerkesztés előtt `*.pre_audit` biztonsági másolat készült a módosított fájl mellé. A 45 szerkesztés gépi naplója, a pontos régi és új szöveggel: `audit/results/s3/fix_log.json`.

### 4.1 S1: a hosszú ablak eltávolítása, a Cassini-korlát bevezetése

**Fizika.** Vegyünk egy skalárt, amely nem csatol a fényhez, és hatótávja jóval nagyobb a b ütközési paraméternél. Ez az effektív PPN-paramétert γ − 1 = −2α/(1+α)-val tolja el, ami α = 0,08-nál −0,147. A Cassini-mérés |γ − 1| < 2,3·10⁻⁵-öt követel meg.

**Saját egyskálás becslésünk (b = 1,6 R☉)** megadja, mekkora λ felett kizárt az adott α:

| α | Kizárt, ha λ ≳ |
|---|---|
| 0,0796 (V28) | 1,26·10⁸ m |
| 0,0265 (α_Y = 1/3, lineáris) | 1,44·10⁸ m |
| 0,00884 (α_Y = 1/3, kvadratikus) | 1,68·10⁸ m |

A J1738+0333 pulzár–fehér törpe kettős ettől függetlenül kizárja az L ≳ 1,5·10¹² m tartományt.

**Változtatások:**
- Az ötödikerő-kód most minden változatra Cassini-ellenőrzést végez, és `long_window_open = False` értéket állít be.
- A kizárási ábrán megjelenik a Cassini-sáv.
- Az eredményeket újrafuttattuk.
- A „csak λ ≲ 72 µm vagy λ ≳ 1,5·10¹⁵ m nyitott” szöveget mindenhol „csak λ ≲ 72 µm nyitott” váltja, a Cassini-élekkel együtt.

### 4.2 S2: a „csak órákra ható H1” megfogalmazás javítása mindenhol

**A helyes állítás, amely most minden érintett dokumentumban szerepel:**
- A TAL step 8 szerint a H1 univerzális csatolás. Az óra ekkor ugyanazt a potenciált (Φ/c² − φ) méri, amely a szabadesést hajtja, így önálló órajel nincs: minden H1-jel az α = 0,0796-os ötödik erővel együtt jár, amely 10 km-en kb. 176-szorosan kizárt.
- Az óraelemzéseinkben tesztelt „csak óra” olvasat fenomenologikus posztulátum, a hatásból nem vezethető le. Csak nem univerzális, fajtafüggő csatolásból jöhetne, amely általában sérti az ekvivalenciaelvet.
- Az általunk megadott H1-kizárási tartományok csak erre a posztulátumra érvényesek.
- Az, hogy „a H1 L = 10 km-en megengedett”, nem jelenti a V28 túlélését.

**Érintett, de még nem javított külső szöveg.** A H1-vitacikk r4-es revíziójában (`h1_discussion_EN_r4`) két részlet ütközik az S2-vel:
- a kivonat mondata: „One branch remains open: the clock-only coupling H1”;
- a 3.1. szakasz: „V23 defines H1 … that acts on the clock sector”.

Az r4 közzététele előtt a benne vizsgált óramodellt egyértelműen el kell választani a V23/V28 univerzális ágától. Addig az r4-et ebben a formában nem szabad közzétenni.

**Javított dokumentumok:**
- a további tesztek összesítése;
- az optikai órás elemzés;
- a Galileo step 6 és a Galileo-összefoglaló;
- a Galileo-jelentés (címlap, kivonat, motiváció, a kizárási tábla alatti megjegyzés, az L = 10 km-es bekezdés);
- a Galileo-csomag README-je;
- az ekvivalenciaelv-jegyzet (a H1 most η = 0-t ad, a teljes ötödik erővel együtt);
- a fehértörpe-dokumentumok;
- az errata (az F1 hatásának leírása);
- az óra-vöröseltolódási README;
- két szkript docstringje (csak a megfogalmazás változott, a számítás nem).

### 4.3 S3: az α_Y = 1/3-os értékek mindkét konvencióban

A lineáris (V23) konvencióban a jel α_Y-nal arányos, így α_Y = 1/3 az α_Y = 1-es eredmény harmadát adja, a telítés 0,0265. A kvadratikus (V27/V28) konvencióban α_Y²-tel arányos, így a kilencedét, a telítés 0,00884. A kvadratikus értékeket a meglévő α_Y = 1-es sablonokkal és ugyanazzal a likelihooddal számoltuk; a lineáris értékek visszaadják a tárolt eredményeket.

| Mennyiség | Lineáris (eddig) | Kvadratikus (új) |
|---|---|---|
| α_eff (Tokyo Skytree, L = 10 km) | 3,05·10⁻⁵ | 1,02·10⁻⁵ |
| Feszültség L = 10 km-en (Skytree) | 0,18σ | −0,04σ |
| Kombinált 95%-os alsó él | 51,2 km | 140,5 km |
| Egyoldali (z > 1,645) él | 44,3 km | 120,0 km |
| Feszültség ACES-projekcióval, L = 10 km | 0,36σ | 0,05σ |
| Galileo 95%-os él (végső / konzervatív / csak E14) | 3 262 / 3 518 / 3 320 km | ≳ 3 910 / 4 280 / 4 000 km |
| Telítés a 95%-os felső korláthoz képest | 0,0265 (kb. 320×) | 0,00884 (kb. 105×) |

Minden érintett érték mellett most fel van tüntetve a konvenció.

---

## 5. Az újraépített Galileo 5/6 jelentés és csomag

Mindkét fájl a korábbi nevén maradt. A javítás előtti változatok `*.pre_audit` néven megmaradtak.

- **`TAL_Galileo56_H1_ujraelemzes_hu.pdf`:** újragenerálva (11 oldal), az S2 és S3 változtatásokkal: címlap, kivonat (keretes értelmezési megjegyzéssel), motiváció, a kizárási tábla alatti megjegyzés, az L = 10 km-es bekezdés és a kvadratikus konvenciójú élek. **A mért eredmény változatlan:** α = (−0,40 ± 4,47)·10⁻⁵ (Galileo E14/E18; ESA végleges pályák és órák, 2016. augusztus – 2021. február; műholdas lézeres távmérés).
- **`TAL_Galileo56_H1_csomag.zip`:** újracsomagolva (108 fájl). Hét fájl változott:
  - az új PDF;
  - a jelentés LaTeX-forrása;
  - a csomag README-je;
  - a step 6 dokumentum;
  - az összefoglaló;
  - a referencia-README;
  - egy szkript docstringje.

  A belső `SHA256SUMS` frissült, és a `sha256sum -c` ellenőrzés hibátlan.

---

## 6. Az ellenőrzés köre

- A szerkesztéseket szkript végezte, és mindegyik szerepel a pontos régi és új szövegével az `audit/results/s3/fix_log.json` naplóban. Ez fájlonkénti ellenőrzést tesz lehetővé.
- A 2.4. és 2.6. szakasz gyengetér-állításai a statikus, gyenge tér és a pontrészecske-határeset elsőrendű eredményei, nem teljes kovariáns levezetések. A 2.6. szakasz állítása, hogy az f_L = exp(Φ/c²) nem ad új fizikát, csak akkor érvényes, ha f_L nem marad meg külön tényezőként az anyag hatásában; ha megmarad, Φ_eff = 2Φ (2.6. szakasz, (a) eset).

## 7. Következtetés

1. A levezetés először a *Time Attraction* v1–v7 3.1. szakaszában, a (10)–(11) egyenletnél törik el. A (9) egyenlet helyesen adja meg a newtoni potenciált. A (10) egyenlet a közönséges GR-vöröseltolódást új tényezőnek nevezi át, és elhagyja a 4π/3-ot. A (11) egyenlet ezt másodszor is hozzáadja az Einstein–Hilbert-tag mellé; gyenge térben az így kapott dinamika kétszer számolja a potenciált. Ez az f_L = exp(Φ/c²) választásnál is így marad, ha f_L külön tényezőként megmarad az anyag hatásában (Φ_eff = 2Φ). Csak ha f_L-t a g₀₀-ban már benne lévő órajárásként értelmezzük, esik egybe a GR-rel a gyenge tér első rendjében, és csak ekkor nem ad új fizikát.
2. Az így kapott gravitációs erősségű univerzális csatolást (α ≈ 0,0796, 10 km) az ötödikerő-mérések kb. 177-szeresen kizárják. Az L = 10 km hatótávot sosem vezették le.
3. Saját S1–S3 hibáinkat kijavítottuk:
   - hosszú hatótávú megengedett ablak nincs, mert a Cassini-korlát kizárja a λ ≳ 1,3·10⁸ m tartományt;
   - a „csak óra” H1 nem levezethető posztulátum, nem a V28;
   - az α_Y = 1/3-os értékek most mindkét konvencióban szerepelnek.
4. **Egyik javítás sem változtatja meg a következtetéseket.** A V28 univerzális formájában kizárt; a „csak óra” H1 posztulátum L = 10 km-en a Galileo-adatokkal továbbra sem tesztelhető; és egyetlen konzisztens TAL-változat sem ad mérhető, TAL-specifikus jelet.

---

## Függelék: fájljegyzék

Az útvonalak a mellékelt csomag (`academy_review_package.zip`) `verification/` mappájához képest értendők; ez a mappa a projekt szerkezetét követi.

- **A teljes audit (magyarul):** `audit/docs/AUDIT_hu.md`. A 9. fejezet a javítási napló, fájlonként a régi és új szöveggel.
- **Függőségi ábra:** `audit/results/plots/fuggosegi_diagram.png` (előállítja: `audit/code/plot_dependency.py`).
- **Szerkesztési napló:** `audit/results/s3/fix_log.json`; a kvadratikus S3-számok: `audit/results/s3/s3_quadratic.json`; a szimbolikus és numerikus ellenőrzések: `audit/results/verify.json`.
- **Szkriptek:** `audit/code/apply_s1_s3_fixes.py`, `audit/code/apply_tex_fixes.py`, `audit/code/s3_quadratic.py`, `audit/code/verify_sympy.py`.
- **A javított ötödikerő-elemzés:** `fifth_force_tests/docs/OTODIK_ERO_hu.md`, `fifth_force_tests/code/run_fifth_force.py`, `fifth_force_tests/results/` (a `*.pre_audit` változatokkal együtt).
- **A Galileo-jelentés és -csomag:** `TAL_Galileo56_H1_ujraelemzes_hu.pdf` és `TAL_Galileo56_H1_csomag.zip`, a csomag legfelső szintjén, nem a `verification/` mappában (a projektben: `galileo_reanalysis/export/`; bájtra azonosak, lásd `SHA256SUMS`).

A szkriptek abszolút útvonallal hivatkoznak az eredeti projektgyökérre; a más projektmappákból beolvasott bemeneti fájlok kérésre elérhetők a szerzőtől.

---

© 2026 Szabolcsi Dávid. Licenc: [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/).
