# Time Attraction Law: Location of the First Critical Break in the Derivation, and Corrections S1–S3 to the Step 29 Analyses

**Author:** Dávid Szabolcsi, independent researcher, Unterterzen, Switzerland (ORCID 0009-0005-6300-074X)
**Date:** 2 November 2026
**License:** [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/)
**Copyright:** © 2026 Dávid Szabolcsi
**Related records:**
- TAL V28, *Scalar-Tensor Yukawa Fit*: 10.5281/zenodo.23814053 (concept DOI 10.5281/zenodo.22983681)
- *Time Attraction* v1–v7: 10.5281/zenodo.23066993

---

## Abstract

This document reports a forensic audit of the derivation chain of the Time Attraction Law (TAL), from the first paper (*Time Attraction*, v1–v7) to the current version V28. The first critical break is in §3.1, Eqs. (9)–(11) of the first paper:

- **Eq. (9)** correctly writes down the ordinary Newtonian potential.
- **Eq. (10)** relabels the ordinary weak-field general-relativistic (GR) redshift, 1 + Φ/c², as a new "time attraction" factor f_L, and drops the geometric factor 4π/3 along the way.
- **Eq. (11)** inserts this factor into the action a second time, next to the Einstein–Hilbert term, so the GR time dilation is counted twice.

This double counting is what produces the universal, gravitational-strength fifth force of the later versions (α = 1/(4π) ≈ 0.0796 at λ = L = 10 km). Laboratory and geophysical fifth-force searches exclude that force by a factor of about 177. The double counting persists for the choice f_L = exp(Φ/c²) as long as f_L is retained as a separate factor in the matter action (Φ_eff = 2Φ); only if f_L is read as the clock rate already contained in g₀₀ does it coincide with GR, to first order in the weak field, and add no new physics.

The audit also found three errors in our own Step 29 analyses (S1–S3). This document describes them and their corrections:

- **S1:** a spurious long-range allowed window, now removed using the Cassini bound.
- **S2:** an incorrect "clock-only H1" wording, corrected throughout.
- **S3:** α_Y = 1/3 values that silently depended on one coupling convention, now given in both conventions.

The Galileo 5/6 reanalysis report (PDF) and its reproducibility package (ZIP) were rebuilt under the same file names. **None of the corrections changes any conclusion.**

---

## 1. Introduction

TAL was developed over many numbered versions. Its V28 form is a scalar–tensor theory with a Yukawa-type scalar of fixed range L = 10 km and coupling α_Y = 1, β_Yuk = 1/(4π), which gives a fifth-force strength α = 1/(4π) ≈ 0.0796.

In the Step 29 programme we tested this theory against:
- Galileo 5/6 clock data;
- optical-clock comparisons;
- fifth-force searches;
- screened variants;
- galaxy rotation curves and baryon acoustic oscillations;
- white dwarfs, neutron stars, gravitational waves, Big Bang nucleosynthesis and the cosmic microwave background;
- equivalence-principle tests.

Every consistent variant either failed or reduced to a theory with no TAL-specific prediction. We therefore audited the derivation chain itself, to find where it first goes wrong.

Our approach was to trace each inherited quantity (γ_L, α_Y, β_Yuk, α, L, ω_BD, the H0/H1 clock coupling) back to the version where it first appears, and to check each step symbolically and numerically.

This document reports two things:
- the earliest break that every later result inherits (Section 2);
- the errors we found in our own analyses and how they were fixed (Sections 3–4).

---

## 2. The first critical break: *Time Attraction* v1–v7, §3.1, Eqs. (9)–(11)

### 2.1 The equations as published

> Φ = −G_N ∫ ρ(x′) / |x − x′| d³x′,  |Φ_L| ≈ G M / L = (4π/3) G_N ρ̄_L L²  (9)
>
> f_L ≈ 1 + Φ_L/c² ≈ 1 − γ_L ρ̄_L  ⇒  f_L = exp(−γ_L ρ̄_L),  γ_L = G_N L²/c²  (10)
>
> S = ∫ d⁴x √−g [ R / (16π G_N) + f_L(ρ̄_L) L_m ]  (11)

### 2.2 Equation (9) is correct

Equation (9) is the ordinary Newtonian potential. For a homogeneous sphere of radius L and mean density ρ̄_L:
- the potential at the surface is |Φ| = (4π/3) G ρ̄_L L²;
- at the centre it is |Φ| = 2π G ρ̄_L L².

Nothing new appears at this stage.

### 2.3 Where Equation (10) goes wrong

1. **Relabelling.** The first step, f_L ≈ 1 + Φ_L/c², is exactly the weak-field GR gravitational redshift (the time-dilation factor √(−g₀₀) ≈ 1 + Φ/c²). The "time attraction" factor is therefore, at its origin, ordinary GR time dilation under a new name, not a new effect.
2. **Lost geometric factor.** In the second step, Φ_L/c² → −γ_L ρ̄_L with γ_L = G L²/c², the factor 4π/3 disappears. With the geometry kept, the consistent coefficient is (4π/3) G L²/c² at the surface or 2π G L²/c² at the centre. γ_L ρ̄_L is only 0.239 of the true surface potential.

### 2.4 Where Equation (11) goes wrong: double counting

Equation (11) multiplies the matter Lagrangian by f_L and keeps the Einstein–Hilbert term R/(16πG_N) unchanged. The form S_EH + f_L L_m is not, by itself, a double count; the double count shows up in the dynamics that follow from it.

**Derivation (weak-field, slow-motion, point-particle limit).** Take point-particle matter, L_m → −Σ m c² ∫ dτ. The matter action becomes −Σ m c² ∫ f_L dτ. The metric from S_EH already supplies the clock rate dτ ≈ (1 + Φ/c²) dt. To first order, a test mass therefore moves in the effective potential

  Φ_eff = Φ + c² ln f_L ≈ Φ + c² (f_L − 1).

Eq. (10) sets f_L − 1 ≈ Φ_L/c², which gives Φ_eff ≈ Φ + Φ_L. Φ is the potential already contained in GR; Φ_L is the same Newtonian potential again, smoothed over the scale L and normalised without the 4π/3 factor. In this limit, then, the action counts the gravitational potential twice: once through the metric and once through f_L. Because f_L is universal, the extra term acts on all matter as a fifth force of gravitational strength with range set by L. This is the origin of α = 1/(4π) in the later versions.

**Scope.** This derivation is restricted to the weak-field, slow-motion, point-particle limit. f_L depends on the smoothed density ρ̄_L, which itself depends on the matter fields, so the full covariant field equations of Eq. (11) contain additional terms. The audit did not derive those.

### 2.5 Why this break is critical

Every later normalisation of the theory descends from this γ_L:

- **V24 step 1:** "γ_L = G L²/c²".
- **V23 / step 5:** α_Y = 1 is chosen because it "reproduces the homogeneous top-hat limit (φ_L = γ_L ρ_src)"; the Yukawa kernel integrates to L².
- **V27 code:** `GAMMA_L = 4π β_Yuk G L²/c²`, commented "Since 4π β_Yuk = 1". In other words, β_Yuk = 1/(4π) was chosen backwards so that γ_L comes out.

The result is a coupling of gravitational strength, α = 1/(4π) ≈ 0.0796. At λ = 10 km the compiled bound is α₉₅ ≈ 4.5·10⁻⁴, so this value is excluded by a factor of about 177. Keeping the factor 4π/3 would not have helped: it would have given α ≈ 1/3, which is excluded even more strongly.

### 2.6 The consistent version

Carried through consistently, Eqs. (9)–(10) give f_L = exp(Φ/c²). Whether this choice adds new physics depends on how f_L enters the action, and two cases must be distinguished.

**(a) f_L retained as a separate factor in the matter action.** If the action keeps the form S_EH + f_L L_m of Eq. (11), substituting f_L = exp(Φ/c²) into the result of §2.4 gives Φ_eff = Φ + c² ln f_L = Φ + Φ = 2Φ. The potential is then still counted twice: free fall is governed by twice the Newtonian potential, whereas light propagation and clock rates are governed by the metric, i.e. by Φ. This is the same double counting as in §2.4, now with unit relative strength, and it is excluded on the same grounds (cf. the Cassini bound in §4.1). This choice therefore provides no consistent rescue of Eq. (11).

**(b) f_L not retained as a separate factor.** Only if f_L does not appear as an independent factor in the matter action, i.e. if f_L is read merely as the clock rate already contained in g₀₀ (the GR gravitational redshift itself), does f_L = exp(Φ/c²) coincide with the GR clock rate √(−g₀₀) ≈ 1 + Φ/c² in the static weak-field limit. In this case it adds no new physics. The statement holds only to first order in the weak field; it is not a claim that exp(Φ/c²) reproduces GR beyond the weak-field approximation.

New physics would require α and λ to be free parameters independent of GR. In that case the existing measurements bound them, and no TAL-specific value is singled out.

### 2.7 Secondary breaks (for completeness)

- **Laboratory prediction (v1 Eqs. 3 and 13).** It uses a local lab density in place of the L-sphere average, and Eq. (13) has the wrong sign. A 10 t mass gives about 5·10⁻²⁷ (L = 367 m) or about 2·10⁻²⁸ (L = 10 km), below the ordinary GR redshift of the same mass. The expected Step 29 lab signal therefore never followed from the theory; the solenoid signal is ≤ 2.4·10⁻⁴⁸.
- **L = 10 km.** It is never derived. It began as an illustrative neutron-star averaging window in v1, became a scan point in V21 and a fixed universal constant in V27/V28. This contradicts v1's own postulate of a fixed L₀.
- **Dark-matter branch C(ρ) (v8–v17).** It is not derived and contradicts v1 ("the model does not by itself replace dark matter"). The V28 galaxy boost is at most 1.08, while 2.7–4.3 is required.
- **H0/H1 clock coupling (V23, step 8).** H1 is defined as universal, so a clock measures the same effective potential that drives free fall. There is then no independent clock signal.
- **α_Y convention split.** It is linear in V23 (α = α_Y/(4π)) and quadratic in the V27/V28 code (q = α_Y² β_Yuk). The two agree only at α_Y = 1.

---

## 3. Error log: errors in our own Step 29 analyses

| ID | Where | Error | Effect on conclusions |
|---|---|---|---|
| S1 | Fifth-force analysis (`fifth_force_tests/docs/OTODIK_ERO_hu.md`) and the summary of further tests | It claimed that at α = 0.08 a long-range window λ ≳ 1.5·10¹⁵ m remains open. This extrapolated an inverse-square-law compilation and ignored the Cassini PPN bound. | None. V28 remains excluded. |
| S2 | Optical-clock, Galileo, equivalence-principle, white-dwarf and errata documents; the Galileo report | It described H1 as a "clock-only" coupling and called it "allowed at L = 10 km". Step 8 defines H1 as universal, and our own derivation (B7) shows that a clock-only reading cannot be derived from the action. | None. The bounds stay numerically valid, but only for the clock-only postulate. |
| S3 | Optical-clock and Galileo documents; the Galileo report | The α_Y = 1/3 numbers used only the linear (V23) convention and did not say so; V27/V28 use the quadratic convention. | None. Edges shift by a factor of about 2.7–2.8; the verdicts are unchanged. |

---

## 4. Corrections

Before any edit, a backup copy (`*.pre_audit`) was kept next to each modified file. A machine-readable log of all 45 edits, with the exact old and new text, is in `audit/results/s3/fix_log.json`.

### 4.1 S1: long-range window removed, Cassini bound added

**Physics.** Take a scalar that does not couple to light, with range much longer than the impact parameter b. It shifts the effective PPN parameter by γ − 1 = −2α/(1+α), which is −0.147 at α = 0.08. Cassini requires |γ − 1| < 2.3·10⁻⁵.

**Our single-scale estimate (b = 1.6 R☉)** gives the λ above which each α is excluded:

| α | Excluded for λ ≳ |
|---|---|
| 0.0796 (V28) | 1.26·10⁸ m |
| 0.0265 (α_Y = 1/3, linear) | 1.44·10⁸ m |
| 0.00884 (α_Y = 1/3, quadratic) | 1.68·10⁸ m |

The pulsar–white-dwarf binary J1738+0333 independently excludes L ≳ 1.5·10¹² m.

**Changes made:**
- The fifth-force code now evaluates a Cassini check for every variant and sets `long_window_open = False`.
- The exclusion plot shows the Cassini band.
- The results were re-run.
- The text "only λ ≲ 72 µm or λ ≳ 1.5·10¹⁵ m is open" was replaced everywhere by "only λ ≲ 72 µm is open", together with the Cassini edges.

### 4.2 S2: "clock-only H1" wording corrected everywhere

**Correct statement, now used in every affected document:**
- In TAL step 8, H1 is a universal coupling. A clock then measures the same potential (Φ/c² − φ) that drives free fall, so there is no independent clock signal: any H1 signal comes together with the α = 0.0796 fifth force, which is excluded at 10 km by about 176×.
- The clock-only reading tested in our clock analyses is a phenomenological postulate that cannot be derived from the action. It could only come from a non-universal, species-dependent coupling, which generically violates the equivalence principle.
- The H1 exclusion ranges we report apply only to this postulate.
- The statement "H1 is allowed at L = 10 km" does not mean that V28 survives.

**Affected text outside these analyses (not yet corrected).** The H1 discussion paper, revision r4 (`h1_discussion_EN_r4`), contains two passages that conflict with S2:
- the abstract sentence "One branch remains open: the clock-only coupling H1";
- §3.1, "V23 defines H1 … that acts on the clock sector".

Before r4 is published, the clock-only model it tests must be clearly separated from the universal V23/V28 branch. Until then, r4 should not be published in its current form.

**Documents corrected:**
- summary of further tests;
- optical-clock analysis;
- Galileo step 6 and Galileo summary;
- Galileo report (title page, abstract, motivation, exclusion-table note, L = 10 km paragraph);
- Galileo package README;
- equivalence-principle note (H1 now gives η = 0 together with the full fifth force);
- white-dwarf documents;
- errata (F1 impact statement);
- clock-redshift README;
- docstrings of two scripts (wording only, no change to the computation).

### 4.3 S3: α_Y = 1/3 values given in both conventions

In the linear (V23) convention the signal scales as α_Y, so α_Y = 1/3 gives 1/3 of the α_Y = 1 result, with saturation at 0.0265. In the quadratic (V27/V28) convention it scales as α_Y², giving 1/9, with saturation at 0.00884. We computed the quadratic values with the existing α_Y = 1 templates and the same likelihood; the linear values reproduce the stored results.

| Quantity | Linear (as before) | Quadratic (added) |
|---|---|---|
| α_eff (Tokyo Skytree, L = 10 km) | 3.05·10⁻⁵ | 1.02·10⁻⁵ |
| Tension at L = 10 km (Skytree) | 0.18σ | −0.04σ |
| Combined 95% lower edge | 51.2 km | 140.5 km |
| One-sided (z > 1.645) edge | 44.3 km | 120.0 km |
| Tension with ACES projection, L = 10 km | 0.36σ | 0.05σ |
| Galileo 95% edge (final / conservative / E14 only) | 3,262 / 3,518 / 3,320 km | ≳ 3,910 / 4,280 / 4,000 km |
| Saturation versus 95% upper bound | 0.0265 (about 320×) | 0.00884 (about 105×) |

Every affected value is now labelled with its convention.

---

## 5. Rebuilt Galileo 5/6 report and package

Both files keep their previous names. The pre-correction versions are kept as `*.pre_audit`.

- **`TAL_Galileo56_H1_ujraelemzes_hu.pdf`** was regenerated (11 pages) with the S2 and S3 changes: the title page, the abstract (with a boxed interpretation note), the motivation, the exclusion-table note, the L = 10 km paragraph and the quadratic-convention edges. **The measured result is unchanged:** α = (−0.40 ± 4.47)·10⁻⁵ (Galileo E14/E18, ESA final orbits and clocks, August 2016 to February 2021, with satellite laser ranging).
- **`TAL_Galileo56_H1_csomag.zip`** was repacked (108 files). Seven files changed:
  - the new PDF;
  - the report's LaTeX source;
  - the package README;
  - the step 6 document;
  - the summary;
  - the reference README;
  - one script docstring.

  The internal `SHA256SUMS` was updated, and `sha256sum -c` passes.

---

## 6. Scope of verification

- The edits were applied by script, and each one is recorded with its exact old and new text in `audit/results/s3/fix_log.json`. This allows file-by-file checking.
- The weak-field statements in §2.4 and §2.6 are first-order results in the static weak-field, point-particle limit, not full covariant derivations. The statement in §2.6 that f_L = exp(Φ/c²) adds no new physics applies only if f_L is not retained as a separate factor in the matter action; if it is retained, Φ_eff = 2Φ (§2.6, case a).

## 7. Conclusion

1. The derivation first breaks in *Time Attraction* v1–v7, §3.1, Eqs. (10)–(11). Eq. (9) correctly gives the Newtonian potential. Eq. (10) relabels the ordinary GR redshift as a new factor and drops 4π/3. Eq. (11) adds it a second time beside the Einstein–Hilbert term; in the weak-field limit the resulting dynamics count the potential twice. This remains so for f_L = exp(Φ/c²) as long as f_L is retained as a separate factor in the matter action (Φ_eff = 2Φ). Only if f_L is read as the clock rate already contained in g₀₀ does it coincide with GR, to first order in the weak field, and then it adds no new physics.
2. The resulting gravitational-strength universal coupling (α ≈ 0.0796 at 10 km) is excluded by fifth-force measurements by about 177×. The range L = 10 km was never derived.
3. Our own errors S1–S3 have been corrected:
   - there is no long-range allowed window, because Cassini excludes λ ≳ 1.3·10⁸ m;
   - "clock-only H1" is a non-derivable postulate, not V28;
   - α_Y = 1/3 values are now given in both conventions.
4. **None of the corrections changes the conclusions.** V28 in its universal form is excluded; the clock-only H1 postulate remains untestable at L = 10 km by Galileo; and no consistent TAL variant gives a measurable, TAL-specific signal.

---

## Appendix: file inventory

Paths are relative to the `verification/` folder of the accompanying package (`academy_review_package.zip`), which mirrors the project layout.

- **Full audit, Hungarian:** `audit/docs/AUDIT_hu.md`. Chapter 9 is the change log with old and new text per file.
- **Dependency diagram:** `audit/results/plots/fuggosegi_diagram.png` (generated by `audit/code/plot_dependency.py`).
- **Edit log:** `audit/results/s3/fix_log.json`; quadratic S3 numbers in `audit/results/s3/s3_quadratic.json`; symbolic and numerical checks in `audit/results/verify.json`.
- **Scripts:** `audit/code/apply_s1_s3_fixes.py`, `audit/code/apply_tex_fixes.py`, `audit/code/s3_quadratic.py`, `audit/code/verify_sympy.py`.
- **Corrected fifth-force analysis:** `fifth_force_tests/docs/OTODIK_ERO_hu.md`, `fifth_force_tests/code/run_fifth_force.py`, `fifth_force_tests/results/` (with the `*.pre_audit` versions).
- **Galileo report and package:** `TAL_Galileo56_H1_ujraelemzes_hu.pdf` and `TAL_Galileo56_H1_csomag.zip`, at the top level of the package rather than under `verification/` (in the project: `galileo_reanalysis/export/`; byte-identical, see `SHA256SUMS`).

The scripts refer to the original project root by absolute path; inputs they read from other project folders are available from the author on request.

---

© 2026 Dávid Szabolcsi. License: [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/).
