# TAL – Academy review package / Akadémiai ellenőrzési csomag

**Author / Szerző:** Dávid Szabolcsi (ORCID 0009-0005-6300-074X)
**Date / Dátum:** 2 November 2026 / 2026. november 2.
**License / Licenc:** [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). © 2026 Dávid Szabolcsi

---

## English

**Purpose.** This package documents two things:
- where the derivation of the Time Attraction Law (TAL) first breaks: *Time Attraction* v1–v7, §3.1, Eqs. (9)–(11);
- the corrections S1–S3 to our own Step 29 analyses:
  - **S1:** the long-range window is removed and the Cassini bound is added;
  - **S2:** the "clock-only H1" wording is corrected;
  - **S3:** α_Y = 1/3 values are given in both conventions.

None of the corrections changes the conclusions.

**Contents** (the main document is file 1):

| # | File | Description |
|---|---|---|
| 1 | `TAL_audit_and_corrections_EN.md` | Main document (English): the first critical break, the S1–S3 error log and fixes, the scope of verification, and the conclusion. |
| 2 | `TAL_audit_es_javitasok_HU.md` | Hungarian version of document 1, for reading. |
| 3 | `TAL_Galileo56_H1_ujraelemzes_hu.pdf` | Galileo 5/6 reanalysis report (Hungarian, 11 pages), rebuilt with the S2 and S3 fixes. The measured result is unchanged: α = (−0.40 ± 4.47)·10⁻⁵. |
| 4 | `TAL_Galileo56_H1_csomag.zip` | Galileo reproducibility package (108 files, 7 updated). Its internal SHA256SUMS check passes. |
| 5 | `OTODIK_ERO_hu.md` | Corrected fifth-force analysis (Hungarian; S1: no long-range window, Cassini bound added). |
| 6 | `fuggosegi_diagram.png` | Dependency diagram of the derivation chain. |
| 7 | `fix_log.json` | Machine log of all 45 edits, with the exact old and new text. |
| 8 | `TAL_audit_and_corrections_EN.pdf` | Typeset PDF of document 1 (7 pages). |
| 9 | `TAL_audit_es_javitasok_HU.pdf` | Typeset PDF of document 2 (7 pages). |
| 10 | `verification/` | Verification files cited in the appendix of documents 1 and 2, in the project's folder layout: the full Hungarian audit, the edit log, the quadratic S3 results, the symbolic and numerical checks, the audit scripts, and the corrected fifth-force analysis with its code and results. The appendix paths are relative to this folder. |
| – | `SHA256SUMS` | Checksums of all files in this package, including those under `verification/` (relative paths; check with `sha256sum -c SHA256SUMS`). |

---

## Magyar

**Cél.** A csomag két dolgot dokumentál:
- hol törik el először a Time Attraction Law (TAL) levezetése: *Time Attraction* v1–v7, 3.1. szakasz, (9)–(11) egyenlet;
- a saját Step 29 elemzéseink S1–S3 javításait:
  - **S1:** kikerült a hosszú hatótávú ablak, bekerült a Cassini-korlát;
  - **S2:** javítottuk a „csak órákra ható H1” megfogalmazást;
  - **S3:** az α_Y = 1/3-os értékek mindkét konvencióban szerepelnek.

Egyik javítás sem változtatja meg a következtetéseket.

**Tartalom** (a fő dokumentum az 1. fájl):

| # | Fájl | Leírás |
|---|---|---|
| 1 | `TAL_audit_and_corrections_EN.md` | Fő dokumentum (angol): az első kritikus törés, az S1–S3 hibajegyzék és javítások, az ellenőrzés köre és a következtetés. |
| 2 | `TAL_audit_es_javitasok_HU.md` | Az 1. dokumentum magyar változata, átolvasáshoz. |
| 3 | `TAL_Galileo56_H1_ujraelemzes_hu.pdf` | A Galileo 5/6 újraelemzés jelentése (11 oldal), az S2 és S3 javításokkal újraépítve. A mért eredmény változatlan: α = (−0,40 ± 4,47)·10⁻⁵. |
| 4 | `TAL_Galileo56_H1_csomag.zip` | A Galileo reprodukálhatósági csomag (108 fájl, ebből 7 frissült). A belső SHA256SUMS ellenőrzés hibátlan. |
| 5 | `OTODIK_ERO_hu.md` | A javított ötödikerő-elemzés (S1: nincs hosszú ablak, bekerült a Cassini-korlát). |
| 6 | `fuggosegi_diagram.png` | A levezetési lánc függőségi ábrája. |
| 7 | `fix_log.json` | Mind a 45 szerkesztés gépi naplója, a pontos régi és új szöveggel. |
| 8 | `TAL_audit_and_corrections_EN.pdf` | Az 1. dokumentum szedett PDF-változata (7 oldal). |
| 9 | `TAL_audit_es_javitasok_HU.pdf` | A 2. dokumentum szedett PDF-változata (7 oldal). |
| 10 | `verification/` | Az 1. és 2. dokumentum függelékében hivatkozott ellenőrző fájlok, a projekt mappaszerkezetében: a teljes magyar audit, a szerkesztési napló, a kvadratikus S3-eredmények, a szimbolikus és numerikus ellenőrzések, az audit szkriptjei, valamint a javított ötödikerő-elemzés kóddal és eredményekkel. A függelék útvonalai ehhez a mappához képest értendők. |
| – | `SHA256SUMS` | A csomag összes fájljának ellenőrzőösszegei, a `verification/` mappáéi is (relatív útvonalakkal; ellenőrzés: `sha256sum -c SHA256SUMS`). |
