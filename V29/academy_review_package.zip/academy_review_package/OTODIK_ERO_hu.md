# V28 univerzális csatolású (A²(φ)g) Yukawa-ág – ötödik-erő / Yukawa-korlátok

*Munkakönyvtár: `/workspace/artifacts/tal-step29-lab/fifth_force_tests/` · készült: 2026-11-01 (CET)*
*Kód: `code/` · eredmények: `results/` · digitalizált görbék: `data/`*

## 0. Rövid válasz

A V28 rögzített ága a standard paraméterezésben **α = +1/(4π) = 0,0796 (vonzó), λ = 10 km**.
Ez **nem α = 1**. Az ág univerzális, nincs benne árnyékolás (screening), és nincs összetételfüggése.

Ez a pont **kizárt**:

- **Összesített (kompilált) korlát.** Adelberger–Heckel–Nelson 2003, 4. ábra (95% CL), saját pixel-digitalizálással: λ = 10 km-nél α₉₅ ≈ **4,5·10⁻⁴**. A modell ennél **≈ 176-szor** nagyobb.
- **Független, csak az absztraktokból ellenőrizhető újraszámolások.** Idealizált geometriát és a legóvatosabb, 1800 kg/m³ sűrűséget feltételeztem. Az egyes kísérletek eltérései:

  | Kísérlet | Eltérés |
  |---|---|
  | Romaides 1997 torony | **97σ** |
  | Romaides 1994 torony | **88σ** |
  | Erie torony | **61σ** |
  | óceáni G (Zumberge 1991) | **54σ** |
  | BREN torony (két forrás) | **26σ**, illetve **25σ** |

- **Hibatűrés.** A legrosszabb esetben is legalább **13-szorosra** kellene növelni a hibákat ahhoz, hogy a V28 2σ-n belül legyen.

A kizárás tehát nem egyetlen mérésen múlik. Legalább öt független kísérlet, két különböző módszerrel (torony és óceán) mutatja ugyanezt.

**Megengedett tartomány:**

- λ = 10 km-nél α ≲ 4,5·10⁻⁴ (95%). V28-nyelven:
  - α_Y ≲ 0,075 (a V28-akció kvadratikus konvenciójában, α = α_Y²/(4π));
  - α_Y ≲ 0,0057 (a Step 5 lineáris konvenciójában, α = α_Y/(4π)).
- Rögzített α = 0,0796 mellett **csak egy λ-tartomány marad nyitva: λ ≲ 72 µm** (a Lee+2020 görbe alatt).
  - *Javítva (audit S1, 2026-11-01):* a korábbi változat egy második, hosszú hatótávú ablakot is említett (λ ≳ 1,5·10¹⁵ m, extrapolálva). Ez **hibás** volt. Az ISL-/bolygómozgási burkoló λ ≫ pályasugár esetén elveszti az érzékenységét, de egy fényhez nem csatoló skalárra a Cassini-féle γ_PPN-korlát (|γ−1| < 2,3·10⁻⁵, Bertotti+2003) megmarad: λ ≫ b esetén γ−1 = −2α/(1+α) = −0,147.
  - Saját, **egyskálás becslésünk** szerint (b = 1,6 R☉; nem teljes Yukawa-fényterjedési illesztés): α = 0,0796 kizárt λ ≳ **1,3·10⁸ m**-től (α = 0,0265: ≳ 1,4·10⁸ m; α = 0,0088: ≳ 1,7·10⁸ m). A Cassini-tartomány átfed az ISL-/bolygómozgási burkolóval, így **nincs hosszú hatótávú ablak**.
- A 72 µm feletti teljes tartomány kizárt. Egyetlen kivétel az 1 mm–1 cm szakasz, amelyet nem digitalizáltam (lásd a 6. pontot); ezt a szomszédos görbék alapján jelölten kizártnak tekintem.

## 1. A V28 paraméterei és előjelkonvenciói (forrás a gépen)

**Akció és csatolás** (`ta-v27-work/hubble_desi_bao_test/tal_cosmology_common.py`, 43–64. sor; V28 README):

- S = ∫√−g [c⁴R/16πG − (c⁴/4πGβ_Yuk)(½(∂φ)² + φ²/2L²) − ρ_vac c²] + S_m[Ψ, A²(φ)g], ahol A = e^{α_Y φ}.
- Paraméterek: L = 10 km, α_Y = 1, β_Yuk = 1/(4π).

**Pontforrás:**

- φ = −α_Y β_Yuk GM e^{−r/L}/(c² r) < 0.
- A próbatest potenciálja: c²α_Y φ = −α_Y² β_Yuk GM e^{−r/L}/r.
- Ebből **V = −G∞Mm/r · (1 + α e^{−r/λ})**, ahol **α = α_Y² β_Yuk = 1/(4π) = 0,0795775** és λ = L.
- α > 0, tehát a többleterő **vonzó**.

**Step 5** (`scalar-tensor-yukawa-fit/step5_coupling_dictionary_ppn_screening_en.md`):

- α_std = α_Y/(4π) = 2β²; G_eff(r) = G[1 + α_std(1 + r/L)e^{−r/L}].
- α_Y = 1 esetén ugyanaz: α = 0,0796.
- **Eltérés α_Y = 1/3-nál:**
  - a Step 5 lineáris képlete szerint α = 1/(12π) = 0,0265;
  - a V28-akció kvadratikus képlete szerint α = 1/(36π) = 0,0088.
- Mindkét értéket vizsgáltam.

**G-szótár:**

- G_lab = G∞(1 + α), mert r ≪ λ.
- Minden laboratóriumi G-mérés (cm–100 m skálán) ugyanazt a G∞(1 + α)-t méri. Ezért a CODATA G-értékek szórása erről az ágról **semmit nem mond**.

**Árnyékolás: nincs.**

- A Step 26 szövege: „no screening branch is introduced”.
- A Step 11 kaméleon/szimmetron mechanizmusa külön, önálló hipotézis („Branch II-Cham”), nem része a rögzített ágnak.
- A Step 5-ben a „screened” szó csak az e^{−r/L} lecsengést jelenti.

**Összetétel: univerzális.** Ekvivalencia-elvi (EP) jel nincs, tehát kizárólag a fordított négyzetes törvény (ISL) tesztjei számítanak.

**L tartománya:** a V28 anyagokban L = 10 km rögzített érték. **Megengedett L-sávot nem találtam** (README, step1–27, cosmology_common, simulator). A „megengedett tartományt” ezért itt én határozom meg (lásd a 0. és 4. pontot).

**A Step 27 „R ≈ 11–160 (feltételes)” jelentése:**

- R = α_modell / α_lim(10 km), vagyis arányszám, **nem szignifikancia**.
- Saját, idealizált újraszámolásokon alapult (óceán: R = 35; tornyok: R = 10,5–160), rögzített G_lab mellett.
- A jelen munka két dolgot tesz hozzá:
  1. az absztraktokból ellenőrizhető σ-szinteket;
  2. a G_óceán–G_lab összevetést.

  Mindkettő megerősíti a Step 27 eredményét.

**Top-hat kontra Yukawa:**

- A V28 ága pontosan Yukawa (Helmholtz-Green-függvény), ezért kiterjedt testekre a szuperpozíció egzakt.
- Kiegészítő változatként a V19–V21 top-hat kernelt (I. formuláció) is „univerzális erőként” végigvezettem a geometriákon:
  - Φ_x = −(3α_Y GM/4πL)·Θ(L − r);
  - a térfogati illesztés itt is α = α_Y/(4π)-t adja.
- Ez **nem** a V28 ág. Csak azt mutatja, mennyit számít a kernel alakja.

## 2. Ellenőrzött publikált korlátok és bemenetek

A DOI-kat és absztraktokat 2026-11-01-én ellenőriztem (APS / DOI / INSPIRE / arXiv).

| Kísérlet | Adat (absztrakt szerint) | Forrás |
|---|---|---|
| Thomas+ 1989, BREN-torony (Nevada), 465 m | (−60 ± 95) µGal a csúcson | PRL 63, 1902, doi:10.1103/PhysRevLett.63.1902 |
| BREN LLNL-jelentés, 454 m | 93 ± 95 µGal; az előjel nincs megadva, ezért konzervatívan −93-at vettem | OSTI 6190822 (a Step 27 olvasata) |
| Romaides+ 1994, WABG (Mississippi) | (−33 ± 30) µGal, 493 m | PRD 50, 3608, doi:10.1103/PhysRevD.50.3608 |
| Romaides+ 1997, WABG | (32 ± 32) µGal, 568 m | PRD 55, 4532, doi:10.1103/PhysRevD.55.4532 |
| Speake+ 1990 / JGR 1991, Erie (Colorado), 300 m | rms maradék 10 µGal; csúcshiba 14 µGal (mérés) + 23 µGal (predikció); \|α\| < 0,001 λ = 1 km-nél | PRL 65, 1967, doi:10.1103/PhysRevLett.65.1967; doi:10.1029/91JB01756 |
| Zumberge+ 1991, óceán (tengeralattjáró, 5000 m-ig) | G = (6,677 ± 0,013)·10⁻¹¹, „consistent with laboratory” | PRL 67, 3051, doi:10.1103/PhysRevLett.67.3051 |
| Ugyanez March+ 2019 olvasatában | maradékmeredekség −0,060 ± 0,172 mGal/km (500–4800 m); rétegmodell: víz 1037 kg/m³ 5000 m-ig, kéreg 2860, köpeny 3400 | PRD 100, 042002, arXiv:1904.12789 |
| Ander+ 1989, grönlandi fúrólyuk | 3,87 mGal anomália 1460 m-en; geológiával is magyarázható | PRL 62, 985, doi:10.1103/PhysRevLett.62.985 |
| Hubler+ 1995, Gigerwald-tó | G 88 és 112 m-en; összhangban a laborral | PRD 51, 4005, doi:10.1103/PhysRevD.51.4005 |
| Achilli+ 1997, Brasimone-tó | >9σ eltérés; **taszító** Yukawát javasoltak; később kalibrációs problémát jeleztek | Nuovo Cim. B 112, 775 |
| Stacey+ 1987, bányák | áttekintés | RMP 59, 157, doi:10.1103/RevModPhys.59.157 |
| Adelberger+ 2003, 4. ábra | 95% CL burkoló λ > 1 cm-re (Fischbach & Talmadge 1999, 2.13. ábra + LLR) | ARNPS 53, 77, arXiv:hep-ph/0307284 (PDF 76. o.) |
| Lee+ 2020, 5. ábra | 95% CL; \|α\| = 1 → λ < 38,6 µm | PRL 124, 101101, arXiv:2002.11761 |
| Murata & Tanaka 2015 | áttekintés (rövid hatótáv) | CQG 32, 033001, doi:10.1088/0264-9381/32/3/033001 |
| Yale, Sandwell, Herring 1998 | hajós és altimetriás gravitáció a Mexikói-öbölben, 40 profil: „mean differences generally less than 1 mGal” | The Leading Edge, 1998. jan., 73–76; topex.ucsd.edu/sandwell/publications/75.pdf |

**Digitalizálás:**

- **Adelberger 2003, 4. ábra.**
  - Módszer: 400 dpi-s render; a sárga tiltott terület alsó határán a fekete vonal középpontját olvastam le.
  - Kalibráció a belső osztásjelekből: 10⁻² … 10⁻¹⁰.
  - Eredmény: α₉₅(10 km) = 4,53·10⁻⁴. A Step 27 független leolvasása 4,46·10⁻⁴ volt, a különbség 1,5%.
  - Bizonytalanság: ±0,05 dex.
- **Lee 2020, 5. ábra.**
  - A forrás vektoros PDF-ábrája az arXiv-ról, 440 dpi-n renderelve.
  - Ellenőrzés: \|α\| = 1-nél az él 36,6 µm, a közölt érték 38,6 µm, tehát kb. −5%.

**Fizetős vagy nem elért elsődleges szövegek** (csak absztraktot használtam): Thomas 1989, Romaides 1994/97, Speake 1990, Zumberge 1991, Achilli 1997, Stacey 1987, Fischbach–Talmadge 1999 (könyv). Bejelentkezést nem kíséreltem meg.

## 3. Módszer: a kernel végigvezetése a geometrián

**Alapformula.** Rétegzett, laterálisan homogén modellben a többlet lefelé mutató tér:

g_x(z) = Σ_k Δρ_k K(z_k − z),

ahol:

- Yukawa-kernel: K_Y(s) = 2πG∞αλ e^{−|s|/λ};
- top-hat kernel: K_TH(s) = (3α_Y G/4L)(L² − s²)Θ(L − |s|).

**Tornyok:**

- A predikció a felszíni tér harmonikus (Laplace-) folytatása, a normál szabadlevegő-gradienssel.
- Laterálisan homogén többlettér konstansként folytatódik, ezért a maradék: Δg(h) = g_x(h) − g_x(0).
- Yukawára ez −2πG∞αρλ(1 − e^{−h/λ}), vagyis negatív: a csúcson kevesebb a gravitáció, mint a predikció.

**Óceán:**

- A Newtoni predikció G_lab-bal számol, a valóság G∞-nel számol, plusz a többlettér.
- A maradék: +4πG_lab α/(1 + α)·ρ_w z + Δg_x(z). Ennek legkisebb négyzetes meredekségét illesztettem 500–4800 m között.
- Egy profilillesztés ebből G_fit = G_lab − s/(4πρ_w) értéket kapna. Ezt vetettem össze Zumberge G-jével, ami csak az absztraktra támaszkodik.

**95%-os korlát (konzervatív):**

α₉₅ = (max(−előjel·m, 0) + 1,96σ) / |dmodell/dα|

A modell felé eső mért eltolódást nem írtam jóvá.

**Sűrűség:**

- Tornyoknál ρ ∈ [1800, 2670] kg/m³. Ez feltevés, nem a cikkekből származik.
- Az óceánnál a March+ 2019 rétegmodelljét használtam, plusz változatokat: H = 5–6 km, kéregsűrűség 2670–3000.

## 4. Eredmények (λ = 10 km)

Forrás: `results/fifth_force_results.json`, `results/run_log.txt`.

### 4.1 Tornyok (V28, α = 0,0796)

| Kísérlet | Modell a csúcson (ρ = 1800 / 2670) | Mért | z (1800 / 2670) | α₉₅ (ρ = 1800) |
|---|---|---|---|---|
| Thomas 1989 BREN, 465 m | −2528 / −3750 µGal | −60 ± 95 | 26 / 39σ | 0,0070 |
| BREN OSTI, 454 m | −2470 / −3664 | −93 ± 95 | 25 / 38σ | 0,0080 |
| Romaides 1994, 493 m | −2677 / −3970 | −33 ± 30 | 88 / 131σ | 0,0030 |
| Romaides 1997, 568 m | −3072 / −4557 | +32 ± 32 | 97 / 143σ | 0,0015 |
| Erie, 300 m | −1644 / −2439 | 0 ± 27 | 61 / 91σ | 0,0020 |

Összevetésül: Eckhardt+ 1988 (WTVD) eredetileg −500 ± 35 µGal anomáliát jelentett 562 m-en. Ezt Jekeli+ 1990 (PRL 64, 1204) további felszíni adatokkal megszüntette. A V28 ennek a már visszavont anomáliának is kb. hatszorosát jósolná.

### 4.2 Óceán (Zumberge 1991)

**Modellmeredekség:**

- **+9,07 mGal/km** (alapmodell);
- 8,37–9,25 mGal/km a modellváltozatokban;
- egységnyi α-ra 123,1 mGal/km, ami egyezik a Step 27 értékével.

**Összevetés a méréssel:**

- A mért meredekség −0,060 ± 0,172, az eltérés **53σ**.
- G-ben kifejezve: a modell G_fit/G_lab − 1 = **−10,4%**-ot jósol. Zumberge mérése +0,04% ± 0,19% (CODATA 2018 G_lab-hoz viszonyítva). Ez **54σ** eltérés, és csak az absztrakt adatait használja.
- A két független módszer (meredekség és G) egyezik.

**Korlát:** α₉₅(10 km) ≈ 0,0027, mindkét módszerrel.

### 4.3 Kombinált eredmény és robusztusság

**Együttes illesztés:** a 4 torony + Erie + óceán együtt, ρ = 1800 mellett, csak statisztikai hibákkal Δχ² ≈ 2,5·10⁴, ami kb. 158σ. A sűrűség korrelált szisztematikus hiba, ezért ez a szám csak tájékoztató. A mérvadó a legkisebb egyedi eltérés: **≥ 25σ**.

**Szükséges hibanövelés a 2σ-hoz (ρ = 1800):**

| Kísérlet | Szorzó |
|---|---|
| BREN | ×13 |
| óceán | ×27 |
| Erie | ×31 |
| Romaides | ×45–49 |

A BREN-jelentés kb. 100 µGal-os gömbközelítési szisztematikát jelez. Ez a modell jelének kevesebb mint 5%-a.

**α_Y = 1/3 változatok:**

- α = 0,0265 (Step 5): z = 8,7–97σ; óceán 19σ.
- α = 0,0088 (V28-akció): z = 2,1–17,9σ; óceán 6,6σ.
- Mindkettő kizárt, az utóbbi a legérzékenyebb tornyok és az óceán alapján.

### 4.4 Kiegészítő top-hat változat (α_Y = 1, nem a V28 ág)

- A felszínen a gradiens nulla, a maradék −(3Gρ/4L)h²-tel nő.
- Eredmény (ρ = 1800 / 2670):

  | Kísérlet | z |
  |---|---|
  | Thomas | 1,4 / 2,4σ |
  | BREN | 1,0 / 1,9σ |
  | Erie | 3,0 / 4,5σ |
  | Romaides 1994 | 6,2 / 9,7σ |
  | Romaides 1997 | 10 / 14σ |
  | óceán | 29σ |

- Ez a változat is kizárt, csak gyengébben, mert a felszín közelében másodrendű.

### 4.5 Összesített görbék és megengedett ablak

**Adelberger 2003, α₉₅:**

| λ | α₉₅ |
|---|---|
| 100 m | 2,25·10⁻³ |
| 1 km | 6,0·10⁻⁴ |
| 10 km | **4,5·10⁻⁴** |
| 31,6 km | 3,0·10⁻⁴ |
| 100 km | 7,3·10⁻⁵ |
| 1000 km | 5,4·10⁻⁶ |

A V28 pontja ennél **176-szor** nagyobb.

**Rögzített α mellett megengedett λ:**

| α | λ ≲ (nyitott) | ISL/bolygó-burkoló hosszú éle (régi „λ ≳”) | Cassini γ_PPN: kizárt λ ≳ (saját egyskálás becslés) | Hosszú ablak |
|---|---|---|---|---|
| 0,0796 | 72 µm | 1,5·10¹⁵ m (extrapolált) | 1,3·10⁸ m | **nincs** |
| 0,0265 | 93 µm | 8,5·10¹⁴ m | 1,4·10⁸ m | **nincs** |
| 0,0088 | 132 µm | 4,9·10¹⁴ m | 1,7·10⁸ m | **nincs** |

*Javítva (audit S1):* a régi táblázat a 3. oszlopot megengedett tartományként adta meg. A Cassini-korlát ezt bezárja.

**A korábbi optikaióra-teszttel összevetve** (`optical_clock_tests`): az órák λ = 10 km-nél nem zártak ki (Yukawa α_Y = 1: 0,85σ). Az ötödik-erő tesztek ennél nagyságrendekkel érzékenyebbek, a kettő nem mond ellent egymásnak.

## 5. A G_lab és a nagy skálájú G kapcsolata

**Miért nincs közvetlen jel:**

- λ = 10 km-nél minden laboratóriumi és tavi G-mérés (Hubler, Moore, Müller, Cornaz) r ≪ λ távolságon mér. Mind G∞(1 + α)-t méri, az eltérés ~α r²/2λ² ≤ 10⁻⁵ nagyságrendű.
- A műholdas GM a G∞M szorzatot méri, M pedig független mérésből nem ismert.
- A G_lab és GM_Föld puszta összevetése tehát **nem korlátoz**.

**Ahol mégis megjelenik a jel:**

- **Óceáni G (Zumberge).** Ez közvetlenül G(r ~ km) és G_lab összevetése, lásd a 4.2 pontot: 54σ.
- **Szabadlevegő-anomália torzulása.** A felszíni gravitáció a GM-alapú normál gravitációhoz képest kb. +62–83 mGal-lal (szárazföld), illetve +56–73 mGal-lal (sekély tenger) torzulna.
  - A hajós gravitáció abszolút módon kötődik a kikötői bázispontokhoz, ezért ezt a torzulást hordozná. Az altimetriás gravitáció a geoid lejtéséből származik, laterálisan homogén eltolást nem lát.
  - A Mexikói-öbölben a 40 profil átlagos eltérése „általában < 1 mGal” (Yale+ 1998), szemben a jósolt kb. 60–70 mGal-lal.
  - **Ezt csak alátámasztásnak tekintem.** Az altimetriás rácsok referenciamodellje (EGM96) felszíni adatokat is tartalmaz, és a kikötői bekötési hibák elérhetik a 13–25 mGal-t (Sandwell & Smith 1997). Még 25 mGal-os hibát feltételezve is kb. háromszoros a hiány.
- **Függőleges gradiens.** A többlet 2πG∞αρ = 0,0083 mGal/m (ρ = 2670), ami a normál 0,3086 mGal/m-es gradiens kb. 2,7%-a. Ez a helyi anomáliák szórásán belül van, ezért önmagában nem jó teszt.
- **Bányák (Stacey).** Mért felszíni gradienssel a jel kiesik; elméleti gradienssel G_bánya/G_lab ≈ 1 − α/2. Ez modellfüggő, ezért nem használtam.

## 6. Fenntartások

1. **Idealizált geometria.** Sík, homogén féltér, terep nélkül. Ez 10–30%-os hatás lehet, a kizárás mértéke pedig ×13–×176, tehát nem változtat a végeredményen. A tornyok közölt magasságonkénti maradékait nem használtam.
2. **A sűrűség feltevés.** A konzervatív 1800 kg/m³ alsó érték.
3. **A predikciós lánc értelmezése.** Feltettem, hogy a toronypredikciók a normál szabadlevegő-gradienst és felszíni folytatást használnak, nem a toronytövön mért gradienst. Az absztraktok ezt támasztják alá („surface data analytically continued”). Ha mért tövi gradienst használtak volna, a lineáris tag kiesne, és toronyként csak a görbületi tag (+2πGαρh²/2λ ≈ +90–133 µGal Romaides 1997-nél) maradna, ami kb. 2–3σ. Az óceáni G-teszt (54σ) és az Adelberger-burkoló (176×) erre nem érzékeny.
4. **A hibák értelmezése.** Gauss-eloszlású 1σ-nak vettem őket. A BREN előjele konzervatív feltevés.
5. **Digitalizálás.** ±0,05 dex (Adelberger), ~5% (Lee). Az 1 mm–1 cm tartományt nem digitalizáltam. A két szomszédos görbe szélén α₉₅ ≲ 3·10⁻³, és a kompilációk folytonos lefedést mutatnak, ezért α = 0,08-at ott is kizártnak tekintem. Ez **jelölt következtetés**, nem saját digitalizálás.
6. **A hosszú hatótávú él.** Az 1,5·10¹⁵ m az Adelberger-ábra szélén túli extrapoláció volt. *Javítva (audit S1):* ez nem nyitott ablak, mert a Cassini γ_PPN (saját egyskálás becslés, `fifth_force_results.json` → `cassini_ppn_estimate`, `allowed_lambda_windows.*.cassini_ppn_excluded_if_lambda_above_m_estimate`) λ ≳ ~1,3·10⁸ m-től kizárja α = 0,08-at. A becslés pontatlansága (b választása, egyetlen skála) a végkövetkeztetést nem érinti, mert λ ≫ b esetén a kizárás ~7·10³-szoros α-ban (0,0796 vs 1,15·10⁻⁵).
7. **Árnyékolás.** A rögzített V28 ágban nincs. Kiút csak egy olyan kaméleon/szimmetron kiterjesztés lehetne (Step 11), amely a Föld kérgét és óceánjait λ ~ 10 km-en árnyékolja. Ezt külön, nemlineáris számítással kellene ellenőrizni. A rögzített ágra nem vonatkozik.
8. **Achilli 1997.** Taszító előjelű anomáliát jelzett, ami a V28 vonzó előjelével ellentétes. Kalibrációs kétségek miatt nem használtam.

## 7. Fájlok

**Kód (`code/`):**

- `kernels.py` – Yukawa és top-hat kernel, rétegek, torony, óceán.
- `run_fifth_force.py` – fő számítás és ábrák.
- `digitize_adelberger2003.py` – az Adelberger-ábra digitalizálása.
- `digitize_lee2020.py` – a Lee-ábra digitalizálása.

**Adatok (`data/`):**

- `adelberger2003_fig4_pixel.json`
- `lee2020_fig5_edges.json`
- `sources/` – letöltött arXiv-források és renderek.

**Eredmények (`results/`):**

- `fifth_force_results.json`
- `alpha95_vs_lambda_own.csv`
- `run_log.txt`

**Ábrák (`results/`):**

- `exclusion_alpha_lambda.png` – a teljes α–λ sík a V28 pontjaival; az audit S1 javítás óta a Cassini γ_PPN saját egyskálás becslése is rajta van (kék sáv). A régi ábra: `exclusion_alpha_lambda.png.pre_audit`.
- `exclusion_geophysical_zoom.png` – a 100 m–1000 km tartomány.
- `tower_residuals.png`
