# Yukawa árapálypilot r3 — független újrafuttatás és audit

## Rövid döntés

**A hat fő állapot számsorai reprodukálódtak, és a feltételes, statikus tenzor-only pilot szükséges numerikus kapui az újrafuttatásban is megfeleltek.** Nem találtam olyan hibát a vizsgált egyenletrendszerben vagy eredménysorokban, amely miatt ezeket a Λ-értékeket vissza kellene vonni.

**Az eredeti kimeneti munkafolyamatot még nem nevezném javítás nélkül lezártnak.** A riportgenerátor két szándékosan elrontott CSV-t is elfogadott; emellett a mi környezetünkben az ép, újraszámolt r2-adatok túl szigorú egyezési feltétele megállítja az eredeti végső riportépítést. Elkészítettem és visszateszteltem egy kizárólag kimeneti ellenőrzést érintő javítást. Egy középponti képlet szövegében külön jelölési elírás van. A részletes csere a `r3_javitasok_HU.md` dokumentumban szerepel.

A korábban hiányzó történeti háttérhíd **az itt azonosított forrásverzióhoz most számszerűen alátámasztható**: a régi kóddal négy valódi BVP-újrafuttatást végeztem. Ez nem az eredeti ZIP-ben már meglévő ellenőrzés, hanem az audit új kiegészítése.

## 1. Mit futtattam ténylegesen?

- A feltöltött ZIP mérete, SHA-256 lenyomata, CRC-je, útvonalbiztonsága és mind a **141 manifest-payload** mérete/hash-e megfelelt. A manifest saját hash-e is egyezik a handoffal.
- Külön, frissen kibontott munkapéldányban lefutott a `reproduce_pilot.py`: **hat háttér és hat árapályválasz újraépült, archív NPZ-hátterek nélkül**. A tárolt NPZ-ket indulás előtt eltávolítottam a futási másolatból.
- Másik munkapéldányban a teljes `run_all.py` lefutott: **18 tényleges script, minden kilépési kód 0**. A négy új módosított háttér NPZ-je itt már az új futás terméke; a későbbi kontrollok ezeket használják, nem az archív tárolt háttereket.
- Külön megírt, entalpia-koordinátás TOV/Riccati GR-kontroll készült RK45-tel. Ez nem hívja az r3 `CO`, `tidal` vagy külső bázisfüggvényét; az EOS és a fizikai állandók közös bemenetek.
- A történeti `coupling_solver.py` **tényleges solve_bvp-hívásával** újra megoldottam a négy a=1 hátteret, az r3-ból meghatározott központi sűrűségen, r3-alapú kezdőbecsléssel. Nem csupán analitikus RHS-rekonstrukciót hasonlítottam össze.
- Külön másolatokban lefutott az eredeti builder tiszta kontrollja, két hibásbemenet-kontroll, majd a javított builder öt regressziós esete és a teljes friss tudományos kimeneten végzett ellenőrzése.

Az eredeti feltöltéseket és korábbi kutatási kódokat nem módosítottam. A tudományos futásokhoz az r3 kódja változatlan maradt; a javasolt builder-javítás külön példányban szerepel.

**Környezet:** Python 3.12.3; NumPy 2.5.4, SciPy 1.18.1, SymPy 1.14.0, pandas 3.1.0. Az eredeti README Python 3.13-at kér. Ezért a környezetek közötti gépi egyezést nem azonosítom a szerző saját, előírt környezetű reprodukciójával.

## 2. A hat újraszámolt állapot

Minden sorban M_K=1.4 M☉. A számjegyek reprodukciós tájékoztatást adnak, nem ilyen fizikai pontosságot.

| EOS | a | L [km] | R_g [km] | Λ_metric |
|---|---:|---:|---:|---:|
| APR4 | 0 | — | 11.319724 | 247.609914 |
| APR4 | 1 | 1 | 11.759346 | 313.440900 |
| APR4 | 1 | 10 | 11.625081 | 287.455163 |
| SLy | 0 | — | 11.706102 | 295.630690 |
| SLy | 1 | 1 | 12.181915 | 378.658368 |
| SLy | 1 | 10 | 12.015736 | 341.284927 |

A feltöltött táblához képest a legnagyobb |ΔR| **3.43×10⁻¹¹ km**, a legnagyobb relatív Λ-eltérés **3.26×10⁻¹⁰**. A legnagyobb eltérés a SLy GR-sorban van; a négy módosított sor eltérése legfeljebb kb. 5.15×10⁻¹² relatív.

A saját GR-águkhoz viszonyított módosulások:

| EOS | L [km] | ΔR/R_GR | ΔΛ/Λ_GR |
|---|---:|---:|---:|
| APR4 | 1 | +3.884% | +26.587% |
| APR4 | 10 | +2.698% | +16.092% |
| SLy | 1 | +4.065% | +28.085% |
| SLy | 10 | +2.645% | +15.443% |

**Ez a teljes feltételesen kalibrált modell eltolódása.** A rögzített G_lab mellett G_* is változik; a számokat nem szabad az extra skalárerő izolált hozzájárulásának nevezni. a=1-nél g=G_*/G_lab=0.9262883177508389, és M_A=1.511408460164327 M☉. Nem régi 1.4-es ADM-sorok átnevezése történt.

## 3. Újrafuttatott numerikus kapuk

| Kontroll | Ebben az auditban mért érték |
|---|---|
| Teljes tudományos futás | 18/18 script, kilépési kód 0 |
| Módosított kontrollsorok | 64 |
| GR-kontrollsorok | 18 |
| Kötelező kiscsatolású állapotok | 12; mind elfogadott, a=0.01/0.001/0.0001 |
| r3 saját GR Love-benchmarkja | max relatív eltérés 2.234×10⁻¹⁰ |
| Külön megírt entalpia-TOV/Riccati | max relatív Λ-eltérés 4.577×10⁻¹⁰ |
| Módosított állapotok tesztelt Λ-burka | max relatív 2.482×10⁻⁷ |
| Kezdősugár-váltás | max relatív Λ-eltérés 7.141×10⁻¹¹ |
| Alkalmazott amplitúdómátrix | minden vizsgált sor rangja 2; κ=1.94807–2.38426 |
| Alkalmazott skaláramplitúdó | max abszolút érték 6.842×10⁻¹⁷ |
| Duális külső kontroll | max abszolút hiba 4.685×10⁻¹⁴ |
| Külső illesztési maradék | max normált érték 4.529×10⁻¹⁴ |
| Integrált egyenletmaradék | 128 oszlopminta; legnagyobb normált maradék 1.349×10⁻⁷ |

Újra lefutott a kovariáns generálás, az egzakt A′=0 kontroll, a régi és új redukció lokális összevetése, a középponti sorhiba, az EOS-határok, a skalár referenciaamplitúdó, a nagy pontosságú külső normalizálás, a DOP853/Radau-váltás és az r2 módszer-összevetés is. Ezek részletes naplói és táblái a csomag `evidence/` könyvtárában vannak.

A GR-képlet módosított háttérre való meghívását az őrfeltétel a külön tesztben is elutasította. Nem GR Love-képletet alkalmaztam a módosított csillagokra.

A burkok **tesztelt beállítások közötti eltérések**, nem szigorú hibabecslések vagy statisztikai intervallumok. A numerikus reprodukció nem bizonyítja a feltételes kalibráció fizikai helyességét.

## 4. A történeti forráshíd új ellenőrzése

Az azonosított forrás: a korábbi munkaterület `tal-yukawa-small-coupling/code/coupling_solver.py` fájlja. SHA-256:

`8e1f370db232d71d8813054f011c84db47ab6d1d2acfbcb03f5fc0c3e9533f32`.

A használt EOS-forrás teljes fájlja bájtazonos az r3 EOS-pillanatképével. A térkép: **a_gate=k_legacy**, φ=k·u, ε_gate=g·ε_lab, p_gate=g·p_lab, M_K=g·M_A. A régi kimenet sqrt(k) nevű oszlopát nem használtam a hatás a paramétereként.

A négy régi-kódos új megoldásból:

- max |R_legacy−R_r3| = **4.725×10⁻⁹ km**;
- max |M_K,legacy−M_K,r3| = **8.493×10⁻¹² M☉**;
- minden régi BVP a kért 2×10⁻⁸ maradékon belül konvergált.

**Korlát:** az r3 központi sűrűségét és kezdőbecslését átadtam. Nem végeztem a régi kódban önálló tömeggyök-keresést, és mindkét implementáció SciPy-kollokációt használ. Ez az adott háttéregyenletek és egységtérkép numerikus egyezését támasztja alá; nem független árapály-megoldó, és nem létezési vagy egyértelműségi bizonyítás. A korábbi „forrás nem állt rendelkezésre” szöveg tehát nem volt hibás a készítő környezetére nézve; az új audit már hozzá tudja adni ezt a verzióazonosított bizonyítékot.

## 5. Konkrét javítandó pontok

### J01 — A builder nem zárja ki a nem véges alapadatot

**Hely és idézet:** `code/build_outputs.py`: `assert required,'Required scientific gate failed; no automatic publication output.'`

**Bizonyíték:** egyetlen SLy/a=1/L=1 elsődleges sor Λ-értékét NaN-ra cseréltem; másik másolatban ugyanennek a sornak az M_K mezőjét +Inf-re. Az eredeti builder mindkét esetben **0 kilépési kóddal** végzett, és `required_pilot_gates_passed=true` státuszt írt. A tiszta kontroll is 0-val végzett. Ez a builder védelmi hiánya, nem az ép eredeti táblában kimutatott rossz szám.

**Javítás:** a „megfelelt” státusz és a publikációs kimenetek létrehozása elé tegyél explicit végességi, állapotrács- és egységellenőrzést; a javasolt `r3_output_guard.py` ezt végzi. A négy hibás javított kontroll — NaN, Inf, ismételt állapot, véges de hibás g — nemnulla kilépéssel megáll; az ép kontroll és a friss teljes tudományos kimenet átmegy. A módosítás nem nyúl integrátorhoz vagy egyenlethez.

**Bizonyosság:** magas, végrehajtott negatív kontroll. **Súly:** jelentős a gépi megfelelési státusz megbízhatóságára; a mostani ép Λ-értékeket nem módosítja. A pontos alkalmazás a javítási dokumentum J01 pontjában van.

### J02 — A végső builder r2-egyezési feltétele túl szigorú a kipróbált másik környezetben

**Hely és idézet:** `code/build_outputs.py`: `assert abs(oo.Lambda_metric-pub.Lambda_metric)<1e-9 and abs(oo.R_g_km-pub.R_g_km)<1e-12`.

**Bizonyíték:** a friss r2 és az archivált r2 legnagyobb eltérése |ΔΛ|=9.6313×10⁻⁸, |ΔR|=3.4282×10⁻¹¹ km. Az eredeti builder emiatt megáll, noha a hatállapotos reprodukció a saját, dokumentált relatív Λ<10⁻⁸ és |ΔR|<10⁻⁷ km feltételén megfelel, és a 18 tudományos script is lefutott. A csomag Python 3.13-at kér; mi 3.12.3-at használtunk, ezért ezt **nem** állítom az előírt 3.13 környezet hibájának.

**Javítás:** a r2-összevetést numerikus toleranciához igazítsd: Λ-ra `np.isclose(...,rtol=1e-8,atol=1e-9)`, R-re `np.isclose(...,rtol=0,atol=1e-7)`. Előtte legyen kötelező J01 végességi ellenőrzése. Ezzel a friss eredményekből a végső riport is felépült, az integrációs kód változtatása nélkül.

**Bizonyosság:** magas a megfigyelt kompatibilitási akadályra. **Súly:** kisebb, portabilitási/kimeneti kérdés; nem tudományos cáfolat.

### J03 — u₀ helyett ν₀ szerepel a leírt h₄ képletben

**Hely és idézet:** `notes/levezetes_HU.md`, „Reguláris középpont”: `h_4=[(\nu_0+2p_1)h_2+16\pi q_0s_2]/14`.

Előtte u₀ van definiálva, nem ν₀. A generált képlet és a futó `CENTRAL` az u₀-nak megfelelő együtthatót használja; ezért ez nem indokol új numerikus sorozatot. **Cseréld `\nu_0`-t `u_0`-ra ebben az egy kifejezésben.** Bizonyosság: magas. Súly: kisebb, szöveges elírás.

## 6. Az opcionális kudarc és a fizikai állítás határa

Az a=10⁻⁸ stresszdiagnosztika nálunk is **3 elfogadott + 1 elutasított** állapotot adott. APR4/L=10 km-nél a csomópontkorlát miatt nem teljesült a 2×10⁻⁸ háttérmaradék; ehhez Λ továbbra sincs. Az r3 ezt helyesen különíti el a hat fő állapottól és a 12 kötelező kiscsatolású kontrolltól. Nem nevezem a fő pilot hibájának, de a négy szélső eset együttes sikerét sem állítom.

A helyesen korlátozott következtetés változatlan: **ebben a feltételes, azonos M_K-jú két-EOS modellben reprodukálható metrikus R–Λ-eltolódás van.** Két EOS alapján az EOS-hatástól való elkülöníthetőség nem dől el. Nincs megfigyelési likelihood, bináris hullámformavalidálás, dinamikai stabilitásvizsgálat vagy prioritásigazolás. A véges külső határ és az alkalmazott skalárforrás választása a dokumentált feltételes válaszdefiníció része marad.

**Kiadási döntésem:** a fő numerikus eredményeket megtartanám. A feltételes kutatási pilot lezárása előtt J01-et javítanám, J02-t a reprodukciós szerződéssel összehangolnám, J03-at kijavítanám; a történeti hídról szóló részt az új forrással és a fenti határokkal bővíteném. Ez AI-segített műszaki audit, nem szakmai lektorálás vagy az elmélet empirikus igazolása.
