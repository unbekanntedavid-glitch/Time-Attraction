#!/usr/bin/env python3
"""Conditional fixed-G_lab II-fluid quadrupole pilot. CC BY-NC4.0, ©2026 Szabolcsi Dávid.
No GR Love formula is evaluated on a modified background.
"""
import os,sys,json,time,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
from scipy.integrate import solve_ivp,solve_bvp
from scipy.optimize import brentq
from scipy.interpolate import PPoly
from scipy.special import hyp2f1
import sympy as s
import importlib.util
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('eos_source',ROOT/'sources/stellar_tal_v21.py');st=importlib.util.module_from_spec(spec);spec.loader.exec_module(st)
PI=np.pi; GM=st.GM; TARGET=1.4*GM
class EOS:
 def __init__(self,name,a):self.raw=st.EOS(name);self.factor=1/(1+a/(4*PI));self.name=name
 def at(self,h):
  e,p,rho,cs=self.raw.at(h);return e*self.factor,p*self.factor,rho,cs
 def hc(self,lr):return float(self.raw.h_of_rho(10**lr))

def scalar_coefficients():
 r,m,e,p,phi,y,a,u,cs=s.symbols('r m e p phi y a u cs',positive=True)
 B=1-2*m/r;f=s.exp(-phi);rho=(B*y*y+u*u*phi*phi)/(2*a);pr=(B*y*y-u*u*phi*phi)/(2*a)
 mp=4*s.pi*r*r*(f*e+rho);bp=2*m/r**2-2*mp/r
 v=(m+4*s.pi*r**3*(f*p+pr))/(r*r*B);pp=(e+p)*(-v+y);ep=pp/cs
 yp=(u*u*phi-a*f*e-(2*B/r+B*v+bp/2)*y)/B
 args=(r,m,e,p,phi,y,a,u,cs)
 total=lambda z:s.diff(z,r)+s.diff(z,m)*mp+s.diff(z,e)*ep+s.diff(z,p)*pp+s.diff(z,phi)*y+s.diff(z,y)*yp
 af=-r*r*B*v/2
 bf=2*s.pi*r*r*f*(e+3*p)-r*r*B*v*v-r*B*v-1-2*s.pi*u*u*r*r*phi*phi/a
 cf=-4*s.pi*r*r*f*e+4*s.pi*u*u*r*r*phi/a-8*s.pi*r*r*B*v*y/a-8*s.pi*r*B*y/a
 df=-4*s.pi*r*r*B*y/a
 sh=-(u*u*phi-a*f*e-2*B*v*y-a*f*(e+p)/(2*cs))/B
 sx=(6/r**2+u*u+a*f*e+16*s.pi*B*y*y/a-a*f*(e+p)/cs)/B
 sp=-(2*B/r+B*v+bp/2)/B
 co=[-(total(bf)+2*v+df*sh)/af,-(total(af)+bf+1)/af,-(total(cf)+16*s.pi*y/a+df*sx)/af,-(cf+total(df)+df*sp)/af,sh,sx,sp]
 co=[s.factor(z) for z in co]
 return s.lambdify(args,co,'numpy',cse=True)
CO=scalar_coefficients()

def bg_values(r,m,h,phi,y,eos,a,L,segment=None):
 e,p,_,cs=eos.at(h)
 if segment is not None:
  # At a piece endpoint select its one-sided sound speed without changing continuous e,p.
  cs=eos.raw.g[segment]*p/(e+p)
 if a==0:
  B=1-2*m/r;v=(m+4*PI*r**3*p)/(r*r*B);mp=4*PI*r*r*e;bp=2*m/r**2-2*mp/r
  return e,p,cs,B,v,mp,bp,np.zeros_like(r)
 f=np.exp(-phi);B=1-2*m/r;rho=(B*y*y+phi*phi/L**2)/(2*a);pr=(B*y*y-phi*phi/L**2)/(2*a)
 mp=4*PI*r*r*(f*e+rho);bp=2*m/r**2-2*mp/r;v=(m+4*PI*r**3*(f*p+pr))/(r*r*B)
 yp=(phi/L**2-a*f*e-(2*B/r+B*v+bp/2)*y)/B
 return e,p,cs,B,v,mp,bp,yp

def gr_at(eos,hc,r0=1e-4,hs=1e-10,rtol=2e-11):
 ec,pc,*_=eos.at(hc);m0=4*PI*ec*r0**3/3;v2=2*PI*(ec+3*pc)/3
 def fun(r,z):
  m,h,nu=z;e,p,*_=eos.at(h);v=(m+4*PI*r**3*p)/(r*(r-2*m));return [4*PI*r*r*e,-v,v]
 def ev(r,z):return z[1]-hs
 ev.terminal=True;ev.direction=-1
 sol=solve_ivp(fun,(r0,40),[m0,hc-v2*r0*r0,v2*r0*r0],events=ev,dense_output=True,rtol=rtol,atol=1e-13,max_step=.04,method='DOP853')
 if not sol.success or not len(sol.t_events[0]):raise RuntimeError('GR surface')
 return sol,float(sol.t_events[0][0])

def gr_background(name,hs=1e-10,r0=1e-4,rtol=2e-11):
 eos=EOS(name,0);hc=brentq(lambda h:gr_at(eos,h,r0,hs,rtol)[0].y[0,-1]-TARGET,.08,.6,xtol=1e-12)
 sol,R=gr_at(eos,hc,r0,hs,rtol)
 return dict(eos=eos,a=0.,L=1.,R=R,hc=hc,r0=r0,hs=hs,grsol=sol,mout=float(sol.y[0,-1]),phic=0.,bg_tol=rtol)

def background(name,a,L,bgtol=2e-8,nL=20.,hs=1e-10,r0=1e-4):
 if a==0:return gr_background(name,hs,r0)
 eos=EOS(name,a)
 # Scalar-free fixed-mass initial background with the correctly rescaled bare SI EOS.
 hc0=brentq(lambda h:gr_at(eos,h,r0,hs)[0].y[0,-1]-TARGET,.06,.8,xtol=1e-10)
 gs,R0=gr_at(eos,hc0,r0,hs);x=np.linspace(0,1,450)
 def linearfun(x,z):
  ri=r0+(R0-r0)*x;re=R0+nL*L*x
  mi,hi,nui=gs.sol(ri);ei,pi,*_=eos.at(hi);Bi=1-2*mi/ri;vi=(mi+4*PI*ri**3*pi)/(ri*ri*Bi);mpi=4*PI*ri*ri*ei;bpi=2*mi/ri**2-2*mpi/ri
  Be=1-2*TARGET/re;ve=TARGET/(re*re*Be);bpe=2*TARGET/re**2
  return np.array([(R0-r0)*z[1],(R0-r0)*(z[0]/L**2-a*ei-(2*Bi/ri+Bi*vi+bpi/2)*z[1])/Bi,nL*L*z[3],nL*L*(z[2]/L**2-(2*Be/re+Be*ve+bpe/2)*z[3])/Be])
 def linearbc(za,zb):
  ec=eos.at(hc0)[0];rout=R0+nL*L;kap=1/L+(1+TARGET/L)/rout
  return np.array([za[1]-(za[0]/L**2-a*ec)*r0/3,zb[0]-za[2],zb[1]-za[3],zb[3]+kap*zb[2]])
 zz=np.zeros((4,len(x)));zz[0]=a*eos.at(hc0)[0]*L*L/(1+L*L/R0**2)
 lin=solve_bvp(linearfun,linearbc,x,zz,tol=1e-7,max_nodes=12000)
 if not lin.success:raise RuntimeError('linear scalar guess '+lin.message)
 phic=float(lin.y[0,0]);zi=gs.sol(r0+(R0-r0)*x);le=lin.sol(x)
 guess=np.vstack([zi[0],zi[2],zi[1],le[0],le[1],np.full_like(x,TARGET),gs.sol(R0)[2]+.5*np.log((1-2*TARGET/(R0+nL*L*x))/(1-2*TARGET/R0)),le[2],le[3]])
 def fun(x,z,par):
  R,pc,hc=par;ri=r0+(R-r0)*x;re=R+nL*L*x
  ei,pi,csi,Bi,vi,mpi,bpi,ypi=bg_values(ri,z[0],z[2],z[3],z[4],eos,a,L)
  Be=1-2*z[5]/re;rho=(Be*z[8]**2+z[7]**2/L**2)/(2*a);pr=(Be*z[8]**2-z[7]**2/L**2)/(2*a)
  mep=4*PI*re*re*rho;ve=(z[5]+4*PI*re**3*pr)/(re*re*Be);bep=2*z[5]/re**2-2*mep/re;ye=(z[7]/L**2-(2*Be/re+Be*ve+bep/2)*z[8])/Be
  return np.vstack([(R-r0)*mpi,(R-r0)*vi,(R-r0)*(-vi+z[4]),(R-r0)*z[4],(R-r0)*ypi,nL*L*mep,nL*L*ve,nL*L*z[8],nL*L*ye])
 def bc(za,zb,par):
  R,pc,hc=par;ec,ep,*_=eos.at(hc);et=np.exp(-pc)*ec;pt=np.exp(-pc)*ep;rho=pc*pc/(2*a*L*L);phi2=(pc/L**2-a*et)/6;nu2=2*PI*(et+rho+3*(pt-rho))/3
  start=np.array([4*PI*(et+rho)*r0**3/3,nu2*r0*r0,hc+(-nu2+phi2)*r0*r0,pc+phi2*r0*r0,2*phi2*r0]);rout=R+nL*L;kap=1/L+(1+TARGET/L)/rout
  return np.r_[za[:5]-start,zb[2]-hs,zb[[0,1,3,4]]-za[5:9],zb[8]+kap*zb[7],zb[5]-TARGET]
 sol=solve_bvp(fun,bc,x,guess,p=[R0,phic,hc0],tol=bgtol,bc_tol=bgtol*.01,max_nodes=18000)
 if not sol.success:
  diag=dict(EOS=name,alphaY=a,L_km=L,tolerance=bgtol,status=int(sol.status),message=sol.message,nodes=int(len(sol.x)),max_residual=float(max(sol.rms_residuals)),max_residual_x=float(sol.x[int(np.argmax(sol.rms_residuals))]),parameters=sol.p.tolist())
  (ROOT/'checks'/f'background_failure_{name}_a{a:g}_L{L:g}_tol{bgtol:g}.json').write_text(json.dumps(diag,indent=2))
  raise RuntimeError('coupled background '+sol.message+' '+str(diag))
 R,phic,hc=sol.p;out=dict(eos=eos,a=a,L=L,R=float(R),hc=float(hc),phic=float(phic),r0=r0,hs=hs,bgsol=sol,nL=nL,mout=float(sol.y[5,-1]),bg_tol=bgtol,bg_max_residual=float(max(sol.rms_residuals)))
 return out

def bg_at(bg,r,exterior=False):
 r=np.asarray(r);R=bg['R'];a=bg['a']
 if a==0:
  if exterior:return np.full_like(r,bg['mout']),np.zeros_like(r),np.zeros_like(r),np.zeros_like(r)
  vals=bg['grsol'].sol(r);return vals[0],vals[1],np.zeros_like(r),np.zeros_like(r)
 if exterior:
  vals=bg['bgsol'].sol((r-R)/(bg['nL']*bg['L']));return vals[5],np.zeros_like(r),vals[7],vals[8]
 vals=bg['bgsol'].sol((r-bg['r0'])/(R-bg['r0']));return vals[0],vals[2],vals[3],vals[4]

def coeff(bg,r,ext=False,seg=None):
 m,h,phi,y=bg_at(bg,r,ext);a=bg['a'];L=bg['L']
 if ext:e=p=0.;cs=1.
 else:e,p,_,cs=bg['eos'].at(h)
 if seg is not None and not ext:cs=bg['eos'].raw.g[seg]*p/(e+p)
 B=1-2*m/r
 if a==0:
  v=(m+4*PI*r**3*p)/(r*r*B)
  P=2/r+(2*m/r**2+4*PI*r*(p-e))/B;Q=-6/(r*r*B)+4*PI*(5*e+9*p+(e+p)/cs)/B-4*v*v
  return np.array([-Q,-P,0.,0.,0.,(6/r**2+1/L**2)/B,-(2/r+2*m/(r*r*B))])
 return np.asarray(CO(r,m,e,p,phi,y,a,1/L,cs),float)

def vacuum_basis(r,M):
 B=1-2*M/r;z=2*M/r;F=hyp2f1(3,5,6,z)
 g=r*r*B;gp=2*r-2*M;d=B/r**3*F
 dp=(2*M/r**5-3*B/r**4)*F-5*M*B/r**5*hyp2f1(4,6,7,z)
 return np.array([[g,d],[gp,dp]])

def scalar_vacuum_basis(bg,outer,far_factor=60.):
 R=bg['R'];M=bg['mout'];L=bg['L'];key=('scalarvac',far_factor)
 if key not in bg:
  far=R+far_factor*L
  def rhs(r,z):
   B=1-2*M/r;P=2/r+2*M/(r*r*B)
   return [(6/r**2+1/L**2)/B-P*z[0]-z[0]*z[0],z[0]]
  initial=[-1/L-(1+M/L)/far,0.]
  sol=solve_ivp(rhs,(far,R),initial,method='DOP853',rtol=3e-12,atol=1e-13,dense_output=True,max_step=L/3)
  if not sol.success:raise RuntimeError('decaying scalar vacuum basis')
  bg[key]=sol
 sol=bg[key];slope,logamp=sol.sol(outer);logR=sol.sol(R)[1]
 return float(slope),float(np.exp(logamp-logR))

def interfaces(bg,rstart):
 R=bg['R'];hc=bg['hc'];rs=[]
 for k,h in enumerate(bg['eos'].raw.hb):
  if bg['hs']<h<hc:
   rr=brentq(lambda r:float(bg_at(bg,r)[1])-h,rstart,R,xtol=2e-11);rs.append(rr)
 return sorted(rs)

def tidal(bg,nmatch=10.,rtol=2e-9,maxstep=.08,start=.005,renorm=True,method='DOP853'):
 R=bg['R'];M=bg['mout'];a=bg['a'];L=bg['L'];r0=max(start,bg['r0']);outer=R+nmatch*L
 if a>0 and nmatch>bg['nL']:raise ValueError('outside stored background')
 pieces=interfaces(bg,r0);ends=sorted(set([r0,R]+pieces+list(np.arange(r0+1,R,1.))))
 U=np.array([[r0*r0,0],[2*r0,0],[0,r0*r0],[0,2*r0]],float)
 calls=0
 for left,right in zip(ends[:-1],ends[1:]):
  hm=float(bg_at(bg,(left+right)/2)[1]);seg=int(np.searchsorted(bg['eos'].raw.hb,hm))
  def rhs(r,z):
   co=coeff(bg,r,False,seg);zz=z.reshape(4,2);return np.array([zz[1],co[0]*zz[0]+co[1]*zz[1]+co[2]*zz[2]+co[3]*zz[3],zz[3],co[4]*zz[0]+co[5]*zz[2]+co[6]*zz[3]]).ravel()
  if os.getenv('TIDAL_DEBUG'):print('interior interval',left,right,'segment',seg,flush=True)
  sol=solve_ivp(rhs,(left,right),U.ravel(),method=method,rtol=rtol,atol=rtol*1e-4,max_step=maxstep)
  if not sol.success:raise RuntimeError('tidal interior '+sol.message)
  if os.getenv('TIDAL_DEBUG'):print('interval solved',sol.nfev,flush=True)
  U=sol.y[:,-1].reshape(4,2);calls+=sol.nfev
  if renorm:U=np.linalg.qr(U)[0]
 # Moving-surface density correction, with p->0 controlled by h_s variations.
 e,p,_,_=bg['eos'].at(bg['hs']);_,h,phi,y=bg_at(bg,R);B=1-2*bg_at(bg,R)[0]/R
 if a==0:v=(M+4*PI*R**3*p)/(R*R*B)
 else:v=bg_values(R,bg_at(bg,R)[0],h,phi,y,bg['eos'],a,L)[4]
 hp=-v+y;xi=(U[0]/2-U[2])/hp;U[1]+=8*PI*np.exp(-phi)*e*xi/B
 if a>0:U[3]-=a*np.exp(-phi)*e*xi/B
 # Exterior uses exact Schwarzschild tensor a,b amplitudes as coordinates, not surface GR Love substitution.
 bunit=R**5;slope,tail=scalar_vacuum_basis(bg,outer)
 V=np.array([[1.,0,0],[0,1.,0],[0,0,tail],[0,0,slope*tail]],float)
 def rhs_ext(r,z):
  mat=z.reshape(4,3);base=vacuum_basis(r,M);base[:,1]*=bunit;H=base[0]@mat[:2];Hp=base[1]@mat[:2];co=coeff(bg,r,True)
  Bv=1-2*M/r;Pv=2/r+2*M/(r*r*Bv);Qv=-6/(r*r*Bv)-4*M*M/(r**4*Bv*Bv)
  forcing=(co[0]+Qv)*H+(co[1]+Pv)*Hp+co[2]*mat[2]+co[3]*mat[3]
  W=-5*bunit/(r*r*Bv)
  return np.array([-base[0,1]*forcing/W,base[0,0]*forcing/W,mat[3],co[4]*H+co[5]*mat[2]+co[6]*mat[3]]).ravel()
 sol=solve_ivp(rhs_ext,(outer,R),V.ravel(),method=method,rtol=rtol,atol=rtol*1e-4,max_step=min(maxstep,L/8))
 if not sol.success:raise RuntimeError('tidal exterior '+sol.message)
 VR=sol.y[:,-1].reshape(4,3);base=vacuum_basis(R,M);base[:,1]*=bunit;E=np.vstack([base@VR[:2],VR[2:]])
 mat=np.column_stack([U,-E[:,1],-E[:,2]]);norms=np.linalg.norm(mat,axis=0);scaled=mat/norms
 answer=np.linalg.solve(scaled,E[:,0])/norms
 b=answer[2]*bunit;lam=b/3;Lambda=lam/M**5;k2=1.5*lam/R**5
 residual=np.linalg.norm(mat@answer-E[:,0])/np.linalg.norm(E[:,0])
 ec,pc,_,csc=bg['eos'].at(bg['hc']);lr=float(np.log10(bg['eos'].raw.at(bg['hc'])[2]))
 result=dict(EOS=bg['eos'].name,alphaY=a,q=a/(4*PI),Gstar_over_Glab=bg['eos'].factor,L_km=L if a else 0.,M_K_Msun=M/GM,M_A_Msun=M/(GM*bg['eos'].factor),R_g_km=R,Lambda_metric=Lambda,lambda_geom_km5=lam,k2_metric=k2,logrho_c_cgs=lr,cs2c=csc,phic=bg['phic'],nmatch=nmatch,match_r_km=outer,start_km=r0,rtol=rtol,maxstep_km=maxstep,bg_tol=bg['bg_tol'],h_surface=bg['hs'],matching_condition_number=float(np.linalg.cond(scaled)),matching_relative_residual=residual,scalar_decay_amplitude=answer[3],interior_function_calls=calls,exterior_function_calls=sol.nfev,integrator=method)
 return {k:(v.item() if isinstance(v,np.generic) else v) for k,v in result.items()}

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--eos',default='SLy');ap.add_argument('--a',type=float,default=0);ap.add_argument('--L',type=float,default=10);ap.add_argument('--nmatch',type=float,default=10);args=ap.parse_args()
 t=time.time();bg=background(args.eos,args.a,args.L);print('background',args.eos,args.a,args.L,bg['R'],bg['hc'],'secs',time.time()-t,flush=True)
 row=tidal(bg,nmatch=args.nmatch);print(json.dumps(row,indent=2),flush=True)
 (ROOT/'checks'/f'smoke_{args.eos}_a{args.a}_L{args.L}.json').write_text(json.dumps(row,indent=2))
