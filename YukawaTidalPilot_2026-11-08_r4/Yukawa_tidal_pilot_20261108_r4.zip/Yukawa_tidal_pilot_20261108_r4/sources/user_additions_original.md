# Mit tarts meg, mit cserélj, és mivel egészítsd ki?

**Ez kiegészítési javaslat, nem egy hibásnak talált hatás helyettesítése.** Az eredeti ZIP-et nem módosítottam. A hozzáadott egyenletek lokálisan ellenőrzöttek; új neutroncsillag- vagy Love-szám-sorozat nem készült.

## 1. Ezt NE cseréld le

Maradjon a bare-energiacsatolású hatás, az Euler-reláció \(\delta h=\chi-H_0/2\), a skalár egyenletének sűrűségforrása, és a negatív \(\delta g_{tt}=-AH_0Y\) konvenció mellett **\(H_2=-H_0\)**. Ezek helyére nem kell konformális nyomforrású egyenlet vagy GR Love-képlet. A csak alkalmazott tenzortide, nulla független növekvő skalármódus és megengedett gerjesztett skalárfarok szintén megtartható.

## 2. A számításban az A′-vel osztó metrikus redukció helyett ezt használd

**Hely:** `notes/levezetes_HU.md`, 3. szakasz, „Redukált egyenletpár”. Az eredeti \(dF/dr-K'=0\) egyenlet maradhat független ellenőrző maradék. A fő integrált metrikus egyenletet azonban ne az A′-vel osztó alakból képezd.

### Beilleszthető szöveg

> A numerikus főrendszerhez a tt Einstein-egyenletből olyan metrikus másodrendű egyenletet használunk, amely nem oszt A′-vel. Legyen H=H₀, v=A′/(2A), és S=−H′−2vH−(16π/a)φ′χ. A korábban megadott K=F rekonstrukcióval képezzük
> \[
> \widehat E_{tt}=\left.\frac{E_{tt}}{AY}\right|_{H_2=-H,\ K=F,\ K'=S,\ K''=S'}=0,
> \]
> ahol \(S'=-H''-2vH'-2v'H-(16\pi/a)(\phi''\chi+\phi'\chi')\). A H″ együtthatója **B**, tehát a másodrendű egyenletet B-vel normalizálhatjuk, A′-vel való osztás nélkül. A csatolt skaláregyenlet és a K-rekonstrukció változatlan. A háttérderiváltak a háttéregyenletekből számítandók. Ez r>0, A≠0, B≠0 tartományon használható; a reguláris középpontot továbbra is sorfejtés kezeli. A régi redukció, valamint a többi Einstein-komponens független maradékként ellenőrizendő.

A kifejtett alak a mellékelt `division_free_equations.txt`; előállítója az `independent_audit.py`. Az új és a régi H″ 24 friss, háttéregyenleteket kielégítő lokális mintán egyezik. Külön A′=0 helyen is ellenőriztem az új egyenlet végességét és az elhagyott szögegyenletet. Ez nem globális csillagteszt.

**Kis csatoláshoz:** \(a=\zeta^2,\ \phi=\zeta\psi,\ \chi=\zeta\eta\). A `canonical_equations.txt` ebben az alakban nem tartalmaz inverz ζ-t. A GR-ág fizikai háttere ψ=0; a csatolás nullára állítása nem jogosít nemnulla szabad skalárháttér megtartására a GR-kontrollban.

## 3. A hiányzó középponti indítást ezzel egészítsd ki

**Hely:** a 4. szakasz reguláris középpontról szóló pontja után.

> A reguláris két oszlopot H=h₂r²+h₄r⁴+O(r⁶), χ=s₂r²+s₄r⁴+O(r⁶) sorokkal indítjuk. A (h₂,s₂)=(1,0) és (0,1) választás a két bázisoszlopot adja, rögzített hossz- és csatornanormalizálással. A h₄ és s₄ együtthatót a háttér középponti együtthatóival együtt az egyenletekből számítjuk; nem állítjuk nullára. A kezdősugár változtatásával a későbbi integrált válasz konvergenciáját külön teszteljük.

A most levezetett explicit h₄, s₄ és K₄ képletek a `central_series.txt` fájlban vannak. A jelölésben `cs_c` maga \(c_{s,c}^{2}=dp/d\epsilon\), nem a hangsebesség. A nyers a>0 képletet a=0-nál ne értékeld: ott a külön GR-rendszert vagy a reguláris kanonikus alakot használd. A középponti sor önmagában még nem igazol felszíni vagy külső illesztést.

## 4. Új kalibrált háttérkód helyett a meglévőt kösd hozzá, explicit térképpel

A korábbi munkádban már van rögzített labor-G-t használó háttérmegoldó:

`user/workspace/co-scientist-outputs/tal-yukawa-small-coupling/code/coupling_solver.py`

Az eredeti kapucsomag óvatos megállapítása a saját mellékelt forrásairól megtartható. Ezt az újonnan azonosított implementációt azonban érdemes hozzáadni, ahelyett hogy a dimenziós helyreállítást ismét egy ellenőrizetlen új kódban valósítanád meg.

| A kapucsomag jelölése | A meglévő háttérkód megfelelője |
|---|---|
| a, a hatás skaláregyütthatója | **k**, nem a kód `alpha_Y=sqrt(k)` kimeneti oszlopa |
| háttér φ | k·u; a korábbi kimenet ezt háttér-`chi` néven is írja |
| perturbáció χ | δφ; nem azonos a régi háttér-`chi` oszloppal |
| bare ε, p geometriai egységben | g·ε_lab, g·p_lab, g=G*/G_lab |
| φ′ | k·v a megoldóban |
| M_K | g·M_ADM a megoldó jelentett fizikai tömegéből |

**Lényeges tömegcél:** ha az új pilot továbbra is \(M_K=1.4M_\odot\), akkor a meglévő kód `M_ADM_Msun` gyökcélja **1.4/g**, nem 1.4. a=k=1 esetén g=0,92628831775 és a cél kb. **1,51140846 M☉**. Ez nem új fizikai eredmény, csak a két korábban expliciten különválasztott tömegkonvenció helyes összekötése. A régi 1.4-es sorokat ezért nem lehet átnevezni az új pilot eredményeivé.

A `background_bridge_check.py` ténylegesen a meglévő kód jobb oldalát ellenőrzi, a BVP-hívást lokális teszttel helyettesítve: **nem számol új csillagot**. Nyolc esetben ellenőriztem a térképet k=0/0,001/0,1/1 és L=1/10 km mellett. A háttér új célra történő integrálása későbbi munka; a korábbi L=10 km-es numerikus validálás nem válik ettől automatikusan L=1 km-es validálássá.

## 5. A külső válaszhoz ezt az amplitúdószerződést add hozzá

**Hely:** az 5. szakasz tenzor-only pilotjának definíciója után.

> A két reguláris belső oszlopból a kapcsolt külső propagálással mérjük ki az alkalmazott tenzor- és független növekvő skaláramplitúdókat. Ezek sorai alkotják az alkalmazott amplitúdók \(\mathsf A\) mátrixát. A tenzor-only kombinációt \(\mathsf A c=(1,0)^T\) megoldásával választjuk ki, rögzített amplitúdóegységekkel. Rangsérült vagy rosszul kondicionált \(\mathsf A\) mellett nem közlünk automatikusan Love-számot; az illesztést, normalizálást és lehetséges fizikai okot külön vizsgáljuk. Ez más feltétel, mint az U mátrix invertálhatósága a Dirichlet–Neumann-diagnosztikában.
>
> A már tesztelten skalármentes külső illesztési tartományban olyan teljes Schwarzschild-bázist használunk, amelyben \(H=a_HT_H+b_HT_Q\), \(T_H\sim r^2\), \(T_Q\sim r^{-3}\). Az itt használt negatív tt konvenció és a \(g_{tt}\)-ben szereplő \(3\mathcal Q/r^3\) STF-normalizálás mellett
> \[
> \lambda_{TT}^{geom}=\frac{b_H}{3a_H}.
> \]
> A nyers \(b_H/a_H\) arány tehát nem maga λ. Ha eltérően normalizált bázist használunk, a megfelelő bázisszorzókat is be kell számítani. Véges sugáron a puszta r² és r⁻³ helyettesítés nem az egzakt Schwarzschild-bázis.

Konkrét ellenőrző bázis: \(T_H=r(r-2m_\infty)\), \(T_Q=5Q_2^2(r/m_\infty-1)/(8m_\infty^3)\), valós x>1 ággal, ahol \(Q_2^2=(x^2-1)Q_2''\). Az `exterior_normalization_controls.csv` nullválaszú és ismert válaszú szintetikus eseteket tartalmaz. A nyers hatványillesztés már tiszta alkalmazott Schwarzschild-tidére is hamis választ ad; ez kontroll, nem a kapucsomagban kimutatott hibás illesztés.

A gerjesztett skalárpartikulárist tartsd meg. A dokumentált figyelmeztetés helyes: csak i₂/k₂ illesztéssel nem oldható meg a kapcsolt külső. A következő megvalósításban ezért kapcsolt külső bázis, r_b- és toleranciaváltás kell, nem felszíni GR-képlet.

## 6. Továbbküldhető következő feladat

> A levezetési kaput ne új elmélettel helyettesítsd. Építsd be az A′-vel nem osztó tt-redukciót és a negyedrendű középponti sorokat; a régi redukció maradjon kontroll. Kösd össze a meglévő rögzített-labor-G háttérmegoldót a dokumentált k↔a és M_ADM↔M_K térképpel. Először egy integrált GR Love-benchmarkot és a→0 folytonosságot zárj le. Ezután a mozgó felszín, az EOS-darabhatárok és a kapcsolt külső illesztés következzen, az alkalmazott amplitúdómátrix rangjával és kondicionálásával. Csak ezek után készíts SLy/APR4 pilotot a kijelölt M_K célnál. A két EOS alapján ne állíts EOS-függetlenséget vagy megfigyelési kizárást.

**Nincs szükség a teljes eredeti ZIP lecserélésére.** A javaslat egy r1 kiegészítés: egy robusztusabb numerikus redukció, konkrét középponti indítás, meglévő kalibrált háttérhez vezető adapter és explicit külső amplitúdónormalizálás.
