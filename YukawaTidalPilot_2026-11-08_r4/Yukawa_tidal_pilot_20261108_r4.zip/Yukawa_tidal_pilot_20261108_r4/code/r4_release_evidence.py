#!/usr/bin/env python3
"""Hash/byte and document evidence, without changing scientific input or solution tables."""
from pathlib import Path
import json,hashlib,difflib
import pandas as pd
from output_guard import need,prepublication
ROOT=Path(__file__).resolve().parents[1];OLD=Path('/workspace/yukawa_tidal_pilot_20261108_r3')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
 report=json.loads((ROOT/'checks/r4_publication_regressions.json').read_text());need(report['pass'] and report['tests']==70,'regression record')
 for name in ['code/pilot.py','code/equations.py','sources/stellar_tal_v21.py','sources/radial_equations_prior_gate.txt','sources/reduced_equations_prior_gate.txt','notes/central_series_generated.txt','notes/canonical_equations_generated.txt','data/pilot_results.csv']:
  need(sha(ROOT/name)==sha(OLD/name),'changed scientific file '+name)
 old=(OLD/'notes/levezetes_HU.md').read_text();new=(ROOT/'notes/levezetes_HU.md').read_text();need(new==old.replace(r'h_4=[(\nu_0+2p_1)',r'h_4=[(u_0+2p_1)'), 'J03 isolated replacement');need(r'u_0=12m_3' in new and r'h_4=[(u_0+2p_1)' in new,'central notation')
 d=pd.read_csv(ROOT/'data/pilot_results.csv');o=pd.read_csv(OLD/'data/pilot_results.csv');rows=[]
 for n in d.itertuples():
  prior=o[(o.EOS==n.EOS)&(o.alphaY==n.alphaY)&(o.L_km==n.L_km)].iloc[0]
  rows.append(dict(EOS=n.EOS,alphaY=n.alphaY,L_km=n.L_km,r3_R_g_km=prior.R_g_km,r4_R_g_km=n.R_g_km,delta_R_g_km=n.R_g_km-prior.R_g_km,r3_Lambda_metric=prior.Lambda_metric,r4_Lambda_metric=n.Lambda_metric,delta_Lambda_metric=n.Lambda_metric-prior.Lambda_metric))
 pd.DataFrame(rows).to_csv(ROOT/'data/r3_r4_baseline_comparison.csv',index=False)
 need(all(x['delta_R_g_km']==0 and x['delta_Lambda_metric']==0 for x in rows),'baseline number changed')
 archive=OLD/'delivery/Yukawa_tidal_pilot_20261108_r3.zip';need(sha(archive)=='4cf7257918e028049f81040b9783952100ed9a5d751412430dd97ee54f3ea49d','r3 archive changed')
 evidence={'regression_tests':report['tests'],'positive_tests':report['positive_builder_tests'],'negative_tests':report['negative_tests'],'optimized_tests':report['optimized_tests'],'physics_run_all_rerun_in_r4':False,'six_state_reproduction':json.loads((ROOT/'checks/reproduction_states.json').read_text()),'primary_csv_byte_identical_to_r3':True,'primary_csv_sha256':sha(ROOT/'data/pilot_results.csv'),'field_equation_EOS_generated_formula_files_byte_identical':True,'J03_only_document_replacement':True,'r3_archive_sha256_unchanged':sha(archive),'publication_preflight':prepublication(ROOT),'supplied_bridge_personally_verified':False,'PDF_generated':False,'pass':True}
 (ROOT/'checks/r4_release_evidence.json').write_text(json.dumps(evidence,indent=2))
 lic=(ROOT/'LICENSE.txt').read_text()
 (ROOT/'notes/r4_ellenorzes_HU.md').write_text(f"""# R4: adatkapu, portabilitás és reprodukció

A fizikai megoldó, mezőegyenletek, EOS, generált középponti képletek és a hat elsődleges állapot CSV-je bájtazonos az r3-mal. A h₄ leírt képletében az u₀ jelölés használata javult; az u₀ definíciója és a futó képlet változatlan. A hatállapotos R- és Λ-delta minden sorban 0, lásd `data/r3_r4_baseline_comparison.csv`.

Az r4-ben {report['tests']} izolált adat-/riportregresszió futott: {report['positive_builder_tests']} pozitív és {report['negative_tests']} elutasítási eset, ebből {report['optimized_tests']} `python -O` alatt. A tiszta és a szerződésen belüli portabilitási fixture átment; a NaN Λ, Inf M_K, hibás/duplikált/hiányzó rács, véges hibás g/q/tömegtérkép/egység, hibás kontroll és a szerződésen kívüli r2 összevetés nemnulla kóddal megállt. A hibás builderes esetekben nem keletkezett új publikációs adat/ábra/jegyzet, és a státusz hamisra váltott. A pozitív portabilitási eset ellenőrzött adatperturbáció, nem itt lefuttatott másik Python-környezet.

Hat háttér és hat kapcsolt árapályválasz tárolt NPZ nélkül újrafutott. A saját r3-környezettel azonos környezetben a tárolt R és Λ értékekhez a reprodukció eltérése 0. Az archívum ellenőrzése ezt külön kibontott példányban ismétli, és utána a védett builder is fut. A hozzá tartozó jelentés a ZIP-en kívüli `delivery/archive_verification.json` fájlban van; nem körkörös manifesthivatkozás.

A 18-scriptes tudományos `run_all.py` az r4-ben nem futott újra. A 64 módosított, 18 GR- és 12 kötelező kiscsatolású kontroll örökölt r3-bizonyíték; az r4 ezek tényleges adatait is ellenőrzi publikálás előtt, de nem azonosítja ezt új fizikai validálással. A labor-G kalibráció feltételes. Az opcionális a=10⁻⁸ APR4/L=10 háttér elutasítása és a hozzá tartozó Λ hiánya megmaradt.

A történeti háttérhíd kiegészítése a szolgáltatott Academia AI numerikus beszámoló tulajdonított állítása. Nem szakmai lektorálás, és nyers kód/futásanyag híján itt nem személyesen ellenőrzött eredmény. Lásd `forrashid_beszamolo_HU.md`. EOS-elkülöníthetőségi, megfigyelési, stabilitási vagy elsőségi állítás nincs.

PDF nem készült; az ábrákat ugyanazon adatokból újrageneráltuk, a PNG/SVG fájlok olvashatóságát ellenőriztük.

"""+lic)
 (ROOT/'internal/r4_audit_response_HU.md').write_text(f"""# Belső t780 javítási válasz — a ZIP-en kívül

J01: önálló `output_guard.py`, rögzített CSV-rács/séma és numerikus JSON-bizonyítékséma. A builder bármely hibánál explicit kivétellel, nemnulla kóddal és hamis státusszal áll meg. A publikációs adatok előtt végesség, egyediség, rács, egység, q/a/g, M_K/M_A és a tényleges kontrollok is kaput kapnak. A reprodukció bemeneti táblája is ellenőrzött. Az archívumintegritás védelme sem assertfüggő.

J02: a már rögzített Λ np.isclose(rtol=1e-8,atol=1e-9), R np.isclose(rtol=0,atol=1e-7 km) portabilitási szerződés. Előbb kötelező a végesség/egységellenőrzés. Az integrálási és fizikai kontrolltoleranciák nem változtak. A pozitív fixture és a valóban szerződésen kívüli véges hibák egyaránt tesztelve normál és -O módban.

J03: csak h₄ leírásában ν₀→u₀. A definíció, generált fájlok, solver/EOS és hat baseline CSV változatlan hashű. Hat sorban ΔR=ΔΛ=0.

Futások: {report['tests']} regresszió ({report['positive_builder_tests']} pozitív, {report['negative_tests']} elutasítás), {report['optimized_tests']} optimalizált. Hat saját uncached állapot újraépült; külön ZIP-kibontásból is reprodukció és builder következik. A 18-scriptes fizikai kontrollsorozat itt nem ismételt: r3-bizonyíték marad.

A történeti solver SHA és négy BVP-eredmény kizárólag a szolgáltatott Academia AI Markdown-beszámolóból származik. Nem állítunk átadott kódot, személyes újrafuttatást, önálló történeti tömeggyök-keresést vagy független árapály-megoldót. Az opcionális kis-a háttérhiba nincs sikerré átírva.

A módosított és új fájlok pontos listája régi/új SHA256 értékekkel a `checks/r4_change_inventory.json` fájlban szerepel. PDF-változás nincs; tudományos főadat- és egyenletváltozás nincs.

"""+lic)
 print(json.dumps(evidence,indent=2),flush=True)
 # No stdout writes after inventory hashing: the redirected log is stable.
 # Inventory excludes itself and packaging/extraction scratch, avoiding self hashes.
 from package_pilot import payload
 changed=[];added=[];unchanged=[]
 for p in payload():
  rel=p.relative_to(ROOT).as_posix()
  if rel=='checks/r4_change_inventory.json':continue
  prior=OLD/rel;item={'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)}
  if not prior.exists():added.append(item)
  elif sha(prior)!=sha(p):item['r3_sha256']=sha(prior);changed.append(item)
  else:unchanged.append(rel)
 (ROOT/'checks/r4_change_inventory.json').write_text(json.dumps({'modified':changed,'added':added,'unchanged':unchanged,'excludes_self':True,'physics_inputs_and_primary_baseline_unchanged':True},indent=2))

