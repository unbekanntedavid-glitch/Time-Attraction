#!/usr/bin/env python3
"""Exact v=0 on-shell local jet with positive matter pressure and B>0."""
from derive_covariant import *
rv=s.Integer(5);mv=s.Rational(1,10);ev=s.Rational(1,200);fv=s.Rational(1,10);yv=s.Integer(0);uv=s.Rational(1,2);av=s.Integer(1);cv=s.Rational(2,5);aa=s.Rational(4,5)
bv=1-2*mv/rv;pv=s.exp(fv)*(uv**2*fv**2/2-mv/(4*s.pi*rv**3));rho=uv**2*fv**2/2
mp=4*s.pi*rv**2*(s.exp(-fv)*ev+rho);bp=2*mv/rv**2-2*mp/rv
mm,pp,ff,yy,rr=s.symbols('mm pp ff yy rr',real=True)
b=1-2*mm/rr;vv=(mm+4*s.pi*rr**3*(s.exp(-ff)*pp+(b*yy**2-uv**2*ff**2)/2))/(rr**2*b)
point={rr:rv,mm:mv,pp:pv,ff:fv,yy:yv}
v0=s.simplify(vv.subs(point));assert v0==0
yp=(uv**2*fv-s.exp(-fv)*ev)/bv
vp=s.simplify((s.diff(vv,rr)+s.diff(vv,mm)*mp+s.diff(vv,yy)*yp).subs(point))
csym=s.symbols('r m e p psi w zeta mu cs',real=True);loc=dict(zip(['r','m','e','p','psi','w','zeta','mu','cs'],csym))
co=[s.sympify(line,locals=loc) for line in (ROOT/'notes/canonical_equations_generated.txt').read_text().splitlines()[2:]]
sub=dict(zip(csym,[rv,mv,ev,pv,fv,0,1,uv,cv]));co=[s.factor(t.subs(sub)) for t in co]
hv,hp,xv,xp=s.Rational(1,50),-s.Rational(1,40),s.Rational(1,30),s.Rational(1,20)
hpp=s.factor(co[0]*hv+co[1]*hp+co[2]*xv+co[3]*xp);xpp=s.factor(co[4]*hv+co[5]*xv+co[6]*xp)
kval=(2*s.pi*rv**2*s.exp(-fv)*(ev+3*pv)-1-2*s.pi*uv**2*rv**2*fv**2)*hv+(-4*s.pi*rv**2*s.exp(-fv)*ev+4*s.pi*uv**2*rv**2*fv)*xv
kp=-hp;kpp=-hpp-2*vp*hv-16*s.pi*yp*xv
mapping={r:rv,A:aa,s.diff(A,r):0,s.diff(A,r,2):2*aa*vp,B:bv,s.diff(B,r):bp,phi:fv,s.diff(phi,r):0,s.diff(phi,r,2):yp,e:ev,p:pv,cs2:cv,alpha:av,mu:uv,H0:hv,s.diff(H0,r):hp,s.diff(H0,r,2):hpp,H2:-hv,s.diff(H2,r):-hp,s.diff(H2,r,2):-hpp,K:kval,s.diff(K,r):kp,s.diff(K,r,2):kpp,chi:xv,s.diff(chi,r):xp,s.diff(chi,r,2):xpp}
results={name:s.simplify(expr.subs(mapping,simultaneous=True)) for name,expr in eqs.items()}
assert all(v==0 for v in results.values()),results
report={'Aprime_exact':'0','positive_pressure':bool(pv.evalf()>0),'B':str(bv),'finite_Hpp':str(hpp),'covariant_residuals':{k:str(v) for k,v in results.items()},'scope':'Exact local on-shell jet; not a global stellar zero-lapse-gradient claim. Old A-prime-dividing normalized master deliberately not used.','pass':True}
(ROOT/'checks/zero_Aprime_exact.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
