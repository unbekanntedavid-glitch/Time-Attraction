#!/usr/bin/env python3
"""Explicit publication-input contracts. No correctness gate depends on Python assert.
©2026 Szabolcsi Dávid; CC BY-NC 4.0. Independently implemented from supplied audit claims.
"""
from pathlib import Path
import json,math
import pandas as pd
import numpy as np
GM=1.476625038050125
KEY=['EOS','alphaY','L_km']
SCHEMA=json.loads(Path(__file__).with_name('publication_schema.json').read_text())
def need(ok,message):
 if not bool(ok):raise ValueError('Publication input rejected: '+str(message))
def close(a,b,rtol=1e-12,atol=1e-14):return bool(np.all(np.isclose(a,b,rtol=rtol,atol=atol)))
def finite(d,columns,label):
 for col in columns:
  need(col in d,label+' missing '+col)
  try:v=pd.to_numeric(d[col],errors='raise').to_numpy(dtype=float)
  except Exception as ex:raise ValueError(label+' invalid numeric '+col) from ex
  need(np.isfinite(v).all(),label+' nonfinite '+col)
def validate_state_table(d,label='state table',expected=None,mass_atol=1e-8):
 cols=KEY+['M_K_Msun','M_A_Msun','Gstar_over_Glab','q','R_g_km','Lambda_metric','lambda_geom_km5','k2_metric']
 finite(d,[c for c in cols if c!='EOS'],label)
 need(not d.duplicated(KEY).any(),label+' duplicate physical state') if expected is not None else None
 if expected is not None:need(set(map(tuple,d[KEY].to_numpy()))==set(expected),label+' wrong/missing physical state grid')
 a=d.alphaY.to_numpy(float);g=1/(1+a/(4*math.pi));mk=d.M_K_Msun.to_numpy(float)
 need((a>=0).all() and set(d.EOS)<=set(['SLy','APR4']),label+' EOS/coupling')
 need(close(d.q,a/(4*math.pi)) and close(d.Gstar_over_Glab,g),label+' G_lab calibration')
 need(close(mk,1.4,rtol=0,atol=mass_atol),label+' physical distant-Kepler mass')
 need(close(d.M_A_Msun,mk/g),label+' ADM/Kepler mapping')
 need((d.R_g_km>2*GM*mk).all() and (d.Lambda_metric>0).all(),label+' invalid radius/response')
 need(close(d.lambda_geom_km5,d.Lambda_metric*(GM*mk)**5,rtol=1e-10),label+' lambda units')
 need(close(d.k2_metric,1.5*d.lambda_geom_km5/d.R_g_km**5,rtol=1e-10),label+' k2 normalization')
 if 'cs2c' in d:need(((d.cs2c>0)&(d.cs2c<1)).all(),label+' sampled central causality')
 if 'applied_A_rank' in d:
  finite(d,['applied_A_rank','applied_A_condition','applied_A_sigma_min','applied_A_sigma_max','applied_tensor','applied_scalar','applied_dual_error','matching_relative_residual'],label)
  need((d.applied_A_rank==2).all() and ((d.applied_A_condition>=1)&(d.applied_A_condition<1e10)).all(),label+' applied matrix rank/condition')
  need((d.applied_A_sigma_min>0).all() and close(d.applied_A_condition,d.applied_A_sigma_max/d.applied_A_sigma_min,rtol=1e-10),label+' matrix singular values')
  need(close(d.applied_tensor,1,rtol=0,atol=1e-10) and (d.applied_scalar.abs()<1e-10).all(),label+' applied tide')
  need(((d.matching_relative_residual>=0)&(d.matching_relative_residual<2e-7)).all() and ((d.applied_dual_error>=0)&(d.applied_dual_error<2e-7)).all(),label+' exterior control')
 return d
BASE_GRID={(name,a,L) for name in ['SLy','APR4'] for a,L in [(0.,0.),(1.,1.),(1.,10.)]}
def comparison_contract(fresh,published):
 validate_state_table(fresh,'fresh r2',BASE_GRID);validate_state_table(published,'archived r2',BASE_GRID)
 for row in fresh.itertuples():
  old=published[(published.EOS==row.EOS)&(published.alphaY==row.alphaY)&(published.L_km==row.L_km)].iloc[0]
  need(np.isclose(row.Lambda_metric,old.Lambda_metric,rtol=1e-8,atol=1e-9),'r2 Lambda portability contract')
  need(np.isclose(row.R_g_km,old.R_g_km,rtol=0,atol=1e-7),'r2 radius portability contract')
def check_table(root,name,schema):
 p=root/name;need(p.is_file(),'missing '+name);d=pd.read_csv(p)
 need(len(d)==schema['rows'],name+' row count');need(set(schema['columns'])<=set(d.columns),name+' columns')
 ks=schema['keys'];lookup={}
 if ks:
  need(not d.duplicated(ks).any(),name+' duplicated key')
  expected=[tuple(row[k] for k in ks) for row in schema['grid']];actual=[tuple(row) for row in d[ks].to_numpy()]
  need(set(expected)==set(actual),name+' wrong/missing grid')
  lookup={key:schema['nullable_by_row'][i] for i,key in enumerate(expected)}
 for i,(_,row) in enumerate(d.iterrows()):
  nullable=lookup[tuple(row[k] for k in ks)] if ks else schema['nullable_by_row'][i]
  for col in schema['numeric']:
   try:x=float(row[col])
   except Exception as ex:raise ValueError(name+' invalid '+col) from ex
   need(math.isfinite(x) or (col in nullable and math.isnan(x)),name+' nonfinite '+col)
 if name.startswith('data/background_') and name.endswith(('_GR.csv','_L1.csv','_L10.csv')):
  need((np.diff(d.r_km)>0).all() and (d.m_geom_km>=0).all() and (d.epsilon_geom_kmminus2>=0).all(),name+' background grid/units')
 if 'M_K_Msun' in d:validate_state_table(d,name,BASE_GRID if name in ['data/pilot_results.csv','data/r2_fresh_rerun.csv','sources/r2_pilot_results.csv'] else None,mass_atol=1e-7 if name=='data/gr_convergence_controls.csv' else 1e-8)
 return d

def validate_publication(root):
 root=Path(root);tables={n:check_table(root,n,sc) for n,sc in SCHEMA.items()}
 main=tables['data/pilot_results.csv'];need(all(str(v).lower()=='true' for v in main[main.alphaY==1].gates_passed),'primary declared gate failure');comparison_contract(tables['data/r2_fresh_rerun.csv'],tables['sources/r2_pilot_results.csv'])
 # Validate the actual control rows used in the summaries, not only pre-existing pass flags.
 for n,d in tables.items():
  if n.startswith('data/controls_') or n=='data/gr_convergence_controls.csv':
   groupkeys=['EOS','alphaY','L_km']
   for key,part in d.groupby(groupkeys):
    ref=part[part.test=='baseline'];need(len(ref)==1,n+' baseline');lv=float(ref.iloc[0].Lambda_metric)
    threshold=1e-6 if key[1]==0 else 3e-4
    need((np.abs(part.Lambda_metric/lv-1)<threshold).all(),n+' actual response convergence')
    if key[1]==1:
     m=main[(main.EOS==key[0])&(main.alphaY==key[1])&(main.L_km==key[2])].iloc[0]
     need(close(m.Lambda_metric,lv,rtol=1e-12,atol=1e-9),n+' baseline mismatch')
     dl=float(np.max(np.abs(part.Lambda_metric-lv)));dr=float(np.max(np.abs(part.R_g_km-ref.iloc[0].R_g_km)))
     need(close(m.tested_Lambda_abs_envelope,dl,rtol=1e-6,atol=1e-10) and close(m.tested_R_km_abs_envelope,dr,rtol=1e-6,atol=1e-10),n+' declared envelope mismatch')
     need(close(m.tested_Lambda_relative_envelope,dl/abs(lv),rtol=1e-6,atol=1e-12),n+' relative envelope units')
 gr=tables['data/gr_benchmarks.csv'];err=np.abs(gr.Lambda_riccati/gr.Lambda_subspace-1)
 need((err<1e-6).all() and close(gr.relative_difference,err,rtol=1e-5,atol=1e-12),'GR benchmark actual values')
 for x in gr.itertuples():
  ref=main[(main.EOS==x.EOS)&(main.alphaY==0)].iloc[0];need(close(x.Lambda_subspace,ref.Lambda_metric,rtol=1e-8,atol=1e-9),'GR main consistency')
 lim=tables['data/coupling_limit.csv']
 for (eos,L),part in lim.groupby(['EOS','L_km']):
  part=part.sort_values('alphaY',ascending=False);ref=main[(main.EOS==eos)&(main.alphaY==0)].iloc[0].Lambda_metric;err=part.Lambda_metric.to_numpy()/ref-1
  need(close(part.relative_to_GR,err,rtol=1e-6,atol=1e-10) and all(abs(b)<abs(a)/5 for a,b in zip(err,err[1:])),'coupling limit actual values')
 syn=tables['data/exterior_normalization_controls.csv']
 need(close(syn.exact_abs_error,np.abs(syn.recovered_exact_lambda_geom_km5-syn.known_lambda_geom_km5),rtol=1e-6,atol=1e-10) and (syn.exact_abs_error<1e-3).all() and (syn.Legendre_hypergeometric_relative_error<1e-12).all(),'tensor normalization controls')
 scalar=tables['data/scalar_amplitude_controls.csv'];need(close(scalar.applied_scalar_abs_error,np.abs(scalar.recovered_applied_scalar-scalar.known_applied_scalar),rtol=1e-6,atol=1e-14),'scalar amplitude error consistency');need((scalar.applied_scalar_abs_error<1e-12).all() and (scalar.Wronskian_relative_error<1e-8).all(),'scalar normalization controls')
 integ=tables['data/integrated_equation_residuals.csv'];need((integ[[c for c in integ if 'normalized' in c or 'Fprime' in c]].abs().to_numpy()<5e-4).all(),'integrated residual controls')
 eos=tables['data/eos_junction_controls.csv'];need((eos[['epsilon_continuity_relative_error','pressure_continuity_relative_error']].abs().to_numpy()<1e-11).all(),'EOS junction controls')
 attempts=tables['data/weak_coupling_attempts.csv'];bad=attempts[attempts.status=='inconclusive_background_rejected'];need(len(bad)==1 and bad.iloc[0].EOS=='APR4' and bad.iloc[0].L_km==10 and pd.isna(bad.iloc[0].Lambda_metric),'quarantined optional state')
 need(len(attempts[attempts.status=='accepted'])==3,'optional accepted state grid')
 # JSON numeric tokens are strict too, while explicit nulls in rejected-state evidence remain valid.
 def invalid(token):raise ValueError('nonfinite JSON token '+token)
 for p in (root/'checks').glob('*.json'):json.loads(p.read_text(),parse_constant=invalid)
 evidence=json.loads(Path(__file__).with_name('evidence_schema.json').read_text())
 for name,paths in evidence.items():
  obj=json.loads((root/'checks'/name).read_text())
  for path in paths:
   x=obj
   for key in path:x=x[key]
   need(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x),name+' invalid numeric evidence '+str(path))
 bg=json.loads((root/'checks/background_acceptance.json').read_text())
 for x in bg['cases']:need(0<=x['max_rms_residual']<=x['requested_tolerance'] and abs(x['boundary_mass_error_km'])<1e-10,'background actual acceptance')
 extra=json.loads((root/'checks/extra_audits.json').read_text())
 for x in extra['cases']:need(x['alternate_integrator_relative_difference']<3e-5 and 0<x['max_cs2_sampled_with_one_sided_interfaces']<1 and x['max_unused_background_angular_normalized_residual_fd']<1e-4,'alternate-integrator/background evidence')
 norm=json.loads((root/'checks/normalization_and_bridge.json').read_text())
 need(close(norm['max_exact_lambda_abs_error_km5'],float(syn.exact_abs_error.max()),rtol=1e-6,atol=1e-10) and close(norm['max_Legendre_relative_error'],float(syn.Legendre_hypergeometric_relative_error.max()),rtol=1e-6,atol=1e-15),'normalization evidence consistency')
 analytic=tables['data/background_analytic_map_controls.csv'];g=1/(1+analytic.k_action/(4*math.pi))
 need(close(analytic.Gstar_over_Glab,g) and close(analytic.legacy_reported_alpha_sqrt_k,np.sqrt(analytic.k_action)) and close(analytic.target_legacy_MADM_Msun,1.4/g) and close(analytic.derived_MK_Msun,1.4) and (analytic.canonical_to_analytic_k_u_map_abs_error<1e-15).all(),'analytic map units/calibration')
 num=json.loads((root/'checks/numerical_gates.json').read_text())
 for item in num['GR_benchmarks']:
  row=gr[gr.EOS==item['EOS']].iloc[0]
  need(0<=item['relative_difference']<1e-6 and close(item['relative_difference'],row.relative_difference,rtol=1e-5,atol=1e-12),'reported GR benchmark consistency')
 integrated=json.loads((root/'checks/integrated_equation_residuals.json').read_text())
 for col,value in integrated['max_normalized_residuals'].items():need(0<=value<5e-4 and close(value,float(integ[col].max()),rtol=1e-6,atol=1e-12),'reported integrated residual consistency')
 scalar_report=json.loads((root/'checks/scalar_amplitude_controls.json').read_text())
 need(close(scalar_report['max_applied_scalar_abs_error'],float(scalar.applied_scalar_abs_error.max()),rtol=1e-6,atol=1e-15) and scalar_report['max_applied_scalar_abs_error']<1e-12 and scalar_report['max_scalar_Wronskian_relative_error']<1e-8,'reported scalar normalization consistency')
 units=json.loads((root/'checks/physical_units.json').read_text())
 need(close(units['G_lab_SI'],6.67430e-11,rtol=0,atol=0) and units['c_m_per_s']==299792458. and units['solar_mass_kg']==1.988409870698051e30 and close(units['G_lab_solar_mass_over_c2_km'],GM) and close(units['target_geometric_mass_km'],1.4*GM),'physical unit definition')
 return {'tables_checked':len(tables),'primary_states':len(main),'finite_grid_units_calibration_mass_and_actual_controls_passed':True,'portability_contract':{'Lambda_rtol':1e-8,'Lambda_atol':1e-9,'R_rtol':0,'R_atol_km':1e-7}}
def prepublication(root):
 try:return validate_publication(root)
 except Exception as ex:
  p=Path(root)/'checks/scientific_status.json';p.write_text(json.dumps({'required_pilot_gates_passed':False,'publication_input_gate_passed':False,'error':str(ex)},indent=2));raise
if __name__=='__main__':
 import sys
 print(json.dumps(prepublication(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]),indent=2))
