#!/usr/bin/env python3
"""Known growing/decaying scalar amplitudes in the explicitly defined curved vacuum reference."""
from run_suite import *
from extra_audits import load_bg
if __name__=='__main__':
 rows=[]
 for name in ['SLy','APR4']:
  for L in [1.,10.]:
   bg=load_bg(name,L);R=bg['R'];M=bg['mout'];BR=1-2*M/R;sR,tR=scalar_vacuum_basis(bg,R);assert tR==1.
   for n in [8.,12.,14.]:
    rb=R+n*L
    def rhs(r,z):
     B=1-2*M/r;P=2/r+2*M/(r*r*B);return [z[1],(6/r**2+1/L**2)*z[0]/B-P*z[1]]
    sol=solve_ivp(rhs,(R,rb),[0.,1/R],method='DOP853',rtol=3e-12,atol=1e-13,max_step=min(L/8,.08));assert sol.success
    G,Gp=sol.y[:,-1];kd,D=scalar_vacuum_basis(bg,rb);Dp=kd*D;kg=Gp/G
    W=G*Dp-Gp*D;expected=-R*BR/(rb*rb*(1-2*M/rb));we=abs(W/expected-1)
    for ag,bd in [(0.,1.),(0.,-.7),(1.,0.),(.25,-.7)]:
     eta=ag*G+bd*D;ep=ag*Gp+bd*Dp;measured=(ep-kd*eta)/((kg-kd)*G)
     error=abs(measured-ag)
     rows.append(dict(EOS=name,L_km=L,nmatch=n,known_applied_scalar=ag,known_decaying_scalar=bd,recovered_applied_scalar=measured,applied_scalar_abs_error=error,Wronskian_relative_error=we,decaying_R_normalization=tR,growing_R_value=0.,growing_R_derivative=1/R))
 assert max(v['applied_scalar_abs_error'] for v in rows)<1e-12
 assert max(v['Wronskian_relative_error'] for v in rows)<1e-8
 write_rows(ROOT/'data/scalar_amplitude_controls.csv',rows)
 report={'synthetic_scalar_reference_cases':len(rows),'both_L_tested':True,'matching_offsets_L':[8.,12.,14.],'max_applied_scalar_abs_error':max(v['applied_scalar_abs_error'] for v in rows),'max_scalar_Wronskian_relative_error':max(v['Wronskian_relative_error'] for v in rows),'scope':'Curved Schwarzschild homogeneous reference normalization; actual stellar response uses the separate coupled vacuum including tensor-induced particular mode.','pass':True}
 (ROOT/'checks/scalar_amplitude_controls.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
