#!/usr/bin/env python3
"""Fresh archived-r2 recalculations in the r3 output tree; older trees are read-only."""
from run_suite import *
spec=importlib.util.spec_from_file_location('r2_reference',ROOT/'sources/pilot_r2_reference.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
if __name__=='__main__':
 rows=[]
 for name in ['SLy','APR4']:
  for a,L in [(0.,1.),(1.,1.),(1.,10.)]:
   bg=old.background(name,a,L,bgtol=2e-8);row=old.tidal(bg,**BASE);rows.append(row);write_rows(ROOT/'data/r2_fresh_rerun.csv',rows);print('r2 fresh',name,a,L,row['R_g_km'],row['Lambda_metric'],flush=True)
 (ROOT/'checks/r2_fresh_rerun.json').write_text(json.dumps({'states':len(rows),'cached_backgrounds_used':False,'source_sha256':hashlib.sha256((ROOT/'sources/pilot_r2_reference.py').read_bytes()).hexdigest(),'earlier_packages_modified':False},indent=2))
