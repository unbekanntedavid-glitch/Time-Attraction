#!/usr/bin/env python3
"""Supplement L=10 km integrated decoupling tests with L=1 km, both EOSs.
©2026 Szabolcsi Dávid, CC BY-NC4.0.
"""
from run_suite import *
if __name__=='__main__':
 import pandas as pd
 limits=pd.read_csv(ROOT/'data/coupling_limit.csv').to_dict('records');limits=[v for v in limits if v['L_km']==10.]
 gr=pd.read_csv(ROOT/'data/pilot_results.csv');refs={name:float(gr[(gr.EOS==name)&(gr.alphaY==0)].iloc[0].Lambda_metric) for name in ['SLy','APR4']}
 for name in ['SLy','APR4']:
  for a in [.01,.001,.0001]:
   bg=background(name,a,1.,bgtol=2e-8);row=tidal(bg,**BASE);row['relative_to_GR']=row['Lambda_metric']/refs[name]-1;limits.append(row);write_rows(ROOT/'data/coupling_limit.csv',limits);print(name,1.,a,row['relative_to_GR'],flush=True)
 report=json.loads((ROOT/'checks/numerical_gates.json').read_text());passing={}
 for name in ['SLy','APR4']:
  for L in [1.,10.]:
   seq=sorted([v for v in limits if v['EOS']==name and v['L_km']==L],key=lambda z:-z['alphaY']);passing[f'{name}_L{L:g}']=bool(len(seq)==3 and all(abs(b['relative_to_GR'])<abs(a['relative_to_GR'])/5 for a,b in zip(seq,seq[1:])))
 report['small_coupling_monotone_toward_GR']=passing;report['small_coupling_configurations']=len(limits);report['all_numeric_gates_passed']=bool(report['all_numeric_gates_passed'] and all(passing.values()))
 (ROOT/'checks/numerical_gates.json').write_text(json.dumps(report,indent=2));print(json.dumps(passing,indent=2))
