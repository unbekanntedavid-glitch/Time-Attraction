#!/usr/bin/env python3
"""Record actual accepted collocation residuals and exterior-tail estimates.
©2026 Szabolcsi Dávid; CC BY-NC4.0.
"""
from pilot import *
if __name__=='__main__':
 rows=[]
 for name in ['SLy','APR4']:
  for L in [1.,10.]:
   bg=background(name,1.,L,bgtol=2e-8);sol=bg['bgsol'];R=bg['R'];out=R+20*L;last=sol.sol(1.);phiout=float(last[7]);leading_tail=2*PI*out*out*phiout*phiout/L
   row=dict(EOS=name,L_km=L,collocation_success=bool(sol.success),nodes=int(len(sol.x)),max_rms_residual=float(max(sol.rms_residuals)),requested_tolerance=2e-8,boundary_mass_error_km=float(last[5]-TARGET),R_km=R,hc=bg['hc'],phi_c=bg['phic'],phi_outer=phiout,leading_decaying_tail_mass_estimate_Msun=float(leading_tail/GM),outer_radius_km=out)
   assert sol.success and row['max_rms_residual']<=2e-8 and abs(row['boundary_mass_error_km'])<1e-10
   rows.append(row);print(json.dumps(row),flush=True)
 (ROOT/'checks/background_acceptance.json').write_text(json.dumps({'cases':rows,'tail_note':'Leading decaying-tail estimate, not an exact bound; no beyond-cutoff growing shooting branch is included.','pass':True},indent=2))
