"""Safe extraction, every payload hash, and uncached six-state numerical replay from ZIP."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile, tempfile, os, subprocess, sys, stat
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT = Path(__file__).resolve().parents[1]
DEL = ROOT / 'delivery'
NAME = 'Yukawa_tidal_pilot_20261108_r4'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def artifact(p):
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
if __name__ == '__main__':
    build = json.loads((DEL / 'package_build.json').read_text())
    archive = Path(build['archive'])
    if not sha(archive) == build['sha256']:
        raise ValueError('validation failed')
    (ROOT / 'rebuild_from_zip').mkdir(exist_ok=True)
    target = Path(tempfile.mkdtemp(prefix='payload_', dir=ROOT / 'rebuild_from_zip'))
    with zipfile.ZipFile(archive) as z:
        if not z.testzip() is None:
            raise ValueError('validation failed')
        if not sum((i.file_size for i in z.infolist())) < 150000000:
            raise ValueError('validation failed')
        for info in z.infolist():
            name = PurePosixPath(info.filename)
            if not (not name.is_absolute() and '..' not in name.parts and (name.parts[0] == NAME)):
                raise ValueError('validation failed')
            if not not stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError('validation failed')
            dest = target.joinpath(*name.parts)
            if not dest.resolve().is_relative_to(target.resolve()):
                raise ValueError('validation failed')
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(info))
    root = target / NAME
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    expected = {v['path'] for v in manifest['files']}
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if not actual == expected | {'MANIFEST.json'}:
        raise ValueError('validation failed')
    for row in manifest['files']:
        p = root / row['path']
        if not (p.stat().st_size == row['bytes'] and sha(p) == row['sha256']):
            raise ValueError(row['path'])
    if not sha(root / 'MANIFEST.json') == build['manifest_sha256']:
        raise ValueError('validation failed')
    logfile = DEL / 'archive_reproduction.log'
    with logfile.open('w') as f:
        run = subprocess.run([sys.executable, '-u', str(root / 'code/reproduce_pilot.py')], cwd=root, stdout=f, stderr=subprocess.STDOUT, env=os.environ | {'OPENBLAS_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1'})
    if not run.returncode == 0:
        raise ValueError(logfile)
    numeric = json.loads((root / 'checks/reproduction_states.json').read_text())
    if not (numeric['pass'] and numeric['rebuilt_background_and_tide_states'] == 6 and (not numeric['cached_backgrounds_used'])):
        raise ValueError('validation failed')
    buildlog = DEL / 'archive_builder.log'
    with buildlog.open('w') as f:
        built = subprocess.run([sys.executable, '-u', str(root / 'code/build_outputs.py')], cwd=root, stdout=f, stderr=subprocess.STDOUT, env=os.environ | {'OPENBLAS_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1'})
    if built.returncode != 0:
        raise ValueError(str(buildlog))
    publication = json.loads((root / 'checks/scientific_status.json').read_text())
    if not publication['required_pilot_gates_passed']:
        raise ValueError('extracted builder rejected clean replay')
    report = {'isolated_builder_exit_code': built.returncode, 'isolated_publication_input_gate': publication['publication_input_gate'], 'scientific_run_all_rerun_in_r4': False, 'archive': artifact(archive), 'manifest_sha256': build['manifest_sha256'], 'verified_payload_files': len(manifest['files']), 'CRC_passed': True, 'path_safety_passed': True, 'all_payload_hashes_passed': True, 'numeric_replay_from_extracted_payload': numeric, 'replay_exit_code': run.returncode, 'replay_log': artifact(logfile), 'extracted_root': str(root), 'verified_at_Europe_Zurich': datetime.now(ZoneInfo('Europe/Zurich')).isoformat()}
    rp = DEL / 'archive_verification.json'
    rp.write_text(json.dumps(report, indent=2))
    handoff = {'scope': 'r4 publication/data guards and notation patch; inherited r3 physics evidence; six-state uncached replay and isolated builder; optional small-a rejection retained; historical bridge supplied Academia AI report only', 'artifacts': [artifact(archive), artifact(ROOT / 'MANIFEST.json'), artifact(rp), artifact(ROOT / 'notes/dontesi_jegyzet_HU.md'), artifact(ROOT / 'data/r3_r4_baseline_comparison.csv'), artifact(ROOT / 'checks/r4_change_inventory.json'), artifact(ROOT / 'checks/r4_publication_regressions.json'), artifact(ROOT / 'internal/r4_audit_response_HU.md')], 'payload_files': len(manifest['files']), 'uncached_rebuilt_states_from_ZIP': 6, 'internal_review_is_outside_ZIP': True, 'verification_time_zone': 'Europe/Zurich'}
    (DEL / 'handoff.json').write_text(json.dumps(handoff, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(handoff, ensure_ascii=False, indent=2))
