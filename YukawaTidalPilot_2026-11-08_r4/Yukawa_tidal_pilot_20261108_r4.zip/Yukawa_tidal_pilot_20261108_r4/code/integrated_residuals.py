#!/usr/bin/env python3
"""Independent finite-difference residuals on actual integrated regular columns."""
from reaudit_numeric import *
from run_suite import write_rows,BASE
from extra_audits import load_bg

def algebra(bg,rv,z):
 z=np.asarray(z).reshape(4,2);m,h,psi,w=canonical_at(bg,rv);a=bg['a'];zz=np.sqrt(a);L=bg['L']
 e,p,cs,B,v,mp,bp,wp=canonical_background_values(rv,m,h,psi,w,bg['eos'],zz,L)
 f=np.exp(-zz*psi)
 af=-rv*rv*B*v/2;bf=2*PI*rv*rv*f*(e+3*p)-rv*rv*B*v*v-rv*B*v-1-2*PI*rv*rv*psi*psi/L**2
 cf=-4*PI*zz*rv*rv*f*e+4*PI*rv*rv*psi/L**2-8*PI*rv*rv*B*v*w-8*PI*rv*B*w;df=-4*PI*rv*rv*B*w
 F=af*z[1]+bf*z[0]+cf*z[2]+df*z[3];S=-z[1]-2*v*z[0]-16*PI*w*z[2]
 return dict(F=F,S=S,v=v,B=B,e=e,p=p,cs=cs,psi=psi,w=w,phi=zz*psi,y=zz*w,h=h,m=m)

if __name__=='__main__':
 rows=[];case_rows=[]
 for name in ['SLy','APR4']:
  for LL in [1.,10.]:
   bg=load_bg(name,LL);zeta=np.sqrt(bg['a']);L=LL
   def hook(bg,rv,poly,dh):
    zs=[poly(rv+j*dh).reshape(4,2) for j in [-2,-1,0,1,2]];al=[algebra(bg,rv+j*dh,zs[k]) for k,j in enumerate([-2,-1,0,1,2])]
    def derivative(vals):return (np.asarray(vals[0])-8*np.asarray(vals[1])+8*np.asarray(vals[3])-np.asarray(vals[4]))/(12*dh)
    state=zs[2];c=al[2];dstate=derivative(zs);Fprime=derivative([q['F'] for q in al]);Sprime=derivative([q['S'] for q in al]);vprime=derivative([q['v'] for q in al]);Bprime=derivative([q['B'] for q in al]);phipp=derivative([q['y'] for q in al]);eprime=derivative([q['e'] for q in al]);pprime=derivative([q['p'] for q in al]);avalue=.8;ap=2*avalue*c['v'];app=2*avalue*vprime+4*avalue*c['v']**2
    for j in [0,1]:
     hv,hp,eta,etap=state[:,j];hpp=dstate[1,j];xv=zeta*eta;xp=zeta*etap;xpp=zeta*dstate[3,j]
     args=[rv,avalue,c['B'],c['phi'],ap,app,Bprime,c['y'],phipp,c['e'],c['p'],c['cs'],eprime,pprime,bg['a'],1/L,hv,hp,hpp,xv,xp,xpp]
     rawargs=[rv,avalue,c['B'],c['phi'],ap,app,Bprime,c['y'],phipp,c['e'],c['p'],c['cs'],bg['a'],1/L,hv,hp,hpp,-hv,-hp,-hpp,c['F'][j],c['S'][j],Sprime[j],xv,xp]
     scale=max(abs(hpp),abs(hv)/rv**2,abs(hp)/rv,abs(dstate[3,j]),abs(eta)/rv**2,abs(etap)/rv,1e-18)
     kscale=max(abs(Fprime[j]),abs(c['S'][j]),abs(hp),abs(etap),1e-18)
     rows.append(dict(EOS=name,L_km=L,r_km=rv,column=j,fd_halfstep_km=dh,old_reconstruction_Fprime_minus_S_normalized=abs(Fprime[j]-c['S'][j])/kscale,tt_Einstein_normalized=abs(float(ft(*rawargs)))/scale,unused_rr_Einstein_normalized=abs(float(fr(*rawargs)))/scale,unused_rtheta_Einstein_normalized=abs(float(frt(*rawargs)))/max(abs(hp),abs(etap),1e-18),unused_angular_Einstein_normalized=abs(float(fa(*rawargs)))/scale,scalar_equation_normalized=abs(float(fs(*args)))/zeta/scale,old_normalized_metric_equation=abs(float(fm(*args)))/scale))
   answer=tidal(bg,**BASE,diagnostic=hook);case_rows.append(answer);print('integrated residual case',name,L,'samples',len(rows),flush=True)
 write_rows(ROOT/'data/integrated_equation_residuals.csv',rows);write_rows(ROOT/'data/exterior_particular_controls.csv',case_rows)
 cols=[k for k in rows[0] if 'normalized' in k or 'Fprime' in k]
 maxima={k:max(v[k] for v in rows) for k in cols}
 passing=all(v<5e-4 for v in maxima.values())
 report=dict(samples=len(rows),cases=4,derivative_method='Independent five-point finite differences of dense numerical solution and collocation background; Fprime-S, tt, scalar and unused Einstein equations.',max_normalized_residuals=maxima,threshold=5e-4,pass_gate=passing)
 (ROOT/'checks/integrated_equation_residuals.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert passing
