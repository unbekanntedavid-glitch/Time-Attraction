#!/usr/bin/env python3
"""Independent analytic-map and exact-vacuum normalization controls; no claimed legacy solver import."""
from run_suite import *
import mpmath as mp
if __name__=='__main__':
 rows=[];mp.mp.dps=70;M=TARGET
 for rv in [8.,12.,30.,100.,200.]:
  T=vacuum_basis(rv,M);x=mp.mpf(rv)/mp.mpf(M)-1
  q22=mp.mpf('1.5')*(x*x-1)*mp.log((x+1)/(x-1))-3*x+2*x/(x*x-1)
  qref=float(5*q22/(8*mp.mpf(M)**3));qerror=abs(T[0,1]/qref-1)
  for known in [0.,1000.,10000.,50000.]:
   ah=1e-6;bh=3*ah*known;state=T@np.array([ah,bh]);fit=np.linalg.solve(T,state);recovered=fit[1]/fit[0]/3
   power=np.array([[rv*rv,rv**-3],[2*rv,-3*rv**-4]]);pf=np.linalg.solve(power,state);false=pf[1]/pf[0]/3
   rows.append(dict(r_km=rv,known_lambda_geom_km5=known,recovered_exact_lambda_geom_km5=recovered,exact_abs_error=abs(recovered-known),Legendre_hypergeometric_relative_error=qerror,power_fit_lambda_geom_km5=false,exact_basis_condition_number=np.linalg.cond(T)))
 assert max(v['exact_abs_error'] for v in rows)<1e-3
 assert max(v['Legendre_hypergeometric_relative_error'] for v in rows)<1e-12
 assert min(abs(v['power_fit_lambda_geom_km5']) for v in rows if v['known_lambda_geom_km5']==0)>100
 write_rows(ROOT/'data/exterior_normalization_controls.csv',rows)
 bridge=[]
 for k in [0.,.001,.1,1.]:
  for L in [1.,10.]:
   g=1/(1+k/(4*PI));r0=8.;mass=.9;elab=.0006;plab=.00008;e=g*elab;p=g*plab;u=.02;vlegacy=-.001;z=np.sqrt(k);psi=z*u;w=z*vlegacy;phi=k*u;yp=k*vlegacy;B=1-2*mass/r0;f=np.exp(-phi)
   rhok=k*(B*vlegacy*vlegacy+u*u/L**2)/2;prk=k*(B*vlegacy*vlegacy-u*u/L**2)/2
   mk=4*PI*r0*r0*(f*e+rhok);vk=(mass+4*PI*r0**3*(f*p+prk))/(r0*r0*B);bk=2*mass/r0**2-2*mk/r0
   upp=(u/L**2-f*e-(2*B/r0+B*vk+bk/2)*vlegacy)/B
   rhoc=(B*w*w+psi*psi/L**2)/2;prc=(B*w*w-psi*psi/L**2)/2
   mc=4*PI*r0*r0*(f*e+rhoc);vc=(mass+4*PI*r0**3*(f*p+prc))/(r0*r0*B);bc=2*mass/r0**2-2*mc/r0
   wpp=(psi/L**2-z*f*e-(2*B/r0+B*vc+bc/2)*w)/B
   err=max(abs(mc-mk),abs(vc-vk),abs(wpp-z*upp),abs(phi-z*psi),abs(yp-z*w))
   bridge.append(dict(k_action=k,legacy_reported_alpha_sqrt_k=np.sqrt(k),L_km=L,Gstar_over_Glab=g,target_legacy_MADM_Msun=1.4/g,derived_MK_Msun=g*(1.4/g),epsilon_geom=e,p_geom=p,canonical_to_analytic_k_u_map_abs_error=err,legacy_solver_imported=False,GR_physical_background_zero=bool(k!=0 or (psi==0 and w==0))))
 assert max(v['canonical_to_analytic_k_u_map_abs_error'] for v in bridge)<1e-15
 assert max(abs(v['derived_MK_Msun']-1.4) for v in bridge)<1e-15
 write_rows(ROOT/'data/background_analytic_map_controls.csv',bridge)
 gr=[]
 for name in ['SLy','APR4']:
  bg=gr_background(name)
  for rv in [.1,1.,bg['R']*.9]:
   m,h,ps,w=canonical_at(bg,rv);e,p,_,cs=bg['eos'].at(h);B=1-2*m/rv;v=(m+4*PI*rv**3*p)/(rv*rv*B)
   P=2/rv+(2*m/rv**2+4*PI*rv*(p-e))/B
   Q=-6/(rv**2*B)+4*PI*(5*e+9*p+(e+p)/cs)/B-4*v*v
   co=coeff(bg,rv);err=max(abs(co[0]+Q),abs(co[1]+P),abs(co[2]),abs(co[3]),abs(co[4]))
   gr.append(dict(EOS=name,r_km=rv,psi=float(ps),psi_prime=float(w),metric_and_scalar_decoupling_abs_error=err))
 assert max(v['metric_and_scalar_decoupling_abs_error'] for v in gr)<1e-9
 write_rows(ROOT/'data/canonical_zero_coupling_controls.csv',gr)
 report={'exact_tensor_synthetic_cases':len(rows),'max_exact_lambda_abs_error_km5':max(v['exact_abs_error'] for v in rows),'max_Legendre_relative_error':max(v['Legendre_hypergeometric_relative_error'] for v in rows),'analytic_bridge_cases':len(bridge),'max_analytic_map_abs_error':max(v['canonical_to_analytic_k_u_map_abs_error'] for v in bridge),'claimed_legacy_solver_available':False,'bridge_scope':'Independent analytic k-u RHS reconstruction only. User-cited coupling_solver.py and audit supplements were not available locally; no actual RHS provenance equivalence to that file is claimed.','canonical_GR_cases':len(gr),'max_canonical_GR_abs_error':max(v['metric_and_scalar_decoupling_abs_error'] for v in gr),'pass':True}
 (ROOT/'checks/normalization_and_bridge.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
