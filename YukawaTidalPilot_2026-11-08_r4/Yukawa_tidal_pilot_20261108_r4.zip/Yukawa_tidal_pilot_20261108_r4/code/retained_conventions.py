#!/usr/bin/env python3
"""Executable checks of r2 conventions retained by r3; scalar amplitudes have an explicit unit conversion."""
from run_suite import *
import pandas as pd
spec=importlib.util.spec_from_file_location('r2_convention_reference',ROOT/'sources/pilot_r2_reference.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
if __name__=='__main__':
 basis=[]
 for r in [8.,12.,30.,100.,200.]:
  equal=np.array_equal(vacuum_basis(r,TARGET),old.vacuum_basis(r,TARGET));assert equal;basis.append(dict(r_km=r,exact_array_equality=bool(equal)))
 new=pd.read_csv(ROOT/'data/pilot_results.csv');prior=pd.read_csv(ROOT/'data/r2_fresh_rerun.csv');rows=[]
 for n in new.itertuples():
  o=prior[(prior.EOS==n.EOS)&(prior.alphaY==n.alphaY)&(prior.L_km==n.L_km)].iloc[0]
  unit=float(o.scalar_decay_amplitude/n.R_g_km**2);difference=n.scalar_decay_amplitude-unit
  assert abs(n.M_K_Msun-o.M_K_Msun)<1e-9 and n.Gstar_over_Glab==o.Gstar_over_Glab
  assert abs(difference)<1e-7*max(abs(unit),1.)
  rows.append(dict(EOS=n.EOS,alphaY=n.alphaY,L_km=n.L_km,MK_difference_Msun=n.M_K_Msun-o.M_K_Msun,Gstar_over_Glab_difference=n.Gstar_over_Glab-o.Gstar_over_Glab,r2_scalar_decay_amplitude=o.scalar_decay_amplitude,r2_scalar_amplitude_in_r3_tensor_unit=unit,r3_scalar_decay_amplitude=n.scalar_decay_amplitude,rescaled_scalar_amplitude_difference=difference))
 write_rows(ROOT/'data/retained_conventions.csv',rows)
 report={'exact_r2_r3_tensor_basis_samples':basis,'states_with_unchanged_mass_coupling_range_G_conventions':len(rows),'max_rescaled_scalar_amplitude_difference':max(abs(v['rescaled_scalar_amplitude_difference']) for v in rows),'scalar_unit_conversion':'r3 applied tensor aH=1/R^2 versus r2 aH=1; for a=1 eta=chi, so old scalar coefficient is divided by R^2. These are reference coefficients, not scalar Love numbers.','lambda_factor':1/3,'pass':True}
 (ROOT/'checks/retained_conventions.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
