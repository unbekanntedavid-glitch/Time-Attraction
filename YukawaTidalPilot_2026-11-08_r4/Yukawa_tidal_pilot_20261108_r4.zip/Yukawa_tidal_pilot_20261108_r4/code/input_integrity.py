#!/usr/bin/env python3
"""Read-only input/protected-package integrity checks; no old directory writes."""
from pathlib import Path
import hashlib,json,zipfile,ast,math
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
 sources=json.loads((ROOT/'sources/prior_action_provenance.json').read_text());rows=[]
 constants={}
 for node in ast.parse((ROOT/'sources/stellar_tal_v21.py').read_text()).body:
  if isinstance(node,ast.Assign):
   for target in node.targets:
    if isinstance(target,ast.Name) and target.id in ['G','C','MS']:constants[target.id]=ast.literal_eval(node.value)
 gm=constants['G']*constants['MS']/constants['C']**2/1000;g=1/(1+1/(4*math.pi))
 units={'G_lab_SI':constants['G'],'c_m_per_s':constants['C'],'solar_mass_kg':constants['MS'],'G_lab_solar_mass_over_c2_km':gm,'target_MK_solar_mass':1.4,'target_geometric_mass_km':1.4*gm,'a1_Gstar_over_Glab':g,'a1_target_ADM_solar_mass':1.4/g,'source':'sources/stellar_tal_v21.py, top-level constants G C MS'}
 assert gm==1.476625038050125
 (ROOT/'checks/physical_units.json').write_text(json.dumps(units,indent=2))
 for entry in sources['copied_sources']:
  p=ROOT/entry['copy'];h=digest(p);assert h==entry['sha256'];rows.append({'path':entry['copy'],'bytes':p.stat().st_size,'sha256':h})
 h=digest(ROOT/'sources/user_additions_original.md');assert h=='524719bb26fa502928086415133342f47eec0298661eda20eb67be62b985f571'
 preserved=[]
 for p,h in [(Path('/workspace/yukawa_binding_publication_20261108_b/delivery/YBE-2026-11-08-b_publication_set.zip'),'8601e972e5c19efac801bb9f49c5ebe99bbd89cfb56e9fc44b2ccd3ad6b3469a'),(Path('/workspace/yukawa_tidal_pilot_20261108/delivery/Yukawa_tidal_derivation_gate_20261108.zip'),'e826593f756729715517b027eced04a6215d7f6e6860954f9c76e5754ee9b2b4'),(Path('/workspace/yukawa_tidal_pilot_20261108_r2/delivery/Yukawa_tidal_pilot_20261108_r2.zip'),'2dca3c6c9a8a28527ea1b3b4fc5f17f886c8ffcbf964ab7e12b9990b11112c4c')]:
  if p.exists():
   actual=digest(p);assert actual==h;preserved.append({'path':str(p),'sha256':actual,'bytes':p.stat().st_size,'verified_now':True})
  else:preserved.append({'path':str(p),'expected_sha256':h,'verified_now':False})
 old=Path('/workspace/yukawa_tidal_pilot_20261108_r2/code/pilot.py')
 if old.exists():assert digest(old)==digest(ROOT/'sources/pilot_r2_reference.py')
 original=Path('/workspace/yukawa_tidal_review_inputs/user_additions_20261108.md')
 if original.exists():assert digest(original)==digest(ROOT/'sources/user_additions_original.md')
 report={'action_snapshot_integrity':rows,'review_sha256':digest(ROOT/'sources/user_additions_original.md'),'preserved_archives':preserved,'legacy_solver':'not locally available; independent analytic map is not a source-code bridge to it','pass':True}
 (ROOT/'checks/input_integrity.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
