"""Noncircular payload manifest and local ZIP construction. No remote writes."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile, ast
ROOT = Path(__file__).resolve().parents[1]
NAME = 'Yukawa_tidal_pilot_20261108_r4'
DEL = ROOT / 'delivery'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def payload():
    files = [ROOT / n for n in ['LICENSE.txt', 'README_HU.md', 'requirements.txt']]
    for directory in ['code', 'sources', 'checks', 'notes', 'data', 'figures']:
        for p in (ROOT / directory).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and (p.suffix != '.pyc'):
                if not (not p.is_symlink() and p.resolve().is_relative_to(ROOT)):
                    raise ValueError('validation failed')
                files.append(p)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())
if __name__ == '__main__':
    DEL.mkdir(exist_ok=True)
    from output_guard import prepublication
    prepublication(ROOT)
    status = json.loads((ROOT / 'checks/scientific_status.json').read_text())
    if not status['required_pilot_gates_passed']:
        raise ValueError('validation failed')
    for p in (ROOT / 'code').glob('*.py'):
        ast.parse(p.read_text(), filename=str(p))
    files = payload()
    records = [dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size, sha256=sha(p)) for p in files]
    manifest = {'schema': 'payload-sha256-v1', 'excludes': ['MANIFEST.json itself', 'delivery/', 'internal/', 'rebuild_from_zip/', '__pycache__/'], 'policy': 'No archive or handoff hash is embedded in its own payload. The external handoff binds ZIP and manifest hashes.', 'files': records}
    mp = ROOT / 'MANIFEST.json'
    mp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    out = DEL / (NAME + '.zip')
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files + [mp]:
            rel = p.relative_to(ROOT).as_posix()
            if not (not PurePosixPath(rel).is_absolute() and '..' not in PurePosixPath(rel).parts):
                raise ValueError('validation failed')
            info = zipfile.ZipInfo(NAME + '/' + rel, date_time=(2026, 11, 8, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 33188 << 16
            z.writestr(info, p.read_bytes())
    with zipfile.ZipFile(out) as z:
        if not z.testzip() is None:
            raise ValueError('validation failed')
    info = {'archive': str(out), 'bytes': out.stat().st_size, 'sha256': sha(out), 'manifest_sha256': sha(mp), 'payload_files': len(files), 'zip_entries': len(files) + 1, 'internal_review_excluded': True}
    (DEL / 'package_build.json').write_text(json.dumps(info, indent=2))
    print(json.dumps(info, indent=2))
