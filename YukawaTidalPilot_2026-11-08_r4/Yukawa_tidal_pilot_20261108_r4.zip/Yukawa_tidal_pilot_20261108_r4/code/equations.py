#!/usr/bin/env python3
"""Action-derived tt metric reduction, regular canonical fields and central series.
©2026 Szabolcsi Dávid; CC BY-NC4.0. No division by A' or inverse zeta.
"""
from pathlib import Path
import sympy as s
import json,time
ROOT=Path(__file__).resolve().parents[1]
def build():
 r,m,e,p,psi,w,z,u,cs=s.symbols('r m e p psi w zeta mu cs',real=True)
 H,Hp,Hpp,eta,etap=s.symbols('H Hp Hpp eta etap',real=True)
 B=1-2*m/r;f=s.exp(-z*psi);rho=(B*w*w+u*u*psi*psi)/2;pr=(B*w*w-u*u*psi*psi)/2
 mp=4*s.pi*r*r*(f*e+rho);bp=2*m/r**2-2*mp/r
 v=(m+4*s.pi*r**3*(f*p+pr))/(r*r*B);pp=(e+p)*(-v+z*w);ep=pp/cs
 wp=(u*u*psi-z*f*e-(2*B/r+B*v+bp/2)*w)/B
 total=lambda t:s.diff(t,r)+s.diff(t,m)*mp+s.diff(t,e)*ep+s.diff(t,p)*pp+s.diff(t,psi)*w+s.diff(t,w)*wp
 vp=total(v)
 af=-r*r*B*v/2;bf=2*s.pi*r*r*f*(e+3*p)-r*r*B*v*v-r*B*v-1-2*s.pi*u*u*r*r*psi*psi
 cf=-4*s.pi*z*r*r*f*e+4*s.pi*u*u*r*r*psi-8*s.pi*r*r*B*v*w-8*s.pi*r*B*w
 df=-4*s.pi*r*r*B*w;F=af*Hp+bf*H+cf*eta+df*etap
 S=-Hp-2*v*H-16*s.pi*w*eta
 Sp=-Hpp-2*v*Hp-2*vp*H-16*s.pi*(wp*eta+w*etap)
 # Read original independent covariant Einstein component, not the old reduced master equation.
 rr=s.symbols('r',real=True);alpha,mu,E,P,C=s.symbols('alpha mu epsilon p cs2',nonzero=True)
 funcs={n:s.Function(n)(rr) for n in ['A','B','phi','H0','H2','K','chi']}
 loc={'r':rr,'alpha':alpha,'mu':mu,'epsilon':E,'p':P,'cs2':C}|{n:s.Function(n) for n in funcs}
 lines=(ROOT/'sources/radial_equations_prior_gate.txt').read_text().splitlines();raw=s.sympify(lines[1],locals=loc)
 q=funcs
 replace={rr:r,alpha:z*z,mu:u,E:e,P:p,C:cs,q['B']:B,s.diff(q['B'],rr):bp,q['phi']:z*psi,s.diff(q['phi'],rr):z*w,q['chi']:z*eta,s.diff(q['chi'],rr):z*etap,q['H0']:H,q['H2']:-H,s.diff(q['H2'],rr):-Hp,q['K']:F,s.diff(q['K'],rr):S,s.diff(q['K'],rr,2):Sp}
 tt=s.factor(raw.xreplace(replace))
 coefficient=s.factor(s.diff(tt,Hpp));assert s.factor(coefficient-B)==0
 hcoeff=[s.factor(-s.diff(tt,t)/B) for t in [H,Hp,eta,etap]]
 sh=-(u*u*psi-z*f*e-2*B*v*w-z*f*(e+p)/(2*cs))/B
 sx=(6/r**2+u*u+z*z*f*e+16*s.pi*B*w*w-z*z*f*(e+p)/cs)/B
 sp=-(2*B/r+B*v+bp/2)/B
 co=hcoeff+[s.factor(sh),s.factor(sx),s.factor(sp)]
 for expr in co:
  assert not any(t.base==z and t.exp.is_negative for t in expr.atoms(s.Pow))
  assert not expr.subs(z,0).has(s.zoo,s.nan,s.oo)
  assert not s.denom(s.factor(expr)).has(v)
 assert hcoeff[3]==0
 compact_H=6/(r*r*B)+4*v*v-4*s.pi*f*(5*e+9*p+(e+p)/cs)/B+8*s.pi*u*u*psi*psi/B
 assert s.factor(co[0]-compact_H)==0
 assert s.factor(co[1]-sp)==0
 assert s.factor(co[2]-16*s.pi*sh)==0
 args=(r,m,e,p,psi,w,z,u,cs)
 func=s.lambdify(args,co,'numpy',cse=True)
 old=(total(af)+bf+1)*Hp+(total(bf)+2*v)*H+(total(cf)+16*s.pi*w)*eta+(cf+total(df))*etap+af*Hpp+df*(sh*H+sx*eta+sp*etap)
 # Avoid a costly global symbolic quotient; numerical audits below evaluate old residual independently.
 oldfun=s.lambdify(args+(H,Hp,Hpp,eta,etap),old,'numpy',cse=True)
 # Central coefficients from exact limits, using background regularity rather than setting r^4 terms to zero.
 ec,pc,psic,m3,psi2,csc,h2,s2=s.symbols('ec pc psic m3 psi2 cs_c h2 s2',real=True)
 sub={m:m3*r**3,e:ec,p:pc,psi:psic+psi2*r*r,w:2*psi2*r,cs:csc}
 A0=s.simplify(s.limit((co[0]-6/r**2).subs(sub),r,0))
 P1=s.simplify(s.limit(((co[1]+2/r)/r).subs(sub),r,0))
 C0=s.simplify(s.limit(co[2].subs(sub),r,0))
 SH=s.simplify(s.limit(co[4].subs(sub),r,0));SX=s.simplify(s.limit((co[5]-6/r**2).subs(sub),r,0));SP=s.simplify(s.limit(((co[6]+2/r)/r).subs(sub),r,0))
 fc=s.exp(-z*psic);m3expr=4*s.pi*(fc*ec+u*u*psic*psic/2)/3;v1=m3expr+4*s.pi*(fc*pc-u*u*psic*psic/2);p2expr=(u*u*psic-z*fc*ec)/6
 central_sub={m3:m3expr,psi2:p2expr}
 h4=s.factor(((A0+2*P1)*h2+C0*s2).subs(central_sub)/14)
 s4=s.factor((SH*h2+(SX+2*SP)*s2).subs(central_sub)/14)
 K4=s.factor(-h4-v1*h2/2-8*s.pi*p2expr*s2)
 cent=s.lambdify((ec,pc,psic,z,u,csc,h2,s2),(h4,s4,K4),'numpy',cse=True)
 (ROOT/'notes/canonical_equations_generated.txt').write_text('State H,Hprime,eta,etaprime; a=zeta^2; phi=zeta psi; chi=zeta eta.\nHpp coefficients H,Hp,eta,etap then etapp coefficients H,eta,etap:\n'+'\n'.join(s.sstr(t) for t in co)+'\n')
 (ROOT/'notes/central_series_generated.txt').write_text('cs_c means dp/depsilon, i.e. sound speed squared. Canonical eta series.\nH=h2*r^2+h4*r^4; eta=s2*r^2+s4*r^4; K=-h2*r^2+K4*r^4.\nh4 = '+s.sstr(h4)+'\ns4 = '+s.sstr(s4)+'\nK4 = '+s.sstr(K4)+'\n')
 (ROOT/'checks/tt_symbolic_identity.json').write_text(json.dumps({'Hpp_coefficient_equals_B':True,'inverse_zeta_in_coefficients':False,'inverse_Aprime_in_coefficients':False,'metric_etap_coefficient_zero':True,'compact_metric_identity':True,'metric_scalar_reciprocity_Heta_equals_16pi_etaH':True,'GR_requires_psi_zero':True,'construction':'tt Einstein component plus K reconstruction and rtheta constraint; prior dF/dr-S retained separately'},indent=2))
 return func,cent,oldfun
CO,CENTRAL,OLD_RESIDUAL=build()
if __name__=='__main__':print('tt/canonical/central equations generated and coefficient gates passed',flush=True)
