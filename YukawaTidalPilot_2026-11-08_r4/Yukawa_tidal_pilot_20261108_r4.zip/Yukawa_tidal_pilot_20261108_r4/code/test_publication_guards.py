#!/usr/bin/env python3
"""Isolated executable publication positive/negative regressions, normal and -O."""
from pathlib import Path
import tempfile,shutil,subprocess,sys,os,json,hashlib
from concurrent.futures import ThreadPoolExecutor,as_completed
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mutate(root,case):
 path=root/'data/pilot_results.csv';d=pd.read_csv(path);i=d.index[(d.EOS=='SLy')&(d.alphaY==1)&(d.L_km==1)][0]
 def write(p,fn,sync=False):
  v=pd.read_csv(root/p);fn(v)
  if sync:
   v['lambda_geom_km5']=v.Lambda_metric*(1.476625038050125*v.M_K_Msun)**5;v['k2_metric']=1.5*v.lambda_geom_km5/v.R_g_km**5
  v.to_csv(root/p,index=False)
 c='data/controls_SLy_a1_L1.csv'
 if case in ['clean','reproduce_clean']:return
 if case=='nan_lambda':d.loc[i,'Lambda_metric']=float('nan')
 elif case=='inf_MK':d.loc[i,'M_K_Msun']=float('inf')
 elif case=='duplicate':d.iloc[1]=d.iloc[0]
 elif case=='missing':d=d.iloc[:-1]
 elif case=='wrong_EOS':d.loc[i,'EOS']='H4'
 elif case=='wrong_a':d.loc[i,'alphaY']=.5
 elif case=='wrong_L':d.loc[i,'L_km']=100.
 elif case=='wrong_g':d.loc[i,'Gstar_over_Glab']=.95
 elif case=='wrong_q':d.loc[i,'q']=.2
 elif case=='wrong_MK':d.loc[i,'M_K_Msun']=1.5
 elif case=='wrong_MADM':d.loc[i,'M_A_Msun']=1.4
 elif case=='wrong_units':d.loc[i,'lambda_geom_km5']*=1000
 elif case=='control_nan':write(c,lambda v:v.__setitem__('Lambda_metric',float('nan')));return
 elif case=='control_duplicate':write(c,lambda v:v.__setitem__('test',['baseline']*len(v)));return
 elif case=='control_grid':write(c,lambda v:v.loc.__setitem__((0,'test'),'unknown'));return
 elif case=='control_badresponse':write(c,lambda v:v.loc.__setitem__((2,'Lambda_metric'),999.),True);return
 elif case=='control_rank':write(c,lambda v:v.loc.__setitem__((0,'applied_A_rank'),1));return
 elif case=='control_inf':write(c,lambda v:v.loc.__setitem__((0,'matching_relative_residual'),float('inf')));return
 elif case=='synthetic_nan':write('data/exterior_normalization_controls.csv',lambda v:v.loc.__setitem__((0,'recovered_exact_lambda_geom_km5'),float('nan')));return
 elif case=='scalar_bad':write('data/scalar_amplitude_controls.csv',lambda v:v.loc.__setitem__((0,'recovered_applied_scalar'),99.));return
 elif case=='background_inf':write('data/background_SLy_GR.csv',lambda v:v.loc.__setitem__((10,'epsilon_geom_kmminus2'),float('inf')));return
 elif case in ['json_bad','json_null']:
  p=root/'checks/background_acceptance.json';o=json.loads(p.read_text());o['cases'][0]['max_rms_residual']=None if case=='json_null' else .01;p.write_text(json.dumps(o));return
 elif case=='json_badnorm':
  p=root/'checks/normalization_and_bridge.json';o=json.loads(p.read_text());o['max_exact_lambda_abs_error_km5']=10.;p.write_text(json.dumps(o));return
 elif case=='wrong_SI':
  p=root/'checks/physical_units.json';o=json.loads(p.read_text());o['G_lab_SI']=6.6e-11;p.write_text(json.dumps(o));return
 elif case in ['portable','portable_near_bound','r2_outside_Lambda','r2_outside_R','r2_nan']:
  def f(v):
   if case=='r2_nan':v.loc[0,'Lambda_metric']=float('nan')
   elif case=='r2_outside_Lambda':v.loc[0,'Lambda_metric']*=1+2e-8
   elif case=='r2_outside_R':v.loc[0,'R_g_km']+=2e-7
   elif case=='portable':v.loc[0,'Lambda_metric']+=9.6313e-8;v.loc[0,'R_g_km']+=3.4282e-11
   else:v.loc[0,'Lambda_metric']+=.5*(1e-8*v.loc[0,'Lambda_metric']+1e-9);v.loc[0,'R_g_km']+=5e-8
  write('data/r2_fresh_rerun.csv',f,True);return
 else:raise ValueError(case)
 d.to_csv(path,index=False)
def run(case,opt,script='build_outputs.py'):
 parent=ROOT/'regression_runs';parent.mkdir(exist_ok=True)
 with tempfile.TemporaryDirectory(dir=parent) as td:
  root=Path(td)
  for name in ['code','sources','checks','data','notes','figures']:shutil.copytree(ROOT/name,root/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  for name in ['LICENSE.txt','README_HU.md','requirements.txt']:shutil.copy2(ROOT/name,root/name)
  mutate(root,case)
  watched=[root/'data/r2_r3_changes.csv']+list((root/'figures').glob('*'))+list((root/'notes').glob('*'))
  before={str(p.relative_to(root)):digest(p) for p in watched if p.is_file()}
  proc=subprocess.run([sys.executable]+(['-O'] if opt else [])+[str(root/'code'/script)],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=os.environ|{'OPENBLAS_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'})
  positive=case in ['clean','portable','portable_near_bound']
  if positive:
   if proc.returncode!=0:raise RuntimeError(case+' '+proc.stdout)
   status=json.loads((root/'checks/scientific_status.json').read_text())
   if not status['required_pilot_gates_passed']:raise RuntimeError('clean failed status')
  else:
   if proc.returncode==0:raise RuntimeError('corruption accepted '+case)
   if script=='build_outputs.py':
    status=json.loads((root/'checks/scientific_status.json').read_text())
    if status.get('required_pilot_gates_passed') is not False:raise RuntimeError('stale passed status '+case)
    if any(digest(root/p)!=h for p,h in before.items()):raise RuntimeError('publication output changed before rejection '+case)
  return {'case':case,'optimized':opt,'script':script,'exit_code':proc.returncode,'expected_accept':positive,'pass':True,'diagnostic':proc.stdout[-1600:] if not positive else 'accepted'}
if __name__=='__main__':
 cases=['clean','portable','portable_near_bound','nan_lambda','inf_MK','duplicate','missing','wrong_EOS','wrong_a','wrong_L','wrong_g','wrong_q','wrong_MK','wrong_MADM','wrong_units','control_nan','control_duplicate','control_grid','control_badresponse','control_rank','control_inf','synthetic_nan','scalar_bad','background_inf','json_bad','json_null','json_badnorm','wrong_SI','r2_outside_Lambda','r2_outside_R','r2_nan']
 jobs=[(c,o,'build_outputs.py') for c in cases for o in [False,True]]+[(c,o,'reproduce_pilot.py') for c in ['nan_lambda','inf_MK','duplicate','wrong_g'] for o in [False,True]]
 rows=[]
 with ThreadPoolExecutor(max_workers=4) as pool:
  for f in as_completed([pool.submit(run,*j) for j in jobs]):
   row=f.result();rows.append(row);print(row['case'],row['optimized'],row['script'],row['exit_code'],flush=True)
 report={'cases':rows,'tests':len(rows),'positive_builder_tests':sum(v['expected_accept'] for v in rows),'negative_tests':sum(not v['expected_accept'] for v in rows),'optimized_tests':sum(v['optimized'] for v in rows),'scope':'Postprocessing/data-ingestion regression only, not a rerun of scientific integrators. Portable fixtures are controlled perturbations, not a claim to have run another Python environment.','pass':True}
 (ROOT/'checks/r4_publication_regressions.json').write_text(json.dumps(report,indent=2));print('REGRESSIONS',len(rows),'passed',flush=True)
