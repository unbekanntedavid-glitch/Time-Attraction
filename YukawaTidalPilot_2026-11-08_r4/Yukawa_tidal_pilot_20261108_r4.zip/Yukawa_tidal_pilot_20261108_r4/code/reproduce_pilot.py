#!/usr/bin/env python3
"""Rebuild six baseline states and compare against packaged CSV, without cached backgrounds.
©2026 Szabolcsi Dávid; CC BY-NC4.0.
"""
from run_suite import *
import pandas as pd
from output_guard import validate_state_table,BASE_GRID,need
if __name__=='__main__':
 reference=pd.read_csv(ROOT/'data/pilot_results.csv');validate_state_table(reference,'reproduction reference',BASE_GRID);rows=[]
 for name in ['SLy','APR4']:
  for a,L in [(0.,1.),(1.,1.),(1.,10.)]:
   bg=background(name,a,L,bgtol=2e-8);value=tidal(bg,**BASE);old=reference[(reference.EOS==name)&(reference.alphaY==a)&(reference.L_km==(L if a else 0))].iloc[0]
   rerr=abs(value['R_g_km']-float(old.R_g_km));lerr=abs(value['Lambda_metric']/float(old.Lambda_metric)-1)
   need(np.isclose(value['R_g_km'],float(old.R_g_km),rtol=0,atol=1e-7) and np.isclose(value['Lambda_metric'],float(old.Lambda_metric),rtol=1e-8,atol=1e-9),'six-state numerical portability contract')
   rows.append(dict(EOS=name,alphaY=a,L_km=L if a else 0.,R_abs_difference_km=rerr,Lambda_relative_difference=lerr));print(rows[-1],flush=True)
 report={'rebuilt_background_and_tide_states':len(rows),'cached_backgrounds_used':False,'results':rows,'pass':True};(ROOT/'checks/reproduction_states.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
