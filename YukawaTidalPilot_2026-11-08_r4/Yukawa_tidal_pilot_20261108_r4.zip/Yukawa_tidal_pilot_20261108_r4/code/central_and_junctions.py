#!/usr/bin/env python3
"""Numerical regular-series defects and one-sided EOS junction controls."""
from run_suite import *
from extra_audits import load_bg

def canonical_F(rv,m,e,p,psi,w,z,L,H,Hp,eta,etap):
 B=1-2*m/rv;f=np.exp(-z*psi);pr=(B*w*w-psi*psi/L**2)/2;v=(m+4*PI*rv**3*(f*p+pr))/(rv*rv*B)
 af=-rv*rv*B*v/2;bf=2*PI*rv*rv*f*(e+3*p)-rv*rv*B*v*v-rv*B*v-1-2*PI*rv*rv*psi*psi/L**2
 cf=-4*PI*z*rv*rv*f*e+4*PI*rv*rv*psi/L**2-8*PI*rv*rv*B*v*w-8*PI*rv*B*w;df=-4*PI*rv*rv*B*w
 return af*Hp+bf*H+cf*eta+df*etap
if __name__=='__main__':
 series=[];coefficients=[];summaries=[];junction=[]
 for name in ['SLy','APR4']:
  for a,L in [(0.,1.),(1.,1.),(1.,10.)]:
   bg=gr_background(name) if a==0 else load_bg(name,L);R=bg['R'];ec,pc,_,cs=bg['eos'].at(bg['hc']);psic=bg.get('psic',0.);z=np.sqrt(a)
   m3,m5,nu2,nu4,hb2,hb4,ps2,ps4=background_central(ec,pc,psic,z,L,cs)
   for column,(h2,s2) in enumerate([(1/R**2,0),(0,1/R**2)]):
    h4,s4,K4=CENTRAL(ec,pc,psic,z,1/L,cs,h2,s2)
    coefficients.append(dict(EOS=name,alphaY=a,L_km=L if a else 0.,column=column,h2=h2,s2_canonical_eta=s2,h4=h4,s4_canonical_eta=s4,K4=K4,cs2c=cs,m3=m3,m5=m5,psi2=ps2,psi4=ps4,h_background_r2=hb2,h_background_r4=hb4))
    defects=[]
    for rv in [.1,.05,.025]:
     m=m3*rv**3+m5*rv**5;h=bg['hc']+hb2*rv**2+hb4*rv**4;psi=psic+ps2*rv**2+ps4*rv**4;w=2*ps2*rv+4*ps4*rv**3;e,p,_,c=bg['eos'].at(h)
     H=h2*rv**2+h4*rv**4;Hp=2*h2*rv+4*h4*rv**3;Hpp=2*h2+12*h4*rv**2;eta=s2*rv**2+s4*rv**4;etap=2*s2*rv+4*s4*rv**3;etapp=2*s2+12*s4*rv**2
     co=CO(rv,m,e,p,psi,w,z,1/L,c)
     rh=Hpp-co[0]*H-co[1]*Hp-co[2]*eta-co[3]*etap;rs=etapp-co[4]*H-co[5]*eta-co[6]*etap
     F=canonical_F(rv,m,e,p,psi,w,z,L,H,Hp,eta,etap);rk=F-(-h2*rv**2+K4*rv**4)
     defect=max(abs(rh)/rv**2,abs(rs)/rv**2,abs(rk)/rv**4);defects.append(defect)
     series.append(dict(EOS=name,alphaY=a,L_km=L if a else 0.,column=column,r_km=rv,metric_defect_div_r2=abs(rh)/rv**2,scalar_defect_div_r2=abs(rs)/rv**2,K_defect_div_r4=abs(rk)/rv**4,max_scaled_defect=defect))
    passing=bool(defects[-1]<.3*defects[0]+2e-11);assert passing,(name,a,L,column,defects)
    summaries.append(dict(EOS=name,alphaY=a,L_km=L if a else 0.,column=column,r_0p025_over_r_0p1_scaled_defect=defects[-1]/max(defects[0],1e-30),pass_gate=passing))
  eos=EOS(name,1.)
  for j,h in enumerate(eos.raw.hb):
   dh=h*1e-8;em,pm,_,cm=eos.at(h-dh);ep,pp,_,cp=eos.at(h+dh);em0=em+(em+pm)*dh/cm;ep0=ep-(ep+pp)*dh/cp;pm0=pm+(em+pm)*dh;pp0=pp-(ep+pp)*dh
   row=dict(EOS=name,junction=j,h_junction=h,epsilon_continuity_relative_error=abs(em0-ep0)/max(em0,ep0),pressure_continuity_relative_error=abs(pm0-pp0)/max(pm0,pp0),cs2_left=cm,cs2_right=cp)
   assert max(row['epsilon_continuity_relative_error'],row['pressure_continuity_relative_error'])<1e-11
   junction.append(row)
 write_rows(ROOT/'data/central_series_coefficients.csv',coefficients);write_rows(ROOT/'data/central_series_defects.csv',series);write_rows(ROOT/'data/eos_junction_controls.csv',junction)
 report=dict(regular_columns=len(summaries),sampled_series_points=len(series),series_controls=summaries,EOS_junctions=len(junction),max_EOS_energy_continuity_relative_error=max(v['epsilon_continuity_relative_error'] for v in junction),max_EOS_pressure_continuity_relative_error=max(v['pressure_continuity_relative_error'] for v in junction),scope='Continuous energy/pressure piecewise-polytrope interfaces, one-sided cs2. No genuine first-order density transition is present or validated.',pass_gate=True)
 (ROOT/'checks/central_and_junctions.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
