"""Build plots and HU scientific status only from observed CSV/check outputs."""
from pathlib import Path
import json, hashlib, sys
from output_guard import prepublication, need, comparison_contract
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
LIC = '© 2026 Szabolcsi Dávid · ORCID 0009-0005-6300-074X · CC BY-NC 4.0 International · https://creativecommons.org/licenses/by-nc/4.0/ · Kereskedelmi használat csak a szerző írásos engedélyével.'
plt.rcParams.update({'font.size': 11, 'svg.fonttype': 'none'})

def load(n):
    return json.loads((ROOT / 'checks' / n).read_text())

def save(fig, name):
    fig.text(0.5, 0.012, LIC, ha='center', fontsize=5.8)
    fig.tight_layout(rect=[0, 0.045, 1, 0.97])
    fig.savefig(ROOT / 'figures' / f'{name}.png', dpi=170)
    fig.savefig(ROOT / 'figures' / f'{name}.svg')
    plt.close(fig)

def mdtable(df, columns):
    out = '| ' + ' | '.join(columns) + ' |\n| ' + ' | '.join(['---'] * len(columns)) + ' |\n'
    for row in df[columns].itertuples(index=False, name=None):
        out += '| ' + ' | '.join((str(v) for v in row)) + ' |\n'
    return out

def build_outputs():
    guard = prepublication(ROOT)
    df = pd.read_csv(ROOT / 'data/pilot_results.csv').sort_values(['EOS', 'alphaY', 'L_km'])
    old = pd.read_csv(ROOT / 'data/r2_fresh_rerun.csv')
    published = pd.read_csv(ROOT / 'sources/r2_pilot_results.csv')
    methods = pd.read_csv(ROOT / 'data/method_controls.csv')
    if not (len(df) == 6 and len(old) == 6):
        raise ValueError('validation failed')
    changes = []
    for new in df.itertuples():
        oo = old[(old.EOS == new.EOS) & (old.alphaY == new.alphaY) & (old.L_km == new.L_km)].iloc[0]
        pub = published[(published.EOS == new.EOS) & (published.alphaY == new.alphaY) & (published.L_km == new.L_km)].iloc[0]
        need(np.isclose(oo.Lambda_metric, pub.Lambda_metric, rtol=1e-08, atol=1e-09) and np.isclose(oo.R_g_km, pub.R_g_km, rtol=0, atol=1e-07), 'r2 portability contract')
        changes.append(dict(EOS=new.EOS, alphaY=new.alphaY, L_km=new.L_km, M_K_Msun=new.M_K_Msun, Gstar_over_Glab=new.Gstar_over_Glab, r2_R_g_km=oo.R_g_km, r3_R_g_km=new.R_g_km, delta_R_g_km=new.R_g_km - oo.R_g_km, r2_Lambda_metric=oo.Lambda_metric, r3_Lambda_metric=new.Lambda_metric, delta_Lambda_metric=new.Lambda_metric - oo.Lambda_metric, relative_delta_Lambda=new.Lambda_metric / oo.Lambda_metric - 1, r2_published_minus_fresh_Lambda=pub.Lambda_metric - oo.Lambda_metric))
    changes = pd.DataFrame(changes)
    controls = pd.concat([pd.read_csv(p) for p in sorted((ROOT / 'data').glob('controls_*_a1_*.csv'))], ignore_index=True)
    grc = pd.read_csv(ROOT / 'data/gr_convergence_controls.csv')
    limits = pd.read_csv(ROOT / 'data/coupling_limit.csv')
    weak = load('weak_coupling_stress.json')
    numeric = load('numerical_gates.json')
    gr = load('gr_convergence_controls.json')
    extra = load('extra_audits.json')
    der = load('derivation_reaudit.json')
    norm = load('normalization_and_bridge.json')
    cent = load('central_and_junctions.json')
    integ = load('integrated_equation_residuals.json')
    cov = load('covariant_generation_r3.json')
    zero = load('zero_Aprime_exact.json')
    bg = load('background_acceptance.json')
    mc = load('method_controls.json')
    rep = load('reproduction_states.json')
    inputs = load('input_integrity.json')
    execution = load('execution_record.json')
    required = bool(numeric['all_numeric_gates_passed'] and gr['pass'] and extra['pass'] and der['pass'] and norm['pass'] and cent['pass_gate'] and integ['pass_gate'] and cov['pass'] and zero['pass'] and bg['pass'] and mc['pass'] and rep['pass'] and inputs['pass'] and execution['all_exit_codes_zero'] and (len(limits) == 12) and load('strict_controls.json')['pass'] and load('scalar_amplitude_controls.json')['pass'] and load('retained_conventions.json')['pass'])
    if not required:
        raise ValueError('Required scientific gate failed; no automatic publication output.')
    for record in execution['runs']:
        if not hashlib.sha256((ROOT / 'code' / record['script']).read_bytes()).hexdigest() == record['script_sha256']:
            raise ValueError(record['script'])
    changes.to_csv(ROOT / 'data/r2_r3_changes.csv', index=False)
    Arows = pd.concat([df, controls, grc], ignore_index=True)
    center = controls[controls.test.str.contains('central_start')].copy()
    maxcenter = 0.0
    for (name, L), group in center.groupby(['EOS', 'L_km']):
        ref = float(df[(df.EOS == name) & (df.alphaY == 1) & (df.L_km == L)].iloc[0].Lambda_metric)
        maxcenter = max(maxcenter, float(np.max(np.abs(group.Lambda_metric / ref - 1))))
    summary = {'publication_input_gate': guard, 'physics_evidence_origin': 'Inherited r3 scientific controls; r4 adds input/output regressions and six-state archive replay, not a rerun of run_all.', 'supplied_historical_bridge_report': 'Academia AI numerical report; not personally rerun here; see notes/forrashid_beszamolo_HU.md', 'required_pilot_gates_passed': required, 'physical_units': load('physical_units.json'), 'scalar_reference_controls': load('scalar_amplitude_controls.json'), 'retained_conventions': load('retained_conventions.json'), 'primary_states': len(df), 'coupled_control_records': len(controls), 'GR_control_records': len(grc), 'required_small_coupling_states': len(limits), 'GR_max_relative_benchmark_error': max((v['relative_difference'] for v in numeric['GR_benchmarks'])), 'max_tested_relative_Lambda_envelope': float(df.tested_Lambda_relative_envelope.max()), 'max_tested_radius_envelope_km': float(df.tested_R_km_abs_envelope.max()), 'central_start_max_relative_Lambda_variation': maxcenter, 'applied_A_min_condition': float(Arows.applied_A_condition.min()), 'applied_A_max_condition': float(Arows.applied_A_condition.max()), 'all_A_rank_two': bool((Arows.applied_A_rank == 2).all()), 'max_abs_applied_scalar': float(Arows.applied_scalar.abs().max()), 'max_dual_error': float(Arows.applied_dual_error.max()), 'max_matching_residual': float(Arows.matching_relative_residual.max()), 'max_r2_r3_relative_Lambda_change': float(changes.relative_delta_Lambda.abs().max()), 'max_r2_r3_abs_Lambda_change': float(changes.delta_Lambda_metric.abs().max()), 'max_r2_r3_radius_change_km': float(changes.delta_R_g_km.abs().max()), 'optional_extreme_coupling': weak, 'unavailable_prerequisites': ['user-cited coupling_solver.py', 'user-cited independent audit attachments'], 'scope': 'conditional unscreened dust-test G_lab calibration; static tensor-only metric response; no mixed physical response matrix, EOS distinguishability verdict, stability inference or observational likelihood', 'integration_dependencies_sha256': {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in ['code/pilot.py', 'code/equations.py', 'code/run_suite.py', 'sources/stellar_tal_v21.py', 'sources/radial_equations_prior_gate.txt']}}
    (ROOT / 'checks/scientific_status.json').write_text(json.dumps(summary, indent=2))
    fig, ax = plt.subplots(figsize=(11, 7))
    colors = {'SLy': '#1261a0', 'APR4': '#be432b'}
    markers = {0.0: 'o', 1.0: 's', 10.0: '^'}
    for row in df.itertuples():
        label = f'{row.EOS} ' + ('GR' if row.alphaY == 0 else f'a=1, L={row.L_km:g} km')
        ax.scatter(row.R_g_km, row.Lambda_metric, color=colors[row.EOS], marker=markers[row.L_km], s=100, label=label)
        if row.alphaY:
            ax.errorbar(row.R_g_km, row.Lambda_metric, xerr=row.tested_R_km_abs_envelope, yerr=row.tested_Lambda_abs_envelope, color=colors[row.EOS], capsize=3)
    ax.set(xlabel='Metrikus sugár R_g [km]', ylabel='Λ_K^metric', title='Azonos távoli Kepler-tömeg: M_K=1.4 M☉\nFeltételes labor-G kalibráció; két EOS, statikus tenzor-only válasz')
    ax.grid(alpha=0.25)
    ax.legend(fontsize=9)
    save(fig, 'R_Lambda_pilot')
    fig, ax = plt.subplots(figsize=(12, 7))
    labels = [f'{x.EOS} ' + ('GR' if x.alphaY == 0 else f'L={x.L_km:g}') for x in changes.itertuples()]
    ax.bar(labels, changes.delta_Lambda_metric, color=[colors[x] for x in changes.EOS])
    ax.axhline(0, color='black', lw=0.8)
    ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0))
    ax.set(ylabel='Λ(r3) − Λ(r2 újraintegrálva)', title='Mért r2–r3 eltérés ugyanazon hat állapotban\nAz eltérések nem fizikai bizonytalansági intervallumok')
    ax.grid(axis='y', alpha=0.25)
    save(fig, 'r2_r3_delta')
    fig, ax = plt.subplots(figsize=(14, 7))
    order = list(controls.test.drop_duplicates())
    x = np.arange(len(order))
    for k, ((name, L), group) in enumerate(controls.groupby(['EOS', 'L_km'])):
        ref = float(group[group.test == 'baseline'].iloc[0].Lambda_metric)
        series = group.set_index('test').reindex(order)
        err = np.maximum(np.abs(series.Lambda_metric / ref - 1).to_numpy(), 1e-15)
        ax.plot(x + (k - 1.5) * 0.08, err, 'o', label=f'{name}, L={L:g} km')
    ax.set_yscale('log')
    ax.set_xticks(x, order, rotation=55, ha='right', fontsize=8)
    ax.set(ylabel='|Λ / Λ_alap − 1| (ábrapadló: 10⁻¹⁵)', title='Tényleges paraméterváltási kontrollok — négy módosított állapot')
    ax.legend()
    ax.grid(alpha=0.25)
    save(fig, 'numerical_controls')
    fig, ax = plt.subplots(figsize=(11, 7))
    for (name, L), group in limits.groupby(['EOS', 'L_km']):
        group = group.sort_values('alphaY')
        ax.loglog(group.alphaY, np.abs(group.relative_to_GR), 'o-', label=f'{name}, L={L:g} km')
    ax.set(xlabel='a a hatásban (nem sqrt(a))', ylabel='|Λ(a) / Λ_GR − 1|', title='Integrált csatolás → 0 kontroll mindkét L-re és EOS-ra')
    ax.legend()
    ax.grid(which='both', alpha=0.25)
    save(fig, 'coupling_to_GR')
    syn = pd.read_csv(ROOT / 'data/exterior_normalization_controls.csv')
    syn = syn[syn.known_lambda_geom_km5 == 0]
    fig, ax = plt.subplots(figsize=(11, 7))
    ax.loglog(syn.r_km, np.maximum(syn.exact_abs_error, 1e-15), 'o-', label='Pontos Schwarzschild-bázis: |nullválasz hibája|')
    ax.loglog(syn.r_km, np.abs(syn.power_fit_lambda_geom_km5), 's-', label='Puszta hatványillesztés: hamis |λ|')
    ax.set(xlabel='Illesztési sugár [km]', ylabel='|λ_geom| [km⁵]', title='Szintetikus, tiszta alkalmazott tide — ismert λ=0\nA hatványillesztés kizárólag negatív kontroll')
    ax.legend()
    ax.grid(which='both', alpha=0.25)
    save(fig, 'exterior_normalization')
    cdf = pd.read_csv(ROOT / 'data/central_series_defects.csv')
    fig, ax = plt.subplots(figsize=(12, 7))
    for (name, a, L, column), group in cdf.groupby(['EOS', 'alphaY', 'L_km', 'column']):
        if column != 0:
            continue
        group = group.sort_values('r_km')
        ax.loglog(group.r_km, group.max_scaled_defect, 'o-', label=f'{name}, ' + ('GR' if not a else f'L={L:g} km'))
    ax.set(xlabel='Középponttól mért r [km]', ylabel='max(|metrika/skalar hiba|/r², |K-hiba|/r⁴)', title='Negyedrendű középponti sor — numerikus egyenlethiba\nTenzoros reguláris oszlop; mindkét oszlop CSV-ben ellenőrizve')
    ax.legend()
    ax.grid(which='both', alpha=0.25)
    save(fig, 'central_series_defects')
    tab = df[['EOS', 'alphaY', 'L_km', 'R_g_km', 'Lambda_metric']].copy()
    tab['R_g_km'] = tab.R_g_km.map(lambda x: f'{x:.6f}')
    tab['Lambda_metric'] = tab.Lambda_metric.map(lambda x: f'{x:.6f}')
    note = '# Döntési jegyzet — r4\n\nAz r3-ban a hat elsődleges állapot újra lett integrálva a hatásalapú, A′-vel nem osztó tt-egyenlettel, kanonikus skalárral, negyedrendű középponti sorral és explicit alkalmazott amplitúdómátrixszal. Minden állapotban M_K=1.4 M☉; a=1 esetén G_*/G_lab=0.9262883177508389 és M_A=1.511408460164327 M☉. A feltételes porpróba-kalibráció nem mérésillesztés.\n\n' + mdtable(tab, list(tab.columns))
    note += f"\nAz átvett r3 futásanyagban a szükséges pilotkapuk megfeleltek: {len(controls)} módosított és {len(grc)} GR-kontrollsor, {len(limits)} kiscsatolású állapot. A GR-benchmark legnagyobb relatív eltérése {summary['GR_max_relative_benchmark_error']:.3g}; a tesztelt relatív Λ-burok maximuma {summary['max_tested_relative_Lambda_envelope']:.3g}. A r2-hez mért legnagyobb |ΔΛ| {summary['max_r2_r3_abs_Lambda_change']:.3g}, relatíve {summary['max_r2_r3_relative_Lambda_change']:.3g}; |ΔR| maximuma {summary['max_r2_r3_radius_change_km']:.3g} km. A CSV több számjegye a reprodukciót szolgálja, nem ekkora fizikai pontosságot.\n"
    note += '\n**Korlátok:** a megjelölt korábbi `coupling_solver.py` nem volt helyben elérhető, ezért ahhoz forráskódszintű híd nincs igazolva. Nyolc analitikus térképkontroll és az elérhető r2 hat friss számítása áll rendelkezésre. A további a=10⁻⁸ stresszteszt három állapotban elfogadott hátteret adott; APR4, L=10 km esetén a kollokációs csomópontkorlát miatt a háttér elutasítva, Λ nincs közölve. Ez nem a hat elsődleges állapot vagy a kötelező a≥10⁻⁴ kontroll sikertelensége.\n'
    note += '\n**Döntés:** feltételes R–Λ eltolódás számszerűen vizsgálható, de két EOS alapján az EOS-hatástól való elkülöníthetőség nem dönthető el. A következő fizikai fázis szélesebb, közös kauzális tartományú EOS-minta és megfelelő külső forrás-/hullámformamodell. Az elutasított szélső kiscsatolású eset háttérhálóját és EOS-illesztéseit külön kell diagnosztizálni; az EOS-határhoz igazított kollokáció lehetséges, még nem tesztelt javítási irány. Megfigyelési likelihood, dinamikai stabilitás vagy újdonságvizsgálat nem készült; ezekre nincs állítás.\n\n' + LIC + '\n'
    note += '\nR4: mezőegyenlet, EOS és tudományos főadatsor nem változott. Az r2 portabilitási szerződés nem fizikai hibabecslés. A történeti háttérhíd új, szolgáltatott Academia AI beszámolóját külön, tulajdonított forrásként kezeljük; nem szakmai lektorálás, és itt nem futtatott kód bizonyítéka. Lásd `forrashid_beszamolo_HU.md`.\n'
    (ROOT / 'notes/dontesi_jegyzet_HU.md').write_text(note)
    validation = '# Mennyiségi ellenőrzési összefoglaló — r4\n\nAz alábbi értékek az átvett r3 futásadatokból származnak; az r4 nem futtatja újra a 18 tudományos scriptet. Az r4 publikációs bemenetellenőrzést, pozitív/negatív regressziót, valamint elkülönített hatállapotos reprodukciót és riportépítést végez. A kötelező hatállapotos pilot ellenőrzéseit és az opcionális szélső kiscsatolású diagnosztikát külön kezeljük.\n\n'
    rows = [('Integrált GR Love-benchmark', f"2 EOS; max relatív eltérés {summary['GR_max_relative_benchmark_error']:.6g}"), ('Módosított numerikus kontroll', f"{len(controls)} sor; max tesztelt relatív Λ-eltérés {summary['max_tested_relative_Lambda_envelope']:.6g}"), ('GR numerikus kontroll', f'{len(grc)} sor'), ('Középponti kezdősugár', f'0.01/0.005/0.0025 km; max relatív Λ-eltérés {maxcenter:.6g}'), ('Kiscsatolású határ', 'a=0.01/0.001/0.0001, mindkét EOS és L; 12 elfogadott állapot'), ('Alkalmazott A mátrix', f"minden rang 2; kondíciószám {summary['applied_A_min_condition']:.6g}–{summary['applied_A_max_condition']:.6g}"), ('Duális külső kontroll', f"max abszolút hiba {summary['max_dual_error']:.6g}; alkalmazott skalár max |a_s| {summary['max_abs_applied_scalar']:.6g}"), ('Külső illesztés', f"max normált maradék {summary['max_matching_residual']:.6g}; n=8/10/12/14; DOP853/Radau és 4×4 kontroll"), ('Lokális redukció és Einstein', f"24 friss minta + egy közel zérus A′ minta; régi/új H″ max relatív eltérés {der['max_old_Hpp_relative_difference']:.6g}"), ('Egzakt A′=0', 'pozitív p, B>0; mind a hat kovariáns maradék pontosan 0'), ('Integrált differenciális maradék', f"{integ['samples']} oszlopminta; max {max(integ['max_normalized_residuals'].values()):.6g}; önálló ötpontos differencia"), ('Középponti negyedrendű sor', f'12 oszlop, 36 pont; a skálázott hiba a 0.1→0.025 km váltásnál kb. 1/16'), ('EOS-illesztések', f"{cent['EOS_junctions']} darabhatár; max ε relatív illesztési hiba {cent['max_EOS_energy_continuity_relative_error']:.6g}"), ('Skalár referenciaamplitúdó', f"48 ismert keverék; max alkalmazott amplitúdóhiba {load('scalar_amplitude_controls.json')['max_applied_scalar_abs_error']:.6g}; Wronskián relatív hibája {load('scalar_amplitude_controls.json')['max_scalar_Wronskian_relative_error']:.6g}"), ('Pontos külső normalizálás', f"{norm['exact_tensor_synthetic_cases']} ismert/nulla válasz; max λ absz. visszamérési hiba {norm['max_exact_lambda_abs_error_km5']:.6g} km⁵; Legendre eltérés {norm['max_Legendre_relative_error']:.6g}"), ('Analitikus k-u egységtérkép', f"8 eset; max eltérés {norm['max_analytic_map_abs_error']:.6g}; hiányzó régi kódot nem importál"), ('Háttér elfogadása', f'4 BVP; mind kért 2×10⁻⁸ maradékon belül; a távoli farok külön becslés'), ('R2 kontroll', '6 régi állapot friss háttér- és perturbációintegrálással'), ('R3 reprodukció', '6 állapot tárolt háttér nélkül ismét felépítve')]
    validation += '| Kontroll | Mért eredmény |\n|---|---|\n' + ''.join((f'| {a} | {b} |\n' for a, b in rows))
    validation += '\n## Elutasított további diagnosztika\n\nAz a=10⁻⁸ APR4, L=10 km háttér a további hálósűrítés csomópontkorlátja miatt nem érte el a 2×10⁻⁸ kért maradékot. A pontos hiba és az utolsó iteráció paraméterei a `checks/background_failure_APR4_a1e-08_L10_tol2e-08.json` fájlban vannak; ezek nem elfogadott csillagparaméterek. A három másik a=10⁻⁸ állapot elfogadott; a negyedikhez nincs árapályérték. A `weak_coupling_attempts.csv` ezt üres Λ-mezővel jelöli.\n'
    validation += '\nA tesztelt numerikus burkok nem statisztikai hibák vagy szigorú felső korlátok. A végességi és lokális azonosságtesztek nem helyettesítik az integrált ellenőrzéseket; a tárolt futások mindkettőt tartalmazzák. A valódi sűrűségugrás, alkalmazott skalártide melletti fizikai válaszmátrix, bináris likelihood és dinamikai módusspektrum nem vizsgált.\n\n' + LIC + '\n'
    (ROOT / 'notes/ellenorzesi_osszefoglalo_HU.md').write_text(validation)
    (ROOT / 'internal').mkdir(exist_ok=True)
    internal = '# Belső t778 összevetés — nem a kutatási ZIP része\n\n'
    internal += '1. Hatás, sűrűségforrás, δh és H₂=−H: megtartva; hat kovariáns export újragenerálva és az előzővel egzakt azonos. Nincs konformális csere.\n'
    internal += f"2. tt-redukció: beépítve. A H″-együttható B, nincs A′-osztás. 24 lokális régi/új összevetés max relatív eltérése {der['max_old_Hpp_relative_difference']:.6g}; egzakt A′=0 maradékok nullák. A csak tt-cserés régi futások max |ΔΛ| értéke {mc['max_tt_only_abs_delta']:.6g}.\n"
    internal += '3. Kanonikus alak: ζ²=a, φ=ζψ, χ=ζη. a=1 esetén a térkép identitás; a=0 háttér ψ=0. Az a→0 szükséges 12 integrált kontroll újrafutott; három további 10⁻⁸ állapot elfogadott, egy háttér elutasítva. Nem állítunk e négy stresszállapotra egységes numerikus sikert.\n'
    internal += f"4. h₄,s₄,K₄: újraalkotva egzakt középponti határértékből. 12 reguláris oszlop numerikus sorhibája a várt skálázást mutatja. A r⁴ és a csak r² indítás izolált max |ΔΛ| értéke {mc['max_r4_series_abs_delta']:.6g}; kezdősugár max relatív eltérése {maxcenter:.6g}.\n"
    internal += '5. Régi coupling_solver.py-híd: a megjelölt fájl és a javaslatban hivatkozott auditmellékletek helyben nem találhatók; a forráskód hídja nincs igazolva. A k-u RHS önálló analitikus rekonstrukciója 8 esetben ellenőrizve. a=k, nem sqrt(k); ε=g ε_lab és M_K=g M_A. a=1 mellett a gyökcél 1.4/g. Az elérhető r2 már ezt a tömegcélt használta; a hat friss régi háttér és az r3 sugara között mért legnagyobb eltérés a mellékelt táblázat szerint 0 km. Ez nem a hiányzó implementáció validálása.\n'
    internal += f"6. Alkalmazott A: a tényleges alkalmazott amplitúdókra építve, nem U-ra. Rang 2 és mért kondíciószámok minden kontrollban tárolva. Az A-kiválasztás és a független megengedett 4×4 illesztés izolált max |ΔΛ| értéke {mc['max_selector_abs_delta']:.6g}.\n"
    internal += '7. Külső bázis és 1/3 faktor: az r2 pontos hiper\xadgeometrikus bázisa és λ=b_H/(3a_H) szerződése maradt. Új, nagy pontosságú Legendre- és 20 szintetikus ismert/nullválasz-kontroll készült; a puszta hatványillesztés csak hamis választ mutató negatív kontroll. A skalár referenciaegyüttható új tenzoregysége miatt a régi skalárcsökkenési amplitúdót R²-tel osztva kell összevetni az újjal (a=1 mellett η=χ); ezt hat állapoton külön futó teszt ellenőrzi. Az r2/r3 pontos tenzorbázis értékei öt sugáron bájtszinten azonos lebegőpontos tömbök. A kapcsolt vákuumban a skalárpartikuláris benne van; r_b-, tolerancia-, lépés- és Radau-váltás mindkét L-en újrafutott.\n\n'
    show = changes.copy()
    show['delta_Lambda_metric'] = show.delta_Lambda_metric.map(lambda x: f'{x:.12g}')
    internal += mdtable(show, ['EOS', 'alphaY', 'L_km', 'r2_Lambda_metric', 'r3_Lambda_metric', 'delta_Lambda_metric', 'delta_R_g_km'])
    internal += '\nA változások numerikus módszerváltási eltérések, az elsődleges állapotok tesztelt burkán belül. Az egyes módszerek kontrolljait a `data/method_controls.csv` és `checks/method_controls.json` tartalmazza. A hiányzó forrás, a szélső kiscsatolású háttérhiba, a kevert fizikai válasz és az EOS-/likelihood-/stabilitási korlátok nincsenek sikerként feltüntetve.\n\n' + LIC + '\n'
    (ROOT / 'internal/review_point_by_point_HU.md').write_text(internal)
    artifacts = []
    for p in sorted((ROOT / 'figures').iterdir()):
        if p.suffix == '.png':
            with Image.open(p) as im:
                im.verify()
        elif p.suffix == '.svg':
            ET.parse(p)
        else:
            continue
        artifacts.append({'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    if not len(artifacts) == 12:
        raise ValueError('validation failed')
    (ROOT / 'checks/plot_integrity.json').write_text(json.dumps({'readable_plots': artifacts, 'pass': True}, indent=2))
    print(json.dumps(summary, indent=2))
if __name__ == '__main__':
    try:
        build_outputs()
    except Exception as ex:
        (ROOT / 'checks/scientific_status.json').write_text(json.dumps({'required_pilot_gates_passed': False, 'publication_input_gate_passed': False, 'error': str(ex)}, indent=2))
        raise
