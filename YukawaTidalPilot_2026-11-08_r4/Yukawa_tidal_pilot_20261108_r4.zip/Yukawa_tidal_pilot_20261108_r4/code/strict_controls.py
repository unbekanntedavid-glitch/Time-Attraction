#!/usr/bin/env python3
"""Add a tighter tidal tolerance and a fourth step refinement without reusing tidal responses."""
from run_suite import *
from extra_audits import load_bg
import pandas as pd
if __name__=='__main__':
 report=json.loads((ROOT/'checks/numerical_gates.json').read_text());primary=pd.read_csv(ROOT/'data/pilot_results.csv');updates=[]
 for name in ['SLy','APR4']:
  for L in [1.,10.]:
   path=ROOT/'data'/f'controls_{name}_a1_L{L:g}.csv';controls=pd.read_csv(path);controls=controls[~controls.test.isin(['rtol_3e11','step_0p015'])];rows=controls.to_dict('records');bg=load_bg(name,L)
   for label,delta in [('rtol_3e11',dict(rtol=3e-11)),('step_0p015',dict(maxstep=.015))]:
    row=tidal(bg,**(BASE|delta));row['test']=label;rows.append(row);print(name,L,label,row['Lambda_metric'],flush=True)
   write_rows(path,rows);ref=rows[0];dlam=max(abs(v['Lambda_metric']-ref['Lambda_metric']) for v in rows);dr=max(abs(v['R_g_km']-ref['R_g_km']) for v in rows)
   fields=dict(tested_Lambda_abs_envelope=dlam,tested_R_km_abs_envelope=dr,tested_Lambda_relative_envelope=dlam/abs(ref['Lambda_metric']),gates_passed=bool(dlam/abs(ref['Lambda_metric'])<3e-4 and all(v['applied_A_rank']==2 and v['applied_A_condition']<1e10 for v in rows)))
   assert fields['gates_passed'];mask=(primary.EOS==name)&(primary.alphaY==1)&(primary.L_km==L)
   for k,v in fields.items():primary.loc[mask,k]=v
   for obj in report['coupled_cases']:
    if obj.get('result',{}).get('EOS')==name and obj['result']['L_km']==L:obj['result'].update(fields)
   updates.append(dict(EOS=name,L_km=L,control_records=len(rows),**fields))
 primary.to_csv(ROOT/'data/pilot_results.csv',index=False);(ROOT/'checks/numerical_gates.json').write_text(json.dumps(report,indent=2));(ROOT/'checks/strict_controls.json').write_text(json.dumps({'cases':updates,'tighter_tidal_rtol':3e-11,'smallest_step_km':.015,'pass':True},indent=2))
