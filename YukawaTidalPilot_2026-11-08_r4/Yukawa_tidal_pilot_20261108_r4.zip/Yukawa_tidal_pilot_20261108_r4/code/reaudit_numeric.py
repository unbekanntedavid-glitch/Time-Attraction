#!/usr/bin/env python3
"""Evaluate the independently exported prior equation pair on new on-shell jets.
©2026 Szabolcsi Dávid, CC BY-NC4.0.
"""
from pilot import *
import csv
r=s.symbols('r',real=True);alpha,mu=s.symbols('alpha mu',nonzero=True)
A,B,phi,H,chi,er,pr,vr=[s.Function(n)(r) for n in ['A','B','phi','H0','chi','epsilon','p','cs2']]
text=(ROOT/'sources/reduced_equations_prior_gate.txt').read_text().splitlines()
loc={'r':r,'alpha':alpha,'mu':mu,'A':s.Function('A'),'B':s.Function('B'),'phi':s.Function('phi'),'H0':s.Function('H0'),'chi':s.Function('chi'),'epsilon':s.Function('epsilon'),'p':s.Function('p'),'cs2':s.Function('cs2')}
metric=s.sympify(text[10],locals=loc);scalar=s.sympify(text[7],locals=loc)
# All background derivatives in the prior export remain independent inputs here.
variables=[r,A,B,phi,s.diff(A,r),s.diff(A,r,2),s.diff(B,r),s.diff(phi,r),s.diff(phi,r,2),er,pr,vr,s.diff(er,r),s.diff(pr,r),alpha,mu,H,s.diff(H,r),s.diff(H,r,2),chi,s.diff(chi,r),s.diff(chi,r,2)]
fm=s.lambdify(variables,metric,'numpy',cse=True);fs=s.lambdify(variables,scalar,'numpy',cse=True)
raw=(ROOT/'sources/radial_equations_prior_gate.txt').read_text().splitlines()
E0,P0,C0=s.symbols('epsilon p cs2',nonzero=True);H2=s.Function('H2')(r);K=s.Function('K')(r)
rawloc=loc|{'epsilon':E0,'p':P0,'cs2':C0,'H2':s.Function('H2'),'K':s.Function('K')}
et=s.sympify(raw[1],locals=rawloc);ea=s.sympify(raw[13],locals=rawloc)
rawvariables=[r,A,B,phi,s.diff(A,r),s.diff(A,r,2),s.diff(B,r),s.diff(phi,r),s.diff(phi,r,2),E0,P0,C0,alpha,mu,H,s.diff(H,r),s.diff(H,r,2),H2,s.diff(H2,r),s.diff(H2,r,2),K,s.diff(K,r),s.diff(K,r,2),chi,s.diff(chi,r)]
ft=s.lambdify(rawvariables,et,'numpy',cse=True);fa=s.lambdify(rawvariables,ea,'numpy',cse=True)
fr=s.lambdify(rawvariables,s.sympify(raw[4],locals=rawloc),'numpy',cse=True);frt=s.lambdify(rawvariables,s.sympify(raw[7],locals=rawloc),'numpy',cse=True)

rr,mm,pp0,ff,yy,aa,uu=s.symbols('rr mm pp0 ff yy aa uu',real=True);bb=1-2*mm/rr
vjet=(mm+4*s.pi*rr**3*(s.exp(-ff)*pp0+(bb*yy**2-uu**2*ff**2)/(2*aa)))/(rr**2*bb)
grad=s.lambdify((rr,mm,pp0,ff,yy,aa,uu),[s.diff(vjet,z) for z in (rr,mm,pp0,ff,yy)],'numpy');vf=s.lambdify((rr,mm,pp0,ff,yy,aa,uu),vjet,'numpy')

spec=importlib.util.spec_from_file_location('r2_equations_reference',ROOT/'sources/pilot_r2_reference.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
rng=np.random.default_rng(778);rows=[]
for i in range(25):
 rv=float(rng.uniform(1,15));mv=float(rng.uniform(.02,min(.8,rv/4)));ev=float(rng.uniform(.00001,.002));pv=ev*float(rng.uniform(.1,.4));cv=float(rng.uniform(.1,.7));fv=float(rng.uniform(.001,.05));yv=float(rng.uniform(-.002,.002));av=float(rng.uniform(.01,2));uv=float(rng.uniform(.05,1));avalue=.8
 zero=i==24
 if zero:
  rv,mv,ev,pv,cv,yv,av,uv=5.,.1,.0002,.00001,.4,0.,1.,.5
  fv=brentq(lambda f:uv*uv*f*f/(2*av)-np.exp(-f)*pv-mv/(4*PI*rv**3),.001,.5,xtol=1e-15)
 bv=1-2*mv/rv;f=np.exp(-fv);mp=4*PI*rv**2*(f*ev+(bv*yv*yv+uv*uv*fv*fv)/(2*av));bp=2*mv/rv**2-2*mp/rv;v=float(vf(rv,mv,pv,fv,yv,av,uv));pp=(ev+pv)*(-v+yv);ep=pp/cv;yp=(uv*uv*fv-av*f*ev-(2*bv/rv+bv*v+bp/2)*yv)/bv
 vp=float(np.array(grad(rv,mv,pv,fv,yv,av,uv))@np.array([1,mp,pp,yv,yp]));ap=2*avalue*v;app=2*avalue*vp+4*avalue*v*v
 hv,hp,xv,xp=rng.uniform(-.03,.03,4);z=np.sqrt(av);eta=xv/z;etap=xp/z
 co=CO(rv,mv,ev,pv,fv/z,yv/z,z,uv,cv);hpp=co[0]*hv+co[1]*hp+co[2]*eta+co[3]*etap;xpp=z*(co[4]*hv+co[5]*eta+co[6]*etap)
 args=[rv,avalue,bv,fv,ap,app,bp,yv,yp,ev,pv,cv,ep,pp,av,uv,hv,hp,hpp,xv,xp,xpp]
 mr=None if zero else float(fm(*args));sr=float(fs(*args))
 af=-rv*rv*bv*v/2;bf=2*PI*rv*rv*f*(ev+3*pv)-rv*rv*bv*v*v-rv*bv*v-1-2*PI*uv*uv*rv*rv*fv*fv/av
 cf=-4*PI*rv*rv*f*ev+4*PI*uv*uv*rv*rv*fv/av-8*PI*rv*rv*bv*v*yv/av-8*PI*rv*bv*yv/av;df=-4*PI*rv*rv*bv*yv/av
 kval=af*hp+bf*hv+cf*xv+df*xp;kp=-hp-2*v*hv-16*PI*yv*xv/av;kpp=-hpp-2*vp*hv-2*v*hp-16*PI*(yp*xv+yv*xp)/av
 rawargs=[rv,avalue,bv,fv,ap,app,bp,yv,yp,ev,pv,cv,av,uv,hv,hp,hpp,-hv,-hp,-hpp,kval,kp,kpp,xv,xp]
 tr=float(ft(*rawargs));ar=float(fa(*rawargs));rrr=float(fr(*rawargs));rtr=float(frt(*rawargs));un=float(OLD_RESIDUAL(rv,mv,ev,pv,fv/z,yv/z,z,uv,cv,hv,hp,hpp,eta,etap))
 olddiff=None
 if not zero:
  oc=old.CO(rv,mv,ev,pv,fv,yv,av,uv,cv);ohpp=oc[0]*hv+oc[1]*hp+oc[2]*xv+oc[3]*xp;olddiff=float(abs(ohpp-hpp)/max(abs(ohpp),abs(hpp),1e-10))
 assert np.isfinite(hpp) and max(abs(t) for t in [sr,tr,ar,rrr,rtr,un]+([] if zero else [mr]))<1e-8
 if zero:assert abs(ap)<1e-15
 rows.append(dict(sample=i,Aprime_zero=zero,Aprime=ap,Hpp=hpp,old_normalized_metric_residual=mr,old_Hpp_relative_difference=olddiff,old_unnormalized_reduction_residual=un,scalar_residual=sr,Einstein_tt_residual=tr,unused_Einstein_rr_residual=rrr,unused_Einstein_rtheta_residual=rtr,unused_Einstein_angular_residual=ar))
with (ROOT/'data/derivation_reaudit_jets.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
report={'samples':len(rows),'random_nonzero_Aprime_samples':24,'Aprime_zero_test':rows[-1],'max_old_Hpp_relative_difference':max(z['old_Hpp_relative_difference'] for z in rows if z['old_Hpp_relative_difference'] is not None),'max_residuals':{k:max(abs(z[k]) for z in rows if z[k] is not None) for k in rows[0] if 'residual' in k},'method':'Independently exported covariant equations and old normalized/unnormalized reduction on fresh on-shell jets; normalized old equation is deliberately not evaluated at Aprime=0.','pass':True}
(ROOT/'checks/derivation_reaudit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
