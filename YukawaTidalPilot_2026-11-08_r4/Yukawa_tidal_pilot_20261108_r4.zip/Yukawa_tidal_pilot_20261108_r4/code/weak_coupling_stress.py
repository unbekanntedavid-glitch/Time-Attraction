#!/usr/bin/env python3
"""Additional a=1e-8 diagnostic. An unaccepted background never produces a Love number."""
from run_suite import *
import pandas as pd
if __name__=='__main__':
 refs=pd.read_csv(ROOT/'data/pilot_results.csv');rows=[];attempts=[]
 for name in ['SLy','APR4']:
  ref=float(refs[(refs.EOS==name)&(refs.alphaY==0)].iloc[0].Lambda_metric)
  for L in [1.,10.]:
   try:
    bg=background(name,1e-8,L,bgtol=2e-8);row=tidal(bg,**BASE);row['relative_to_GR']=row['Lambda_metric']/ref-1
    assert abs(row['relative_to_GR'])<1e-6 and row['applied_A_rank']==2
    rows.append(row);attempts.append(dict(EOS=name,L_km=L,alphaY=1e-8,status='accepted',Lambda_metric=row['Lambda_metric'],relative_to_GR=row['relative_to_GR'],error=''));print(name,L,row['relative_to_GR'],flush=True)
   except RuntimeError as ex:
    attempts.append(dict(EOS=name,L_km=L,alphaY=1e-8,status='inconclusive_background_rejected',Lambda_metric=None,relative_to_GR=None,error=str(ex)));print('INCONCLUSIVE',name,L,str(ex),flush=True)
   write_rows(ROOT/'data/weak_coupling_stress.csv',rows);write_rows(ROOT/'data/weak_coupling_attempts.csv',attempts)
 try:gr_riccati({'a':1.})
 except ValueError:guard=True
 else:guard=False
 assert guard
 report={'coupling_a':1e-8,'attempted_states':len(attempts),'accepted_states':len(rows),'inconclusive_states':[v for v in attempts if v['status']!='accepted'],'max_absolute_relative_Lambda_to_GR':max(abs(v['relative_to_GR']) for v in rows),'GR_only_formula_rejects_modified_background':guard,'all_four_states_accepted':len(rows)==4,'required_pilot_gate':False,'scope':'Additional extreme-coupling diagnostic, separate from the required a=.01,.001,.0001 sequences. No tidal value is reported for a rejected background.'}
 (ROOT/'checks/weak_coupling_stress.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
