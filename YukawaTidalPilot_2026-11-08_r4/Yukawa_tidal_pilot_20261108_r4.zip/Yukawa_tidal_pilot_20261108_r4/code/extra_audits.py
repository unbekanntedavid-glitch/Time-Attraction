#!/usr/bin/env python3
"""Vacuum normalization, causal/background and alternate-integrator audits.
©2026 Szabolcsi Dávid, CC BY-NC4.0.
"""
from pilot import *
from types import SimpleNamespace
import csv

def load_bg(name,L):
 data=np.load(ROOT/'data'/f'background_{name}_a1_L{L:g}.npz');a,L,nL,r0,hs=data['parameters'];R,pc,hc=data['p'];poly=PPoly(data['c'],data['x'])
 return dict(eos=EOS(name,a),a=float(a),L=float(L),nL=float(nL),r0=float(r0),hs=float(hs),R=float(R),hc=float(hc),phic=float(np.sqrt(a)*pc),psic=float(pc),mout=float(poly(1)[5]),bgsol=SimpleNamespace(sol=poly),bg_tol=2e-8)

if __name__=='__main__':
 # Exact hypergeometric tensor vacuum basis: Wronskian and differential residual.
 basisrows=[];M=TARGET
 for rv in [8.,12.,30.,100.,200.]:
  base=vacuum_basis(rv,M);h=rv*1e-4
  dd=(vacuum_basis(rv-2*h,M)[1]-8*vacuum_basis(rv-h,M)[1]+8*vacuum_basis(rv+h,M)[1]-vacuum_basis(rv+2*h,M)[1])/(12*h)
  B=1-2*M/rv;P=2/rv+2*M/(rv*rv*B);Q=-6/(rv*rv*B)-4*M*M/(rv**4*B*B);res=dd+P*base[1]+Q*base[0];scale=np.abs(dd)+np.abs(P*base[1])+np.abs(Q*base[0])
  wr=np.linalg.det(base);expected=-5/(rv*rv*B)
  basisrows.append(dict(r_km=rv,growing_norm_residual=float(abs(res[0])/scale[0]),decaying_norm_residual=float(abs(res[1])/scale[1]),Wronskian_relative_error=float(abs(wr/expected-1))))
 assert max(max(v['growing_norm_residual'],v['decaying_norm_residual'],v['Wronskian_relative_error']) for v in basisrows)<1e-7
 report={'tensor_vacuum_basis':basisrows,'cases':[]}
 for name in ['SLy','APR4']:
  for L in [1.,10.]:
   bg=load_bg(name,L);R=bg['R'];mi=interfaces(bg,.001)
   points=np.r_[np.linspace(.03,R*.999,160),np.array(mi)*(1-1e-8),np.array(mi)*(1+1e-8)]
   css=[float(bg['eos'].at(bg['hc'])[3])];vcoeff=[];residuals=[]
   for rv in points:
    m,h,phi,y=bg_at(bg,rv);e,p,cs,B,v,mp,bp,yp=bg_values(rv,m,h,phi,y,bg['eos'],1,L)
    css.append(float(cs));vcoeff.append(float(v/rv))
    dh=min(2e-4,max(1e-6,rv*1e-4))
    if rv-dh<=bg['r0'] or rv+dh>=R or any(abs(rv-z)<3*dh for z in mi):continue
    def getv(r):
     mm,hh,ff,yy=bg_at(bg,r);return bg_values(r,mm,hh,ff,yy,bg['eos'],1,L)[4]
    vp=(getv(rv+dh)-getv(rv-dh))/(2*dh)
    rho=(B*y*y+phi*phi/L**2)/2;pt=np.exp(-phi)*p-rho
    lhs=B*(vp+v*v+v/rv)+bp*(v+1/rv)/2
    denom=max(abs(B*vp),abs(B*v*v),abs(B*v/rv),abs(bp*(v+1/rv)/2),abs(8*PI*pt),1e-10)
    residuals.append(float(abs(lhs-8*PI*pt)/denom))
   outer=R+12*L;s60,t60=scalar_vacuum_basis(bg,outer,60.);s80,t80=scalar_vacuum_basis(bg,outer,80.)
   row={'EOS':name,'L_km':L,'max_cs2_sampled_with_one_sided_interfaces':max(css),'min_nuprime_over_r':min(vcoeff),'max_unused_background_angular_normalized_residual_fd':max(residuals),'scalar_decay_slope_60_vs_80L_relative':abs(s60/s80-1),'scalar_decay_normalization_60_vs_80L_relative':abs(t60/t80-1)}
   assert row['max_cs2_sampled_with_one_sided_interfaces']<1 and min(vcoeff)>0
   assert row['max_unused_background_angular_normalized_residual_fd']<1e-4
   assert row['scalar_decay_slope_60_vs_80L_relative']<1e-8 and row['scalar_decay_normalization_60_vs_80L_relative']<1e-8
   reference=tidal(bg,nmatch=12,rtol=3e-10,maxstep=.06,start=.005)
   alternate=tidal(bg,nmatch=12,rtol=3e-9,maxstep=.06,start=.005,method='Radau')
   row['Lambda_DOP853']=reference['Lambda_metric'];row['Lambda_Radau']=alternate['Lambda_metric'];row['alternate_integrator_relative_difference']=abs(alternate['Lambda_metric']/reference['Lambda_metric']-1)
   assert row['alternate_integrator_relative_difference']<3e-5,row
   report['cases'].append(row);(ROOT/'checks/extra_audits.json').write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
 report['pass']=True;(ROOT/'checks/extra_audits.json').write_text(json.dumps(report,indent=2))
