#!/usr/bin/env python3
"""Actual integrated pilot and convergence suite. ©2026 Szabolcsi Dávid, CC BY-NC4.0."""
from pilot import *
import csv,traceback,multiprocessing
from concurrent.futures import ProcessPoolExecutor,as_completed

def write_rows(path,rows):
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with Path(path).open('w') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def dump_background(bg,label):
 R=bg['R'];a=bg['a'];rs=np.r_[np.linspace(bg['r0'],R,700),np.linspace(R,R+20*bg['L'],700)[1:]];rows=[]
 for r in rs:
  ext=r>R;m,h,phi,y=bg_at(bg,r,ext);e=p=cs=0.
  if not ext:e,p,_,cs=bg['eos'].at(h)
  rows.append(dict(r_km=r,m_geom_km=float(m),h=float(h),phi=float(phi),phi_prime_per_km=float(y),epsilon_geom_kmminus2=float(e),p_geom_kmminus2=float(p),cs2=float(cs),region='vacuum' if ext else 'fluid'))
 write_rows(ROOT/'data'/f'background_{label}.csv',rows)
 if a>0:
  np.savez_compressed(ROOT/'data'/f'background_{label}.npz',x=bg['bgsol'].sol.x,c=bg['bgsol'].sol.c,p=bg['bgsol'].p,parameters=np.array([a,bg['L'],bg['nL'],bg['r0'],bg['hs']]))

def gr_riccati(bg):
 if bg['a']!=0:raise ValueError('GR-only Love benchmark: modified backgrounds are excluded')
 R=bg['R'];M=bg['mout'];r0=.0025;y=np.array([2.]);edges=[r0]+interfaces(bg,r0)+[R]
 for left,right in zip(edges[:-1],edges[1:]):
  seg=int(np.searchsorted(bg['eos'].raw.hb,float(bg_at(bg,(left+right)/2)[1])))
  def fun(r,z):
   co=coeff(bg,r,False,seg);P=-co[1];Q=-co[0];return [-z[0]**2/r+(1/r-P)*z[0]-r*Q]
  sol=solve_ivp(fun,(left,right),y,method='DOP853',rtol=3e-12,atol=1e-13,max_step=.015);assert sol.success;y=sol.y[:,-1]
 e=bg['eos'].at(bg['hs'])[0];Y=float(y[0]-4*PI*R**3*e/M);C=M/R
 numerator=8*C**5/5*(1-2*C)**2*(2+2*C*(Y-1)-Y)
 denominator=2*C*(6-3*Y+3*C*(5*Y-8))+4*C**3*(13-11*Y+C*(3*Y-2)+2*C*C*(1+Y))+3*(1-2*C)**2*(2-Y+2*C*(Y-1))*np.log(1-2*C)
 k=numerator/denominator
 return dict(EOS=bg['eos'].name,y_surface=Y,k2_riccati=k,Lambda_riccati=2*k/(3*C**5))

BASE=dict(nmatch=12.,rtol=3e-10,maxstep=.06,start=.005)
def case(name,L):
 label=f'{name}_a1_L{L:g}';rows=[];t=time.time()
 try:
  bg=background(name,1.,L,bgtol=2e-8,nL=20.);dump_background(bg,label)
  tests=[('baseline',{}),('central_start_0p01',dict(start=.01)),('central_start_0p0025',dict(start=.0025)),('central_leading_only',dict(series_order=2)),('outer_8L',dict(nmatch=8.)),('outer_10L',dict(nmatch=10.)),('outer_14L',dict(nmatch=14.)),('rtol_3e8',dict(rtol=3e-8)),('step_0p12',dict(maxstep=.12)),('step_0p03',dict(maxstep=.03))]
  for labeltest,delta in tests:
   params=BASE|delta;row=tidal(bg,**params);row['test']=labeltest;rows.append(row);write_rows(ROOT/'data'/f'controls_{label}.csv',rows)
   print(label,labeltest,'Lambda',row['Lambda_metric'],'secs',round(time.time()-t,2),flush=True)
  # Independently altered background tolerance, outer domain, central start and surface threshold.
  for labeltest,opts in [('background_tol_8e8',dict(bgtol=8e-8)),('background_outer24L',dict(bgtol=2e-8,nL=24.)),('background_start_0p0005',dict(bgtol=2e-8,r0=.0005)),('surface_h1e8',dict(bgtol=2e-8,hs=1e-8))]:
   b2=background(name,1.,L,**opts);row=tidal(b2,**BASE);row['test']=labeltest;rows.append(row);write_rows(ROOT/'data'/f'controls_{label}.csv',rows);print(label,labeltest,'Lambda',row['Lambda_metric'],flush=True)
  ref=rows[0];dLam=max(abs(v['Lambda_metric']-ref['Lambda_metric']) for v in rows[1:]);dR=max(abs(v['R_g_km']-ref['R_g_km']) for v in rows[1:]);ref['tested_Lambda_abs_envelope']=dLam;ref['tested_R_km_abs_envelope']=dR;ref['tested_Lambda_relative_envelope']=dLam/abs(ref['Lambda_metric']);ref['gates_passed']=bool(dLam/abs(ref['Lambda_metric'])<3e-4 and ref['cs2c']<1 and max(v['matching_relative_residual'] for v in rows)<2e-7 and all(v['applied_A_rank']==2 and v['applied_A_condition']<1e10 and v['applied_dual_error']<2e-7 for v in rows) and abs(ref['M_K_Msun']-1.4)<1e-8)
  return dict(result=ref,controls=rows,status='ok')
 except Exception as ex:
  err={'status':'failed','EOS':name,'L_km':L,'error':str(ex),'traceback':traceback.format_exc(),'successful_controls':rows};(ROOT/'checks'/f'failure_{label}.json').write_text(json.dumps(err,indent=2));return err

if __name__=='__main__':
 start=time.time();grrows=[];grchecks=[];limitrows=[]
 for name in ['SLy','APR4']:
  bg=gr_background(name);dump_background(bg,f'{name}_GR');r=tidal(bg,**BASE);ri=gr_riccati(bg);ri['Lambda_subspace']=r['Lambda_metric'];ri['relative_difference']=abs(ri['Lambda_riccati']/r['Lambda_metric']-1);ri['pass']=bool(ri['relative_difference']<1e-6)
  assert ri['pass'],ri
  grrows.append(r);grchecks.append(ri);print('GR benchmark',name,ri,flush=True)
 write_rows(ROOT/'data/gr_benchmarks.csv',grchecks)
 # Both pilot EOSs have an integrated small-coupling sequence at L=10 km.
 for name in ['SLy','APR4']:
  for a in [.01,.001,.0001]:
   bg=background(name,a,10.,bgtol=2e-8);r=tidal(bg,**BASE);r['relative_to_GR']=r['Lambda_metric']/next(v for v in grrows if v['EOS']==name)['Lambda_metric']-1;limitrows.append(r);write_rows(ROOT/'data/coupling_limit.csv',limitrows);print('coupling limit',name,a,r['relative_to_GR'],flush=True)
 results=[]
 with ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('fork')) as pool:
  fs=[pool.submit(case,name,L) for name in ['SLy','APR4'] for L in [1.,10.]]
  for future in as_completed(fs):
   obj=future.result();results.append(obj);(ROOT/'checks/suite_progress.json').write_text(json.dumps({'cases':results,'elapsed_s':time.time()-start},indent=2));print('case returned',obj['status'],flush=True)
 coupled=[v['result'] for v in results if v['status']=='ok'];allrows=grrows+coupled
 write_rows(ROOT/'data/pilot_results.csv',allrows)
 limpass={name:bool(all(abs(b['relative_to_GR'])<abs(a['relative_to_GR'])/5 for a,b in zip([v for v in limitrows if v['EOS']==name],[v for v in limitrows if v['EOS']==name][1:]))) for name in ['SLy','APR4']}
 report={'GR_benchmarks':grchecks,'small_coupling_monotone_toward_GR':limpass,'coupled_cases':[{k:v for k,v in r.items() if k not in ['controls']} for r in results],'all_numeric_gates_passed':bool(len(coupled)==4 and all(v['gates_passed'] for v in coupled) and all(limpass.values())),'scope':'conditional fixed-G_lab unscreened dust calibration; tensor-only static metric response; two EOS pilot; no observational likelihood or stability calculation','elapsed_s':time.time()-start}
 (ROOT/'checks/numerical_gates.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
