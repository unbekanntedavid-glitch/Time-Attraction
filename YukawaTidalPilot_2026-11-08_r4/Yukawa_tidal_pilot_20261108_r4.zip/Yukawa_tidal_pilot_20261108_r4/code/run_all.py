#!/usr/bin/env python3
"""Run actual scientific checks and save stdout, exit status and current code digests."""
from pathlib import Path
import subprocess,sys,os,time,json,hashlib
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parents[1];LOG=ROOT/'checks/logs';LOG.mkdir(exist_ok=True)
def run(name):
 t=time.monotonic();p=ROOT/'code'/name;out=LOG/(p.stem+'.log');print('START',name,flush=True)
 with out.open('w') as f:obj=subprocess.run([sys.executable,'-u',str(p)],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,env=os.environ|{'OPENBLAS_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'})
 row=dict(script=name,exit_code=obj.returncode,elapsed_seconds=time.monotonic()-t,log=str(out.relative_to(ROOT)),script_sha256=hashlib.sha256(p.read_bytes()).hexdigest());print('END',name,row['exit_code'],round(row['elapsed_seconds'],2),flush=True);return row
if __name__=='__main__':
 rows=[];rows.append(run('input_integrity.py'));rows.append(run('run_suite.py'));rows.append(run('strict_controls.py'))
 if any(v['exit_code'] for v in rows):raise SystemExit('Input or integrated pilot gate failed; inspect logs before reporting scientific numbers.')
 groups=[['extend_limits.py','gr_controls.py','weak_coupling_stress.py'],['extra_audits.py','background_acceptance.py'],['derive_covariant.py','zero_Aprime_exact.py','reaudit_numeric.py'],['normalization_and_bridge.py','scalar_amplitude_controls.py','central_and_junctions.py','integrated_residuals.py'],['rerun_r2_comparison.py','method_comparison.py','retained_conventions.py']]
 def chain(group):return [run(n) for n in group]
 with ThreadPoolExecutor(max_workers=4) as pool:
  for f in as_completed([pool.submit(chain,g) for g in groups]):
   rows+=f.result();(ROOT/'checks/execution_record.json').write_text(json.dumps({'runs':rows,'all_exit_codes_zero':all(v['exit_code']==0 for v in rows)},indent=2))
 assert all(v['exit_code']==0 for v in rows),rows
 print('Scientific scripts passed:',len(rows),flush=True)
