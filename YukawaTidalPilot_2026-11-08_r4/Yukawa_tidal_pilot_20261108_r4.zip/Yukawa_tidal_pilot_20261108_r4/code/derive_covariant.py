#!/usr/bin/env python3
"""Exact first variations, static even l=2 m=0 RW gauge; no background substitution into GR Love formula.
©2026 Szabolcsi Dávid; CC BY-NC 4.0. See LICENSE.txt.
Exports redundant radial Einstein equations for audit, not an NS tidal solver.
"""
from pathlib import Path
import sympy as s
import json, time
ROOT=Path(__file__).resolve().parents[1]
t,r,th,ph=s.symbols('t r theta azimuth', real=True)
x=[t,r,th,ph]; N=4
A,B,phi,H0,H2,K,chi=[s.Function(n)(r) for n in ['A','B','phi','H0','H2','K','chi']]
e,p,cs2,alpha,mu=s.symbols('epsilon p cs2 alpha mu', nonzero=True)
Y=(3*s.cos(th)**2-1)/2
f=s.exp(-phi); dh=chi-H0/2; de=(e+p)*dh/cs2; dp=(e+p)*dh
g=s.diag(-A,1/B,r*r,r*r*s.sin(th)**2); gi=g.inv()
h=s.diag(-A*H0*Y,H2*Y/B,r*r*K*Y,r*r*s.sin(th)**2*K*Y)
dgi=-gi*h*gi
D=lambda z,i:s.diff(z,x[i])
Gamma={}; C={}
for a in range(N):
 for b in range(N):
  for c in range(N):
   Gamma[a,b,c]=s.simplify(sum(gi[a,d]*(D(g[d,c],b)+D(g[d,b],c)-D(g[b,c],d))/2 for d in range(N)))
   C[a,b,c]=s.simplify(sum((gi[a,d]*(D(h[d,c],b)+D(h[d,b],c)-D(h[b,c],d))+dgi[a,d]*(D(g[d,c],b)+D(g[d,b],c)-D(g[b,c],d)))/2 for d in range(N)))
print('connections ready',flush=True)
R=s.zeros(N); dR=s.zeros(N)
for a in range(N):
 for b in range(a,N):
  R[a,b]=s.simplify(sum(D(Gamma[c,a,b],c)-D(Gamma[c,a,c],b)+sum(Gamma[c,c,d]*Gamma[d,a,b]-Gamma[c,b,d]*Gamma[d,a,c] for d in range(N)) for c in range(N)))
  dR[a,b]=s.expand(sum(D(C[c,a,b],c)-D(C[c,a,c],b)+sum(C[c,c,d]*Gamma[d,a,b]+Gamma[c,c,d]*C[d,a,b]-C[c,b,d]*Gamma[d,a,c]-Gamma[c,b,d]*C[d,a,c] for d in range(N)) for c in range(N)))
  R[b,a]=R[a,b]; dR[b,a]=dR[a,b]
Rsc=s.simplify(s.trace(gi*R)); dRsc=s.expand(s.trace(gi*dR)+s.trace(dgi*R))
dG=dR-h*Rsc/2-g*dRsc/2
kin=B*s.diff(phi,r)**2+mu**2*phi**2
dkin=(B*(2*s.diff(phi,r)*s.diff(chi,r)-H2*s.diff(phi,r)**2)+2*mu**2*phi*chi)*Y
Tm=s.diag(A*f*(de+e*(H0-chi))*Y,f*(dp+p*(H2-chi))*Y/B,r*r*f*(dp+p*(K-chi))*Y,r*r*s.sin(th)**2*f*(dp+p*(K-chi))*Y)
Ts=s.zeros(N)
for a in range(N):
 for b in range(N):
  Ts[a,b]=(D(chi*Y,a)*D(phi,b)+D(phi,a)*D(chi*Y,b)-h[a,b]*kin/2-g[a,b]*dkin/2)/alpha
E=dG-8*s.pi*(Tm+Ts)
# harmonic projection by exact evaluation after division. Valid for this pure l=2 ansatz.
proj=lambda z:s.factor(s.expand(z).subs(th,s.pi/3))
eqs={
 'tt_over_A_Y':proj(E[0,0]/(A*Y)),
 'rr_times_B_over_Y':proj(E[1,1]*B/Y),
 'rtheta_over_dY':proj(E[1,2]/s.diff(Y,th)),
 'angular_tracefree':proj((E[2,2]-E[3,3]/s.sin(th)**2)/(s.diff(Y,th,2)-s.cot(th)*s.diff(Y,th))),
 'theta_theta_over_r2_Y':proj(E[2,2]/(r*r*Y))}
boxphi=B*s.diff(phi,r,2)+(2*B/r+B*s.diff(A,r)/(2*A)+s.diff(B,r)/2)*s.diff(phi,r)
eqs['scalar']=B*s.diff(chi,r,2)+(2*B/r+B*s.diff(A,r)/(2*A)+s.diff(B,r)/2)*s.diff(chi,r)-(6/r**2+mu**2+alpha*f*e)*chi+alpha*f*de-H2*boxphi+B*(s.diff(H0,r)-s.diff(H2,r)+2*s.diff(K,r))*s.diff(phi,r)/2
out=ROOT/'notes/covariant_equations_r3.txt'
out.write_text('\n\n'.join(k+' = 0\n'+s.sstr(v) for k,v in eqs.items())+'\n')
(ROOT/'notes/covariant_equations_r3.tex').write_text('\n'.join('\\[ '+s.latex(v)+'=0 \\]' for v in eqs.values()))
# The angular tracefree equation must impose H2=-H0, with our negative h_tt convention.
assert s.simplify(eqs['angular_tracefree']+(H0+H2)/2)==0

# Compare to immutable prior export after independently constructing delta G and delta T.
import hashlib
lines=(ROOT/'sources/radial_equations_prior_gate.txt').read_text().splitlines()
loc={'r':r,'alpha':alpha,'mu':mu,'epsilon':e,'p':p,'cs2':cs2}|{n:s.Function(n) for n in ['A','B','phi','H0','H2','K','chi']}
for j,(name,expr) in enumerate(eqs.items()):
 ref=s.sympify(lines[j*3+1],locals=loc);assert s.factor(expr-ref)==0,name
report={'independently_generated_covariant_components':list(eqs),'all_prior_component_identities':True,'angular_tracefree_H2_equals_minus_H0':True,'fluid_variation':'conserved current; bare EOS; delta h=chi-H0/2; density scalar source; no conformal trace replacement','prior_raw_sha256':hashlib.sha256((ROOT/'sources/radial_equations_prior_gate.txt').read_bytes()).hexdigest(),'pass':True}
(ROOT/'checks/covariant_generation_r3.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
