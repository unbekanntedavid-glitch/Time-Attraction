#!/usr/bin/env python3
"""Executed method ablations, not a claim that symbolic checks are stellar results."""
from run_suite import *
from extra_audits import load_bg
import pandas as pd
spec=importlib.util.spec_from_file_location('r2_method_reference',ROOT/'sources/pilot_r2_reference.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def tt_physical(r,m,e,p,phi,y,a,mu,cs):
 z=np.sqrt(a);co=np.asarray(CO(r,m,e,p,phi/z,y/z,z,mu,cs),float)
 return co*np.array([1,1,1/z,1/z,z,1,1])
if __name__=='__main__':
 prior=pd.read_csv(ROOT/'data/r2_fresh_rerun.csv');rows=[]
 old.CO=tt_physical
 for name in ['SLy','APR4']:
  for a,L in [(0.,1.),(1.,1.),(1.,10.)]:
   bgold=old.background(name,a,L,bgtol=2e-8);tt=old.tidal(bgold,**BASE)
   bg=gr_background(name) if a==0 else load_bg(name,L)
   new=tidal(bg,**BASE);lead=tidal(bg,**BASE,series_order=2)
   ref=prior[(prior.EOS==name)&(prior.alphaY==a)&(prior.L_km==(L if a else 0))].iloc[0]
   row=dict(EOS=name,alphaY=a,L_km=L if a else 0.,r2_fresh_Lambda=float(ref.Lambda_metric),r2_with_tt_only_Lambda=tt['Lambda_metric'],r3_leading_only_Lambda=lead['Lambda_metric'],r3_r4_Lambda=new['Lambda_metric'],r3_allowed4x4_Lambda=new['old_matching_Lambda_metric'],tt_only_delta=tt['Lambda_metric']-ref.Lambda_metric,r4_series_delta=new['Lambda_metric']-lead['Lambda_metric'],applied_matrix_selector_delta=new['Lambda_metric']-new['old_matching_Lambda_metric'],background_radius_delta_km=bg['R']-bgold['R'])
   assert abs(row['tt_only_delta']/ref.Lambda_metric)<1e-6 and abs(row['r4_series_delta']/new['Lambda_metric'])<1e-6 and abs(row['applied_matrix_selector_delta']/new['Lambda_metric'])<1e-10
   rows.append(row);write_rows(ROOT/'data/method_controls.csv',rows);print(row,flush=True)
 (ROOT/'checks/method_controls.json').write_text(json.dumps({'states':6,'old_backgrounds_reintegrated':True,'tt_only_uses_archived_implementation_except_metric_coefficients':True,'r4_versus_leading_only_uses_same_r3_background_and_exterior':True,'applied_selector_versus_allowed4x4_uses_same_coupled_exterior':True,'max_tt_only_abs_delta':max(abs(v['tt_only_delta']) for v in rows),'max_r4_series_abs_delta':max(abs(v['r4_series_delta']) for v in rows),'max_selector_abs_delta':max(abs(v['applied_matrix_selector_delta']) for v in rows),'pass':True},indent=2))
