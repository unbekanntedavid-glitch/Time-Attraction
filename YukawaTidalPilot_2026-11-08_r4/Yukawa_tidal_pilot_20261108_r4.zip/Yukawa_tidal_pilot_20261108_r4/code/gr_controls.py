#!/usr/bin/env python3
"""GR center/step/tolerance/exterior/background controls. ©2026 Szabolcsi Dávid, CC BY-NC4.0."""
from run_suite import *
if __name__=='__main__':
 rows=[];summary=[]
 for name in ['SLy','APR4']:
  bg=gr_background(name)
  for label,delta in [('baseline',{}),('start_0p01',dict(start=.01)),('start_0p0025',dict(start=.0025)),('step_0p12',dict(maxstep=.12)),('step_0p03',dict(maxstep=.03)),('rtol_3e8',dict(rtol=3e-8)),('outer_8L',dict(nmatch=8.)),('outer_16L',dict(nmatch=16.))]:
   r=tidal(bg,**(BASE|delta));r['test']=label;rows.append(r)
  other=gr_background(name,rtol=1e-9);r=tidal(other,**BASE);r['test']='background_rtol1e9';rows.append(r)
  group=[r for r in rows if r['EOS']==name];ref=group[0];maxd=max(abs(r['Lambda_metric']/ref['Lambda_metric']-1) for r in group);assert maxd<1e-6
  summary.append(dict(EOS=name,max_relative_Lambda_variation=maxd,max_R_km_variation=max(abs(r['R_g_km']-ref['R_g_km']) for r in group),tests=len(group)))
 write_rows(ROOT/'data/gr_convergence_controls.csv',rows);report={'cases':summary,'pass':True};(ROOT/'checks/gr_convergence_controls.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
