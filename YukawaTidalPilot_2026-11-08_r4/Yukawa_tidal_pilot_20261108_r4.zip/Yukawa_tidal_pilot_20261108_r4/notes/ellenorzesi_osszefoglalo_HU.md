# Mennyiségi ellenőrzési összefoglaló — r4

Az alábbi értékek az átvett r3 futásadatokból származnak; az r4 nem futtatja újra a 18 tudományos scriptet. Az r4 publikációs bemenetellenőrzést, pozitív/negatív regressziót, valamint elkülönített hatállapotos reprodukciót és riportépítést végez. A kötelező hatállapotos pilot ellenőrzéseit és az opcionális szélső kiscsatolású diagnosztikát külön kezeljük.

| Kontroll | Mért eredmény |
|---|---|
| Integrált GR Love-benchmark | 2 EOS; max relatív eltérés 2.23314e-10 |
| Módosított numerikus kontroll | 64 sor; max tesztelt relatív Λ-eltérés 2.48172e-07 |
| GR numerikus kontroll | 18 sor |
| Középponti kezdősugár | 0.01/0.005/0.0025 km; max relatív Λ-eltérés 7.14149e-11 |
| Kiscsatolású határ | a=0.01/0.001/0.0001, mindkét EOS és L; 12 elfogadott állapot |
| Alkalmazott A mátrix | minden rang 2; kondíciószám 1.94807–2.38426 |
| Duális külső kontroll | max abszolút hiba 2.9112e-14; alkalmazott skalár max |a_s| 5.34033e-17 |
| Külső illesztés | max normált maradék 3.33071e-14; n=8/10/12/14; DOP853/Radau és 4×4 kontroll |
| Lokális redukció és Einstein | 24 friss minta + egy közel zérus A′ minta; régi/új H″ max relatív eltérés 3.25279e-15 |
| Egzakt A′=0 | pozitív p, B>0; mind a hat kovariáns maradék pontosan 0 |
| Integrált differenciális maradék | 128 oszlopminta; max 1.34886e-07; önálló ötpontos differencia |
| Középponti negyedrendű sor | 12 oszlop, 36 pont; a skálázott hiba a 0.1→0.025 km váltásnál kb. 1/16 |
| EOS-illesztések | 12 darabhatár; max ε relatív illesztési hiba 1.65288e-13 |
| Skalár referenciaamplitúdó | 48 ismert keverék; max alkalmazott amplitúdóhiba 2.22045e-16; Wronskián relatív hibája 1.71996e-12 |
| Pontos külső normalizálás | 20 ismert/nulla válasz; max λ absz. visszamérési hiba 6.66064e-06 km⁵; Legendre eltérés 4.44089e-16 |
| Analitikus k-u egységtérkép | 8 eset; max eltérés 1.0842e-19; hiányzó régi kódot nem importál |
| Háttér elfogadása | 4 BVP; mind kért 2×10⁻⁸ maradékon belül; a távoli farok külön becslés |
| R2 kontroll | 6 régi állapot friss háttér- és perturbációintegrálással |
| R3 reprodukció | 6 állapot tárolt háttér nélkül ismét felépítve |

## Elutasított további diagnosztika

Az a=10⁻⁸ APR4, L=10 km háttér a további hálósűrítés csomópontkorlátja miatt nem érte el a 2×10⁻⁸ kért maradékot. A pontos hiba és az utolsó iteráció paraméterei a `checks/background_failure_APR4_a1e-08_L10_tol2e-08.json` fájlban vannak; ezek nem elfogadott csillagparaméterek. A három másik a=10⁻⁸ állapot elfogadott; a negyedikhez nincs árapályérték. A `weak_coupling_attempts.csv` ezt üres Λ-mezővel jelöli.

A tesztelt numerikus burkok nem statisztikai hibák vagy szigorú felső korlátok. A végességi és lokális azonosságtesztek nem helyettesítik az integrált ellenőrzéseket; a tárolt futások mindkettőt tartalmazzák. A valódi sűrűségugrás, alkalmazott skalártide melletti fizikai válaszmátrix, bináris likelihood és dinamikai módusspektrum nem vizsgált.

© 2026 Szabolcsi Dávid · ORCID 0009-0005-6300-074X · CC BY-NC 4.0 International · https://creativecommons.org/licenses/by-nc/4.0/ · Kereskedelmi használat csak a szerző írásos engedélyével.
