# R4: adatkapu, portabilitás és reprodukció

A fizikai megoldó, mezőegyenletek, EOS, generált középponti képletek és a hat elsődleges állapot CSV-je bájtazonos az r3-mal. A h₄ leírt képletében az u₀ jelölés használata javult; az u₀ definíciója és a futó képlet változatlan. A hatállapotos R- és Λ-delta minden sorban 0, lásd `data/r3_r4_baseline_comparison.csv`.

Az r4-ben 70 izolált adat-/riportregresszió futott: 6 pozitív és 64 elutasítási eset, ebből 35 `python -O` alatt. A tiszta és a szerződésen belüli portabilitási fixture átment; a NaN Λ, Inf M_K, hibás/duplikált/hiányzó rács, véges hibás g/q/tömegtérkép/egység, hibás kontroll és a szerződésen kívüli r2 összevetés nemnulla kóddal megállt. A hibás builderes esetekben nem keletkezett új publikációs adat/ábra/jegyzet, és a státusz hamisra váltott. A pozitív portabilitási eset ellenőrzött adatperturbáció, nem itt lefuttatott másik Python-környezet.

Hat háttér és hat kapcsolt árapályválasz tárolt NPZ nélkül újrafutott. A saját r3-környezettel azonos környezetben a tárolt R és Λ értékekhez a reprodukció eltérése 0. Az archívum ellenőrzése ezt külön kibontott példányban ismétli, és utána a védett builder is fut. A hozzá tartozó jelentés a ZIP-en kívüli `delivery/archive_verification.json` fájlban van; nem körkörös manifesthivatkozás.

A 18-scriptes tudományos `run_all.py` az r4-ben nem futott újra. A 64 módosított, 18 GR- és 12 kötelező kiscsatolású kontroll örökölt r3-bizonyíték; az r4 ezek tényleges adatait is ellenőrzi publikálás előtt, de nem azonosítja ezt új fizikai validálással. A labor-G kalibráció feltételes. Az opcionális a=10⁻⁸ APR4/L=10 háttér elutasítása és a hozzá tartozó Λ hiánya megmaradt.

A történeti háttérhíd kiegészítése a szolgáltatott Academia AI numerikus beszámoló tulajdonított állítása. Nem szakmai lektorálás, és nyers kód/futásanyag híján itt nem személyesen ellenőrzött eredmény. Lásd `forrashid_beszamolo_HU.md`. EOS-elkülöníthetőségi, megfigyelési, stabilitási vagy elsőségi állítás nincs.

PDF nem készült; az ábrákat ugyanazon adatokból újrageneráltuk, a PNG/SVG fájlok olvashatóságát ellenőriztük.

© 2026 Szabolcsi Dávid
ORCID 0009-0005-6300-074X
CC BY-NC 4.0 International
https://creativecommons.org/licenses/by-nc/4.0/
Commercial use only with the author's written permission.
Third-party literature is cited, not relicensed.
