# Hatásalapú, kétcsatornás statikus árapályválasz — r3

## Hatás és a fizikai egységek szerződése

A források a `sources/binding_energy_EN.tex` (37–52. sor) és `sources/ns_yukawa_EN_r3.tex` (46–78. sor) változatlan pillanatképei. Az azonosított geometrizált hatás:

\[
S=\int d^4x\sqrt{-g}\left[\frac{R}{16\pi}-\frac{(\nabla\phi)^2+\mu^2\phi^2}{2a}-e^{-\phi}\epsilon(n)\right],\quad a=\alpha_Y,\quad\mu=L^{-1}.
\]

A megmaradó áram \(\nabla_\mu(nu^\mu)=0\); a sűrűség a g metrikához tartozik. A bare EOS nyomása \(p=n\epsilon_n-\epsilon\). A metrikus variáció a megmaradó áramot tartja rögzítve, nem a koordinátasűrűséget:
\(T^m_{\mu\nu}=f[(\epsilon+p)u_\mu u_\nu+pg_{\mu\nu}]\), \(f=e^{-\phi}\).
A skaláregyenlet \(\Box\phi-\mu^2\phi=-af\epsilon\). Ez sűrűségforrás, nem konformális nyomforrás. Az effektív nyomás fp, mert \(n\partial_n(f\epsilon)-f\epsilon=fp\).

A dimenziós munkadefiníció c=1 mellett a gravitációs és skalártagot egyaránt \(G_*^{-1}\)-gyel szorozza. Így \(\epsilon_{geom}=G_*\epsilon_{SI}/c^4\), és ugyanígy p. Az eredeti geometrizált hatás egymagában ezt a dimenziós helyreállítást és a laboratóriumi kísérletet nem rögzíti. A mostani számítás **feltételes, árnyékolatlan, kis önkötésű porpróba-kalibráció**:

\[
q=\frac{a}{4\pi},\qquad G_{pair}(d)=G_*[1+q(1+d/L)e^{-d/L}],\qquad
 d\ll L:\quad g=\frac{G_*}{G_{lab}}=\frac1{1+q}.
\]

A laborállandó az EOS-forrásban 6.67430×10⁻¹¹ SI. A kód a labor-G-vel geometrizált bare ε,p értékeket g-vel szorozza; az EOS h-ja és dp/dε értéke nem változik. a=1 esetén g=0.9262883177508389. Ez nem laboradat-illesztés.

A távoli, r≫L Kepler-tömeg szerződése:
\[
M_K=\frac{c^2m_\infty}{G_{lab}},\qquad M_A=\frac{c^2m_\infty}{G_*},\qquad M_K=gM_A.
\]
A cél minden modellben \(M_K=1.4M_\odot\), tehát \(m_\infty=G_{lab}(1.4M_\odot)/c^2\). a=1 mellett az ADM-tömegcél 1.511408460164327 M☉. A futásban c=299792458 m/s, M☉=1.988409870698051×10³⁰ kg, G_lab M☉/c²=1.476625038050125 km, így a geometriai tömegcél 2.067275053270175 km. Ezek az EOS-forrás tényleges állandói, nem a kézirat kerekített átváltási értékei. Nem a korábbi 1.4-es ADM-sort címkézzük át. A felszíni m(R) nem azonos m∞-nel.

A megjelölt `coupling_solver.py` és a kísérő auditfájlok nem voltak a hozzáférhető helyi anyagban. A nyolcesetes új teszt az analitikusan újraalkotott k-u jobb oldalt ellenőrzi, **nem** a hiányzó fájl implementációját. A térkép a=k, φ=k u, φ′=k v_legacy; a régi sqrt(k) kimeneti oszlop nem a hatás a paramétere. A hatáscsalád egyezése nem a korábbi történeti numerikus megoldó azonosságának igazolása. A ténylegesen elérhető r2 megoldót hat állapotban ismét integráltuk.

## Konzisztens folyadékperturbáció és kanonikus háttér

\(a=\zeta^2,\ \phi=\zeta\psi,\ \chi=\delta\phi=\zeta\eta\). A kanonikus hatás skalártagja \(-[(\nabla\psi)^2+\mu^2\psi^2]/2\), anyagcsatolása exp(−ζψ). Nincs inverz ζ a numerikus főoperátorban.

\[
B=1-2m/r,\quad A=e^{2\nu},\quad w=\psi',\quad
\rho_\psi=(Bw^2+\mu^2\psi^2)/2,\quad p_{r\psi}=(Bw^2-\mu^2\psi^2)/2,
\]
\[
m'=4\pi r^2(f\epsilon+\rho_\psi),\quad v=\nu'=\frac{m+4\pi r^3(fp+p_{r\psi})}{r^2B},\quad
h'=-v+\zeta w,
\]
\[
B w'+(2B/r+Bv+B'/2)w-\mu^2\psi=-\zeta f\epsilon.
\]

ζ=0-nál a GR-ágon ψ=w=0 pontosan. Nem tartunk meg nemnulla szabad skalárhátteret, amely saját stresszt adna. A skalármentes ágon az η próbacsatorna szétcsatolt; alkalmazott skalártide nélkül a kiválasztott megoldásban η=0. A lapse konstans időskála-eltolását ν∞=0 szerint lehet rögzíteni; a radiális főrendszer csak ν′-t használ, a válasz arányát ez nem módosítja.

Statikus, elektromos, páros paritású l=2, Regge–Wheeler-mérték:
\[
\delta g_{tt}=-AHY,\quad \delta g_{rr}=B^{-1}H_2Y,\quad
\delta g_{AB}=r^2KY\Omega_{AB},\quad \Delta_\Omega Y=-6Y.
\]
A nyommentes szögegyenlet ebben az előjelkonvencióban **H₂=−H**. A folyadék Euler-relációja
\[
\delta h=\zeta\eta-H/2,\quad \delta p=(\epsilon+p)(\zeta\eta-H/2),\quad
\delta\epsilon=(\epsilon+p)(\zeta\eta-H/2)/c_s^2.
\]
Itt c_s²=dp/dε, a bare EOS egyoldali deriváltja. A változatlan árammegmaradás a statikus ansatzban és \(\delta u^t=-u^tHY/2\) mellett fennáll.

## A′-vel nem osztó tt-redukció

A kovariáns generátor külön felépíti δΓ, δR, δG és az iménti folyadék- és skalárstressz variációját. Az eredmény hat redundáns radiális komponense a `notes/covariant_equations_r3.txt` fájlban található; azonosságukat a változatlan korábbi exporttal ismét ellenőriztük.

Az rθ kényszere és az rr rekonstrukciója:
\[
S=K'=-H'-2vH-16\pi w\eta,\quad K=F=f_HH'+g_HH+f_\eta\eta+g_\eta\eta',
\]
\[
f_H=-r^2Bv/2,\quad g_H=2\pi r^2f(\epsilon+3p)-r^2Bv^2-rBv-1-2\pi\mu^2r^2\psi^2,
\]
\[
f_\eta=-4\pi\zeta r^2f\epsilon+4\pi\mu^2r^2\psi-8\pi r^2Bvw-8\pi rBw,
\qquad g_\eta=-4\pi r^2Bw.
\]

A fő metrikus egyenletet nem dF/dr−S=0 H″-ra osztásával állítjuk elő. Az önálló tt Einstein-komponensben K=F, K′=S és
\(K''=-H''-2vH'-2v'H-16\pi(w'\eta+w\eta')\).
Az \(E_{tt}/(AY)\) így kapott H″-együtthatója **B**. A kód ezt egzakt szimbolikus azonosságként ellenőrzi. A főrendszer B-vel oszt, nem A′-vel; érvényességi tartománya r>0, A≠0, B≠0, az EOS megfelelő szakaszán c_s²>0.

A kifejtett tt-alak a következő kompakt egyenletpárral azonos (ezt is szimbolikusan ellenőriztük):
\[
H''=-P H'+U_HH+16\pi Q\eta,\qquad
\eta''=-P\eta'+QH+U_\eta\eta,
\]
\[
P=2/r+v+B'/(2B),
\]
\[
U_H=\frac6{r^2B}+4v^2-\frac{4\pi f}{B}\left(5\epsilon+9p+\frac{\epsilon+p}{c_s^2}\right)+\frac{8\pi\mu^2\psi^2}{B},
\]
\[
Q=-\frac{\mu^2\psi-\zeta f\epsilon-2Bvw-\zeta f(\epsilon+p)/(2c_s^2)}B,
\]
\[
U_\eta=\frac{6/r^2+\mu^2+\zeta^2f\epsilon-\zeta^2f(\epsilon+p)/c_s^2}{B}+16\pi w^2.
\]

A nyers generált együtthatók a `canonical_equations_generated.txt` fájlban vannak. Az azonosságok között a H–η keresztcsatolás 16π aránya és a közös elsőderivált-együttható is szerepel. A régi dF/dr−S=0 maradékot és az rr, rθ, szög Einstein-komponenseket nem hagytuk el az ellenőrzésből. Huszonnégy friss lokális mintán a két redukció H″-értékét hasonlítottuk össze; külön egzakt A′=0, pozitív p, B>0 lokális mintán minden kovariáns egyenletet ellenőriztünk. Ezek mellett négy integrált csillag reguláris oszlopain önálló numerikus differenciálással is maradékot mértünk. A lokális minták önmagukban nem csillagtesztek.

## Reguláris középpont — explicit negyedrendű indítás

Legyen f_c=exp(−ζψ_c), c_c=dp/dε|c (tehát nem a hangsebesség). A háttér együtthatói:
\[
m_3=\frac{4\pi}3(f_c\epsilon_c+\mu^2\psi_c^2/2),\quad
v_1=m_3+4\pi(f_cp_c-\mu^2\psi_c^2/2),\quad
\psi_2=(\mu^2\psi_c-\zeta f_c\epsilon_c)/6.
\]
A háttérhez \(m=m_3r^3+m_5r^5\), \(\psi=\psi_c+\psi_2r^2+\psi_4r^4\), \(h=h_c+h_{b2}r^2+h_{b4}r^4\) sorokat használunk a módosított BVP középponti feltételében. Az m₅, ψ₄ és h_b4 együtthatókat a kód `background_central` függvénye számolja a háttéregyenletekből.

A perturbációknál
\[
H=h_2r^2+h_4r^4+O(r^6),\quad\eta=s_2r^2+s_4r^4+O(r^6),\quad K=-h_2r^2+K_4r^4+O(r^6).
\]
A rövid explicit képlet:
\[
p_1=-v_1+2m_3,\quad
u_0=12m_3-4\pi f_c[5\epsilon_c+9p_c+(\epsilon_c+p_c)/c_c]+8\pi\mu^2\psi_c^2,
\]
\[
q_0=-\mu^2\psi_c+\zeta f_c\epsilon_c+\zeta f_c(\epsilon_c+p_c)/(2c_c),
\quad z_0=12m_3+\mu^2+\zeta^2f_c\epsilon_c-\zeta^2f_c(\epsilon_c+p_c)/c_c,
\]
\[
h_4=[(u_0+2p_1)h_2+16\pi q_0s_2]/14,\quad
s_4=[q_0h_2+(z_0+2p_1)s_2]/14,\quad
K_4=-h_4-v_1h_2/2-8\pi\psi_2s_2.
\]
A `central_series_generated.txt` kifejtett alakját egzakt határértékből képezzük, nem illesztjük csillageredményhez. A két vezető oszlop (h₂,s₂)=(1,0),(0,1); a futó integrálásban mindkettőt azonos R⁻² közös tényezővel szorozzuk, vagyis x=r/R egységben az egységnyi két oszlopot használjuk. Ez nem módosítja a reguláris alteret. A derivált- és csatornaegység a QR-ben diag(1,R,1,R); ezt a kondíciószámok értelmezéséhez is rögzítjük.

A számított h₄,s₄,K₄ értékek CSV-ben szerepelnek. Tizenkét oszlop harminchat numerikus sorhibája és a 0.01, 0.005, 0.0025 km kezdősugár-váltások külön kontrollok. A csak r²-es indítással is újrafuttattuk a válasz kiválasztását; ez kontroll, nem a közzétett indítás.

## EOS-darabhatárok és mozgó anyagfelszín

Az SLy/APR4 itt Read-féle szakaszos politrop illesztés, a mellékelt eredeti SLy-kéreggel. p és ε folytonos; c_s² ugrik. Az integrálás minden tényleges h-határnál megáll és az adott szakasz egyoldali c_s² értékével folytatódik. H,H′,η,η′ itt folytonos. A `eos_junction_controls.csv` a két EOS darabillesztéseit ellenőrzi.

A felszíni feltétel \(\Delta h=\zeta\eta-H/2+\xi^rh'=0\):
\[
\xi^r=(H/2-\zeta\eta)/h'.
\]
A megzavart, elmozdult felszínen nincs anyaghéj vagy skalárfelülettöltés. A numerikus p→0 határhoz használt véges h_s küszöbnél az eltűnő ε felszíni tagjának korrekciója:
\[
[H']=8\pi f\epsilon_s\xi^r/B,\quad [\eta']=-\zeta f\epsilon_s\xi^r/B,
\quad [H]=[\eta]=0.
\]
A [ ] kívül mínusz belül. A h_s=10⁻¹⁰ és 10⁻⁸ váltást ténylegesen lefuttattuk. A nemnulla küszöb maradó p_s hibája numerikus truncálási hiba, nem fizikai héjmodell. Valódi elsőrendű, véges sűrűségugrásos fázisátmenet egyik választott EOS-ban sincs; ilyen átmenet általános illesztését ez a pilot nem validálja.

## Kapcsolt vákuum és alkalmazott amplitúdómátrix

Az anyagfelszínen a háttérskalárt nem nullázzuk. A vákuum ε=p=0, de ψ,w,m(r) és a két perturbáció csatolása megmarad R és r_b között. A homogén Schwarzschild-skaláregyenlet csak a külső amplitúdók referenciaegyenlete; nem helyettesíti a csatolt vákuumot.

A már elhanyagolható skalárháttér határában a pontos tenzorbázis:
\[
T_H=r(r-2M),\quad T_Q=\frac{5}{8M^3}Q_2^2(r/M-1),\quad
Q_2^2(x)=(x^2-1)Q_2''(x),\quad M=m_\infty.
\]
A kód T_Q-t a vele azonos \(B r^{-3}{}_2F_1(3,5;6;2M/r)\) alakban számolja. A Wronskián −5/(r²B). A nagy pontosságú Legendre-referenciát, a differenciálmaradékot, valamint az ismert és nulla λ-jú szintetikus állapotokat külön ellenőriztük. A puszta r²,r⁻³ illesztés tiszta Schwarzschild alkalmazott tide esetén is hamis választ ad; ezt csak negatív kontrollként használjuk.

Numerikus tenzorkoordináták: \(H=aT_H/R^2+bR^3T_Q\). Ezért \(a_H=a/R^2\), \(b_H=bR^3\). A skalárcsatorna kanonikus η. A csökkenő skalárreferencia η_D a Schwarzschild l=2 egyenletből készül Riccati-integrálással, η_D(R)=1 normával; a távoli indítást R+60L és R+80L között változtattuk. A növekvő referencia η_G ugyanennek az egyenletnek η_G(R)=0, η_G′(R)=1/R kezdetű megoldása. Ez rögzíti az amplitúdóegységet, nem a módosított csillag R-nél feltételezett skalármentességét.

A véges külső skála r_b=R+nL; az alapérték n=12, a kontrollok 8,10,14. A háttér BVP n_bg=20 és 24 tartományt használ. Az r_b pontban három megengedett referenciaoszlop:

* tenzor alkalmazott: (a,b,η,η′)=(1,0,0,0);
* tenzor válasz: (0,1,0,0);
* csökkenő skalár: (0,0,η_D,η_D′).

Mindhárom oszlopot a **csatolt** vákuumegyenlettel visszük R-ig. A tenzoroszlopok az integrálás során skalárpartikulárist kapnak; a CSV ezt az R-beli η értékkel is dokumentálja. Nem csupán i₂/k₂ illesztést végzünk.

Az alkalmazott tenzoramplitúdó a(r_b). Az alkalmazott skaláramplitúdó funkcionálja
\[
a_s=\frac{\eta'-\kappa_D\eta}{(\kappa_G-\kappa_D)\eta_G(r_b)},\quad\kappa_{D,G}=\eta'_{D,G}/\eta_{D,G}.
\]
Az amplitúdófunkcionálokat duális propagálással, \(\ell'=-\ell\mathsf M\) egyenlettel visszük R-ig; \(\mathsf M\) a kapcsolt vákuum elsőrendű transzportja. A két belső reguláris oszlophoz tartozó alkalmazott amplitúdók alkotják a valódi 2×2 **𝔄** mátrixot. Megoldjuk \(\mathsf A c=(1,0)^T\)-t. Előre rögzített kapu: rang 2 és kondíciószám <10¹⁰ az előbb megadott egységekkel. Az elemek, szinguláris értékek és kondíciószám minden futási sorban szerepelnek. Ez nem a Dirichlet–Neumann U mátrixának invertálhatósága.

A kiválasztott állapotból külön meghatározzuk b-t és a csökkenő skalár együtthatóját. Az eredményt a megengedett oszlopokkal végzett önálló, normált 4×4 illesztéssel is összevetjük. A duális funkcionáloknak a három megengedett oszlopon (1,0,0), illetve (0,0,0) értéket kell adniuk; ennek hibáját szintén mérjük.

Ez r_b-n rögzített, majd r_b-váltással ellenőrzött **tenzor-only** definíció. A tenzor által gerjesztett skalár engedett, a független alkalmazott skalár nulla. A partikuláris skalár r_b-n zérus kezdetének csekély, véges külső határhibáját nem nevezzük pontos végtelenbeli eredménynek: a n-váltások mért burka szerepel a számok mellett. A globálisan exponenciálisan növekvő masszív skalárt nem folytatjuk izolált, aszimptotikusan sík térként a végtelenig. Tényleges külső forráshoz megfelelő lokális pufferzóna és társtávolság szükséges; társat és bináris hullámformát most nem modellezünk.

Általános, skalártidével is alkalmazott kétcsatornás vizsgálatban az alkalmazott amplitúdókat és a válaszamplitúdókat külön A és B mátrix mérné ki, és b=B A⁻¹ a adná az amplitúdóválaszt. A fizikai kevert elemekhez mindkét forrás és multipólus egységeit is rögzíteni kell. Ebben a pilotban ennek tenzor-only oszlopát számoljuk; **nem** közlünk fizikailag kalibrált vegyes Love-mátrixot vagy önálló, univerzális skalár Love-számot.

## A közölt mennyiségek

Az aszimptotikusan időnormált, tömegközéppontos konvenció:
\[
g_{tt}=-1+2M/r-\mathcal E_{ij}x^ix^j+3\mathcal Q_{ij}n^in^j/r^3+\cdots,
\quad\mathcal Q_{ij}=-\lambda^{geom}_{TT}\mathcal E_{ij}.
\]
A negatív δg_tt mellett ebből
\[
\lambda^{geom}_{TT}=\frac{b_H}{3a_H}=\frac{b}{3a}R^5,\quad
\Lambda_K^{metric}=\lambda^{geom}_{TT}/m_\infty^5,\quad
R_g=\sqrt{\mathrm{Area}_g/(4\pi)}.
\]
A jelentett k₂=3λ/(2R⁵) csupán ugyanezen válasz átnormálása. **Módosított háttérre nem értékelünk GR Love-képletet.** A GR képlet kizárólag a külön GR-benchmarkban fut; a kód ezt őrfeltétellel is védi.

Λ_K^metric nem automatikusan egy GR-hullámforma likelihoodjának Λ paramétere. A λ_phys=λ_geom/G_* és λ_K=λ_geom/G_lab eltérő tömegkvadrupólus-konvenciókhoz tartozik. A felszíni anyagi órák/rudak modelljét nem rögzítettük, ezért R_g metrikus sugárdiagnosztika. Megfigyelési kizárás, dinamikai stabilitás és EOS-től való elkülöníthetőség nem következik ebből a két-EOS statikus pilotból.

## Reprodukció és ellenőrzések értelmezése

A `code/run_all.py` a hat elsődleges állapotot és a tényleges kontrollokat futtatja; a naplók és kilépési kódok a `checks/` alatt vannak. A `code/reproduce_pilot.py` hat hátteret és választ épít újra, tárolt hátterek használata nélkül. A generált egyenletfájlok saját újraalkotások; nem a felhasználói javaslatban említett, de nem átadott auditmellékletek.

A numerikus burkok tesztelt beállítások közötti eltérések, nem szigorú hibakorlátok, statisztikai konfidenciaintervallumok vagy fizikai modellhibák. A további a=10⁻⁸ stresszteszt elfogadott és elutasított háttereit külön kezeljük; elutasított háttérhez nincs Λ. A szükséges a=0.01,0.001,0.0001 sorozatoktól ez elkülönített diagnosztika. A mennyiségi státuszt az `ellenorzesi_osszefoglalo_HU.md`, a rövid döntést a `dontesi_jegyzet_HU.md` adja.


© 2026 Szabolcsi Dávid · ORCID 0009-0005-6300-074X · CC BY-NC 4.0 International · https://creativecommons.org/licenses/by-nc/4.0/ · Kereskedelmi használat csak a szerző írásos engedélyével.
