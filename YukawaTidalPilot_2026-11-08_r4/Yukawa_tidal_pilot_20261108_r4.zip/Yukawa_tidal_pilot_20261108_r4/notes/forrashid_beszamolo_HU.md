# Tulajdonított történeti háttérhíd-beszámoló

Forrás: a felhasználó által szolgáltatott Academia AI numerikus beszámoló, `sources/r3_audit_supplied_20261108.md`, SHA256 ecac5b01873c86e2756ccd22d2627965ff2a46f1cc47d417e4ebd0b3ff087255. Ez AI-segített műszaki beszámoló, nem szakmai lektorálás. Az alábbi állításokat itt nem futtattuk újra, és nem nevezzük saját, független ellenőrzésnek.

A beszámoló a `coupling_solver.py` verzióját a 8e1f370db232d71d8813054f011c84db47ab6d1d2acfbcb03f5fc0c3e9533f32 SHA256 értékkel azonosítja. Négy a=1 háttérre tényleges BVP-megoldást jelent: r3-központi sűrűséggel és r3-alapú kezdőbecsléssel, ugyanazzal a SciPy-kollokációval. Jelentett maximumok: |ΔR|=4.725×10⁻⁹ km és |ΔM_K|=8.493×10⁻¹² M☉; jelentése szerint mind a négy háttér a kért 2×10⁻⁸ maradékon belül konvergált. A térkép a=k, φ=k u, ε=g ε_lab, p=g p_lab, M_K=g M_A.

Nem történt benne önálló történeti tömeggyök-keresés; nem független árapály-megoldó, létezési vagy egyértelműségi bizonyítás. Az itt kapott anyag csak Markdown: a hivatkozott kód, nyers futásanyag, `r3_output_guard.py`, `r3_javitasok_HU.md` és az ott említett evidence könyvtár nincs átadva. Az új r4 őrfeltételeket ezért önállóan írtuk meg. A történeti kód forrását és a beszámoló nyers numerikus bizonyítékát nem állítjuk helyben elérhetőnek vagy személyesen ellenőrzöttnek.

Az r3 korábbi helyi forráshiány-megállapítása továbbra is a készítő akkori környezetére vonatkozik. A szolgáltatott beszámoló ennek külön tulajdonított, verzióazonosított kiegészítése. EOS-függetlenségi, megfigyelési, stabilitási vagy elsőségi következtetés nincs.

© 2026 Szabolcsi Dávid
ORCID 0009-0005-6300-074X
CC BY-NC 4.0 International
https://creativecommons.org/licenses/by-nc/4.0/
Commercial use only with the author's written permission.
Third-party literature is cited, not relicensed.
