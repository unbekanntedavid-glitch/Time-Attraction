# Döntési jegyzet — r4

Az r3-ban a hat elsődleges állapot újra lett integrálva a hatásalapú, A′-vel nem osztó tt-egyenlettel, kanonikus skalárral, negyedrendű középponti sorral és explicit alkalmazott amplitúdómátrixszal. Minden állapotban M_K=1.4 M☉; a=1 esetén G_*/G_lab=0.9262883177508389 és M_A=1.511408460164327 M☉. A feltételes porpróba-kalibráció nem mérésillesztés.

| EOS | alphaY | L_km | R_g_km | Lambda_metric |
| --- | --- | --- | --- | --- |
| APR4 | 0.0 | 0.0 | 11.319724 | 247.609914 |
| APR4 | 1.0 | 1.0 | 11.759346 | 313.440900 |
| APR4 | 1.0 | 10.0 | 11.625081 | 287.455163 |
| SLy | 0.0 | 0.0 | 11.706102 | 295.630690 |
| SLy | 1.0 | 1.0 | 12.181915 | 378.658368 |
| SLy | 1.0 | 10.0 | 12.015736 | 341.284927 |

Az átvett r3 futásanyagban a szükséges pilotkapuk megfeleltek: 64 módosított és 18 GR-kontrollsor, 12 kiscsatolású állapot. A GR-benchmark legnagyobb relatív eltérése 2.23e-10; a tesztelt relatív Λ-burok maximuma 2.48e-07. A r2-hez mért legnagyobb |ΔΛ| 8.45e-08, relatíve 2.23e-10; |ΔR| maximuma 0 km. A CSV több számjegye a reprodukciót szolgálja, nem ekkora fizikai pontosságot.

**Korlátok:** a megjelölt korábbi `coupling_solver.py` nem volt helyben elérhető, ezért ahhoz forráskódszintű híd nincs igazolva. Nyolc analitikus térképkontroll és az elérhető r2 hat friss számítása áll rendelkezésre. A további a=10⁻⁸ stresszteszt három állapotban elfogadott hátteret adott; APR4, L=10 km esetén a kollokációs csomópontkorlát miatt a háttér elutasítva, Λ nincs közölve. Ez nem a hat elsődleges állapot vagy a kötelező a≥10⁻⁴ kontroll sikertelensége.

**Döntés:** feltételes R–Λ eltolódás számszerűen vizsgálható, de két EOS alapján az EOS-hatástól való elkülöníthetőség nem dönthető el. A következő fizikai fázis szélesebb, közös kauzális tartományú EOS-minta és megfelelő külső forrás-/hullámformamodell. Az elutasított szélső kiscsatolású eset háttérhálóját és EOS-illesztéseit külön kell diagnosztizálni; az EOS-határhoz igazított kollokáció lehetséges, még nem tesztelt javítási irány. Megfigyelési likelihood, dinamikai stabilitás vagy újdonságvizsgálat nem készült; ezekre nincs állítás.

© 2026 Szabolcsi Dávid · ORCID 0009-0005-6300-074X · CC BY-NC 4.0 International · https://creativecommons.org/licenses/by-nc/4.0/ · Kereskedelmi használat csak a szerző írásos engedélyével.

R4: mezőegyenlet, EOS és tudományos főadatsor nem változott. Az r2 portabilitási szerződés nem fizikai hibabecslés. A történeti háttérhíd új, szolgáltatott Academia AI beszámolóját külön, tulajdonított forrásként kezeljük; nem szakmai lektorálás, és itt nem futtatott kód bizonyítéka. Lásd `forrashid_beszamolo_HU.md`.
