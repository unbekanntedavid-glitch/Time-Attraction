# Yukawa árapály-pilot r4 — fájlcsomag

Hatásalapú statikus l=2 metrikus–skalár–fluid számítás. SLy/APR4, azonos távoli Kepler-tömeg: M_K=1.4 M☉; GR és a=1, L=1/10 km. A labor-G kalibráció feltételes, árnyékolatlan porpróba-határ. Ez nem megfigyelési vagy stabilitási elemzés.

## Olvasási sorrend

1. `notes/dontesi_jegyzet_HU.md`: rövid státusz, számok és korlátok.
2. `notes/levezetes_HU.md`: hatás, variáció, tt-redukció, középpont, felszín és külső amplitúdók.
3. `notes/ellenorzesi_osszefoglalo_HU.md`: ténylegesen futtatott mennyiségi kontrollok.
4. `data/pilot_results.csv`, `data/r2_r3_changes.csv`, `figures/`: adatok és ábrák.

## Újrafuttatás

Python 3.13 és a `requirements.txt` szerinti környezet mellett, a csomag gyökeréből:

```bash
OPENBLAS_NUM_THREADS=1 python3 code/run_all.py
OPENBLAS_NUM_THREADS=1 python3 code/reproduce_pilot.py
python3 code/build_outputs.py
```

A fő futtatás saját `data/`, `checks/` és `notes/` fájljait újragenerálja. Meglévő kutatási archívumot nem módosít. A származási csomagok külső elérhetősége nélkül az inputellenőrző a mellékelt pillanatképek hashét ellenőrzi; a nem elérhető korábbi ZIP-eket nem állítja ellenőrzöttnek.

Az `a=10^-8` opcionális háttérdiagnosztikában elutasítás is szerepelhet; ez nem kerül át Λ-adattá. Az elsődleges hat állapot és a kötelező 0.01/0.001/0.0001 csatolási kontroll ettől külön van. A hiányzó történeti `coupling_solver.py` helyett nem állítunk forráskód-azonosságot: önálló analitikus térkép és az elérhető r2 megoldó ismétlése szerepel.

A `stellar_tal_v21.py` forrásból csak az EOS osztályt és az egységállandókat használjuk; a régi TAL/top-hat szerkezeti, megfigyelési és stabilitási rutinokat nem hívjuk. A `sources/` változatlan bemeneti pillanatképeket tartalmaz, nem önállóan fordítható régi kéziratcsomagot. A felhasználói javaslat eredeti másolata változatlan. A generált r3 képletek a saját kódból származnak.

## Integritás

A `MANIFEST.json` minden csomagolt adattartalom relatív útját, méretét és SHA256 értékét tartalmazza, saját magát és a ZIP-et nem. A ZIP és a manifest SHA256 értéke a csomagon kívüli `delivery/handoff.json` fájlban szerepel. A kicsomagoláskor útvonalbiztonsági, CRC- és minden payload-fájlra hash-ellenőrzés történik. A külső archívum-ellenőrző jelentés szintén a `delivery/` könyvtárban marad; ezzel nincs körkörös hashfüggés.

PDF nem készült. A Markdown-levezetés, CSV, forráskód, PNG és SVG ábrák a csomag részei.

© 2026 Szabolcsi Dávid · ORCID 0009-0005-6300-074X · CC BY-NC 4.0 International · https://creativecommons.org/licenses/by-nc/4.0/ · Kereskedelmi használat csak a szerző írásos engedélyével.

## R4 munkahatár és adatminőségi szerződés

A fizikai megoldó, mezőegyenletek, EOS és a hat elsődleges számsor változatlan. A 64 módosított, 18 GR- és 12 kötelező kiscsatolású kontroll az r3 átvett bizonyítéka; az r4 nem ismétli a 18-scriptes `run_all.py` futást. Az r4 a publikációs bemeneteket ellenőrzi, pozitív és hibásbemenet-regressziókat futtat normál Python és `python -O` alatt, továbbá hat hátteret és választ épít újra tárolt NPZ nélkül, majd izolált archívummásolatból riportot épít.

A `code/output_guard.py` önálló megvalósítás, nem az auditban említett, át nem adott kód. Az eredeti audit pillanatképe és a történeti háttérhíd tulajdonított Academia AI beszámolója külön forrás. Ez AI-segített technikai audit, nem szakmai lektorálás (peer review); a történeti kód és a nyers bizonyíték nincs helyben személyesen ellenőrizve.

A hat állapot rácsa, egyedisége, kötelező numerikus végessége, egységei, q–a–g kalibrációja, ADM–Kepler térképe és az összefoglalóhoz használt kontrollok tényleges értékei a státusz és publikációs fájlok írása előtt ellenőrződnek. Kivétel kizárólag a név szerint megadott GR-metaadatok üres mezője, az A′=0 helyen nem értékelt régi redukció, illetve a karanténba tett opcionális háttér Λ=null értéke. NaN Λ vagy Inf tömeg soha nem kivétel. Hibánál a státusz hamis, a folyamat nemnulla kóddal áll meg. A védelmi ellenőrzések nem `assert`-re épülnek.

A főállapotok M_K-céljának bemeneti kapuja 10⁻⁸ M☉. Az eleve lazább háttértoleranciával futtatott GR-kontrollhoz külön 10⁻⁷ M☉ adatellenőrzés tartozik; az átvett kontrollban mért legnagyobb tömegeltérés 1.0224×10⁻⁸ M☉. Ez nem integrátortolerancia- vagy fizikai pontosságmódosítás.

Az r2 környezetközi összevetés szerződése: Λ `np.isclose(rtol=1e-8,atol=1e-9)`, R `np.isclose(rtol=0,atol=1e-7 km)`, előzetes végességi ellenőrzéssel. Ez portabilitási elfogadás, nem a fizikai hibaburok vagy a numerikus integrálási toleranciák átállítása.

```bash
python3 code/test_publication_guards.py
python3 code/reproduce_pilot.py
python3 code/build_outputs.py
python3 code/package_pilot.py
python3 code/verify_package.py
```

A részletes, tételes javítási válasz a ZIP-en kívüli `internal/r4_audit_response_HU.md`; a kutatási archívumban tudományos módszer-, státusz- és forrásleírás szerepel. PDF nem készült.
