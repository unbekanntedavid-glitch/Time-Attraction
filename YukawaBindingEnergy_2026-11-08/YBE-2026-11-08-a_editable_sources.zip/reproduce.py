#!/usr/bin/env python3
"""Self-contained checked-data and numerical reproduction entry point.
No input is fetched from the network. No pickle cache is read by checks/controls.
The equilibrium equations and EOS are the unchanged supplied production files.
"""
from pathlib import Path
import argparse,sys,json,hashlib,os,shutil,subprocess,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');ap.add_argument('--controls',action='store_true');ap.add_argument('--figures',action='store_true');ap.add_argument('--regenerate',action='store_true');ap.add_argument('--archived-peak-validator',action='store_true');ap.add_argument('--out',type=Path,default=ROOT/'run');args=ap.parse_args()
OUT=args.out.resolve()
if OUT == ROOT or any(OUT == ROOT/x or ROOT/x in OUT.parents for x in ['data','code','metadata','manuscript','figures','validation']):
 raise ValueError('Output must not overwrite source/input directories')
OUT.mkdir(parents=True,exist_ok=True)

def fail(ok,msg):
 if not bool(ok):raise ValueError(msg)
def write(name,x):
 (OUT/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
prov=json.loads((ROOT/'metadata/provenance.json').read_text())
fail('required_inputs' in prov,'Missing provenance inputs')
for item in prov['required_inputs']:
 fail(set(['path','bytes','sha256'])<=set(item),'Missing fingerprint key')
 rp=Path(item['path']);fail(not rp.is_absolute() and '..' not in rp.parts,'Unsafe input path')
 f=ROOT/rp;fail(f.is_file(),'Missing input: '+str(rp));fail(f.stat().st_size==item['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==item['sha256'],'Input integrity: '+str(rp))
if args.regenerate or args.archived_peak_validator:
 work=OUT/('sequence_run' if args.regenerate else 'archived_peak_validator')
 fail(not work.exists(),'Refusing to overwrite an existing simulation directory')
 shutil.copytree(ROOT/'code',work)
 if args.archived_peak_validator:
  for f in (ROOT/'data').iterdir():
   if f.is_file():shutil.copyfile(f,work/f.name)
 tmp=work/'isolated_tmp';tmp.mkdir();env=os.environ.copy();env.update(TMPDIR=str(tmp),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 target=work/('binding_sequences.py' if args.regenerate else 'verify_results.py')
 subprocess.run([sys.executable,str(target)],cwd=work,env=env,check=True)
 print(work);sys.exit(0)
if args.figures:
 subprocess.run([sys.executable,str(ROOT/'code/make_figures.py')],cwd=ROOT,check=True)
# Isolate the harmless import-time temporary cache directory. No cache is loaded.
tmp=OUT/'tmp';tmp.mkdir(exist_ok=True);os.environ['TMPDIR']=str(tmp)
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.optimize import brentq
sys.path.insert(0,str(ROOT/'code'));import binding_sequences as b

def need(df,cols,name):
 fail(set(cols)<=set(df.columns),'Missing column in '+name)
 fail(np.isfinite(df[cols].to_numpy(dtype=float)).all(),'Nonfinite physical quantity in '+name)
s=pd.read_csv(ROOT/'data/equilibrium_sequences.csv');c=pd.read_csv(ROOT/'data/comparisons.csv');su=pd.read_csv(ROOT/'data/sequence_summary.csv');cv=pd.read_csv(ROOT/'data/convergence.csv')
need(s,['logrho','L_km','R_km','M_ADM_Msun','mR_Msun','tail_Msun','MB_Msun','Ebind_1e51erg','cs2max'],'sequences')
need(c,['L_km','target_Msun','delta_Ebind_1e51erg','delta_MB_Msun','delta_ADM_Msun','numerical_sensitivity_1e51erg'],'comparisons')
need(su,['L_km','logrho_peak','logrho_candidate_supremum','candidate_supremum_ADM_Msun','candidate_supremum_MB_Msun'],'limits')
need(cv,['L_km','logrho','delta_ADM_Msun','delta_MB_Msun','delta_R_km','delta_Ebind_1e51erg'],'controls')
fail(len(s)==1391 and len(c)==24 and len(su)==9 and len(cv)==114,'Dataset counts')
fail(s[s.grid_point].groupby(['EOS','L_km']).size().eq(89).all(),'89-point grids required')
mbudget=float(abs(s.M_ADM_Msun-s.mR_Msun-s.tail_Msun).max());eidentity=float(abs(s.Ebind_1e51erg-(s.MB_Msun-s.M_ADM_Msun)*b.EUNIT).max())
fail(mbudget<1e-14 and eidentity<1e-9,'Mass/energy identity')
eoschecks=[];maxcsdiff=0.
for name,group in s.groupby('EOS'):
 fail(name in ['SLy','APR4','H4'],'Unknown EOS');e=b.st.EOS(name)
 rho=np.geomspace(1e4,10**15.7,4001);ii=np.searchsorted(e.b,rho);g,k,a=e.g[ii],e.k[ii],e.a[ii];pp=k*rho**g;ee=(1+a)*rho+pp/(g-1)
 analytic=float(np.max(abs(rho*((1+a)+g*pp/((g-1)*rho))-ee-pp)/(ee+pp)))
 keep=np.min(abs(np.log(rho[:,None]/e.b[None,:])),axis=1)>1e-4;h=e.h_of_rho(rho[keep]);dt=1e-5
 up,_,ru,_=e.at(h*np.exp(dt));dn,_,rd,_=e.at(h*np.exp(-dt));en,pr,rr,_=e.at(h)
 fd=float(np.max(abs(rr*(up-dn)/(ru-rd)-(en+pr))/(en+pr)));fail(analytic<1e-12 and fd<1e-7,'EOS first law')
 eoschecks.append(dict(EOS=name,analytic_firstlaw_relative=analytic,native_enthalpy_derivative_relative=fd))
 for r in group.itertuples():
  cs=b.csmax(e,float(e.h_of_rho(10**r.logrho)));maxcsdiff=max(maxcsdiff,abs(cs-r.cs2max));fail(abs(cs-r.cs2max)<1e-8 and (cs<=1+1e-10)==r.causal,'Causality flag')
 for lim in su[su.EOS==name].itertuples():
  onset=brentq(lambda z:float(e.h_of_rho(10**z)-e.h_causal()),5,16.5)
  fail(abs(lim.logrho_candidate_supremum-min(onset,lim.logrho_peak))<1e-8,'Causal endpoint rule')
maxroot=0.;maxpaircs=0.
for r in c.itertuples():
 gs=su[(su.EOS==r.EOS)&(su.L_km==0)].iloc[0];ys=su[(su.EOS==r.EOS)&(su.L_km==r.L_km)].iloc[0]
 fail(r.match_key in ['MB_Msun','M_ADM_Msun'],'Invalid mass matching key')
 if r.contrast=='common_ADM_1p4':expected=1.4
 elif r.contrast=='common_MB_GR1p4':expected=c[(c.EOS==r.EOS)&(c.contrast=='common_ADM_1p4')].iloc[0].GR_MB_Msun
 elif r.contrast=='common_ADM_near_limit':expected=.99*min(gs.candidate_supremum_ADM_Msun,ys.candidate_supremum_ADM_Msun)
 elif r.contrast=='common_MB_near_limit':expected=.99*min(gs.candidate_supremum_MB_Msun,ys.candidate_supremum_MB_Msun)
 else:raise ValueError('Unknown contrast')
 fail(abs(expected-r.target_Msun)<1e-10,'Target rule')
 for prefix,lim in [('GR',gs),('II',ys)]:
  z=getattr(r,prefix+'_logrho');cs=getattr(r,prefix+'_cs2max');maxpaircs=max(maxpaircs,cs)
  fail(z<lim.logrho_candidate_supremum and cs<=1+1e-10,'Causal first-rising match')
  residual=abs(getattr(r,prefix+'_'+r.match_key)-r.target_Msun);maxroot=max(maxroot,residual);fail(residual<2e-9,'Mass root')
 fail(abs(r.delta_Ebind_1e51erg-(r.II_Ebind_1e51erg-r.GR_Ebind_1e51erg))<1e-9,'Energy contrast')
negative=[]
for label,df,cols in [('missing',pd.DataFrame({'x':[1.]}),['y']),('NaN',pd.DataFrame({'x':[np.nan]}),['x']),('infinity',pd.DataFrame({'x':[np.inf]}),['x'])]:
 try:need(df,cols,'negative control')
 except ValueError:negative.append(label)
 else:raise AssertionError('Unrejected invalid input')
checkreport=dict(status='checks_passed',n_configurations=len(s),n_pairs=len(c),n_archived_controls=len(cv),mass_budget_identity_max_Msun=mbudget,energy_identity_max_1e51erg=eidentity,EOS_firstlaw=eoschecks,all_1391_causality_flags_recomputed=True,max_cs2_table_difference=maxcsdiff,max_pair_cs2=maxpaircs,max_mass_target_residual_Msun=maxroot,negative_controls_rejected=negative,peak_fits='Archived peak-fit outputs are included; they are not re-fitted by --check or --controls.',interpretation='Numerical consistency and reproduction, not independent physical validation or dynamical stability.')
write('data_check.json',checkreport)
if args.controls:
 t=time.time();cache={};rows=[];integrals=[]
 def base(name,L,lr):
  key=(name,L,round(lr,11))
  if key not in cache:cache[key]=b.gr(b.st.EOS(name),lr) if not L else b.ii(b.st.EOS(name),lr,L)
  return cache[key]
 for j,r in enumerate(cv.itertuples()):
  rr,sol=base(r.EOS,r.L_km,r.logrho)
  if not r.L_km:ff,_=b.gr(b.st.EOS(r.EOS),r.logrho,2e-13)
  else:
   tail={'short_domain':12.,'long_domain':24.}.get(r.test,18.);tol=5e-8 if r.test in ['tight_tol','endpoint_tight'] else 2e-7
   ff,_=b.ii(b.st.EOS(r.EOS),r.logrho,r.L_km,sol,tail,tol)
  for result in [rr,ff]:
   fail(all(k in result and np.isfinite(result[k]) for k in ['M_ADM_Msun','MB_Msun','R_km','Ebind_1e51erg','tail_Msun','cs2max']),'Missing/nonfinite recomputed quantity')
  rec=dict(EOS=r.EOS,L_km=r.L_km,logrho=r.logrho,test=r.test,contrast=r.contrast,contrast_L_km=r.contrast_L_km)
  for k,dk in [('M_ADM_Msun','delta_ADM_Msun'),('MB_Msun','delta_MB_Msun'),('R_km','delta_R_km'),('Ebind_1e51erg','delta_Ebind_1e51erg')]:
   rec[dk]=ff[k]-rr[k];rec['difference_from_archive_'+dk]=rec[dk]-getattr(r,dk)
  fail(abs(rec['difference_from_archive_delta_ADM_Msun'])<1e-8,'Control reproduction')
  rows.append(rec)
  if (j+1)%12==0:print('Control rows',j+1,'/',len(cv),flush=True)
 for (name,L,lr),(rr,sol) in cache.items():
  if not L:continue
  R=sol.p[0];T=sol.T
  def f(x):
   y=sol.sol(x);r=R+T*x;B=1-2*y[5]/r
   return 4*np.pi*r*r*(B*y[8]**2+y[7]**2/L**2)/2*T/b.GM
  val,err=quad(f,0,1,epsabs=1e-12,epsrel=1e-10,limit=200)
  xx=np.linspace(0,1,2001);yy=sol.sol(xx);ri=sol.r0+(R-sol.r0)*xx;re=R+T*xx
  Bmin=float(min(np.min(1-2*yy[0]/ri),np.min(1-2*yy[5]/re)));fail(Bmin>0 and np.isfinite(yy).all(),'Metric/nonfinite failure')
  integrals.append(dict(EOS=name,L_km=L,logrho=lr,exterior_integral_minus_mass_difference_Msun=val-rr['tail_Msun'],min_metric_B=Bmin))
 df=pd.DataFrame(rows);df.to_csv(OUT/'reproduced_controls.csv',index=False);pd.DataFrame(integrals).to_csv(OUT/'exterior_integrals.csv',index=False)
 write('control_check.json',dict(status='controls_reproduced',n_rows=len(df),n_unique_baselines=len(cache),elapsed_seconds=time.time()-t,max_difference_from_archive_ADM_Msun=float(df.difference_from_archive_delta_ADM_Msun.abs().max()),maxima_by_test={key:{k:float(g[k].abs().max()) for k in ['delta_ADM_Msun','delta_MB_Msun','delta_Ebind_1e51erg']} for key,g in df.groupby('test')},max_exterior_integral_discrepancy_Msun=float(pd.DataFrame(integrals).exterior_integral_minus_mass_difference_Msun.abs().max()),method_status='Re-execution of supplied collocation algorithm, not a distinct physical validation method.'))
print(json.dumps(checkreport,indent=2),flush=True)
