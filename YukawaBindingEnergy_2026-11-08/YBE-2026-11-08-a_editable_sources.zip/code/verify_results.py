#!/usr/bin/env python3
"""Independent identities, branch guards, input comparisons and resolution checks.
Run after binding_sequences.py, from the workspace root. Prior-output comparisons
are optional when the bundle is run elsewhere; all internal checks always run.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from numpy.polynomial.legendre import leggauss
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P));import binding_sequences as b
s=pd.read_csv(P/'equilibrium_sequences.csv');c=pd.read_csv(P/'comparisons.csv');su=pd.read_csv(P/'sequence_summary.csv')
checks={}
checks['sequence_count']=len(s.groupby(['EOS','L_km']))
checks['grid_points_per_sequence']=s[s.grid_point].groupby(['EOS','L_km']).size().tolist()
assert checks['sequence_count']==9 and set(checks['grid_points_per_sequence'])=={89}
checks['mass_budget_max_Msun']=float(abs(s.M_ADM_Msun-s.mR_Msun-s.tail_Msun).max())
checks['energy_identity_max_1e51erg']=float(abs(s.Ebind_1e51erg-(s.MB_Msun-s.M_ADM_Msun)*b.EUNIT).max())
assert checks['mass_budget_max_Msun']<1e-14 and checks['energy_identity_max_1e51erg']<1e-10
assert (c.GR_causal & c.II_causal).all()
checks['all_24_pairs_causal']=True
for row in c.itertuples():
 for model,L in [('GR',0.),('II',row.L_km)]:
  lim=su[(su.EOS==row.EOS)&(su.L_km==L)].iloc[0]
  assert getattr(row,model+'_logrho')<lim.logrho_candidate_supremum
checks['all_pairs_same_first_rising_candidate_branch']=True
checks['max_root_mass_residual_Msun']=float(pd.read_csv(P/'root_checks.csv').root_residual_Msun.abs().max())
checks['max_quad_96_minus_48_Msun']=float(s.MB_quad_delta_Msun.abs().max())
checks['max_firstlaw_slope_residual']=float(c[['GR_firstlaw_slope_residual','II_firstlaw_slope_residual']].abs().max().max())
# Reconstruct central density by a 45-point versus 89-point branch-only PCHIP,
# then compare energies against direct solve-and-root values (not interpolated results).
interp=[]
for row in c.itertuples():
 key=row.match_key;tar=row.target_Msun
 for model,L in [('GR',0.),('II',row.L_km)]:
  base=s[(s.EOS==row.EOS)&(s.L_km==L)&s.grid_point&s.causal_rising_candidate].sort_values('logrho')
  for stride in [2,1]:
   d=base.iloc[::stride];v=d[key].values;z=d.logrho.values
   assert (np.diff(v)>0).all()
   if not v[0]<=tar<=v[-1]:continue
   # Interpolating central density stays strictly inside this branch's tabulated domain.
   zi=float(PchipInterpolator(v,z,extrapolate=False)(tar))
   val=float(PchipInterpolator(z,d.Ebind_1e51erg.values,extrapolate=False)(zi))
   interp.append(dict(EOS=row.EOS,L_km=L,comparison_L_km=row.L_km,contrast=row.contrast,grid_dex=.0125*stride,interpolated_logrho=zi,direct_logrho=getattr(row,model+'_logrho'),delta_Ebind_vs_direct_1e51erg=val-getattr(row,model+'_Ebind_1e51erg')))
pd.DataFrame(interp).to_csv(P/'interpolation_checks.csv',index=False)
checks['max_interpolation_error_by_grid_1e51erg']=pd.DataFrame(interp).groupby('grid_dex').delta_Ebind_vs_direct_1e51erg.apply(lambda x:float(abs(x).max())).to_dict()
# Guard demonstrations: no out-of-range targets, no interpolation across a fold.
def guarded_inverse(x,y,target):
 x=np.asarray(x);y=np.asarray(y)
 if not(np.isfinite(x).all() and np.isfinite(y).all() and np.isfinite(target)):raise ValueError('nonfinite')
 if not((np.diff(x)>0).all() and (np.diff(y)>0).all()):raise ValueError('branch fold')
 if not y[0]<=target<=y[-1]:raise ValueError('extrapolation')
 return float(PchipInterpolator(y,x,extrapolate=False)(target))
negative=[]
for label,x,y,t in [('extrapolation',[1,2,3],[1,2,3],4),('fold',[1,2,3],[1,3,2],2),('nan',[1,2,3],[1,np.nan,3],2),('inf_target',[1,2,3],[1,2,3],np.inf)]:
 try:guarded_inverse(x,y,t)
 except ValueError:negative.append(label)
 else:raise AssertionError('missing guard '+label)
checks['negative_controls_rejected']=negative
# Input fingerprints. Do not claim a physical baryon-number calibration absent in EOS.
archive=Path('user/workspace/uploads/scalar-tensor-yukawa-fit_audit_package (2).zip')
prior=Path('user/workspace/co-scientist-outputs/tal-local-yukawa-exterior')
inputs={}
for p in [archive,P/'source/stellar_tal_v21.py',P/'source/curved_yukawa_adm_and_stability.py',P/'source/curved_yukawa_adm_sequences.csv',prior/'solve_exterior.py',prior/'source_to_infinity.csv',prior/'mass_budget.csv',prior/'sequence_summary.csv']:
 if p.exists():inputs[str(p.relative_to(Path.cwd()) if p.is_absolute() else p)]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
checks['inputs']=inputs
# Selected source rows at EXACT archived density, independently re-solved.
refs=[]
source=pd.read_csv(P/'source/curved_yukawa_adm_sequences.csv')
for row in source[source.alpha_Y==1].itertuples():
 d=s[(s.EOS==row.EOS)&(s.L_km==row.L_km)]
 r=d.iloc[(d.logrho-15).abs().argmin()]
 assert abs(r.logrho-15)<1e-9
 refs.append(dict(reference='latest_archive_density15',EOS=row.EOS,L_km=row.L_km,case='rho15',delta_ADM_Msun=r.M_ADM_Msun-row.M_ADM_at_15p0_Msun,delta_MB_Msun=r.MB_Msun-row.M_baryon_at_15p0_Msun,delta_tail_Msun=r.tail_Msun-row.Delta_M_phi_ext_curved_15p0_Msun,delta_R_km=r.R_km-row.R_at_15p0_curved_km))
if (prior/'mass_budget.csv').exists():
 for row in pd.read_csv(prior/'mass_budget.csv').itertuples():
  e=b.st.EOS(row.EOS);r,sol=b.ii(e,row.logrho,row.L_km)
  refs.append(dict(reference='prior_independent_mass_budget',EOS=row.EOS,L_km=row.L_km,case=row.case,delta_ADM_Msun=r['M_ADM_Msun']-row.M_ADM_Msun,delta_MB_Msun=np.nan,delta_tail_Msun=r['tail_Msun']-row.tail_Msun,delta_R_km=r['R_km']-row.R_km))
if (prior/'source_to_infinity.csv').exists():
 old=pd.read_csv(prior/'source_to_infinity.csv');checks['prior_source_to_infinity_rows']=len(old)
 for n in ['SLy','APR4']:
  for L in [1.,10.]:
   oldrow=old[(old.EOS==n)&(old.L_km==L)&(old['mode']=='curved')].iloc[(old[(old.EOS==n)&(old.L_km==L)&(old['mode']=='curved')].logrho-15).abs().argmin()]
   assert abs(oldrow.logrho-15)<1e-8
   now=s[(s.EOS==n)&(s.L_km==L)].iloc[(s[(s.EOS==n)&(s.L_km==L)].logrho-15).abs().argmin()]
   refs.append(dict(reference='prior_independent_sequence_rho15',EOS=n,L_km=L,case='rho15',delta_ADM_Msun=now.M_ADM_Msun-oldrow.M_ADM_Msun,delta_MB_Msun=np.nan,delta_tail_Msun=now.tail_Msun-oldrow.tail_Msun,delta_R_km=now.R_km-oldrow.R_km))
pd.DataFrame(refs).to_csv(P/'source_crosschecks.csv',index=False)
checks['source_crosschecks_by_reference']={key:g.select_dtypes('number').drop(columns='L_km').abs().max().to_dict() for key,g in pd.DataFrame(refs).groupby('reference')}
# Peak-position sensitivity from centered quadratic fits at two local windows.
# These are numerical controls, not replacements for direct mass-target roots.
peakchecks=[]
for row in su.itertuples():
 e=b.st.EOS(row.EOS);centre=row.logrho_peak
 seed=None if row.L_km==0 else b.ii(e,centre,row.L_km)[1]
 for width in [.001,.0005]:
  offsets=np.linspace(-width,width,7); records=[]
  for off in offsets:
   r,_=b.gr(e,centre+off,2e-13) if row.L_km==0 else b.ii(e,centre+off,row.L_km,seed,18.,5e-8)
   records.append(r)
  masses=np.array([r['M_ADM_Msun'] for r in records]);mb=np.array([r['MB_Msun'] for r in records]);energy=np.array([r['Ebind_1e51erg'] for r in records])
  coeff=np.polyfit(offsets,masses,2);dp=-coeff[1]/(2*coeff[0]);assert abs(dp)<width and coeff[0]<0
  peakchecks.append(dict(EOS=row.EOS,L_km=row.L_km,half_window_dex=width,baseline_logrho_peak=centre,fine_quadratic_logrho_peak=centre+dp,delta_logrho_peak=dp,delta_Mmax_Msun=np.polyval(coeff,dp)-row.Mmax_ADM_Msun,fine_Ebind_at_peak_1e51erg=np.polyval(np.polyfit(offsets,energy,2),dp),mass_fit_max_residual_Msun=float(abs(np.polyval(coeff,offsets)-masses).max())))
pd.DataFrame(peakchecks).to_csv(P/'peak_convergence.csv',index=False)
checks['peak_position_max_change_dex']=float(pd.DataFrame(peakchecks).delta_logrho_peak.abs().max())
checks['peak_mass_max_change_Msun']=float(pd.DataFrame(peakchecks).delta_Mmax_Msun.abs().max())
checks['versions']=dict(python=sys.version,numpy=np.__version__,scipy=__import__('scipy').__version__,pandas=pd.__version__)
def clean(x):
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,float) and not np.isfinite(x):return None
 return x
checks=clean(checks)
(P/'validation.json').write_text(json.dumps(checks,indent=2,allow_nan=False))
print(json.dumps({k:v for k,v in checks.items() if k not in ['inputs','versions']},indent=2))
