#!/usr/bin/env python3
"""Equilibrium binding energies for GR and local action-derived II-Fluid alpha_Y=1.
Run from any working directory: python3 binding_sequences.py [--eos SLy APR4 H4]
Source files live next to this script in source/. numpy/scipy/pandas/matplotlib only.
No empirical EOS or dynamical stability assumption is introduced.
"""
from pathlib import Path
import sys, json, argparse, hashlib, time, warnings, tempfile
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp, solve_bvp
from scipy.optimize import brentq, minimize_scalar
from scipy.interpolate import PchipInterpolator
from numpy.polynomial.legendre import leggauss
ROOT=Path(__file__).resolve().parent
CACHE=Path(tempfile.gettempdir())/'tal-binding-energy-cache'; CACHE.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'source'))
import stellar_tal_v21 as st
import solve_exterior as ex
ex.base_integrate=st.integrate
GM=st.GM; MU=1.66053906892e-27 # kg, explicitly chosen reference mass; EOS supplies no absolute n calibration
MS=st.MS; C=st.C; EUNIT=MS*C*C/1e44 # 10^51 erg = 10^44 J


def eos_checks(name):
    e=st.EOS(name); rr=np.geomspace(1e5,10**15.7,16001)
    h=e.h_of_rho(rr); eg,p,rho,cs=e.at(h); energy=eg/st.CONV; pres=p/st.CONV
    # Independent analytic EOS evaluated directly in rest density, not via at(h).
    i=np.searchsorted(e.b,rr); pp=e.k[i]*rr**e.g[i]
    ee=(1+e.a[i])*rr+pp/(e.g[i]-1)
    # Thermodynamic first law d(epsilon/rho)/d rho = P/rho^2.
    step=1e-5; a=rr*np.exp(-step); b=rr*np.exp(step)
    def specific(r):
        j=np.searchsorted(e.b,r)
        return 1+e.a[j]+e.k[j]*r**(e.g[j]-1)/(e.g[j]-1)
    deriv=(specific(b)-specific(a))/(2*step)
    good=np.min(abs(np.log(rr[:,None]/e.b)),axis=1)>2*step
    first=np.max(abs(deriv[good]/(pp/rr)[good]-1))
    jumps=[]
    for k,r in enumerate(e.b):
        ps=[e.k[j]*r**e.g[j] for j in [k,k+1]]
        es=[(1+e.a[j])*r+ps[t]/(e.g[j]-1) for t,j in enumerate([k,k+1])]
        jumps.append(dict(rho0_g_cm3=float(r),pressure_relative_jump=float(ps[1]/ps[0]-1),energy_relative_jump=float(es[1]/es[0]-1)))
    # Sound-speed envelope includes every segment end from both sides.
    low=float(specific(np.array([1e-20]))[0])
    ans=dict(EOS=name,enthalpy_inverse_max_rel=float(max(abs(rho/rr-1))),energy_max_rel=float(max(abs(energy/ee-1))),pressure_max_rel=float(max(abs(pres/pp-1))),first_law_max_rel=float(first),low_density_epsilon_over_rho_c2=low,junctions=jumps,
      normalization='rho0 is rest-mass density, not epsilon/c^2; MB=integral rho0 dVproper; n=rho0/m_ref; no exp(-phi) or lapse multiplier',
      m_ref_kg=MU,N_B_per_solar_baryon_mass=MS/MU)
    assert ans['enthalpy_inverse_max_rel']<1e-6 and ans['first_law_max_rel']<1e-5
    assert max(abs(x['energy_relative_jump']) for x in jumps)<1e-12
    return ans


def csmax(e,hc):
    hb=e.hb[e.hb<hc]; hs=np.r_[np.linspace(1e-14,hc,2001),hb*(1-1e-10),hb*(1+1e-10)]
    return float(e.at(hs)[3].max())


def gr_ivp(e,lr,rtol=2e-12):
    hc=float(e.h_of_rho(10**lr)); ec,pc,_,_=e.at(hc); r0=1e-5
    dh=2*np.pi/3*(ec+3*pc)*r0*r0
    def rhs(h,y):
        r,m,mb=y; en,p,rho,_=e.at(h)
        dr=-r*(r-2*m)/(m+4*np.pi*r**3*p)
        return [dr,4*np.pi*r*r*en*dr,4*np.pi*r*r*rho*st.CONV/np.sqrt(1-2*m/r)*dr]
    init=[r0,4*np.pi*ec*r0**3/3,4*np.pi*10**lr*st.CONV*r0**3/3]
    s=solve_ivp(rhs,[hc-dh,1e-12],init,rtol=rtol,atol=[1e-10,1e-12,1e-12],dense_output=True,max_step=hc/150)
    if not s.success: raise RuntimeError(s.message)
    R,m,mb=s.y[:,-1]; cs=csmax(e,hc)
    # Independent quadrature in h, split at all EOS interfaces and clustered near centre.
    breaks=np.unique(np.r_[1e-12,e.hb[e.hb<hc-dh],hc-dh, hc-np.geomspace(dh,hc*.01,20)])
    def qmb(n):
        x,w=leggauss(n); a=breaks[:-1,None]; b=breaks[1:,None]; hh=(a+b)/2+(b-a)/2*x
        r,mm,_=s.sol(hh.ravel()); en,p,rho,_=e.at(hh.ravel())
        dr=-r*(r-2*mm)/(mm+4*np.pi*r**3*p)
        f=-4*np.pi*r*r*rho*st.CONV/np.sqrt(1-2*mm/r)*dr/GM
        return float(np.sum(f.reshape(hh.shape)*w*(b-a)/2)+init[2]/GM)
    mb48=qmb(48); mb96=qmb(96)
    rec=dict(logrho=lr,L_km=0.,mode='GR',R_km=R,mR_Msun=m/GM,M_ADM_Msun=m/GM,tail_Msun=0.,MB_Msun=mb/GM,MB_quadrature_Msun=mb96,MB_quad_delta_Msun=mb96-mb48,MB_ode_minus_quad_Msun=mb/GM-mb96,phiR=0.,phi_c=0.,cs2max=cs,causal=cs<=1+1e-10,bvp_rms=np.nan,bc_max=np.nan,nodes=len(s.t),tail_L=0.,surface_mu_infinity=np.sqrt(1-2*m/R))
    rec['Ebind_1e51erg']=(rec['MB_Msun']-rec['M_ADM_Msun'])*EUNIT
    rec['NB_ref_mu']=rec['MB_Msun']*MS/MU
    return rec,s


def gr(e,lr,rtol=2e-12):
    # Scalar-free collocation removes small IVP surface/central interpolation noise.
    iv,sv=gr_ivp(e,lr,rtol)
    hc=float(e.h_of_rho(10**lr)); ec,pc,_,_=e.at(hc); r0=1e-5
    xx=np.linspace(0,1,551); R=iv['R_km']
    hh=np.linspace(sv.t[-1],sv.t[0],8001); rr,mm,bb=sv.sol(hh)
    ri=r0+(R-r0)*xx
    hi=np.interp(ri,rr[::-1],hh[::-1]); mi=np.interp(ri,rr[::-1],mm[::-1])
    nu=.5*np.log(1-2*iv['M_ADM_Msun']*GM/R)-hi
    def fun(x,y,p):
        r=r0+(p[0]-r0)*x; m,nu,h=y; en,pr,_,_=e.at(np.maximum(h,1e-14));en=np.where(h>0,en,0);pr=np.where(h>0,pr,0)
        v=(m+4*np.pi*r**3*pr)/(r*(r-2*m))
        return np.array([4*np.pi*r*r*en,v,-v])*(p[0]-r0)
    def bc(a,b,p):
        return [a[0]-4*np.pi*ec*r0**3/3,a[2]-hc,b[2],b[1]-.5*np.log(1-2*b[0]/p[0])]
    tol=2e-7 if rtol>=1e-12 else 5e-8
    s=solve_bvp(fun,bc,xx,np.array([mi,nu,hi]),p=[R],tol=tol,bc_tol=1e-12,max_nodes=22000)
    if not s.success:raise RuntimeError(s.message)
    s.r0=r0
    m48=baryon(e,s,48,hidx=2); mb=baryon(e,s,96,hidx=2); R=float(s.p[0]); m=s.sol(1)[0]; cs=csmax(e,hc)
    rec=dict(logrho=lr,L_km=0.,mode='GR',R_km=R,mR_Msun=m/GM,M_ADM_Msun=m/GM,tail_Msun=0.,MB_Msun=mb,MB_quadrature_Msun=mb,MB_quad_delta_Msun=mb-m48,MB_ode_minus_quad_Msun=iv['MB_Msun']-mb,GR_ivp_minus_bvp_ADM_Msun=iv['M_ADM_Msun']-m/GM,phiR=0.,phi_c=0.,cs2max=cs,causal=cs<=1+1e-10,bvp_rms=float(max(s.rms_residuals)),bc_max=float(max(abs(np.array(bc(s.sol(0),s.sol(1),s.p))))),nodes=len(s.x),tail_L=0.,surface_mu_infinity=np.sqrt(1-2*m/R))
    rec['Ebind_1e51erg']=(mb-m/GM)*EUNIT;rec['NB_ref_mu']=mb*MS/MU
    return rec,s


def baryon(e,s,n,hidx=4):
    R=s.p[0]; r0=s.r0; hc=s.sol(0)[hidx]
    xx=[0.,1.]
    for h in e.hb[e.hb<hc]:
        xx.append(brentq(lambda x:float(s.sol(x)[hidx]-h),0,1,xtol=2e-14))
    # Split collocation solution at EOS interfaces; high order quadrature per smooth piece.
    xx=np.sort(xx); x,w=leggauss(n); a=np.array(xx[:-1])[:,None]; b=np.array(xx[1:])[:,None]
    t=(a+b)/2+(b-a)/2*x; y=s.sol(t.ravel()); rr=r0+(R-r0)*t.ravel()
    rho=e.at(np.maximum(y[hidx],1e-14))[2]
    integ=4*np.pi*rr**2*rho*st.CONV/np.sqrt(1-2*y[0]/rr)*(R-r0)/GM
    return float(np.sum(integ.reshape(t.shape)*w*(b-a)/2)+4*np.pi/3*float(e.at(hc)[2])*st.CONV*r0**3/GM)


def ii(e,lr,L,seed=None,tail=18.,tol=2e-7):
    r,s=ex.solve(e,lr,L,seed=seed,tail=tail,tol=tol)
    # Ignore historical flat-tail estimate: only simultaneous curved ADM solution is used.
    for k in ['flat_tail_Msun','flat_sum_Msun']:r.pop(k)
    m48=baryon(e,s,48); m96=baryon(e,s,96)
    r.update(MB_Msun=m96,MB_quadrature_Msun=m96,MB_quad_delta_Msun=m96-m48,MB_ode_minus_quad_Msun=np.nan,
      surface_mu_infinity=float(np.exp(s.sol(1)[1]-s.sol(1)[2])))
    r['Ebind_1e51erg']=(m96-r['M_ADM_Msun'])*EUNIT; r['NB_ref_mu']=m96*MS/MU
    r['causal']=r['cs2max']<=1+1e-10
    return r,s


def run(name):
    out=ROOT/name; out.mkdir(exist_ok=True); e=st.EOS(name)
    (out/'eos_normalization.json').write_text(json.dumps(eos_checks(name),indent=2))
    summaries=[]; selected=[]; checks=[]
    for L in [0.,1.,10.]:
        t=time.time(); cache={}; failed=[]
        def calc(lr):
            key=round(float(lr),11)
            if key not in cache:
                seed=cache[min(cache,key=lambda k:abs(k-key))][1] if cache and L else None
                cache[key]=gr(e,key) if not L else ii(e,key,L,seed)
            return cache[key]
        # Same prespecified grid for all models; includes the descending continuation.
        grid=np.linspace(14.55,15.65,89)
        for lr in grid: calc(lr)
        masses=np.array([calc(lr)[0]['M_ADM_Msun'] for lr in grid]); im=masses.argmax()
        assert 0<im<len(grid)-1
        opt=minimize_scalar(lambda lr:-calc(lr)[0]['M_ADM_Msun'],bounds=(grid[im-1],grid[im+1]),method='bounded',options={'xatol':1e-6})
        peaklr=float(opt.x); pk,_=calc(peaklr)
        # Root first causal onset. H4 has no causal onset in the sequence grid.
        hcau=e.h_causal()
        causelr=brentq(lambda z:float(e.h_of_rho(10**z)-hcau),5,16.5) if np.isfinite(hcau) else np.inf
        limit=min(peaklr,causelr); edge,_=calc(limit)
        # Inset 1e-5 dex ensures strict positive-slope candidates at the endpoint.
        safe=limit-1e-5; cand,_=calc(safe)
        record=dict(EOS=name,L_km=L,logrho_peak=peaklr,Mmax_ADM_Msun=pk['M_ADM_Msun'],MB_at_ADM_peak_Msun=pk['MB_Msun'],peak_cs2max=pk['cs2max'],peak_causal=pk['causal'],causal_onset_logrho=causelr,logrho_candidate_supremum=limit,candidate_supremum_ADM_Msun=edge['M_ADM_Msun'],candidate_supremum_MB_Msun=edge['MB_Msun'],candidate_inset_logrho=safe,candidate_inset_ADM_Msun=cand['M_ADM_Msun'],candidate_inset_MB_Msun=cand['MB_Msun'],limit_reason='causality' if causelr<peaklr else 'ADM turning point')
        # Candidate MB must itself be monotone; no sorting across folds permitted.
        ordered=sorted((lr,r) for lr,(r,s) in cache.items() if lr<=safe)
        assert np.all(np.diff([r['MB_Msun'] for _,r in ordered])>0)
        summaries.append(record)
        # Save pickled BVP solutions only as local computational cache, not deliverables.
        import pickle
        for _,ss in cache.values():
            for attr in ['physics','bc']:
                if hasattr(ss,attr): delattr(ss,attr)
        with (CACHE/f'{name}_L{L:g}.pkl').open('wb') as f:pickle.dump(cache,f)
        for lr,(r,s) in cache.items():
            r.update(EOS=name,branch_id=f'{name}_L{L:g}_'+('first_rising' if lr<peaklr else 'first_descending'),rising_candidate=lr<peaklr,causal_rising_candidate=lr<peaklr and r['causal'],grid_point=bool(np.min(abs(grid-lr))<1e-9))
        pd.DataFrame([r for r,s in cache.values()]).sort_values('logrho').to_csv(out/f'sequence_L{L:g}.csv',index=False)
        print(name,L,'rows',len(cache),'sec',round(time.time()-t,1),record,flush=True)
    pd.DataFrame(summaries).to_csv(out/'sequence_summary.csv',index=False)


def compare(name):
    import pickle
    out=ROOT/name; e=st.EOS(name); su=pd.read_csv(out/'sequence_summary.csv')
    caches={}
    for L in [0.,1.,10.]:
        with (CACHE/f'{name}_L{L:g}.pkl').open('rb') as f:caches[L]=pickle.load(f)
    extra=[]; conver=[]; contrasts=[]; roots=[]
    def calc(lr,L):
        k=round(float(lr),11); cache=caches[L]
        if k not in cache:
            seed=cache[min(cache,key=lambda x:abs(x-k))][1] if L else None
            cache[k]=gr(e,k) if L==0 else ii(e,k,L,seed)
        return cache[k]
    def match(target,key,L):
        s=su[su.L_km==L].iloc[0]; hi=s.candidate_inset_logrho
        # First-rising candidate bracket only, no extrapolation to a missing mass.
        assert calc(14.55,L)[0][key]<=target<=calc(hi,L)[0][key],(name,L,target,key)
        lr=brentq(lambda z:calc(z,L)[0][key]-target,14.55,hi,xtol=2e-10)
        r,sol=calc(lr,L); assert r['causal'] and lr<s.logrho_peak
        roots.append(dict(EOS=name,L_km=L,target_key=key,target_Msun=target,logrho=lr,root_residual_Msun=r[key]-target))
        return r,sol
    baseline14,_=match(1.4,'M_ADM_Msun',0.)
    for L in [1.,10.]:
        gs=su[su.L_km==0].iloc[0]; ys=su[su.L_km==L].iloc[0]
        # Definitions fixed before evaluating contrasts; use 99% of common candidate supremum.
        specs=[('common_ADM_1p4','M_ADM_Msun',1.4),('common_MB_GR1p4','MB_Msun',baseline14['MB_Msun']),
          ('common_ADM_near_limit','M_ADM_Msun',.99*min(gs.candidate_supremum_ADM_Msun,ys.candidate_supremum_ADM_Msun)),
          ('common_MB_near_limit','MB_Msun',.99*min(gs.candidate_supremum_MB_Msun,ys.candidate_supremum_MB_Msun))]
        for label,key,target in specs:
            g,sg=match(target,key,0.); y,sy=match(target,key,L)
            rr=dict(EOS=name,L_km=L,contrast=label,match_key=key,target_Msun=target,
              delta_Ebind_1e51erg=y['Ebind_1e51erg']-g['Ebind_1e51erg'],delta_MB_Msun=y['MB_Msun']-g['MB_Msun'],delta_ADM_Msun=y['M_ADM_Msun']-g['M_ADM_Msun'],
              algebra_residual_1e51erg=(y['Ebind_1e51erg']-g['Ebind_1e51erg'])-((y['MB_Msun']-g['MB_Msun'])-(y['M_ADM_Msun']-g['M_ADM_Msun']))*EUNIT)
            for prefix,r in [('GR',g),('II',y)]:
                for field in ['logrho','R_km','M_ADM_Msun','mR_Msun','MB_Msun','Ebind_1e51erg','tail_Msun','cs2max','causal']:
                    rr[prefix+'_'+field]=r[field]
            # Re-solve all matched densities with tighter tolerance, longer/shorter exterior.
            # Propagate fixed-density discrepancies to fixed-mass target via branch derivative.
            uncertainties=[]
            for model,r,s,LL in [('GR',g,sg,0.),('II',y,sy,L)]:
                dl=2e-4
                rp,_=calc(r['logrho']+dl,LL); rm,_=calc(r['logrho']-dl,LL)
                deriv={k:(rp[k]-rm[k])/(2*dl) for k in [key,'Ebind_1e51erg','M_ADM_Msun','MB_Msun']}
                if LL:
                    variants=[('tight_tol',18.,5e-8),('short_domain',12.,2e-7),('long_domain',24.,2e-7)]
                else: variants=[('tight_ivp',0.,2e-13)]
                ee=[]
                for test,tail,tol in variants:
                    f,sf=ii(e,r['logrho'],LL,s,tail,tol) if LL else gr(e,r['logrho'],tol)
                    fixed=f['Ebind_1e51erg']-r['Ebind_1e51erg']-deriv['Ebind_1e51erg']/deriv[key]*(f[key]-r[key])
                    ee.append(abs(fixed))
                    conver.append(dict(EOS=name,L_km=LL,contrast_L_km=L,contrast=label,test=test,logrho=r['logrho'],delta_ADM_Msun=f['M_ADM_Msun']-r['M_ADM_Msun'],delta_MB_Msun=f['MB_Msun']-r['MB_Msun'],delta_R_km=f['R_km']-r['R_km'],delta_Ebind_1e51erg=f['Ebind_1e51erg']-r['Ebind_1e51erg'],fixed_target_linearized_delta_Ebind_1e51erg=fixed,quad_96_minus_48_Msun=f['MB_quad_delta_Msun']))
                # Interpolation check: adjacent ORIGINAL grid points only, same candidate branch.
                grid=sorted((z,rec) for z,(rec,_) in caches[LL].items() if abs((z-14.55)/.0125-round((z-14.55)/.0125))<1e-7 and z<=su[su.L_km==LL].iloc[0].candidate_inset_logrho)
                z=np.array([t[0] for t in grid]); values=np.array([t[1][key] for t in grid]); ener=np.array([t[1]['Ebind_1e51erg'] for t in grid])
                if values[0]<=target<=values[-1]:
                    zi=float(PchipInterpolator(values,z,extrapolate=False)(target)); ei=float(PchipInterpolator(z,ener,extrapolate=False)(zi))
                    rr[model+'_coarse_pchip_minus_root_1e51erg']=ei-r['Ebind_1e51erg']
                else: rr[model+'_coarse_pchip_minus_root_1e51erg']=np.nan
                # Resolution sensitivity of branch derivative is checked with half step.
                rph,_=calc(r['logrho']+dl/2,LL); rmh,_=calc(r['logrho']-dl/2,LL)
                slope=(rph['M_ADM_Msun']-rmh['M_ADM_Msun'])/(rph['MB_Msun']-rmh['MB_Msun'])
                rr[model+'_firstlaw_slope_residual']=slope-r['surface_mu_infinity']
                uncertainties.append(max(ee)+abs(r['MB_quad_delta_Msun'])*EUNIT)
            rr['numerical_sensitivity_1e51erg']=sum(uncertainties)
            contrasts.append(rr)
    # Endpoint inset rows and unconstrained peaks are distinct from common-target comparisons.
    ends=[]
    for L in [0.,1.,10.]:
        s=su[su.L_km==L].iloc[0]
        for label,lr in [('candidate_inset',s.candidate_inset_logrho),('unconstrained_ADM_peak',s.logrho_peak)]:
            r,ss=calc(lr,L);ends.append(dict(r,EOS=name,L_km=L,case=label))
            fine,sfine=gr(e,lr,2e-13) if L==0 else ii(e,lr,L,ss,18.,5e-8)
            conver.append(dict(EOS=name,L_km=L,contrast_L_km=L,contrast=label,test='endpoint_tight',logrho=lr,delta_ADM_Msun=fine['M_ADM_Msun']-r['M_ADM_Msun'],delta_MB_Msun=fine['MB_Msun']-r['MB_Msun'],delta_R_km=fine['R_km']-r['R_km'],delta_Ebind_1e51erg=fine['Ebind_1e51erg']-r['Ebind_1e51erg'],fixed_target_linearized_delta_Ebind_1e51erg=np.nan,quad_96_minus_48_Msun=fine['MB_quad_delta_Msun']))
    # Full sequence archive includes grid, optimized peaks, direct roots and derivative checks.
    allrows=[]
    for L,cache in caches.items():
        lim=su[su.L_km==L].iloc[0]
        for lr,(r,s) in cache.items():
            r.update(EOS=name,branch_id=f'{name}_L{L:g}_'+('first_rising' if lr<lim.logrho_peak else 'first_descending'),rising_candidate=lr<lim.logrho_peak,causal_rising_candidate=lr<lim.logrho_peak and r['causal'],grid_point=abs((lr-14.55)/.0125-round((lr-14.55)/.0125))<1e-7)
            allrows.append(r)
    pd.DataFrame(allrows).sort_values(['L_km','logrho']).to_csv(out/'equilibrium_sequences.csv',index=False)
    pd.DataFrame(contrasts).to_csv(out/'comparisons.csv',index=False)
    pd.DataFrame(conver).to_csv(out/'convergence.csv',index=False)
    pd.DataFrame(ends).to_csv(out/'endpoints.csv',index=False)
    pd.DataFrame(roots).to_csv(out/'root_checks.csv',index=False)
    print('COMPARE DONE',name,flush=True)


def aggregate():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    (ROOT/'eos_normalization.json').write_text(json.dumps({n:json.loads((ROOT/n/'eos_normalization.json').read_text()) for n in ['SLy','APR4','H4']},indent=2))
    for file in ['equilibrium_sequences','comparisons','convergence','endpoints','root_checks','sequence_summary']:
        pd.concat([pd.read_csv(ROOT/n/(file+'.csv')) for n in ['SLy','APR4','H4']],ignore_index=True).to_csv(ROOT/(file+'.csv'),index=False)
    d=pd.read_csv(ROOT/'equilibrium_sequences.csv');su=pd.read_csv(ROOT/'sequence_summary.csv')
    fig,axs=plt.subplots(1,3,figsize=(14,4.7),sharey=True)
    for ax,n in zip(axs,['SLy','APR4','H4']):
        for L,c,label in [(0.,'black','GR'),(1.,'#0072B2','II-Fluid L=1 km'),(10.,'#D55E00','II-Fluid L=10 km')]:
            a=d[(d.EOS==n)&(d.L_km==L)&d.grid_point].sort_values('logrho'); a=a[a.rising_candidate]
            good=a.causal_rising_candidate
            ax.plot(a.loc[good,'MB_Msun'],a.loc[good,'Ebind_1e51erg'],color=c,label=label)
            b=a[~good]
            if len(b): ax.plot(b.MB_Msun,b.Ebind_1e51erg,':',color=c,alpha=.6)
            ep=su[(su.EOS==n)&(su.L_km==L)].iloc[0]
            end=d[(d.EOS==n)&(d.L_km==L)].iloc[(d[(d.EOS==n)&(d.L_km==L)].logrho-ep.logrho_candidate_supremum).abs().argmin()]
            ax.plot(end.MB_Msun,end.Ebind_1e51erg,'o',mfc='white',mec=c,ms=5)
        ax.set(title=n,xlabel=r'$M_B/M_\odot$');ax.grid(alpha=.2)
    axs[0].set_ylabel(r'$E_{\rm bind}=(M_B-M_{\rm ADM})c^2\ [10^{51}\ {\rm erg}]$');axs[0].legend(fontsize=8)
    fig.suptitle('Equilibrium binding energy; local action-derived branch, alpha_Y=1\nSolid: causal first-rising candidates; dotted: acausal rising continuation; circles: candidate suprema',fontsize=10)
    fig.tight_layout();fig.savefig(ROOT/'energy_vs_MB.png',dpi=200);fig.savefig(ROOT/'energy_vs_MB.svg');plt.close(fig)
    print('AGGREGATE',len(d),'rows',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--eos',nargs='+',default=['SLy','APR4','H4']);ap.add_argument('--compare-only',action='store_true');ap.add_argument('--aggregate-only',action='store_true');a=ap.parse_args()
    if a.aggregate_only:aggregate()
    else:
        for n in a.eos:
            if not a.compare_only:run(n)
            compare(n)
        if a.eos==['SLy','APR4','H4']:aggregate()
