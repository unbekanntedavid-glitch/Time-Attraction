#!/usr/bin/env python3
"""Action-derived TAL local Yukawa Einstein-fluid BVP, not bilateral branch.
G=c=1, r,m,L in km, epsilon,P in km^-2, alpha_Y=1.
Run: python3 solve_exterior.py --zip '...corrected (2).zip' --out RESULTS
Only numpy/scipy/pandas/matplotlib; EOS module extracted from supplied ZIP.
No outward unstable scalar shooting: two-domain collocation with unknown R.
"""
import argparse,sys,zipfile,hashlib,json,time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import solve_bvp,quad
from scipy.optimize import minimize_scalar,brentq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

GM=1.4766250380501247

def load_eos(zpath,work):
    global EOS,base_integrate,GM
    work.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(zpath) as z:
        name=next(n for n in z.namelist() if n.endswith('/stellar_tal_v21.py'))
        (work/'stellar_tal_v21.py').write_bytes(z.read(name))
    sys.path.insert(0,str(work.resolve()))
    from stellar_tal_v21 import EOS,integrate,GM
    base_integrate=integrate


def solve(eos,lr,L,mode='curved',tail=18.,tol=2e-7,seed=None):
    hc=float(eos.h_of_rho(10**lr)); ec,pc,_,_=eos.at(hc)
    r0=1e-5; T=tail*L
    def fields(r,m,nu,phi,q,h=None):
        if h is None: e=p=np.zeros_like(r)
        else:
            e,p,_,_=eos.at(np.clip(h,1e-14,3.))
            e=np.where(h>0,e,0); p=np.where(h>0,p,0)
        f=np.exp(np.clip(-phi,-10,10)); B=1-2*m/r
        rho=(B*q*q+phi*phi/L**2)/2
        pr=(B*q*q-phi*phi/L**2)/2
        dm=4*np.pi*r*r*(f*e+rho)
        v=(m+4*np.pi*r**3*(f*p+pr))/(r*r*B)
        bp=2*m/r**2-2*dm/r
        qp=(phi/L**2-f*e)/B-(2/r+v+bp/(2*B))*q
        return dm,v,q,qp,-v+q
    def fun(x,y,param):
        R=param[0]; a=R-r0
        z=np.array(fields(r0+a*x,*y[:4],y[4]))*a
        if mode=='flat': return z
        ze=np.array(fields(R+T*x,*y[5:]))[:4]*T
        return np.vstack((z,ze))
    def bc(ya,yb,param):
        R=param[0]; phic=ya[2]
        rhoc=(phic**2/L**2)/2
        q1=(phic/L**2-np.exp(-phic)*ec)/3
        cen=[(ya[0]-4*np.pi*(np.exp(-phic)*ec+rhoc)*r0**3/3),ya[3]-q1*r0,ya[4]-hc]
        if mode=='flat':
            return np.r_[cen,yb[4],yb[3]+(1/R+1/L)*yb[2],yb[1]-.5*np.log(1-2*yb[0]/R)]
        re=R+T; me=yb[5]
        # decaying Schwarzschild asymptotic phi~exp(-r/L)r^(-1-M/L)
        far=[yb[8]+(1/L+(1+me/L)/re)*yb[7],yb[6]-.5*np.log(1-2*me/re)]
        return np.r_[cen,yb[4],yb[:4]-ya[5:],far]
    x=np.unique(np.r_[np.linspace(0,1,501),np.geomspace(1e-4,.1,50)])
    if seed is None:
        gr=base_integrate(eos,lr,ngrid=801); R=gr['R']; rr=gr['rg']; hgrid=np.r_[hc,np.linspace(hc-1e-10,1e-10,2400)]
        # GR enthalpy interpolation obtained from a separate radius ODE profile
        from scipy.integrate import solve_ivp
        def gh(r,y):
            m,h=y; e,p,_,_=eos.at(max(h,1e-14))
            return [4*np.pi*r*r*e,-(m+4*np.pi*r**3*p)/(r*(r-2*m))]
        iv=solve_ivp(gh,[r0,R],[4*np.pi*ec*r0**3/3,hc],rtol=1e-8,atol=1e-10,dense_output=True,max_step=.05)
        ri=r0+(R-r0)*x; m,h=iv.sol(ri)
        phi=.7*L**2*eos.at(np.maximum(h,1e-14))[0]/(1+(L/R)**2*5)
        q=np.gradient(phi,ri); nu=.5*np.log(1-2*m[-1]/R)-h
        y=np.vstack((m,nu,phi,q,h))
        if mode!='flat':
            re=R+T*x; pe=max(phi[-1],.0001)*(R/re)*np.exp(-(re-R)/L)
            y=np.vstack((y,np.full_like(x,m[-1]),.5*np.log(1-2*m[-1]/re),pe,-pe*(1/re+1/L)))
    else:
        R=seed.p[0]; y=seed.sol(x)
    sol=solve_bvp(fun,bc,x,y,p=[R],tol=tol,bc_tol=min(tol,1e-10),max_nodes=22000)
    if not sol.success: raise RuntimeError(f'{mode} lr={lr} L={L}: {sol.message}, rms={max(sol.rms_residuals)}, x={sol.x[np.argmax(sol.rms_residuals)]}, nodes={len(sol.x)}, dx={np.diff(sol.x)[np.argmax(sol.rms_residuals)]}, h={sol.y[4,np.argmax(sol.rms_residuals)]}')
    R=float(sol.p[0]); ys=sol.sol(1); mR=ys[0]; phiR=ys[2]
    re=np.linspace(R,R+40*L,4001); pe=phiR*R/re*np.exp(-(re-R)/L)
    qe=-pe*(1/re+1/L)
    flat_tail=quad(lambda r: 2*np.pi*r*r*(phiR*R/r*np.exp(-(r-R)/L))**2*((1-2*mR/r)*(1/r+1/L)**2+1/L**2)/GM,R,R+40*L,epsabs=1e-13)[0]
    hh=sol.sol(np.linspace(0,1,5001))[4]
    hs=np.r_[hh,eos.hb[eos.hb<hc]*(1-1e-9),eos.hb[eos.hb<hc]*(1+1e-9)]
    cs=float(np.max(eos.at(np.maximum(hs,1e-14))[3]))
    rec=dict(logrho=lr,L_km=L,mode=mode,R_km=R,mR_Msun=mR/GM,flat_tail_Msun=flat_tail,
             flat_sum_Msun=mR/GM+flat_tail,phiR=phiR,phi_c=sol.sol(0)[2],cs2max=cs,causal=bool(cs<=1),
             M_ADM_Msun=(ys[5]/GM if mode!='flat' else np.nan),nodes=len(sol.x),bvp_rms=float(max(sol.rms_residuals)),
             bc_max=float(max(abs(bc(sol.sol(0),ys,sol.p)))),tail_L=tail)
    if mode!='flat': rec['tail_Msun']=rec['M_ADM_Msun']-rec['mR_Msun']
    sol.physics=fields; sol.bc=bc; sol.T=T; sol.L=L; sol.r0=r0; sol.record=rec
    return rec,sol


def diagnostics(sol):
    R=sol.p[0]; L=sol.L; T=sol.T
    x=np.linspace(0,1,4001); y=sol.sol(x); dy=sol.sol(x,1)
    re=R+T*x; m,nu,phi,q=y[5:]; dm,dnu,dphi,dq,_=sol.physics(re,m,nu,phi,q)
    B=1-2*m/re; bp=2*m/re**2-2*dm/re
    # Independent derivative of the collocation polynomial, not RHS self-substitution.
    eqs=[dy[5]/T-dm,dy[6]/T-dnu,dy[7]/T-q,dy[8]/T-dq]
    rho=(B*q*q+phi*phi/L**2)/2; pr=(B*q*q-phi*phi/L**2)/2; pt=-rho
    # Radial Einstein constraint, independent polynomial derivative of nu.
    grr=B*(2*(dy[6]/T)/re+1/re**2)-1/re**2-8*np.pi*pr
    # Conservation radial constraint differentiated using polynomial derivatives.
    drho=.5*bp*q*q+B*q*dy[8]/T-phi*dy[7]/T/L**2
    radial=drho+(rho+pr)*dy[6]/T+2*(pr-pt)/re
    # Integration against exact polynomial samples checks source-to-infinity m.
    total=quad(lambda r: 4*np.pi*r*r*((1-2*sol.sol((r-R)/T)[5]/r)*sol.sol((r-R)/T)[8]**2+sol.sol((r-R)/T)[7]**2/L**2)/2/GM,R,R+T,epsabs=1e-11,limit=200)[0]
    a=sol.sol(0); b=sol.sol(1)
    residual=dict(exterior_ode_max=[float(np.max(abs(z))) for z in eqs],radial_Einstein_max_km2=float(max(abs(grr))),
      radial_Einstein_scaled=float(max(abs(grr))/max(abs(2*B*dnu/re))),
      radial_conservation_max_km3=float(max(abs(radial))),mass_quadrature_error_Msun=float(total-(b[5]-b[0])/GM),
      scalar_monotone=bool(np.all(q<0)),scalar_positive=bool(np.all(phi>0)),
      phi_outer_over_surface=float(phi[-1]/phi[0]),mass_last_2L_Msun=float((m[-1]-sol.sol(1-2*L/T)[5])/GM),
      joins_abs=(b[:4]-a[5:]).tolist(),lapse_outer_minus_Schwarz=float(nu[-1]-.5*np.log(B[-1])),
      scalar_log_slope_outer=float(q[-1]/phi[-1]),scalar_asymptotic_log_slope=float(-(1/L+(1+m[-1]/L)/re[-1])),
      mass_plateau_Msun={str(k):float(sol.sol(k*L/T)[5]/GM) for k in [0,1,2,4,8,12,18] if k*L<=T},
      lapse_surface=float(np.exp(a[6])),flat_Schwarz_lapse_surface=float(np.sqrt(1-2*b[0]/R)),
      qR_over_phiR=float(a[8]/a[7]),flat_Robin_qR_over_phiR=float(-(1/R+1/L)),
      metric_B_join=float((1-2*b[0]/R)-(1-2*a[5]/R)),
      lapse_join=float(np.exp(b[1])-np.exp(a[6])),
      nuprime_join=float(sol.sol(1,1)[1]/(R-sol.r0)-sol.sol(0,1)[6]/T))
    return residual,pd.DataFrame(dict(r_km=re,m_Msun=m/GM,nu=nu,phi=phi,dphi_dr=q,B=B,rho_phi_km2=rho,pr_phi_km2=pr))


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--zip',required=True); ap.add_argument('--out',required=True); ap.add_argument('--quick',action='store_true'); args=ap.parse_args()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    load_eos(args.zip,out/'source_eos')
    rows=[]; summary=[]; checks={}; profiles=[]; budgets=[]
    for name in ['SLy','APR4']:
      eos=EOS(name)
      for L in [1.,10.]:
        cache={}
        def calc(lr,mode='curved'):
            key=(round(float(lr),10),mode)
            if key not in cache:
                seeds=[v[1] for k,v in cache.items() if k[1]==mode]
                seed=seeds[-1] if seeds else None
                cache[key]=solve(eos,float(lr),L,mode,seed=seed)
            return cache[key]
        grid=np.linspace(14.8,15.5,22 if not args.quick else 8)
        for lr in grid:
            for mode in ['curved','flat']: calc(lr,mode)
        for mode,mkey in [('curved','M_ADM_Msun'),('flat','mR_Msun')]:
            opt=minimize_scalar(lambda z:-calc(z,mode)[0][mkey],bounds=(15.15,15.45),method='bounded',options={'xatol':2e-6})
            peak,ps=calc(opt.x,mode)
            lr14=brentq(lambda z:calc(z,mode)[0][mkey]-1.4,14.8,15.1,xtol=2e-8)
            canonical,ss=calc(lr14,mode)
            hca=eos.h_causal(); lr_causal=brentq(lambda z:eos.h_of_rho(10**z)-hca,14.5,16.5)
            causal_rec,_=calc(min(lr_causal,float(opt.x)),mode)
            summary.append(dict(EOS=name,L_km=L,mode=mode,mass_definition=mkey,Mmax=peak[mkey],R_at_Mmax=peak['R_km'],logrho_peak=opt.x,
             peak_cs2max=peak['cs2max'],peak_causal=peak['causal'],R14=canonical['R_km'],logrho14=lr14,cs2max14=canonical['cs2max'],
             causal_logrho_limit=lr_causal,causal_rising_supremum_Msun=causal_rec[mkey],causal_rising_R_km=causal_rec['R_km']))
            if mode=='curved':
                for label,rec,s in [('rho15',*calc(15.)),('peak',peak,ps),('M14',canonical,ss)]:
                    old,_=calc(rec['logrho'],'flat')
                    budgets.append(dict(EOS=name,L_km=L,case=label,logrho=rec['logrho'],
                      old_flat_R_km=old['R_km'],old_flat_mR_Msun=old['mR_Msun'],old_flat_tail_Msun=old['flat_tail_Msun'],old_flat_sum_Msun=old['flat_sum_Msun'],
                      R_km=rec['R_km'],mR_Msun=rec['mR_Msun'],tail_Msun=rec['tail_Msun'],M_ADM_Msun=rec['M_ADM_Msun'],cs2max=rec['cs2max'],causal=rec['causal']))
                    diag,prof=diagnostics(s); checks[f'{name}_L{L}_{label}']=diag
                    prof.insert(0,'case',f'{name}_L{L}_{label}'); profiles.append(prof)
                    for tail,tol in [(12.,2e-7),(24.,2e-7),(18.,5e-8)]:
                        rr,sss=solve(eos,rec['logrho'],L,tail=tail,tol=tol,seed=s)
                        checks[f'{name}_L{L}_{label}'][f'convergence_T{tail}_tol{tol}']={k:rr[k]-rec[k] for k in ['M_ADM_Msun','mR_Msun','R_km','phiR']}
        for (lr,mode),(rec,s) in list(cache.items()):
            peaklr=next(z['logrho_peak'] for z in summary if z['EOS']==name and z['L_km']==L and z['mode']==mode)
            matched_flat=calc(lr,'flat')[0] if mode=='curved' else rec
            rows.append(dict(EOS=name,**rec,rising_candidate=bool(lr<peaklr),
                old_flat_mR_Msun=matched_flat['mR_Msun'],old_flat_R_km=matched_flat['R_km'],
                old_flat_tail_Msun=matched_flat['flat_tail_Msun'],old_flat_sum_Msun=matched_flat['flat_sum_Msun']))
        pd.DataFrame(rows).to_csv(out/'source_to_infinity.csv',index=False)
        pd.DataFrame(summary).to_csv(out/'sequence_summary.csv',index=False)
        (out/'diagnostics.json').write_text(json.dumps(checks,indent=2))
        print(name,L,summary[-2:],flush=True)
    pd.DataFrame(budgets).to_csv(out/'mass_budget.csv',index=False)
    pd.concat(profiles).to_csv(out/'exterior_profiles.csv',index=False)
    df=pd.DataFrame(rows); fig,axs=plt.subplots(1,2,figsize=(11,4.6),sharey=True)
    for ax,name in zip(axs,['SLy','APR4']):
      for L,color in [(1.,'tab:blue'),(10.,'tab:red')]:
        for mode,ls in [('curved','-'),('flat','--')]:
          d=df[(df.EOS==name)&(df.L_km==L)&(df['mode']==mode)].sort_values('logrho')
          mass=d.M_ADM_Msun if mode=='curved' else d.mR_Msun
          ax.plot(d.R_km,mass,ls,color=color,label=f'L={L:g} km, '+('ADM, curved exterior' if mode=='curved' else 'm(R), flat Robin'))
          bad=~d.causal
          ax.scatter(d.loc[bad,'R_km'],mass[bad],s=13,marker='x',color=color)
      ax.axhline(1.4,color='gray',lw=.7); ax.set(title=name,xlabel='Areal fluid radius R [km]'); ax.grid(alpha=.2); ax.legend(fontsize=7)
    axs[0].set_ylabel('Mass [solar masses]'); fig.suptitle('Local action-derived Yukawa branch; x = EOS acausal\nRising branches are stability candidates only; no dynamical mode calculation',fontsize=10)
    fig.tight_layout(); fig.savefig(out/'mass_radius.png',dpi=190); plt.close(fig)
    metadata=dict(zip_sha256=hashlib.sha256(Path(args.zip).read_bytes()).hexdigest(),alpha_Y=1,tilde_alpha='alpha_Y/(8*pi)',solver='scipy.solve_bvp two-domain nonlinear collocation',default_tol=2e-7,default_tail_L=18,
      numpy=np.__version__,scipy=__import__('scipy').__version__,python=sys.version,stability='dM_ADM/drho_c positive is a candidate, NOT proof of dynamical stability')
    (out/'run_metadata.json').write_text(json.dumps(metadata,indent=2))

if __name__=='__main__': main()
