#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/manuscript"
for language in EN HU; do
  xelatex -interaction=nonstopmode -halt-on-error "binding_energy_${language}.tex"
  xelatex -interaction=nonstopmode -halt-on-error "binding_energy_${language}.tex"
done
