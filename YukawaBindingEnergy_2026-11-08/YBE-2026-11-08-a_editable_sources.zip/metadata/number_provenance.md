# Printed-number provenance

- Tables 1–2 and their narrative rounded contrasts: `data/comparisons.csv`; exact row map in `article_numbers.csv`. Table 1 E_GR,0 is `GR_Ebind_1e51erg` from `common_ADM_1p4`; MB,0 is `target_Msun` from `common_MB_GR1p4`. The last column scales `delta_MB_Msun` by 1000. The two delta-energy columns refer to distinct matching rules.
- Table 3 limits, causal peak statements: `data/sequence_summary.csv`; masses and log-density columns are copied directly, not stable-mass inferences.
- Table 4 sensitivity maxima/counts: `data/convergence.csv`, grouped by `test`; the re-executed changes are in `validation/reproduced_convergence.csv`. Tiny last-bit differences do not alter the shown rounding.
- Total configurations, grid points, quadrature difference: `data/equilibrium_sequences.csv` and `validation/reproduced_checks.json`.
- Fresh consistency/control results: `validation/distribution_data_check.json` and `validation/distribution_control_check.json` (when the distribution check has been run). Earlier verified check values remain in `validation/reproduced_checks.json`.
- Native-enthalpy first law, target residuals and sound-speed flags: `reproduce.py --check`; stored reports include exact unrounded results.
- Interpolation: `data/interpolation_checks.csv` and `validation/recomputed_interpolation_checks.csv`; maxima by grid step are in `validation/selection_and_interpolation_checks.json`.
- Fixed-target projection, first-law slope and empirical sensitivity: `data/comparisons.csv`, `data/convergence.csv`, `validation/selection_and_interpolation_checks.json` and unchanged `code/binding_sequences.py`.
- Fine peak-window extrema: `data/peak_convergence.csv`; archived-only fit outputs, not a new refit. Their arithmetic was checked.
- Historical source-discretization MB difference: `data/source_crosschecks.csv`, latest_archive_density15 rows. Reference CSV is included at `code/source/curved_yukawa_adm_sequences.csv`. This historical mismatch is not equated with internal collocation sensitivity.
- EOS coefficients and constants: unchanged `code/source/stellar_tal_v21.py`, `code/binding_sequences.py`; EOS reference documented in `references.md`.

Displayed energy unit: 10^51 erg in result tables and bar contrasts, 10^53 erg on the energy–MB curve. One solar rest energy from the supplied constants is 1.787093668741279e54 erg. Rounding in prose and tables is for display, not a new calculation or precision claim.
