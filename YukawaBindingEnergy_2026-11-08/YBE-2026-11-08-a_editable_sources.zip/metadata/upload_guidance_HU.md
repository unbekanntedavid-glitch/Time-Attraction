# Kézi feltöltési útmutató az ellenőrzés után

Most nem történt feltöltés vagy publikálás. Előbb küldd el ellenőrzésre az együttes ZIP-et; ez nem elfogadott vagy lektorált közlemény.

## Zenodo

- Ellenőrzés után a + menüben válaszd a **New upload** lehetőséget ehhez a Yukawa-kötésienergia-munkához. Ne kapcsold automatikusan más tárgyú laboratóriumi korlát-rekordhoz, és ne használd annak DOI-ját.
- Fájlok: `binding_energy_EN.pdf` az angol kézirat, `binding_energy_HU.pdf` a magyar változat, `YBE-2026-11-08-a_data_code.zip` az adat/kód, `YBE-2026-11-08-a_editable_sources.zip` a szerkeszthető kézirat és ábraforrás. Az együttes ZIP-et az ellenőrzéshez használhatod; adattári feltöltésnél nem szükséges ugyanazon fájlokat több ZIP-ben is megismételni. EN és HU ugyanazon tanulmány két nyelvi változata, ne két független tudományos eredményként add meg.
- Típus: válaszd a preprintnek megfelelő kiadványtípust; ne adj meg folyóiratot vagy elfogadást, amely nincs igazolva. Cím és leírás: másold a `description_EN.txt` vagy `description_HU.txt` tartalmát a megfelelő mezőbe, a cím első sorát a címmezőbe.
- Szerző: családnév **Szabolcsi**, utónév **Dávid**, ORCID **0009-0005-6300-074X**. Intézményt csak valós, általad jóváhagyott adattal adj meg; a csomag nem talál ki affiliációt.
- Verziómező: **YBE-2026-11-08-a** (belső verzió). A kézirat dátuma **2026-11-08**; a Zenodo publication date az első nyilvános közzététel tényleges dátuma legyen, ha ez későbbi.
- DOI: nincs azonosító kiosztva. Ha ehhez a munkához valóban nincs DOI-d, az „already have a DOI” kérdésre **No** a helyes válasz. A **Get a DOI now!** csak a saját Zenodo-munkapéldányodban foglal valódi azonosítót. Itt ne másolj be kitalált számot vagy más mű azonosítóját. Kapcsolódóazonosító-mezőbe csak létező, ehhez a munkához igazolt kapcsolat kerüljön.
- Licenc: az alapértelmezett CC BY 4.0-t **Edit** segítségével cseréld **Creative Commons Attribution Non Commercial 4.0 International / CC-BY-NC-4.0** licencre. URL: https://creativecommons.org/licenses/by-nc/4.0/ . Jognyilatkozatként: “commercial use only with the author's written permission.”
- Kulcsszavak: neutron stars; binding energy; baryon mass; ADM mass; massive scalar; Yukawa interaction; piecewise-polytropic EOS; numerical reproducibility.
- Használd a **Save draft** és **Preview** lehetőséget, és nézd át a szerzőt, licencet, fájlokat és leírást. Nyilvános közzétételt csak saját döntésed és az ellenőrzés után indíts. A jelen csomag nem állítja, hogy ez megtörtént.

## Academia

- A saját fiókod feltöltési felületén az angol PDF legyen az elsődleges kézirat; a magyar PDF nyelvi változat. A pontos cím, szerző/ORCID és belső verzió ugyanaz legyen, mint a fájlban.
- Leírásként a megfelelő EN/HU szöveg másolható, az abban szereplő szerzői MI-nyilatkozattal és korlátokkal együtt. Ne jelöld peer-reviewed vagy accepted munkának.
- Az adat-/kód-ZIP csak akkor kerüljön kiegészítőként oda, ha a felület engedélyezi. Máskülönben egy később valóban létrehozott Zenodo-rekord hivatkozása adható meg; most nem találunk ki URL-t vagy DOI-t. EN/HU nem két független találat.
- Tartsd meg a PDF-láblécet és a CC BY-NC 4.0 licencet. Feltöltéshez sem küldtünk ki üzenetet, sem rekordot nem hoztunk létre.

## Hivatalos Zenodo-források, megnyitva: 2026-11-08

https://help.zenodo.org/docs/deposit/create-new-upload/
https://help.zenodo.org/docs/deposit/describe-records/licenses/
https://help.zenodo.org/docs/deposit/describe-records/reserve-doi/
