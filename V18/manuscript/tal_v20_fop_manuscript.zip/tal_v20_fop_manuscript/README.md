# TAL V20 manuscript for Foundations of Physics (Springer)

Author: David Szabolcsi (ORCID 0009-0005-6300-074X)

- `tal_v20_fop.tex` — LaTeX source (article class, 12 pt Times via mathptmx, 2.5 cm margins, line numbers, numbered `thebibliography`).
- `tal_v20_fop.pdf` — compiled manuscript (pdflatex/latexmk, TeX Live 2023).
- `fig1_signal_vs_L.pdf`, `fig2_convergence.pdf` — figures used by the .tex (copies with PNGs in `figures/`).
- `scripts/make_figs.py` — regenerates both figures from the archived CSVs in `final_report/csv/` (read-only inputs).

Build: `latexmk -pdf tal_v20_fop.tex`

Status: conditional design prediction (ideal current-sheet model); not a TAL detection, not a measured instrument sensitivity.
No ON/OFF/±I phase time series exist yet.
