# Regenerates manuscript figures from the archived CSVs (read-only inputs).
import csv, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.serif":["STIXGeneral","Times New Roman","DejaVu Serif"],"mathtext.fontset":"stix","font.size":10,"pdf.fonttype":42})
SRC="/workspace/artifacts/final_report/csv/"
# Fig 1
with open(SRC+"tal_differential_vs_L.csv",encoding="utf-8") as f: rows=list(csv.reader(f))[1:]
L=np.array([float(r[0]) for r in rows]); sg=np.array([float(r[4]) for r in rows]); sb=np.array([float(r[5]) for r in rows])
fig,ax=plt.subplots(figsize=(6.3,4.0))
ax.loglog(L,-sg,"-",color="C0",lw=1.5,label=r"$-\Delta f/f$, $\gamma_L=GL^2/c^2$")
ax.loglog(L,-sb,"--",color="C1",lw=1.2,label=r"$-\Delta f/f$, $\gamma=10^{-22}\,\mathrm{m^3\,kg^{-1}}$ (cross-check)")
i=np.argmax(-sg); ax.plot(L[i],-sg[i],"o",color="C0"); ax.annotate(r"$-1.20\times10^{-48}$ at $L=0.631$ m",(L[i],-sg[i]),xytext=(0.012,3e-47),fontsize=8,arrowprops=dict(arrowstyle="->",lw=0.6))
for x,lab in ((0.95,"0.95 m"),(2.6,"2.6 m")): ax.axvline(x,color="gray",ls=":",lw=0.8); ax.text(x*1.05,1e-60,lab,fontsize=7,color="gray",rotation=90)
ax.set_xlabel(r"averaging radius $L$ (m)"); ax.set_ylabel(r"$|\Delta f/f|$ (main $-$ reference), 14 mA/coil")
ax.set_ylim(1e-62,1e-40); ax.legend(fontsize=8,loc="upper right"); ax.grid(alpha=0.3,which="major")
fig.tight_layout(); fig.savefig("figs/fig1_signal_vs_L.pdf"); fig.savefig("figs/fig1_signal_vs_L.png",dpi=200)
# Fig 2
with open(SRC+"convergence_dW.csv",encoding="utf-8") as f: rows=list(csv.reader(f))[1:]
Lc=np.array([float(r[0]) for r in rows]); V=np.array([[float(x) for x in r[1:5]] for r in rows])
with open(SRC+"convergence_mc_shared_samples.csv",encoding="utf-8") as f: rows=list(csv.reader(f))[1:]
Lm=np.array([float(r[0]) for r in rows]); mv=np.array([float(r[1]) for r in rows]); me=np.array([float(r[2]) for r in rows])
with open(SRC+"tal_differential_vs_L.csv",encoding="utf-8") as f: rows=list(csv.reader(f))[1:]
Lg=np.array([float(r[0]) for r in rows]); dW=np.array([float(r[1]) for r in rows])
fig,(a1,a2)=plt.subplots(1,2,figsize=(6.5,3.2))
a1.loglog(Lg,dW,"-",color="k",lw=1,label=r"$\Delta W(L)/I^2$, base run")
labs=["24000 (base)","6000","12000","12000, radial $\\times2$"]; mk=["o","s","^","v"]
for j in range(4): a1.loglog(Lc,V[:,j],mk[j],ms=4,mfc="none",label=r"$n_{\rm hi}$="+labs[j])
a1.errorbar(Lm,mv,yerr=me,fmt="x",color="C3",ms=5,capsize=2,label="shared-sample MC ($\\pm1\\sigma$)")
a1.set_xlabel(r"$L$ (m)"); a1.set_ylabel(r"$\Delta W(L)/I^2$ (J A$^{-2}$)"); a1.legend(fontsize=6); a1.grid(alpha=0.3)
s=V.std(axis=1,ddof=1); m=V.mean(axis=1); rel=s/np.abs(m)
nz=rel>0
a2.semilogx(Lc[nz],rel[nz],"o-",color="C0",ms=4)
a2.semilogx(Lc[~nz],np.zeros((~nz).sum()),"o",mfc="none",color="gray",ms=4,label="0 (identical $n_{\\rm lo}$, $n_t$;\nnot a far-field error estimate)")
a2.set_xlabel(r"$L$ (m)"); a2.set_ylabel(r"$s/\overline{\Delta W}$ over 4 runs"); a2.legend(fontsize=6,loc="center right"); a2.grid(alpha=0.3)
fig.tight_layout(); fig.savefig("figs/fig2_convergence.pdf"); fig.savefig("figs/fig2_convergence.png",dpi=200)
print("peak",L[i],sg[i]); print(np.c_[Lc,rel])
