#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""BREN tower: report continuation operator applied to a Yukawa-modified source model.
Refinement of the V28 Step 27 flat half-space treatment (TAL, preliminary research).

Chain (all per unit G*rho, metres; multiplied by G and rho at the end):
  1. source model = uniform half-space below the tower-base plane + signed terrain prisms
     (Copernicus GLO-90, 54-km square, 301x301 cells of 180 m; outside: flat at the nearest-side
     mean, Kasameyer et al. 1989 p. 12), density rho;
  2. surface "data": Newtonian (N) and Yukawa (Y) vertical field at every station of a synthetic
     ring/sector survey with the counts of Kammeraad et al. 1990 p. 3, at the model surface;
  3. prediction on the tower with the report operator (eq. 7 of 1989 = eq. 2 of 1990), ring means
     times ring weights, observable relative to z0 = 9.8 m (Kammeraad 1990 p. 5);
  4. direct field on the tower (0,0,z);
  5. B_X(z) = [T_X(z) - T_X(z0)] - [P_X(z) - P_X(z0)] for X = N, Y;
  6. Newtonian terrain-bias correction applied as in the report (computed with G_lab, same rho):
     residual  Dg(z) = G_inf alpha rho [B_Y(z) - B_N(z)] = G_lab rho alpha/(1+alpha) [B_Y - B_N].
     Flat limit: B_Y -> 2 pi lambda (exp(-z/lambda) - exp(-z0/lambda)) (report hypothesis H), B_N -> 0.
"""
import json, math, os, sys, time, hashlib
import numpy as np
from multiprocessing import Pool
import bren_core as bc

HERE = os.path.dirname(os.path.abspath(__file__))
INP = os.path.join(HERE, "inputs"); OUT = os.path.join(HERE, "outputs")
os.makedirs(OUT, exist_ok=True)
REP = json.load(open(os.path.join(INP, "report_values.json")))
DIG = json.load(open(os.path.join(INP, "kammeraad1990_fig1_method1_digitized.json")))
V28 = json.load(open(os.path.join(INP, "v28_step27_reference.json")))

Q = 1.0 / (4.0 * math.pi)                    # alpha = q = alpha_Y^2 beta_Yuk (V28 model point)
LAM = 10.0e3
Z95 = 1.959963984540054
G_LAB = bc.G_LAB
UGAL = 1e8
Z0 = REP["kammeraad1990"]["z0_m"]
RHO_REPORT = REP["kammeraad1990"]["terrain_bias_model_density_kg_m3"]   # 2200
RHOS = [1800.0, 2000.0, 2200.0, 2670.0]
LAMS_SCAN = [300.0, 500.0, 1000.0, 2000.0, 3000.0, 5000.0, 7000.0, 10000.0, 15000.0, 20000.0, 30000.0, 50000.0]
Z_REPORT = [Z0] + DIG["z_m"]
Z_DENSE = [Z0] + list(np.arange(15.0, 465.0 + 1e-9, 5.0))
NPROC = int(os.environ.get("BREN_NPROC", os.cpu_count() or 1))
EPS_Z = 1e-3

def g_inf(alpha):
    return G_LAB / (1.0 + alpha)

# ---------------------------------------------------------------- V28 reproduction (flat half-space)
def v28_flat_residual_uGal(alpha, lam, rho, h):
    return -2.0 * math.pi * g_inf(alpha) * alpha * rho * lam * (1.0 - math.exp(-h / lam)) * UGAL

def alpha_lim_exact(K_uGal, E_uGal):
    """Exact root of Dg(alpha) = -K alpha/(1+alpha) = -E (K, E > 0): alpha_lim = E/(K-E)."""
    if E_uGal <= 0: return 0.0
    if E_uGal >= K_uGal: return math.inf
    return E_uGal / (K_uGal - E_uGal)

def k90_points_diag_cov():
    """Digitised K90 Fig. 1 method-1 points: mean vector and the only covariance available (diagonal,
    sigma^2). The off-diagonal elements are unpublished; the single-point test below does not use them."""
    mu = np.array(DIG["Y_uGal"], float); s = np.array(DIG["sigma_uGal"], float)
    return mu, np.diag(s * s)

def single_point_edge(mu, cov, i, k):
    """Bound edge of a conditional single-point marginal comparison at point i with k-sigma:
    E = -(mu_i - k sqrt(cov_ii)). Only the marginal variance cov_ii of the pre-selected point enters;
    off-diagonal covariance (needed for a joint multi-point chi^2) does not. Tested by check_single_point_marginal.py."""
    return -(float(mu[i]) - k * math.sqrt(float(cov[i, i])))

def flat_H_per_alpha(lam, rho, z, z0):
    """Report hypothesis H(z,z0)/[alpha/(1+alpha)] with G_inf = G_lab/(1+alpha), in uGal."""
    return 2.0 * math.pi * G_LAB * rho * lam * (math.exp(-z / lam) - math.exp(-z0 / lam)) * UGAL

# ---------------------------------------------------------------- source model
def load_terrain(n):
    d = np.load(os.path.join(INP, f"bren_terrain_{n}.npz"))
    xc, h, cell = d["xc"], d["h"], float(d["cell"])
    c = (len(xc) - 1) // 2
    h_base = float(h[c, c])
    t = h - h_base
    half_sq = xc[-1] + cell / 2
    sides = {"N": float(t[-1, :].mean()), "S": float(t[0, :].mean()), "E": float(t[:, -1].mean()), "W": float(t[:, 0].mean())}
    return xc, t, cell, h_base, half_sq, sides

def outer_tiers(half_sq):
    """Single definition of the cell geometry outside the DEM square, shared by make_sets() (source prisms)
    and surface_height() (station heights). Per tier: (cell size cc, nh, inner half-width). Cell centres
    are the integer multiples m*cc, |m| <= nh - 0.5; cell m covers [(m - 1/2) cc, (m + 1/2) cc). A cell
    belongs to the tier if its centre lies outside the inner square (|X| > inner or |Y| > inner)."""
    c1 = 2 * half_sq / 27.0; n1h = 32.5                  # tier 1: 2.0 km cells to 65 km
    c2 = 5 * c1; n2h = 49.5                              # tier 2: 10 km cells to ~497 km
    return ((c1, n1h, half_sq), (c2, n2h, n1h * c1))

def side_height(XX, YY, sides):
    """Outside rule (K89 p. 12): flat at the mean of the nearest side, decided at the cell centre (XX, YY)."""
    return np.where(np.abs(XX) >= np.abs(YY), np.where(XX > 0, sides["E"], sides["W"]),
                    np.where(YY > 0, sides["N"], sides["S"]))

def make_sets(n=301, outside="per_side"):
    xc, t, cell, h_base, half_sq, sides = load_terrain(n)
    X, Y = np.meshgrid(xc, xc, indexing="xy")
    m = t != 0.0
    fine = {"xc": X[m], "yc": Y[m], "half": cell / 2, "cell": cell,
            "zb": np.minimum(t[m], 0.0), "zt": np.maximum(t[m], 0.0), "sgn": np.sign(t[m])}
    sets = [fine]; tiers = []
    if outside == "per_side":
        for cc, nh, inner in outer_tiers(half_sq):
            k = np.arange(-nh + 0.5, nh, 1.0) * cc
            XX, YY = np.meshgrid(k, k, indexing="xy")
            keep = (np.abs(XX) > inner) | (np.abs(YY) > inner)
            XX, YY = XX[keep], YY[keep]
            tt = side_height(XX, YY, sides)
            mm = tt != 0
            sets.append({"xc": XX[mm], "yc": YY[mm], "half": cc / 2, "cell": cc,
                         "zb": np.minimum(tt[mm], 0.0), "zt": np.maximum(tt[mm], 0.0), "sgn": np.sign(tt[mm])})
            tiers.append((cc, nh * cc, inner))
    info = {"n": n, "cell_m": cell, "h_base_m": h_base, "half_square_m": half_sq, "side_means_rel_base_m": sides,
            "outside": outside, "n_prisms": int(sum(len(s["xc"]) for s in sets))}
    return sets, (xc, t, cell, half_sq, sides, outside), info

def surface_height(x, y, geo):
    """Model-surface height (relative to the tower base) at (x, y), from the SAME cell geometry that
    make_sets() uses for the source prisms (prism centres m*cc).
    Containing cell: half-open intervals [c - h, c + h) in x and in y, i.e. a point on a shared cell edge
    belongs to the cell on its +x / +y side. Order: DEM square, tier 1, tier 2; outside every cell (or with
    outside != 'per_side' beyond the square) the surface is the tower-base plane (0). Cells of zero height
    carry no prism and give 0, consistent with make_sets()."""
    xc, t, cell, half_sq, sides, outside = geo
    lo = xc[0] - cell / 2
    i = math.floor((x - lo) / cell); j = math.floor((y - lo) / cell)
    if 0 <= i < len(xc) and 0 <= j < len(xc):
        return float(t[j, i])
    if outside != "per_side":
        return 0.0
    for cc, nh, inner in outer_tiers(half_sq):
        mx = math.floor(x / cc + 0.5); my = math.floor(y / cc + 0.5)     # containing cell index
        if abs(mx) <= nh - 0.5 and abs(my) <= nh - 0.5:
            XX = float(mx) * cc; YY = float(my) * cc                       # its centre, as in make_sets()
            if abs(XX) > inner or abs(YY) > inner:
                return float(side_height(XX, YY, sides))
    return 0.0

# ---------------------------------------------------------------- parallel field evaluation
_G = {}
def _init(sets, lams, near, nz, mid):
    _G["sets"] = sets; _G["lams"] = lams; _G["near"] = near; _G["nz"] = nz; _G["mid"] = mid

def _work(p):
    return bc.field_model(p, _G["sets"], _G["lams"], _G["near"], _G["nz"], _G["mid"])

def eval_points(points, sets, lams, near=6.0, nz=None, mid=24.0):
    with Pool(NPROC, initializer=_init, initargs=(sets, lams, near, nz, mid)) as pool:
        res = pool.map(_work, [tuple(p) for p in points], chunksize=8)
    N = np.array([r[0] for r in res]); Y = np.array([r[1] for r in res])
    return N, Y

# ---------------------------------------------------------------- one configuration
# Convergence configurations (name, keyword arguments of run_config); shared with check_station_surfaces.py.
CONV_CONFIGS = (("grid_151", dict(n=151)), ("grid_451", dict(n=451)), ("rings_x0.5", dict(scale=0.5)), ("rings_x2", dict(scale=2.0)),
                ("Rtrunc_60km", dict(R_trunc=60e3)), ("Rtrunc_120km", dict(R_trunc=120e3)), ("Rtrunc_480km", dict(R_trunc=480e3)),
                ("sector_3x3_within_4km", dict(sub=3)), ("quad_nz16_near12_mid48", dict(nz=16, near=12.0, mid=48.0)), ("outside_flat_at_base", dict(outside="flat")))

def station_points(n=301, scale=1.0, R_trunc=240.0e3, sub=1, outside="per_side"):
    """Source prisms and survey stations of one configuration. Station height = surface of the containing
    source cell (surface_height) + EPS_Z. Used by run_config() and by check_station_surfaces.py."""
    sets, geo, info = make_sets(n, outside)
    edges, M = bc.ring_layout(scale, R_trunc)
    st, ring_of, sec_of = bc.stations(edges, M, sub)
    zs = np.array([surface_height(x, y, geo) for x, y in st])
    spts = np.column_stack([st, zs + EPS_Z])
    return sets, geo, info, edges, M, st, ring_of, sec_of, zs, spts

def run_config(name, n=301, scale=1.0, R_trunc=240.0e3, sub=1, near=6.0, nz=None, outside="per_side", lams=(LAM,), mid=24.0):
    t0 = time.time()
    sets, geo, info, edges, M, st, ring_of, sec_of, zs, spts = station_points(n, scale, R_trunc, sub, outside)
    tz = sorted(set([round(z, 4) for z in Z_REPORT + Z_DENSE + [454.0]]))
    tpts = np.array([(0.0, 0.0, z) for z in tz])
    Ns, Ys = eval_points(spts, sets, list(lams), near, nz, mid)
    Nt, Yt = eval_points(tpts, sets, list(lams), near, nz, mid)
    nr = len(edges) - 1
    gN = bc.ring_means(Ns, ring_of, sec_of, nr)
    gY = np.array([bc.ring_means(Ys[:, k], ring_of, sec_of, nr) for k in range(len(lams))])
    out = {"name": name, "info": info, "n_rings": nr, "n_stations": int(len(st)), "R_trunc_m": R_trunc,
           "edges": edges, "M": M, "tz": np.array(tz), "Nt": Nt, "Yt": Yt, "gN": gN, "gY": gY, "lams": list(lams),
           "station_z_stats": {"min": float(zs.min()), "max": float(zs.max()), "mean_within_2km": float(zs[np.hypot(st[:, 0], st[:, 1]) < 2e3].mean())},
           "seconds": time.time() - t0}
    print(f"[{name}] {len(st)} stations, {len(tz)} tower pts, {info['n_prisms']} prisms, {out['seconds']:.1f} s", flush=True)
    return out

def operator_B(cfg, k_lam, spherical=True, zero_sum=False, bias="exact"):
    """Return dict z -> (B_Y, B_N, B_Yflat_op) relative to z0, per unit G*rho."""
    edges = cfg["edges"]; tz = cfg["tz"]; i0 = int(np.argmin(np.abs(tz - Z0)))
    def W(z):
        w = bc.ring_weights(edges, z, spherical)
        return w / w.sum() if zero_sum else w
    w0 = W(Z0)
    lam = cfg["lams"][k_lam]
    BY, BN, BYop = [], [], []
    for iz, z in enumerate(tz):
        dw = W(z) - w0
        BY.append((cfg["Yt"][iz, k_lam] - cfg["Yt"][i0, k_lam]) - dw @ cfg["gY"][k_lam])
        BN.append((cfg["Nt"][iz] - cfg["Nt"][i0]) - dw @ cfg["gN"])
        # flat model through the same operator: constant surface field 2 pi lambda
        BYop.append(2 * math.pi * lam * (math.exp(-z / lam) - math.exp(-Z0 / lam)) - dw.sum() * 2 * math.pi * lam)
    BY, BN, BYop = np.array(BY), np.array(BN), np.array(BYop)
    if bias == "linear":           # report: correction 'varied linearly with height' -> least-squares line through z0
        dz = tz - Z0
        BN = dz * (dz @ BN) / (dz @ dz)
    return BY, BN, BYop

def residual_uGal(B_Y, B_N, rho, alpha=Q):
    return g_inf(alpha) * alpha * rho * (B_Y - B_N) * UGAL

def K_uGal(B_Y, B_N, rho):
    """Dg = -K alpha/(1+alpha): K = -G_lab rho (B_Y - B_N)."""
    return -G_LAB * rho * (B_Y - B_N) * UGAL

def zi(cfg, z):
    return int(np.argmin(np.abs(cfg["tz"] - z)))

# ---------------------------------------------------------------- self tests
def self_tests():
    T = {}
    A = lambda p, *b: bc.prism_newton_gz(*p, *[np.array([v]) for v in b])[0]
    def brute(p, b, n=160, lam=None):
        x1, x2, y1, y2, z1, z2 = b
        xs = np.linspace(x1, x2, n + 1); xs = .5 * (xs[1:] + xs[:-1]); ys = np.linspace(y1, y2, n + 1); ys = .5 * (ys[1:] + ys[:-1])
        zz = np.linspace(z1, z2, n + 1); zz = .5 * (zz[1:] + zz[:-1])
        X, Y, Z = np.meshgrid(xs, ys, zz, indexing="ij"); dv = (x2 - x1) * (y2 - y1) * (z2 - z1) / n ** 3
        d = np.sqrt((X - p[0]) ** 2 + (Y - p[1]) ** 2 + (Z - p[2]) ** 2); k = (p[2] - Z) / d ** 3
        if lam: k = k * (1 + d / lam) * np.exp(-d / lam)
        return float(k.sum() * dv)
    b = (0.0, 180.0, 0.0, 180.0, 0.0, 60.0); p = (90.0, 300.0, 100.0)
    T["prism_vs_brute_rel"] = abs(A(p, *b) / brute(p, b) - 1)
    S = {"xc": np.array([90.0]), "yc": np.array([90.0]), "half": 90.0, "cell": 180.0, "zb": np.array([0.0]), "zt": np.array([60.0]), "sgn": np.array([1.0])}
    Nn, Yn = bc.field_prisms(p, S, [1000.0], near_cells=6.0)
    T["yukawa_near_vs_brute_rel_lam1km"] = abs(Yn[0] / brute(p, b, lam=1000.0) - 1)
    p2 = (90.0, 90.0 + 6 * 180.0, 300.0)
    Nn2, _ = bc.field_prisms(p2, S, [1e4], near_cells=10.0, mid_cells=10.0)
    Nm2, _ = bc.field_prisms(p2, S, [1e4], near_cells=0.0, mid_cells=10.0)
    T["mid_2x2_vs_analytic_rel_at_6cells"] = abs(Nm2 / Nn2 - 1)
    p3 = (90.0, 90.0 + 24 * 180.0, 300.0)
    Nn3, _ = bc.field_prisms(p3, S, [1e4], near_cells=30.0, mid_cells=30.0)
    Nf3, _ = bc.field_prisms(p3, S, [1e4], near_cells=0.0, mid_cells=0.0)
    T["column_far_vs_analytic_rel_at_24cells"] = abs(Nf3 / Nn3 - 1)
    # zoned scheme vs all-analytic on the real 301 terrain, prisms 1-27 km, tower 9.8 m -> 457.15 m
    sets, _, _ = make_sets(301); St = sets[0]
    def tw(**kw):
        a = bc.field_prisms((0.0, 0.0, 9.8), St, [1e4], **kw); c = bc.field_prisms((0.0, 0.0, 457.15), St, [1e4], **kw)
        return c[0] - a[0], c[1][0] - a[1][0]
    zn, zy = tw(); an, ay = tw(near_cells=1e9, mid_cells=1e9)
    T["zoned_vs_all_analytic_tower_diff_newton_uGal_rho2200"] = float((zn - an) * G_LAB * 2200 * UGAL)
    T["zoned_vs_all_analytic_tower_diff_yukawa_uGal_rho2200"] = float((zy - ay) * G_LAB * 2200 * UGAL)
    L = 3.0e5
    T["bouguer_slab_rel"] = abs(A((0, 0, 1e-3), -L, L, -L, L, -10.0, 0.0) / (2 * math.pi * 10.0) - 1)
    # operator: sum of weights of a single kernel to R vs analytic 1 - z/sqrt(R^2+z^2) (planar)
    e = np.array([0.0, 50.0, 1e3, 240e3]); z = 454.0
    T["planar_weight_sum_minus_analytic"] = abs(bc.ring_weights(e, z, False).sum() - (1 - z / math.hypot(240e3, z)))
    # operator on a harmonic field: buried point mass, planar kernel, fine rings -> must reproduce direct field
    D = 2000.0
    e = np.concatenate([[0.0], np.geomspace(1.0, 2e7, 4000)]); rc = np.sqrt(0.5 * (e[1:] ** 2 + e[:-1] ** 2))
    gs = D / (rc ** 2 + D ** 2) ** 1.5
    pred = bc.ring_weights(e, z, False) @ gs; direct = (D + z) / ((D + z) ** 2) ** 1.5
    T["harmonic_point_mass_rel"] = abs(pred / direct - 1)
    # same for a Yukawa point mass: operator does NOT reproduce it (non-harmonic)
    lam = 1e4
    fy = lambda d: (1 + d / lam) * np.exp(-d / lam)
    ds = np.sqrt(rc ** 2 + D ** 2); gsy = D / ds ** 3 * fy(ds)
    predy = bc.ring_weights(e, z, False) @ gsy; directy = 1 / (D + z) ** 2 * fy(D + z)
    T["yukawa_point_mass_rel_residual_lam10km"] = float(directy / predy - 1)
    return T

# ---------------------------------------------------------------- main
def main():
    t_start = time.time()
    res = {"title": "BREN tower: report continuation operator on a Yukawa source model (Step 27 refinement, V28 line, TAL)",
           "status": "preliminary research; numerical cross-checks with Academia Co-scientist (AI-assisted)",
           "model_point": {"alpha": Q, "lambda_m": LAM}, "z0_m": Z0}
    # 1. V28 reproduction
    rep = {}
    for rho in (2000.0, 2670.0):
        r = v28_flat_residual_uGal(Q, LAM, rho, 454.0)
        K = 2 * math.pi * G_LAB * rho * LAM * (1 - math.exp(-454.0 / LAM)) * UGAL
        E = -(V28["mu_uGal"] - V28["k_sigma"] * V28["sigma_uGal"])
        al = alpha_lim_exact(K, E)
        ref = V28[f"rho_{int(rho)}"]
        rep[f"rho_{int(rho)}"] = {"residual_uGal": r, "alpha_lim": al, "R": Q / al,
                                  "ref_residual_uGal": ref["model_residual_uGal"], "ref_alpha_lim": ref["alpha_lim"], "ref_R": ref["R"],
                                  "max_rel_diff": max(abs(r / ref["model_residual_uGal"] - 1), abs(al / ref["alpha_lim"] - 1), abs(Q / al / ref["R"] - 1))}
    res["v28_reproduction"] = rep
    res["self_tests"] = self_tests()
    print(json.dumps(res["v28_reproduction"], indent=1)); print(json.dumps(res["self_tests"], indent=1), flush=True)

    # 2. main configuration with lambda scan
    base = run_config("base", lams=tuple(LAMS_SCAN))
    k10 = base["lams"].index(LAM)
    res["base_config"] = {"info": base["info"], "n_rings": base["n_rings"], "n_stations": base["n_stations"],
                          "ring_edges_m": base["edges"].tolist(), "sectors_per_ring": base["M"].tolist(),
                          "station_z_stats_rel_base_m": base["station_z_stats"]}
    variants = {"A_spherical_raw": dict(spherical=True, zero_sum=False), "B_spherical_zero_sum": dict(spherical=True, zero_sum=True),
                "C_planar_raw": dict(spherical=False, zero_sum=False), "D_spherical_raw_linear_bias": dict(spherical=True, zero_sum=False, bias="linear")}
    tz = base["tz"]
    # Newtonian terrain bias (report check): G_lab rho B_N at the top, rho = 2200
    BY, BN, BYop = operator_B(base, k10, True, False)
    iz_top90 = zi(base, Z_REPORT[-1]); iz454 = zi(base, 454.0)
    res["newton_terrain_bias_check"] = {
        "rho_kg_m3": RHO_REPORT, "z_m": float(tz[iz_top90]),
        "direct_minus_continued_uGal": float(G_LAB * RHO_REPORT * BN[iz_top90] * UGAL),
        "report_value_uGal": REP["kammeraad1990"]["terrain_bias_uGal_top"], "report_sigma_uGal": REP["kammeraad1990"]["terrain_bias_sigma_uGal"],
        "kasameyer1989_rho1800_uGal_at_454": float(G_LAB * 1800.0 * BN[iz454] * UGAL), "kasameyer1989_report_value_uGal": 100.0,
        "note": "report: method 1 'underestimates the calculated magnitude' of the tower difference; here direct minus continued, Newtonian, same terrain model idea, modern DEM and synthetic rings"}
    # tables at report heights and dense curve
    tables = {}
    for vn, kw in variants.items():
        BY, BN, BYop = operator_B(base, k10, **kw)
        rows = []
        for z in Z_REPORT + [454.0]:
            i = zi(base, z)
            row = {"z_m": float(tz[i])}
            for rho in RHOS:
                fl = Q / (1 + Q) * flat_H_per_alpha(LAM, rho, tz[i], Z0)
                co = residual_uGal(BY[i], BN[i], rho)
                op = residual_uGal(BYop[i], 0.0, rho)
                row[f"rho_{int(rho)}"] = {"flat_uGal": fl, "continuation_uGal": co, "diff_uGal": co - fl, "rel_diff": (co - fl) / fl if fl else 0.0,
                                          "operator_only_uGal": op - fl, "terrain_part_uGal": co - op}
            rows.append(row)
        tables[vn] = rows
    res["tables_lambda10km"] = tables
    BY, BN, BYop = operator_B(base, k10, True, False)
    _, _, BYopB = operator_B(base, k10, True, True)
    BYb, BNb, _ = operator_B(base, k10, True, True)
    res["curve_lambda10km_rho2200"] = {"z_m": tz.tolist(),
        "flat_uGal": [Q / (1 + Q) * flat_H_per_alpha(LAM, RHO_REPORT, z, Z0) for z in tz],
        "contA_uGal": residual_uGal(BY, BN, RHO_REPORT).tolist(), "contB_uGal": residual_uGal(BYb, BNb, RHO_REPORT).tolist(),
        "opA_only_uGal": residual_uGal(BYop, 0.0, RHO_REPORT).tolist(),
        "newton_bias_uGal": (G_LAB * RHO_REPORT * BN * UGAL).tolist()}
    # weights at the top (diagnostic vs Kammeraad Fig. 2b)
    wtop = bc.ring_weights(base["edges"], tz[iz_top90]) - bc.ring_weights(base["edges"], Z0)
    rc = np.sqrt(0.5 * (base["edges"][1:] ** 2 + base["edges"][:-1] ** 2))
    res["weights_top_minus_z0"] = {"r_center_m": rc.tolist(), "w": wtop.tolist(), "sum": float(wtop.sum()),
                                   "sum_expected_planar_trunc": float(-(tz[iz_top90] - Z0) / 240e3)}
    # bounds and R
    E89 = -(-REP["kasameyer1989"]["residual_top_uGal"] - Z95 * REP["kasameyer1989"]["residual_sigma_uGal"])
    zt90 = DIG["z_m"][-1]; i90 = len(DIG["z_m"]) - 1
    mu_vec, cov_diag = k90_points_diag_cov()
    E90 = single_point_edge(mu_vec, cov_diag, i90, Z95); E90_1s = single_point_edge(mu_vec, cov_diag, i90, 1.0)
    res["bounds"] = {"B89": {"z_m": 454.0, "edge_uGal": -E89, "text": "Kasameyer 1989: -93 +- 95 uGal (sign conservative), k = 1.96 (as V28)"},
                     "B90": {"z_m": zt90, "edge_uGal": -E90, "text": "Kammeraad 1990 Fig. 1 method 1 top point, digitized +3.5 +- 40.3 uGal, k = 1.96; conditional single-point marginal comparison (uses only this point's variance; not a reproduction of the K90 correlated chi^2 analysis)"}}
    Rtab = {}
    for vn, kw in variants.items():
        Rtab[vn] = {}
        for k, lam in enumerate(base["lams"]):
            BY, BN, BYop = operator_B(base, k, **kw)
            ent = {}
            for rho in RHOS:
                d = {}
                for bname, zb, E in (("B89", 454.0, E89), ("B90", zt90, E90)):
                    i = zi(base, zb)
                    Kc = K_uGal(BY[i], BN[i], rho); Kf = -flat_H_per_alpha(lam, rho, tz[i], Z0)
                    ac, af = alpha_lim_exact(Kc, E), alpha_lim_exact(Kf, E)
                    d[bname] = {"K_flat_uGal": Kf, "K_cont_uGal": Kc, "alpha_lim_flat": af, "alpha_lim_cont": ac,
                                "R_flat": (Q / af if af not in (0.0, math.inf) else None) if lam == LAM else None,
                                "R_cont": (Q / ac if ac not in (0.0, math.inf) else None) if lam == LAM else None}
                i = zi(base, zt90)
                d["B90_1sigma_alpha_lim_cont"] = alpha_lim_exact(K_uGal(BY[i], BN[i], rho), E90_1s)
                ent[f"rho_{int(rho)}"] = d
            Rtab[vn][str(int(lam))] = ent
    res["lambda_scan"] = Rtab
    res["report_alpha_limit_check_1km"] = {"report_1sigma_correlated_chi2": REP["kammeraad1990"]["alpha_limit_lambda_1km_1sigma"],
        "this_work_single_top_point_1sigma_rho2200_contA": Rtab["A_spherical_raw"]["1000"]["rho_2200"]["B90_1sigma_alpha_lim_cont"],
        "note": "different test constructions: conditional single-point marginal comparison at the top point vs the report's global multi-height correlated chi^2 fit (report p. 9); the difference is not attributed to the missing off-diagonal covariance alone"}

    # 3. convergence tests at lambda = 10 km
    conv = {}
    def top(cfg, kw=None):
        kw = kw or {}
        BY, BN, BYop = operator_B(cfg, 0, **kw)
        i = zi(cfg, zt90)
        BYb, BNb, _ = operator_B(cfg, 0, spherical=True, zero_sum=True)
        return {"contA_uGal_rho2200": residual_uGal(BY[i], BN[i], RHO_REPORT), "contB_uGal_rho2200": residual_uGal(BYb[i], BNb[i], RHO_REPORT),
                "newtonbias_uGal_rho2200": G_LAB * RHO_REPORT * BN[i] * UGAL,
                "terrain_part_uGal": residual_uGal(BY[i] - BYop[i], BN[i], RHO_REPORT), "n_stations": cfg["n_stations"], "n_rings": cfg["n_rings"]}
    b10 = dict(base); b10["Yt"] = base["Yt"][:, [k10]]; b10["gY"] = base["gY"][[k10]]; b10["lams"] = [LAM]
    conv["base"] = top(b10)
    for nm, kw in CONV_CONFIGS:
        conv[nm] = top(run_config(nm, **kw))
    res["convergence_lambda10km"] = conv
    res["runtime_s"] = time.time() - t_start
    # save
    def clean(o):
        if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)): return [clean(v) for v in o]
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, (np.integer,)): return int(o)
        if isinstance(o, np.ndarray): return clean(o.tolist())
        if isinstance(o, float) and (math.isinf(o) or math.isnan(o)): return None
        return o
    json.dump(clean(res), open(os.path.join(OUT, "bren_continuation_results.json"), "w"), indent=1)
    print("done", res["runtime_s"])

if __name__ == "__main__":
    main()
