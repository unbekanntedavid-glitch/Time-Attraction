#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Cross-platform runner: SHA-256 check of inputs/, then the light consistency tests (station surfaces,
single-point marginal test, projection metric), computation, figures/tables and numeric verification.
Outputs are verified numerically, not byte-compared.
Nothing is deleted; the checks run before any computation."""
import hashlib, os, subprocess, sys
here = os.path.dirname(os.path.abspath(__file__)); os.chdir(here)
bad = 0
for line in open("SHA256SUMS_inputs", encoding="utf-8"):
    if not line.strip(): continue
    h, name = line.split(None, 1); name = name.strip()
    if not os.path.isfile(name): print("MISSING", name); bad += 1; continue
    d = hashlib.sha256(open(name, "rb").read()).hexdigest()
    ok = d == h; bad += (not ok); print("OK  " if ok else "FAIL", name)
if bad: sys.exit("input check failed: %d file(s); nothing was run" % bad)
for step in ("check_station_surfaces.py", "check_single_point_marginal.py", "check_projection_metric.py",
             "bren_continuation.py", "make_figures.py", "verify_outputs.py"):
    print("==", step); r = subprocess.run([sys.executable, step])
    if r.returncode: sys.exit("%s failed (exit %d)" % (step, r.returncode))
print("all steps passed")
