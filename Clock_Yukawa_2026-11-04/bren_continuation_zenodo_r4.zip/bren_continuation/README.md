# bren_continuation: BREN tower, report continuation operator vs flat half-space (V28 Step 27 refinement)

Preliminary research, TAL V28 line. Numerical cross-checks with Academia Co-scientist (AI-assisted).

Station heights and source prisms come from one shared cell geometry; the single-point bounds are conditional
single-point marginal comparisons. Version notes: `changelog_EN.md`, `valtozasnaplo_HU.md`.
The large deviation reported here holds in the examined source and operator models and the chosen
single-point comparisons; it is not a full empirical reanalysis of the original experiment.

Methodology notes: `methodology_EN.md` and `methodology_HU.md`.

## Run

    python run_check.py   # Windows, Linux, macOS: SHA-256 check of inputs/, light consistency tests (~10 s), computation (~2-3 min on 8 cores),
                          # figures/tables, numeric verification against reference/
    ./run_all.sh          # same steps, Linux/macOS shell variant

Environment (`requirements.txt`): Python 3.13.5, NumPy 2.5.4, SciPy 1.18.1, matplotlib 3.11.2.
Set `BREN_NPROC` to change the number of worker processes.
Outputs are checked numerically by `verify_outputs.py`, with |d| <= 1e-6 + 1e-6·|ref| per numeric
field and timing fields skipped. They are not expected to be byte-identical (summation order, PDF/PNG
metadata, library builds).

## Files

| file | role |
|---|---|
| `bren_core.py` | prism kernels (Newton analytic, Yukawa), half-space, ring weights of the report operator, ring/sector layout |
| `bren_continuation.py` | V28 reproduction, self-tests, main configuration, variants A–D, λ scan, convergence runs → `outputs/bren_continuation_results.json` |
| `check_station_surfaces.py` | test: every station of the base and all convergence configurations at its containing source-prism surface + 1 mm → `outputs/check_station_surfaces.json` |
| `check_single_point_marginal.py` | test: the single-point bound edge does not change when unused off-diagonal covariance elements change → `outputs/check_single_point_marginal.json` |
| `check_projection_metric.py` | check: east–west metric change of the equirectangular DEM mapping on the full grids → `outputs/check_projection_metric.json` |
| `make_figures.py` | figures (PNG + PDF) and tables (CSV, Markdown) |
| `verify_outputs.py` | numeric verification and physics/consistency checks |
| `prepare_dem.py` | one-off preparation of `inputs/bren_terrain_*.npz` from Copernicus GLO-90 tiles (needs tifffile, imagecodecs; not part of run_all.sh) |
| `inputs/` | terrain grids, report values (with page numbers), digitised K90 Fig. 1, V28 reference numbers |
| `SOURCES.md` | links and SHA-256 of the two LLNL reports (not redistributed) |
| `run_check.py` | cross-platform runner (same steps as run_all.sh) |
| `SHA256SUMS_inputs` | input hashes checked by run_check.py / run_all.sh |
| `reference/reference_results.json` | reference numbers for verify_outputs.py |
| `outputs/` | results JSON, `fig_residual_curve`, `fig_weights`, `fig_lambda_scan`, `table_residuals_report_heights.csv`, `table_residuals_rho2200.md` |
| `changelog_EN.md`, `valtozasnaplo_HU.md` | version notes (EN / HU) |

## License

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Licensed under Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0): https://creativecommons.org/licenses/by-nc/4.0/ (legal code: https://creativecommons.org/licenses/by-nc/4.0/legalcode). All commercial, industrial and technological implementation rights are retained by the author; commercial use only with the author's written permission. Full text: `LICENSE.txt`. Third-party documents and data cited or included as sources remain under their own terms.

## Licenc

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Licenc: Creative Commons Nevezd meg! – Ne add el! 4.0 Nemzetközi (CC BY-NC 4.0): https://creativecommons.org/licenses/by-nc/4.0/deed.hu (jogi szöveg: https://creativecommons.org/licenses/by-nc/4.0/legalcode.hu). Valamennyi kereskedelmi, ipari és technológiai hasznosítási jogot a szerző fenntart; kereskedelmi hasznosítás kizárólag a szerző írásos engedélyével. A licenc szövege: `LICENSE.txt`. A forrásként idézett vagy mellékelt harmadik féltől származó dokumentumokra és adatokra azok saját feltételei vonatkoznak.
