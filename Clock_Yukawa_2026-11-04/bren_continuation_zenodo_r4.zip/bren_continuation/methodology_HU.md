# BREN-torony: a jelentés felfelé folytatási operátora Yukawa-forrásmodellen (a 27. lépés finomítása)

*Előzetes kutatási jegyzet, TAL V28 vonal. Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú).*

*A §6–§10 minden száma a csomag futásából származik (alapkonfiguráció és mind a 10 konvergencia-konfiguráció); változatleírás: `valtozasnaplo_HU.md`.*

## 1. Cél

A V28 27. lépése sík féltérrel veti össze a Yukawa-jelet a BREN-torony eredményével:
Δg(h) = −2π G∞ α ρ λ (1 − e^(−h/λ)). Az eredeti kísérlet másképp jár el. A felszíni gravitációs
felmérést Poisson-típusú operátorral felfelé folytatja a torony magasságaira, és ezt a jóslatot veti
össze a toronyban mért értékekkel. Ez a csomag ugyanarra a forrásmodellre alkalmazza a jelentés
operátorát, kiszámítja a Yukawa-tag felszíni és toronybeli válaszát, és a maradékot összeveti a sík
27. lépéses értékkel. Modellpont: α = q = 1/(4π) = 0,0795775, λ = 10 km.

## 2. Források

* [K89] Kasameyer és mtsai, „A Test of Newton's Law of Gravity Using the BREN Tower, Nevada”,
  UCRL-101001 (Moriond 1989 preprint), OSTI 6190822. Link és SHA-256: lásd `SOURCES.md` (nincs a csomagban).
* [K90] Kammeraad és mtsai, „New results from Nevada: a test of Newton's law using the BREN tower and a
  high density ground gravity survey”, UCRL-JC-103562, CONF-900183--4 (Moriond 1990), OSTI 6993119.
  Link és SHA-256: lásd `SOURCES.md` (nincs a csomagban).

Az átvett számok oldalszámmal együtt az `inputs/report_values.json` fájlban vannak. A K90 1. ábrájának
pontjait (1. módszer) digitalizáltam: `inputs/kammeraad1990_fig1_method1_digitized.json`.

## 3. Operátor (a jelentésekből átvéve, kiegészítés nélkül)

K89 7. egyenlet = K90 2. egyenlet (a gömbi Poisson-integrál z/a rendig kifejtve):

    Δg(z) = z(1 − 2z/a)/(2π) ∫∫ Δg(0, r′, φ) r′ dr′ dφ / [r′² + z²(1 − z/a)]^(3/2)

A jelentések gyűrűkre és szektorokra bontják az integrált. Minden i gyűrűre (r1, r2 sugarak) a
szektorállomások átlaga szorzódik a kernel pontos gyűrűintegráljával:

    K_i(z) = z(1 − 2z/a) [ (r1² + b²)^(−1/2) − (r2² + b²)^(−1/2) ],   b² = z²(1 − z/a),   a = 6371 km.

Csonkítás: R_trunc = 240 km (K90). A megfigyelt mennyiség z0 = 9,8 m-re vonatkozik (K90 5. o.):
Y(z, z0) = [g_mért − g_jósolt](z) − [·](z0). A K90 7. egyenlete a Yukawa-hipotézist
H = 2πρGαλ(e^(−z/λ) − e^(−z0/λ)) alakban adja meg. Ez a sík féltér alakja, ugyanaz, mint a 27. lépésben.

Gyűrűkiosztás. A K90 a darabszámokat közli, a sugarakat nem: 150 m alatt 8 gyűrű 27 szektorral,
150 m és 10 km között 21 gyűrű 36 szektorral, 200 km-nél legfeljebb 70 szektor. Itt a sugarak mértani
sorozatot alkotnak (az első gyűrű a 0–37 m-es korong), 10 és 240 km között pedig 16 gyűrű fut 36 → 70
szektorral. Ez összesen 45 gyűrű és 1838 állomás. **Feltevés:** a sugarakat a jelentések nem közlik.

## 4. Forrásmodell

* Homogén féltér a toronytalp síkja alatt, ρ sűrűséggel. A Yukawa-tere felette 2πGαλρ e^(−z/λ).
  A newtoni tere a jelentésekhez hasonlóan a referencia-ellipszoidba olvad.
* Előjeles domborzati hasábok. Copernicus GLO-90 DEM (EGM2008 magasságok; a csempék SHA-256 összege az
  `inputs/terrain_meta.json` fájlban), 301 × 301 darab 180 m-es cella (54 km-es négyzet, mint K89 12. o.,
  de páratlan darabszámmal, hogy a torony cellaközépre essen). Minden cella 4 × 4 bilineáris minta
  átlaga („simított domborzat”). A négyzeten kívül a felszín a legközelebbi oldal átlagmagasságán sík
  (mint K89-ben), 65 km-ig 2,0 km-es, kb. 500 km-ig 10 km-es cellákkal. **Eltérés:** a jelentések
  1983-as USGS-szintvonalas adatot és 15″-es rácsot, valamint 1,8 / 2,2 g cm⁻³ sűrűséget használtak.
* A torony helye: é. sz. 36,78059°, ny. h. 116,24359° (GeoNames 7282248 / Wikidata Q796933).
* Az állomások a szektorközepeken ülnek, az őket tartalmazó forráscella felszínén (+1 mm). Az
  állomásmagasság és a forráshasábok ugyanabból a cellageometriából származnak. Ellenőrzés az alap- és mind a tíz konvergenciakonfigurációra: `check_station_surfaces.py`.

Kernelek:
* Newton: zárt alakú hasábképlet (Nagy/Plouff típusú) 6 cellányi távolságig; 6 és 24 cella között
  2 × 2 × 8 Gauss-pont; azon túl 1 × 8 pontos Gauss-oszlop.
* Yukawa: a pontkernel szorozva az f(d) = (1 + d/λ) e^(−d/λ) tényezővel. A közeli hasábokra az analitikus
  newtoni érték mínusz egy sima (1 − f) kvadratúrás korrekció.

## 5. Maradék

Rögzített G_lab mellett G∞ = G_lab/(1 + α). X = N (Newton) és X = Y (Yukawa) esetén, egységnyi Gρ-ra:

    B_X(z) = [T_X(z) − T_X(z0)] − [P_X(z) − P_X(z0)]      (T: közvetlen toronyérték, P: folytatott érték)

A jelentések a newtoni domborzati torzítást (közvetlen mínusz folytatott) G_lab-bal és ugyanazzal a
sűrűséggel számolják, és korrekcióként alkalmazzák (K90 4. o.). A Yukawa-maradék ezért

    Δg(z) = G∞ α ρ [B_Y(z) − B_N(z)].

Sík határesetben B_Y → 2πλ(e^(−z/λ) − e^(−z0/λ)) és B_N → 0, ami visszaadja a 27. lépés / K90 7. egyenlet
alakját.

Változatok:
* A: gömbi kernel, nyers súlyok.
* B: nulla összegűre normált súlyok. A K90 2(b) ábrája szerint „a súlyok összege nulla”; 240 km-es
  csonkításnál a nyers összeg −0,00197.
* C: síkbeli kernel.
* D: mint A, de a newtoni torzításra lineáris legkisebb négyzetes illesztéssel, mert a K90 szerint a
  torzítás „lineárisan változott a magassággal”.

## 6. Ellenőrzések

| ellenőrzés | eredmény |
|---|---|
| V28 27. lépés visszaállítása (ρ = 2000 és 2670; maradék, α_lim, R) | relatív eltérés 0 |
| analitikus hasáb vs. nyers erő | 8,7e-6 |
| Yukawa közeltér vs. nyers erő (λ = 1 km) | 5,2e-5 |
| zónás vs. csupa analitikus toronykülönbség, ρ = 2200 | −0,23 µGal (N), −0,23 µGal (Y) |
| harmonikus pontforrás az operátoron át | 1,8e-6 |
| Yukawa pontforrás az operátoron át (λ = 10 km) | −0,47 % (nem harmonikus maradék, várt) |
| **newtoni domborzati torzítás, közvetlen − folytatott, csúcs, ρ = 2200** | **137,6 µGal (jelentés: 140 ± 20 µGal)** |
| ugyanez 454 m-en, ρ = 1800 | 111,9 µGal (K89: kb. 100 µGal) |

A newtoni torzítást nem hangoltam. A K90-nel való egyezése független ellenőrzése az operátornak, a
gyűrűkiosztásnak és a domborzati modellnek.

## 7. Eredmények (λ = 10 km, α = 0,0796, ρ = 2200 kg m⁻³)

Az értékek µGal-ban vannak, z0 = 9,8 m-hez viszonyítva. A táblázat a K90 1. ábrájának digitalizált
magasságait és a 454 m-t tartalmazza. A ρ = 1800, 2000 és 2670 értékei az
`outputs/table_residuals_report_heights.csv` fájlban vannak.

| z (m) | sík | folyt. A | A − sík | folyt. B | B − sík | A csak operátor | domborzati rész |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 43,70 | −229,9 | −213,8 | +16,1 | −224,0 | +5,9 | +10,1 | +5,9 |
| 88,30 | −531,2 | −494,3 | +36,9 | −517,8 | +13,4 | +23,5 | +13,4 |
| 130,45 | −814,8 | −758,4 | +56,4 | −794,5 | +20,3 | +36,1 | +20,3 |
| 173,30 | −1101,8 | −1025,7 | +76,0 | −1074,7 | +27,1 | +48,9 | +27,1 |
| 216,15 | −1387,6 | −1291,9 | +95,6 | −1353,7 | +33,9 | +61,8 | +33,9 |
| 257,05 | −1659,2 | −1544,9 | +114,3 | −1618,8 | +40,3 | +74,0 | +40,3 |
| 300,25 | −1944,9 | −1810,9 | +134,0 | −1897,8 | +47,1 | +86,9 | +47,1 |
| 344,15 | −2234,0 | −2079,9 | +154,0 | −2179,9 | +54,0 | +100,1 | +54,0 |
| 386,35 | −2510,7 | −2337,4 | +173,3 | −2450,0 | +60,6 | +112,7 | +60,6 |
| 428,45 | −2785,5 | −2593,2 | +192,4 | −2718,4 | +67,2 | +125,3 | +67,2 |
| 457,15 | −2972,3 | −2766,9 | +205,4 | −2900,6 | +71,6 | +133,9 | +71,6 |
| 454,00 | −2951,8 | −2747,8 | +204,0 | −2880,6 | +71,2 | +133,0 | +71,2 |

Értelmezés:
* **Csak operátor rész (A változat):** a sík modell a csonkított operátoron átvezetve. A közel állandó
  Yukawa-felszíni tér (ρ = 2200 mellett kb. 68 mGal) és a 240 km-es csonkítás súlyhiányának szorzata a
  csúcson kb. +134 µGal. Ez az operátor megvalósításának tulajdonsága, nem a domborzaté, és függ
  R_trunc-tól (lásd a konvergenciát). A nulla összegű súlyok (B) eltüntetik.
* **Domborzati rész:** a csúcson kb. +72 µGal (a sík érték 2,4 %-a). Minden változatban ugyanaz.
  A sík értékhez hasonlóan lineárisan arányos ρ-val, ezért a relatív változás nem függ ρ-tól.
* Minden magasságon a folytatásos maradék előjele azonos a sík értékével, abszolút értéke pedig kisebb:
  2,4–2,6 %-kal (B) és 6,9–7,0 %-kal (A).

## 8. R = q/α_lim (feltételes, egypontos, k = 1,96)

α_lim = E/(K − E), mint a V28-ban, ahol K a maradék α/(1 + α)-ra eső együtthatója a korlát magasságán.

* B89 korlát: a K89 „93 ± 95 µGal” értéke konzervatív előjellel, −93 − 1,96·95 = −279,2 µGal 454 m-en.
  Ezt a korlátot használja a V28.
* B90 korlát: a K90 1. ábrájának legfelső pontja (1. módszer), digitalizálva +3,5 ± 40,3 µGal
  457,15 m-en, ami −75,5 µGal-os határt ad. Ez feltételes egypontos marginális összevetés egy előre
  rögzített magasságon. Csak a pont saját varianciáját használja; a többi magassággal való
  off-diagonális kovariancia egypontos marginális tesztbe nem lép be (`check_single_point_marginal.py`:
  a határ nem változik, ha rögzített diagonális mellett a nem használt off-diagonális elemeket
  megváltoztatjuk). Nem a K90 korrelált, többpontos χ²-elemzésének reprodukciója; az minden magasságot
  együtt illeszt, és ehhez kell a kovariancia. A K90 9. oldala arra figyelmeztet, hogy egy ilyen közös
  illesztésben a pontok függetlenként kezelése túl erősnek látszó korlátokat ad. A pont kiválasztásából,
  a hibasáv jelentéséből vagy a szisztematikák lefedéséből adódó esetleges problémákat itt nem vizsgáljuk.

| ρ | korlát | R sík (z0 = 9,8 m) | R A | R B | R C | R D |
|---:|---|---:|---:|---:|---:|---:|
| 2000 | B89 | 10,297 | 9,580 | 10,046 | 9,605 | 9,580 |
| 2670 | B89 | 13,773 | 12,815 | 13,439 | 12,849 | 12,816 |
| 2000 | B90 | 38,564 | 35,894 | 37,633 | 35,986 | 35,896 |
| 2670 | B90 | 51,510 | 47,945 | 50,266 | 48,069 | 47,948 |

A V28 27. lépés értékei (z0 = 0, azaz 1 − e^(−h/λ)) R = 10,531 (ρ = 2000) és 14,085 (ρ = 2670); mindkettő
pontosan visszaáll. Már a z0 = 9,8 m-es viszonyítás önmagában 2,2 %-kal csökkenti R-t. A folytatás
ezt további −7,0 %-kal (A) vagy −2,4 %-kal (B) módosítja. A ρ = 1800 és 2200 értékek:
`outputs/table_residuals_rho2200.md`.

λ-pásztázás (ρ = 2000, B89, α_lim sík → A / B):

| λ | sík | A | B |
|---:|---:|---:|---:|
| 300 m | 0,01506 | 0,01504 | 0,01500 |
| 1 km | 0,00946 | 0,00952 | 0,00947 |
| 3 km | 0,00815 | 0,00838 | 0,00826 |
| 10 km | 0,00773 | 0,00831 | 0,00792 |
| 50 km | 0,00759 | 0,01014 | 0,00781 |

Az A változat csak-operátor tagja λ-val nő (csonkítás). A B változatban a változás 3 % alatt marad.
Összevetésként: a K90 λ = 1 km-nél |α| < 0,0032 értéket ad (1σ, korrelált χ²); az itteni egypontos
1σ érték (B90, A, ρ = 2200) 0,00113. Ez két eltérő tesztkonstrukció (közös, többmagasságú korrelált
χ²-illesztés, illetve feltételes egypontos marginális összevetés). A különbség ezért nem tulajdonítható
pusztán a hiányzó off-diagonális kovarianciának, és a két szám közvetlenül nem összemérhető.

## 9. Konvergencia (λ = 10 km, ρ = 2200, csúcs 457,15 m)

| konfiguráció | folyt. A (µGal) | folyt. B (µGal) | newtoni torzítás (µGal) |
|---|---:|---:|---:|
| alap (301-es rács, 45 gyűrű, 240 km) | −2766,87 | −2900,62 | 137,6 |
| 151-es rács (360 m) | −2768,56 | −2902,32 | 165,6 |
| 451-es rács (120 m) | −2768,24 | −2902,00 | 138,3 |
| gyűrűk × 0,5 (22 gyűrű) | −2764,44 | −2898,19 | 107,4 |
| gyűrűk × 2 (90 gyűrű) | −2768,74 | −2902,50 | 165,4 |
| R_trunc 60 km | −2388,02 | −2901,56 | 156,3 |
| R_trunc 120 km | −2640,65 | −2901,00 | 142,5 |
| R_trunc 480 km | −2829,86 | −2900,32 | 131,1 |
| 3 × 3 alállomás 4 km-en belül (8174 áll.) | −2766,97 | −2900,72 | 143,1 |
| kvadratúra nz = 16, közel 12, közép 48 | −2766,87 | −2900,63 | 137,8 |
| a négyzeten kívül sík a talpszinten | −2767,17 | −2900,92 | 139,9 |

A B változat minden konfigurációban 2,44 µGal-on belül stabil. Az A változat a várakozásnak megfelelően
függ R_trunc-tól. A newtoni torzítás a gyűrűfelbontástól kb. ±30 µGal-lal függ, ami a jelentés
±20 µGal-jával azonos nagyságrend. A Yukawa-maradékban kiesik, mert B_Y és B_N ugyanazt az
állomáskiosztást használja.

## 10. Értékelés

* A vizsgált forrás- és operátormodellekben az α = q, λ = 10 km modellpont reziduumai a választott
  egypontos összevetésekben továbbra is nagy eltérést adnak; ez nem az eredeti kísérlet átfogó empirikus
  újraelemzése (szintetikus gyűrűsugarak, modern helyettesítő DEM, homogén sűrűség, a valódi állomás- és
  adatlánc, illetve a közös mérési likelihood rekonstrukciója nélkül). A B89 korláttal szemben a
  feltételes R arány ρ = 2000-nél 10 körül (R = 9,58 A, 10,05 B), ρ = 2670-nél 13 körül (12,82 A,
  13,44 B) marad. A B90 feltételes egypontos marginális összevetéssel szemben 36–50.
* Ez a 27. lépés módszerének finomítása a vizsgált modelleken belül. A folytatás a z0-ra
  viszonyított sík értékhez képest kb. 2–7 %-kal, a V28 z0 = 0 értékéhez képest 4,6–9 %-kal csökkenti
  R-t. A maradékgörbe megtartja a sík alakot, a különbség közel lineárisan nő a magassággal.
* R feltételes arány egy jelentésbeli korláthoz, nem szigma-állítás.

## 11. Korlátok

* Szintetikus gyűrűsugarak; a valódi állomások nem elérhetők. A toronypontok kovarianciája nincs
  közölve, ezért nincs közös, többmagasságú χ²-illesztés; a korlátok feltételes egypontos marginális
  összevetések.
* A DEM-előkészítés (`prepare_dem.py`) helyi ekvidisztáns hengervetületet használ gömbön (R = 6371 km).
  Ez kelet–nyugati irányban nem távolságtartó: a helyi metrika változása ∓27 km északi eltolásnál
  +0,003159 / −0,003177 (kb. 0,32 %; `check_projection_metric.py`, a rácsok egészén). Ezt közöljük, nem
  korrigáljuk. Nem automatikusan ugyanekkora reziduumhiba; a hatásához helyi geodéziai vetülettel
  újragenerált DEM kellene, ezt a csomag nem végzi el (a nyers Copernicus-csempék nincsenek a csomagban).
* Modern DEM az 1983-as adat helyett; egyetlen homogén sűrűség. A valódi sűrűséganomáliák a megfigyelt
  mennyiségben kiesnek (benne vannak az adatban), a Yukawa-megfelelőjük viszont nem. Ezen a modellen
  belül ez a megfelelő B_Y része.
* Csak a függőleges komponens; gömbi hatás csak az (1 − 2z/a) kerneltényezőn át, mint a jelentésekben.
