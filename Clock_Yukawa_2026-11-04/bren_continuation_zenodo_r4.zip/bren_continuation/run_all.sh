#!/usr/bin/env bash
# BREN continuation package: input SHA-256 check, computation, figures/tables, numeric verification.
# Only the inputs (inputs/) are hash-checked; outputs are verified numerically with tolerances.
set -euo pipefail
cd "$(dirname "$0")"
echo "== input SHA-256 check"
sha256sum -c SHA256SUMS_inputs
echo "== light consistency tests (station surfaces, single-point marginal, projection metric)"
python3 check_station_surfaces.py
python3 check_single_point_marginal.py
python3 check_projection_metric.py
echo "== computation"
python3 bren_continuation.py
echo "== figures and tables"
python3 make_figures.py
echo "== numeric verification"
python3 verify_outputs.py
