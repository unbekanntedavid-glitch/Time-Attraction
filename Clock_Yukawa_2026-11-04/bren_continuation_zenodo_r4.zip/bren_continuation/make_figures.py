#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Figures and tables from outputs/bren_continuation_results.json (BREN continuation, Step 27 refinement)."""
import json, os, csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "outputs")
R = json.load(open(os.path.join(OUT, "bren_continuation_results.json")))
DIG = json.load(open(os.path.join(HERE, "inputs", "kammeraad1990_fig1_method1_digitized.json")))
plt.rcParams.update({"font.size": 9, "pdf.fonttype": 42, "svg.hashsalt": "bren", "path.simplify": False})

def save(fig, name):
    fig.savefig(os.path.join(OUT, name + ".png"), dpi=170, metadata={"Software": None})
    fig.savefig(os.path.join(OUT, name + ".pdf"), metadata={"Creator": "make_figures.py", "Producer": None, "CreationDate": None})
    plt.close(fig)

# ---- 1. residual curve
C = R["curve_lambda10km_rho2200"]; z = np.array(C["z_m"])
fl, A, B = np.array(C["flat_uGal"]), np.array(C["contA_uGal"]), np.array(C["contB_uGal"])
op, nb = np.array(C["opA_only_uGal"]), np.array(C["newton_bias_uGal"])
fig, ax = plt.subplots(1, 2, figsize=(10.0, 4.4))
a = ax[0]
a.plot(z, fl, "k-", lw=1.6, label="flat half-space (V28 Step 27 form, z0 = 9.8 m) / sík féltér")
a.plot(z, A, "C0--", lw=1.4, label="continuation A: spherical, raw weights / gömbi, nyers súlyok")
a.plot(z, B, "C3-.", lw=1.4, label="continuation B: zero-sum weights / nulla összegű súlyok")
a.errorbar(DIG["z_m"], DIG["Y_uGal"], yerr=DIG["sigma_uGal"], fmt="o", ms=3, color="0.4", capsize=2,
           label="Kammeraad et al. 1990 Fig. 1, method 1 (digitised) / digitalizált")
a.set_xlabel("height above tower base z (m) / magasság a torony talppontja felett")
a.set_ylabel("Δg(z) − Δg(z0)  (µGal)")
a.set_title("(a) Yukawa residual, α = 0.0796, λ = 10 km, ρ = 2200 kg/m³", fontsize=9)
a.legend(fontsize=6.5, loc="lower left"); a.grid(alpha=.3)
b = ax[1]
b.plot(z, A - fl, "C0--", lw=1.4, label="A − flat (sum) / összesen")
b.plot(z, B - fl, "C3-.", lw=1.4, label="B − flat = terrain part / domborzati rész")
b.plot(z, op - fl, "C2:", lw=1.6, label="A operator-only (flat model through A) / csak operátor")
b.plot(z, nb, "C1-", lw=1.0, label="Newtonian terrain bias (removed) / newtoni domborzati torzítás")
b.axhline(140, color="C1", lw=.6, ls="--"); b.text(20, 146, "report: 140 ± 20 µGal at top (ρ = 2200)", fontsize=6.5, color="C1")
b.set_xlabel("height above tower base z (m) / magasság a torony talppontja felett")
b.set_ylabel("difference / különbség  (µGal)")
b.set_title("(b) continuation minus flat; decomposition", fontsize=9)
b.legend(fontsize=6.5, loc="upper left"); b.grid(alpha=.3)
fig.suptitle("BREN tower: report continuation operator vs flat half-space. Preliminary research; numerical cross-checks with Academia Co-scientist (AI-assisted)", fontsize=8.5)
fig.tight_layout(rect=(0, 0, 1, .95)); save(fig, "fig_residual_curve")

# ---- 2. weights
W = R["weights_top_minus_z0"]
fig, a = plt.subplots(figsize=(6, 3.6))
rc, w = np.array(W["r_center_m"]), np.array(W["w"])
a.semilogx(rc, w, "o-", ms=3)
a.axhline(0, color="k", lw=.5)
a.set_xlabel("ring centre radius (m) / gyűrűközép sugara"); a.set_ylabel("w_i(457 m) − w_i(9.8 m)")
a.set_title(f"Ring weights, top minus z0 (cf. Kammeraad 1990 Fig. 2b); sum = {W['sum']:.6f}", fontsize=8.5)
a.grid(alpha=.3); fig.tight_layout(); save(fig, "fig_weights")

# ---- 3. lambda scan (rho = 2000, both bounds)
L = R["lambda_scan"]; lams = sorted(int(k) for k in L["A_spherical_raw"])
fig, a = plt.subplots(figsize=(6.4, 4.0))
for bnd, mk in (("B89", "o"), ("B90", "s")):
    f = [L["A_spherical_raw"][str(l)]["rho_2000"][bnd]["alpha_lim_flat"] for l in lams]
    a.loglog(lams, f, "k" + mk + "-", ms=3, lw=1, label=f"{bnd} flat / sík")
    for vn, col in (("A_spherical_raw", "C0"), ("B_spherical_zero_sum", "C3")):
        c = [L[vn][str(l)]["rho_2000"][bnd]["alpha_lim_cont"] for l in lams]
        a.loglog(lams, c, col + mk + "--", ms=3, lw=1, label=f"{bnd} continuation {vn[0]} / folytatás")
a.axhline(R["model_point"]["alpha"], color="C2", lw=1); a.text(320, R["model_point"]["alpha"] * 0.82, "α = q = 0.0796 (model point)", color="C2", fontsize=7)
a.set_ylim(1.5e-3, 0.6)
a.set_xlabel("λ (m)"); a.set_ylabel("α_lim (conditional, k = 1.96, ρ = 2000)")
a.set_title("Single-point conditional bound vs λ (not a sigma statement)", fontsize=8.5)
a.legend(fontsize=6, ncol=2, loc="upper right"); a.grid(alpha=.3, which="both"); fig.tight_layout(); save(fig, "fig_lambda_scan")

# ---- 4. tables (CSV + markdown)
rows = []
for vn in ("A_spherical_raw", "B_spherical_zero_sum", "C_planar_raw", "D_spherical_raw_linear_bias"):
    for r in R["tables_lambda10km"][vn]:
        for k, v in r.items():
            if not k.startswith("rho_"): continue
            rows.append([vn, f"{r['z_m']:.2f}", k[4:], f"{v['flat_uGal']:.3f}", f"{v['continuation_uGal']:.3f}", f"{v['diff_uGal']:.3f}",
                         f"{100 * v['rel_diff']:.3f}", f"{v['operator_only_uGal']:.3f}", f"{v['terrain_part_uGal']:.3f}"])
with open(os.path.join(OUT, "table_residuals_report_heights.csv"), "w", newline="") as fh:
    wr = csv.writer(fh, lineterminator="\n")
    wr.writerow(["variant", "z_m", "rho_kg_m3", "flat_uGal", "continuation_uGal", "diff_uGal", "rel_diff_percent", "operator_only_uGal", "terrain_part_uGal"])
    wr.writerows(rows)
md = ["| z (m) | flat (µGal) | cont. A (µGal) | A − flat | cont. B (µGal) | B − flat | A operator-only | terrain part |", "|---:|---:|---:|---:|---:|---:|---:|---:|"]
TA = R["tables_lambda10km"]["A_spherical_raw"]; TB = R["tables_lambda10km"]["B_spherical_zero_sum"]
for ra, rb in zip(TA, TB):
    va, vb = ra["rho_2200"], rb["rho_2200"]
    md.append(f"| {ra['z_m']:.2f} | {va['flat_uGal']:.1f} | {va['continuation_uGal']:.1f} | {va['diff_uGal']:+.1f} | {vb['continuation_uGal']:.1f} | {vb['diff_uGal']:+.1f} | {va['operator_only_uGal']:+.1f} | {vb['terrain_part_uGal']:+.1f} |")
md += ["", "R = q / alpha_lim (conditional, single point, k = 1.96):", "", "| rho | bound | R flat (z0 = 9.8 m) | R cont. A | R cont. B | R cont. C | R cont. D |", "|---:|---|---:|---:|---:|---:|---:|"]
for rho in ("1800", "2000", "2200", "2670"):
    for bnd in ("B89", "B90"):
        e = {vn: L[vn]["10000"][f"rho_{rho}"][bnd] for vn in L}
        md.append(f"| {rho} | {bnd} | {e['A_spherical_raw']['R_flat']:.3f} | " + " | ".join(f"{e[vn]['R_cont']:.3f}" for vn in L) + " |")
open(os.path.join(OUT, "table_residuals_rho2200.md"), "w").write("\n".join(md) + "\n")
print("figures and tables written")
