# bren_continuation r4: változatleírás (előzetes kutatás)

Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); új mérési adat nélkül.

## Mit tartalmaz ez a változat

- A `bren_continuation.py` a BREN-torony reziduumait számítja a jelentésbeli folytatási operátorral, Yukawa-módosított forrásmodellre (homogén féltér és előjeles domborzati hasábok): alapkonfiguráció, A–D változatok, λ-szkennelés és tíz konvergencia-konfiguráció. Az állomásmagasságok és a forráshasábok egyetlen közös cellageometriából származnak (`outer_tiers()`, `side_height()`, `surface_height()`).
- Három könnyű konzisztenciaellenőrzés fut a számítás előtt:
  - `check_station_surfaces.py`: az alap- és mind a tíz konvergencia-konfiguráció minden állomása az őt tartalmazó forráshasáb felszínén van (+1 mm) → `outputs/check_station_surfaces.json`.
  - `check_single_point_marginal.py`: az egypontos korlát határa hét kovarianciaszerkezetnél sem változik a fel nem használt off-diagonális elemekkel → `outputs/check_single_point_marginal.json`.
  - `check_projection_metric.py`: az ekvirektanguláris DEM-leképezés kelet–nyugati metrikaváltozása a rácsokon (+0,003159 / −0,003177 ∓27 km-nél; legfeljebb 0,0032) → `outputs/check_projection_metric.json`.
- A `make_figures.py` írja az ábrákat és táblákat; a `verify_outputs.py` minden numerikus kimenetet tűréssel vet össze a `reference/reference_results.json` fájllal (|d| ≤ 1e-6 + 1e-6·|ref|; nem véges érték és hiányzó kulcs hibának számít), és lefuttatja a fizikai/konzisztenciaellenőrzéseket.
- A B89/B90 korlátértékek feltételes egypontos marginális összevetések, nem az eredeti jelentés korrelált χ²-elemzésének reprodukciói. R feltételes arány egy jelentésbeli korláthoz, nem σ.
- Hatókör: az eltérés a vizsgált forrás- és operátormodelleken és a választott egypontos összevetéseken belül érvényes; szintetikus gyűrűsugarak, modern helyettesítő DEM és homogén sűrűség. Ez nem az eredeti kísérlet empirikus újraelemzése.
- r3: licenc (CC BY-NC 4.0, `LICENSE.txt`), semleges megfogalmazás (csak szöveg és licenc).
- r4 (csak szöveg): az általános MI-segítségre utaló megfogalmazás helyén mostantól „numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú)” (angolul „numerical cross-checks with Academia Co-scientist (AI-assisted)”) áll a README-ben, a módszertani jegyzetekben, ebben a változatleírásban, a `bren_continuation.py` által írt `status` mezőben (így az `outputs/bren_continuation_results.json` és a `reference/reference_results.json` fájlban) és a `fig_residual_curve` címében. Minden JSON-, CSV- és Markdown-táblázat minden számértéke azonos az r3-mal (feldolgozott összevetés); a `SHA256SUMS_inputs` bemeneti hash-ei változatlanok. Az `outputs/bren_continuation_results.json` új SHA-256-ja: a0cf690641b88737f924aa27dcfcb196939dc58447889ed0178eb533d1477f33.
