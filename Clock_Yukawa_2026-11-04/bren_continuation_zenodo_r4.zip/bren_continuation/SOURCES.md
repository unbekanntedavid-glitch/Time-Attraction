# External sources (not redistributed in this package)

The two LLNL reports are not included. Download them from OSTI if needed. The computation itself does not read them; all report values used are in `inputs/report_values.json` with page numbers.

| report | link | SHA-256 of the copy used |
|---|---|---|
| Kasameyer et al. 1989, UCRL-101001 | https://www.osti.gov/biblio/6190822 | bcd9b9a41c29184ca3f358fa2dc95fdd6f17474fa40872d2c912826ac390333f |
| Kammeraad et al. 1990, UCRL-JC-103562 | https://www.osti.gov/servlets/purl/6993119 | 7837be9dfe9a6fd76b4bb190434b7a9eb0aeca06ec69903fde3e8f1ed4d5efeb |
