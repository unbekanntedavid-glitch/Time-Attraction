#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Projection metric check for prepare_dem.py.

prepare_dem.py maps local plane coordinates to latitude/longitude with an equirectangular rule about the
tower: lat = lat0 + y/R, lon = lon0 + x/(R cos lat0), R = 6371 km (sphere). The local east-west scale at
northing y is therefore off by cos(lat0 + y/R)/cos(lat0) - 1 relative to true spherical east-west distance;
the north-south scale is exact on the sphere. This script evaluates that relative change on the full grids
(cell centres, cell edges and the 4 x 4 sub-sample positions used for the cell heights) of
inputs/bren_terrain_{151,301,451}.npz. It quantifies the declared distance accuracy only; it does NOT
compute the effect on the residuals (that would need a regenerated DEM; the raw Copernicus tiles are not
part of this package). The spherical vs ellipsoidal difference is not quantified here.
Output: outputs/check_projection_metric.json. Runs in < 1 s."""
import json, math, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
R_E = 6371.0e3                                   # as in prepare_dem.py
META = json.load(open(os.path.join(HERE, "inputs", "terrain_meta.json")))
LAT0 = math.radians(META["tower_lat"])

def rel(y):
    return np.cos(LAT0 + np.asarray(y) / R_E) / math.cos(LAT0) - 1.0

def main():
    res = {"test": "T_projection_metric: equirectangular east-west metric change over the full DEM grids", "lat0_deg": META["tower_lat"],
           "R_m": R_E, "at_y_m": {str(int(y)): float(rel(y)) for y in (-27000.0, 27000.0)}, "grids": {}}
    sub = (np.arange(4) + 0.5) / 4 - 0.5
    for n in (151, 301, 451):
        d = np.load(os.path.join(HERE, "inputs", f"bren_terrain_{n}.npz")); yc = d["yc"]; cell = float(d["cell"])
        ys = np.concatenate([yc, yc - cell / 2, yc + cell / 2] + [yc + b * cell for b in sub])
        r = rel(ys); rs = rel(np.concatenate([yc + b * cell for b in sub]))
        res["grids"][str(n)] = {"cell_m": cell, "y_extent_m": [float(ys.min()), float(ys.max())],
                                "rel_change_min": float(r.min()), "rel_change_max": float(r.max()),
                                "max_abs_rel_change": float(np.abs(r).max()),
                                "max_abs_rel_change_at_subsamples": float(np.abs(rs).max())}
    m = max(g["max_abs_rel_change"] for g in res["grids"].values())
    res["max_abs_rel_change_all_grids"] = m
    res["claim_lt_1e-4_holds"] = bool(m < 1e-4)
    res["note"] = "about 0.32 % local east-west metric change at the north/south edges; not automatically a residual error of the same size"
    os.makedirs(os.path.join(HERE, "outputs"), exist_ok=True)
    json.dump(res, open(os.path.join(HERE, "outputs", "check_projection_metric.json"), "w"), indent=1)
    print(json.dumps(res, indent=1))
    ok = abs(res["at_y_m"]["-27000"] - 0.003159) < 5e-7 and abs(res["at_y_m"]["27000"] + 0.003177) < 5e-7 and 3.1e-3 < m < 3.4e-3
    if not ok: sys.exit("projection metric check FAILED (value differs from the documented +0.003159 / -0.003177)")
    print("projection metric check passed: documented +0.003159 / -0.003177 at -/+27 km, max |change| %.6f on the full grids" % m)

if __name__ == "__main__":
    main()
