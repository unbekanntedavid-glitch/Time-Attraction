#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Station-height consistency test.

For the base configuration AND every convergence configuration of bren_continuation.py, each survey
station must sit at the surface of the source prism that contains it, plus EPS_Z. The containing prism is
found here independently of surface_height(): by brute-force footprint containment in the prism sets that
make_sets() returns (closed intervals |xc - x| <= half, |yc - y| <= half). A station inside no prism must have height 0
(tower-base plane or a zero-height cell, which carries no prism). If a station touches several prisms with
different heights (shared edge), the station height must be one of them and the case is counted.
Station points are produced by the same station_points() function that run_config() uses.
Output: outputs/check_station_surfaces.json. Exit code 0 = no mismatch. Single process, about 1 min."""
import json, os, sys, time
import numpy as np
sys.dont_write_bytecode = True
import bren_continuation as b

TOL_M = 1e-8

def check(name, kw):
    sets, geo, info, edges, M, st, ring_of, sec_of, zs, spts = b.station_points(**{k: v for k, v in kw.items() if k in ("n", "scale", "R_trunc", "sub", "outside")})
    mism, boundary, n_none = [], 0, 0
    for j, (x, y) in enumerate(st):
        found = []
        for S in sets:
            mask = (np.abs(S["xc"] - x) <= S["half"]) & (np.abs(S["yc"] - y) <= S["half"])
            if mask.any():
                found.extend((S["sgn"][mask] * (S["zt"][mask] - S["zb"][mask])).tolist())
        if not found:
            n_none += 1; ok = abs(zs[j]) <= TOL_M; h = 0.0
        elif max(found) - min(found) <= TOL_M:
            h = found[0]; ok = abs(zs[j] - h) <= TOL_M
        else:
            boundary += 1; ok = any(abs(zs[j] - f) <= TOL_M for f in found); h = found
        ok = ok and spts[j, 2] == zs[j] + b.EPS_Z
        if not ok:
            mism.append({"station": j, "x": float(x), "y": float(y), "station_surface_m": float(zs[j]), "prism_surface_m": h})
    return {"n_stations": int(len(st)), "n_prisms": info["n_prisms"], "mismatch_count": len(mism),
            "stations_on_shared_edge_with_different_heights": boundary, "stations_in_no_prism_height0": n_none,
            "station_z_rel_base_m": {"min": float(zs.min()), "max": float(zs.max())}, "mismatches": mism[:20]}

def main():
    t0 = time.time()
    res = {"test": "T_station_surfaces: station surface = containing source prism surface + EPS_Z", "EPS_Z_m": b.EPS_Z, "tol_m": TOL_M, "configs": {}}
    for name, kw in (("base", {}),) + tuple(b.CONV_CONFIGS):
        r = check(name, kw); res["configs"][name] = r
        print(f"[{'PASS' if r['mismatch_count'] == 0 else 'FAIL'}] {name}: {r['n_stations']} stations, "
              f"{r['mismatch_count']} mismatches, {r['stations_on_shared_edge_with_different_heights']} on shared edges, "
              f"{r['stations_in_no_prism_height0']} in no prism", flush=True)
    res["total_mismatches"] = sum(r["mismatch_count"] for r in res["configs"].values())
    res["seconds"] = time.time() - t0
    os.makedirs(b.OUT, exist_ok=True)
    json.dump(res, open(os.path.join(b.OUT, "check_station_surfaces.json"), "w"), indent=1)
    if res["total_mismatches"]:
        sys.exit(f"station surface check FAILED: {res['total_mismatches']} mismatches")
    print(f"station surface check passed ({res['seconds']:.0f} s)")

if __name__ == "__main__":
    main()
