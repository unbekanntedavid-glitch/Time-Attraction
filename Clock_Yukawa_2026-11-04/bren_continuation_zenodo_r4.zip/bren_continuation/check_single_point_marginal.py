#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Single-point marginal test vs joint multi-point test.

The B90 bound of bren_continuation.py is a conditional single-point marginal comparison at the
pre-selected top point of K90 Fig. 1 (method 1). It uses only that point's own variance. This script
checks, with the same function single_point_edge() that bren_continuation.py uses, that the bound edge
and the resulting alpha limit do NOT change when the unused off-diagonal covariance elements are changed
(diagonal held fixed; several positive-definite correlation structures). As a contrast it shows that a
joint multi-point generalised-least-squares amplitude test (an illustrative construction, NOT a
reproduction of the K90 correlated chi^2 analysis) does depend on the off-diagonal elements.
Output: outputs/check_single_point_marginal.json. Exit 0 = single-point edge invariant. Runs in < 1 s."""
import json, math, os, sys
import numpy as np
sys.dont_write_bytecode = True
import bren_continuation as b

def corr_uniform(n, r):
    return np.full((n, n), r) + (1 - r) * np.eye(n)

def corr_ar1(n, r):
    i = np.arange(n); return r ** np.abs(i[:, None] - i[None, :])

def main():
    mu, cov0 = b.k90_points_diag_cov(); n = len(mu); i = n - 1; s = np.sqrt(np.diag(cov0))
    z = np.array(b.DIG["z_m"]); lam = 1000.0; rho = b.RHO_REPORT
    H = np.array([b.flat_H_per_alpha(lam, rho, zz, b.Z0) for zz in z])       # flat shape per alpha/(1+alpha), uGal
    K = -H[i]
    E_ref = b.single_point_edge(mu, cov0, i, b.Z95); a_ref = b.alpha_lim_exact(K, E_ref)
    E1_ref = b.single_point_edge(mu, cov0, i, 1.0)
    rows, ok = [], True
    structs = [("diagonal", np.eye(n))] + [(f"uniform_{r:+.1f}", corr_uniform(n, r)) for r in (0.3, 0.6, 0.9)] \
              + [(f"ar1_{r:+.1f}", corr_ar1(n, r)) for r in (-0.9, 0.5, 0.9)]
    for name, C in structs:
        cov = C * np.outer(s, s)
        np.linalg.cholesky(cov)                                             # positive definite
        assert np.allclose(np.diag(cov), np.diag(cov0), rtol=1e-14, atol=0)              # same diagonal
        E = b.single_point_edge(mu, cov, i, b.Z95); E1 = b.single_point_edge(mu, cov, i, 1.0); a = b.alpha_lim_exact(K, E)
        Ci = np.linalg.inv(cov); F = H @ Ci @ H
        amp = float(H @ Ci @ mu / F); amp_sigma = float(1 / math.sqrt(F))  # joint GLS amplitude of alpha/(1+alpha)
        same = abs(E - E_ref) <= 1e-12 * abs(E_ref) and abs(E1 - E1_ref) <= 1e-12 * abs(E1_ref) and abs(a - a_ref) <= 1e-12 * abs(a_ref)
        ok &= same
        rows.append({"structure": name, "single_point_edge_uGal": E, "single_point_1sigma_edge_uGal": E1,
                     "single_point_alpha_lim_lam1km_rho2200_flat": a, "unchanged": bool(same),
                     "joint_GLS_amplitude": amp, "joint_GLS_amplitude_sigma": amp_sigma})
        print(f"[{'PASS' if same else 'FAIL'}] {name:14s} single-point edge {E:.6f} uGal, alpha_lim {a:.6g} | joint GLS sigma {amp_sigma:.4g}")
    sig = [r["joint_GLS_amplitude_sigma"] for r in rows]
    res = {"test": "T_single_point_marginal: single-point marginal edge invariant under changes of unused off-diagonal covariance",
           "point_index": i, "z_m": float(z[i]), "rows": rows, "single_point_invariant": bool(ok),
           "joint_GLS_sigma_range": [min(sig), max(sig)], "joint_depends_on_offdiagonal": bool(max(sig) / min(sig) - 1 > 1e-3),
           "note": "joint GLS rows are an illustrative contrast only; they are not a reproduction of the K90 correlated chi^2 limit"}
    os.makedirs(b.OUT, exist_ok=True)
    json.dump(res, open(os.path.join(b.OUT, "check_single_point_marginal.json"), "w"), indent=1)
    if not ok or not res["joint_depends_on_offdiagonal"]:
        sys.exit("single-point marginal check FAILED")
    print("single-point marginal check passed (joint GLS sigma range %.4g .. %.4g)" % tuple(res["joint_GLS_sigma_range"]))

if __name__ == "__main__":
    main()
