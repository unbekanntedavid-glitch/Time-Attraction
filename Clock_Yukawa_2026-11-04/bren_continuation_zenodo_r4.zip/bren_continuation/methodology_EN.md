# BREN tower: report continuation operator on a Yukawa source model (Step 27 refinement)

*Preliminary research note, TAL V28 line. Numerical cross-checks with Academia Co-scientist (AI-assisted).*

*All numbers in §6–§10 come from the run of this package (base and all 10 convergence configurations); version notes in `changelog_EN.md`.*

## 1. Purpose

V28 Step 27 compares a Yukawa signal with the BREN tower result using a flat half-space:
Δg(h) = −2π G∞ α ρ λ (1 − e^(−h/λ)). The original experiment does something else. It upward-continues
the surface gravity survey to the tower heights with a Poisson-type operator and compares that
prediction with the in-tower measurements. This package applies the report's operator to one source
model, computes both the surface and the tower response of a Yukawa term, and compares the residual
with the flat Step 27 value. Model point: α = q = 1/(4π) = 0.0795775, λ = 10 km.

## 2. Sources

* [K89] P. Kasameyer, J. Thomas, O. Fackler, M. Mugge, J. Kammeraad, M. Millett, B. Harris, D. Felske,
  "A Test of Newton's Law of Gravity Using the BREN Tower, Nevada", UCRL-101001 (Moriond 1989 preprint),
  OSTI 6190822. Link and SHA-256: see `SOURCES.md` (not redistributed).
* [K90] J. Kammeraad, P. Kasameyer, O. Fackler, D. Felske, R. Harris, M. Millett, M. Mugge, J. Thomas,
  "New results from Nevada: a test of Newton's law using the BREN tower and a high density ground gravity
  survey", UCRL-JC-103562, CONF-900183--4 (Moriond 1990), OSTI 6993119.
  Link and SHA-256: see `SOURCES.md` (not redistributed).

The numbers taken from them are in `inputs/report_values.json`, with page references. The Fig. 1
points of K90 (method 1) were digitised: `inputs/kammeraad1990_fig1_method1_digitized.json`.

## 3. Operator (taken from the reports; nothing added)

K89 eq. 7 = K90 eq. 2 (spherical Poisson expansion to order z/a):

    Δg(z) = z(1 − 2z/a)/(2π) ∫∫ Δg(0, r′, φ) r′ dr′ dφ / [r′² + z²(1 − z/a)]^(3/2)

The reports discretise this into rings and sectors. Each ring i (radii r1, r2) gets the mean of its
sector stations times the exact ring integral of the kernel:

    K_i(z) = z(1 − 2z/a) [ (r1² + b²)^(−1/2) − (r2² + b²)^(−1/2) ],   b² = z²(1 − z/a),   a = 6371 km.

Survey truncation: R_trunc = 240 km (K90). The observable is referenced to z0 = 9.8 m (K90 p. 5):
Y(z, z0) = [g_obs − g_pred](z) − [g_obs − g_pred](z0). K90 eq. 7 states the Yukawa hypothesis as
H = 2πρGαλ(e^(−z/λ) − e^(−z0/λ)). That is the flat half-space form, the same as Step 27.

Ring layout. K90 gives the counts but not the radii: 8 rings with 27 sectors below 150 m, 21 rings with
36 sectors from 150 m to 10 km, and up to 70 sectors at 200 km. Here the radii are geometric (first ring
= disc 0–37 m) and 16 rings run from 10 to 240 km with 36 → 70 sectors. That gives 45 rings and 1838
stations. **Assumption:** the reports do not publish the radii.

## 4. Source model

* A uniform half-space below the tower-base plane, density ρ. Yukawa field above it: 2πGαλρ e^(−z/λ).
  Its Newtonian field is taken as absorbed by the reference ellipsoid, as in the reports.
* Signed terrain prisms. Copernicus GLO-90 DEM (EGM2008 heights; tiles listed in
  `inputs/terrain_meta.json` with SHA-256), 301 × 301 cells of 180 m (a 54 km square, as in K89 p. 12,
  but with an odd count so the tower sits at a cell centre). Each cell is the mean of 4 × 4 bilinear
  samples ("smoothed terrain"). Outside the square: flat at the mean of the nearest side (as in K89),
  in 2.0 km cells to 65 km and 10 km cells to about 500 km. **Deviation:** the reports used 1983 USGS
  contour data and a 15″ grid, and 1.8 / 2.2 g cm⁻³.
* Tower location: 36.78059 N, 116.24359 W (GeoNames 7282248 / Wikidata Q796933).
* Stations sit at the sector centres, on the surface of the source cell that contains them (+1 mm).
  Station heights and source prisms come from the same cell geometry. Checked for the base
  and all ten convergence configurations by `check_station_surfaces.py`.

Kernels:
* Newton: closed-form prism (Nagy/Plouff type) up to 6 cells away; 2 × 2 × 8 Gauss nodes from 6 to
  24 cells; 1 × 8 Gauss column beyond that.
* Yukawa: the point kernel multiplied by f(d) = (1 + d/λ) e^(−d/λ). Near prisms use the analytic
  Newtonian value minus a smooth (1 − f) quadrature correction.

## 5. Residual

With G_lab fixed, G∞ = G_lab/(1 + α). For X = N (Newton) and X = Y (Yukawa), per unit Gρ:

    B_X(z) = [T_X(z) − T_X(z0)] − [P_X(z) − P_X(z0)]      (T: direct tower value, P: continued value)

The reports compute the Newtonian terrain bias (direct minus continued) with G_lab and the same
density, and apply it as a correction (K90 p. 4). The Yukawa residual is therefore

    Δg(z) = G∞ α ρ [B_Y(z) − B_N(z)].

In the flat limit, B_Y → 2πλ(e^(−z/λ) − e^(−z0/λ)) and B_N → 0, which gives back the Step 27 /
K90 eq. 7 form.

Variants:
* A: spherical kernel, raw weights.
* B: weights renormalised to zero sum. K90 Fig. 2(b) says "the sum of the weights is zero"; with
  truncation at 240 km the raw sum is −0.00197.
* C: planar kernel.
* D: as A, but with a linear least-squares fit of the Newtonian bias, since K90 says the bias "varied
  linearly with height".

## 6. Validation

| check | result |
|---|---|
| V28 Step 27 reproduction (ρ = 2000 and 2670; residual, α_lim, R) | rel. diff 0 |
| analytic prism vs brute force | 8.7e-6 |
| Yukawa near field vs brute force (λ = 1 km) | 5.2e-5 |
| zoned vs all-analytic tower difference, ρ = 2200 | −0.23 µGal (N), −0.23 µGal (Y) |
| harmonic point mass through the operator | 1.8e-6 |
| Yukawa point mass through the operator (λ = 10 km) | −0.47 % (non-harmonic remainder, expected) |
| **Newtonian terrain bias, direct − continued, top, ρ = 2200** | **137.6 µGal (report: 140 ± 20 µGal)** |
| same at 454 m, ρ = 1800 | 111.9 µGal (K89: about 100 µGal) |

The Newtonian bias was not tuned. Its agreement with K90 is an independent check of the operator,
the ring layout and the terrain model.

## 7. Results (λ = 10 km, α = 0.0796, ρ = 2200 kg m⁻³)

Values in µGal relative to z0 = 9.8 m. The table covers the digitised heights of K90 Fig. 1, plus 454 m.
The ρ = 1800, 2000 and 2670 values are in `outputs/table_residuals_report_heights.csv`.

| z (m) | flat | cont. A | A − flat | cont. B | B − flat | A operator-only | terrain part |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 43.70 | −229.9 | −213.8 | +16.1 | −224.0 | +5.9 | +10.1 | +5.9 |
| 88.30 | −531.2 | −494.3 | +36.9 | −517.8 | +13.4 | +23.5 | +13.4 |
| 130.45 | −814.8 | −758.4 | +56.4 | −794.5 | +20.3 | +36.1 | +20.3 |
| 173.30 | −1101.8 | −1025.7 | +76.0 | −1074.7 | +27.1 | +48.9 | +27.1 |
| 216.15 | −1387.6 | −1291.9 | +95.6 | −1353.7 | +33.9 | +61.8 | +33.9 |
| 257.05 | −1659.2 | −1544.9 | +114.3 | −1618.8 | +40.3 | +74.0 | +40.3 |
| 300.25 | −1944.9 | −1810.9 | +134.0 | −1897.8 | +47.1 | +86.9 | +47.1 |
| 344.15 | −2234.0 | −2079.9 | +154.0 | −2179.9 | +54.0 | +100.1 | +54.0 |
| 386.35 | −2510.7 | −2337.4 | +173.3 | −2450.0 | +60.6 | +112.7 | +60.6 |
| 428.45 | −2785.5 | −2593.2 | +192.4 | −2718.4 | +67.2 | +125.3 | +67.2 |
| 457.15 | −2972.3 | −2766.9 | +205.4 | −2900.6 | +71.6 | +133.9 | +71.6 |
| 454.00 | −2951.8 | −2747.8 | +204.0 | −2880.6 | +71.2 | +133.0 | +71.2 |

Interpretation:
* **Operator-only part (variant A):** the flat model fed through the truncated operator. The near-
  constant Yukawa surface field (about 68 mGal at ρ = 2200) times the weight deficit of the 240 km
  truncation gives about +134 µGal at the top. This is a property of how the operator is implemented,
  not of the terrain, and it depends on R_trunc (see convergence). Zero-sum weights (B) remove it.
* **Terrain part:** about +72 µGal at the top (2.4 % of the flat value). It is the same in all
  variants. Like the flat value it scales linearly with ρ, so the relative change does not depend on ρ.
* At every height the continuation residual has the same sign as the flat value and is smaller in
  magnitude, by 2.4–2.6 % (B) and 6.9–7.0 % (A).

## 8. R = q/α_lim (conditional, single point, k = 1.96)

α_lim = E/(K − E), as in V28, where K is the residual coefficient per α/(1 + α) at the bound height.

* B89 bound: K89 "93 ± 95 µGal" taken with the conservative sign, −93 − 1.96·95 = −279.2 µGal at 454 m.
  This is the bound V28 uses.
* B90 bound: the K90 Fig. 1 method 1 top point, digitised as +3.5 ± 40.3 µGal at 457.15 m, giving an
  edge of −75.5 µGal. This is a conditional single-point marginal comparison at a pre-selected height.
  It uses only that point's own variance; the off-diagonal covariance with the other heights does not
  enter a single-point marginal test (`check_single_point_marginal.py`: the edge stays the same when the
  unused off-diagonal elements are changed with the diagonal held fixed). It is not a reproduction of the
  K90 correlated χ² analysis, which fits all heights jointly and needs their covariance; K90 p. 9 warns
  that treating the points as independent in such a joint fit makes limits look too strong. Possible
  problems with the choice of the point, the meaning of the error bar or the coverage of systematics
  are not assessed here.

| ρ | bound | R flat (z0 = 9.8 m) | R A | R B | R C | R D |
|---:|---|---:|---:|---:|---:|---:|
| 2000 | B89 | 10.297 | 9.580 | 10.046 | 9.605 | 9.580 |
| 2670 | B89 | 13.773 | 12.815 | 13.439 | 12.849 | 12.816 |
| 2000 | B90 | 38.564 | 35.894 | 37.633 | 35.986 | 35.896 |
| 2670 | B90 | 51.510 | 47.945 | 50.266 | 48.069 | 47.948 |

The V28 Step 27 values (z0 = 0, i.e. 1 − e^(−h/λ)) are R = 10.531 (ρ = 2000) and 14.085 (ρ = 2670);
both are reproduced exactly. Referencing to z0 = 9.8 m alone lowers R by 2.2 %. The continuation then
changes it by a further −7.0 % (A) or −2.4 % (B). For ρ = 1800 and 2200, see
`outputs/table_residuals_rho2200.md`.

λ scan (ρ = 2000, B89, α_lim flat → A / B):

| λ | flat | A | B |
|---:|---:|---:|---:|
| 300 m | 0.01506 | 0.01504 | 0.01500 |
| 1 km | 0.00946 | 0.00952 | 0.00947 |
| 3 km | 0.00815 | 0.00838 | 0.00826 |
| 10 km | 0.00773 | 0.00831 | 0.00792 |
| 50 km | 0.00759 | 0.01014 | 0.00781 |

The operator-only term in A grows with λ (truncation). In B the change stays below 3 %.
For context: K90 gives |α| < 0.0032 (1σ, correlated χ²) at λ = 1 km; the single-point 1σ value
here (B90, A, ρ = 2200) is 0.00113. These are different test constructions (a joint multi-height
correlated χ² fit vs a conditional single-point marginal comparison). The difference therefore cannot be
attributed to the missing off-diagonal covariance alone, and the two numbers are not directly comparable.

## 9. Convergence (λ = 10 km, ρ = 2200, top 457.15 m)

| configuration | cont. A (µGal) | cont. B (µGal) | Newtonian bias (µGal) |
|---|---:|---:|---:|
| base (301 grid, 45 rings, 240 km) | −2766.87 | −2900.62 | 137.6 |
| grid 151 (360 m) | −2768.56 | −2902.32 | 165.6 |
| grid 451 (120 m) | −2768.24 | −2902.00 | 138.3 |
| rings × 0.5 (22 rings) | −2764.44 | −2898.19 | 107.4 |
| rings × 2 (90 rings) | −2768.74 | −2902.50 | 165.4 |
| R_trunc 60 km | −2388.02 | −2901.56 | 156.3 |
| R_trunc 120 km | −2640.65 | −2901.00 | 142.5 |
| R_trunc 480 km | −2829.86 | −2900.32 | 131.1 |
| 3 × 3 sub-stations within 4 km (8174 st.) | −2766.97 | −2900.72 | 143.1 |
| quadrature nz = 16, near 12, mid 48 | −2766.87 | −2900.63 | 137.8 |
| outside the square flat at base | −2767.17 | −2900.92 | 139.9 |

Variant B is stable to within 2.44 µGal in every configuration. Variant A depends on R_trunc, as
expected. The Newtonian bias depends on the ring discretisation by about ±30 µGal, the same size as
the report's ±20 µGal. It cancels in the Yukawa residual because B_Y and B_N share the station layout.

## 10. Verdict

* In the examined source and operator models, the residuals of the model point α = q, λ = 10 km still
  show a large deviation in the chosen single-point comparisons; this is not a full empirical reanalysis
  of the original experiment (synthetic ring radii, modern substitute DEM, uniform density, no
  reconstruction of the real station and data chain or of the joint measurement likelihood). Against
  B89 the conditional ratio R stays near 10 at ρ = 2000 (R = 9.58 A, 10.05 B) and near 13 at ρ = 2670
  (12.82 A, 13.44 B). Against the B90 conditional single-point marginal comparison it is 36–50.
* This refines the Step 27 method within the examined models. The continuation lowers R by
  about 2–7 % against the z0-referenced flat value, or 4.6–9 % against the V28 z0 = 0 value. The
  residual curve keeps the flat shape, and the difference grows almost linearly with height.
* R is a conditional ratio to a report bound, not a sigma statement.

## 11. Limitations

* Synthetic ring radii; the real stations are not available. The covariance of the tower points is
  unpublished, so there is no joint multi-height χ² fit; the bounds are conditional single-point
  marginal comparisons.
* The DEM preparation (`prepare_dem.py`) uses a local equirectangular mapping on a sphere (R = 6371 km).
  It is not distance-preserving east–west: the local metric change is +0.003159 / −0.003177 at
  ∓27 km northing (about 0.32 %; `check_projection_metric.py`, full grids). This is stated, not corrected.
  It is not automatically a residual error of the same size; its effect would need a DEM regenerated
  with a local geodetic projection, which this package does not do (the raw Copernicus tiles are not in the package).
* Modern DEM instead of the 1983 data; one uniform density. Real density anomalies cancel in the
  observable (they are in the data), but not their Yukawa counterpart. Within this model that
  counterpart is part of B_Y.
* Only the vertical component, and spherical effects only through the kernel factor (1 − 2z/a),
  as in the reports.
