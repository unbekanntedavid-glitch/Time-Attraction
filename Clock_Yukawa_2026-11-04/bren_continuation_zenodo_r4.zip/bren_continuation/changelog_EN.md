# bren_continuation r4: version notes (preliminary research)

Numerical cross-checks with Academia Co-scientist (AI-assisted); no new measurement data.

## What this version contains

- `bren_continuation.py` computes the BREN tower residuals with the report continuation operator applied to a Yukawa-modified source model (uniform half-space plus signed terrain prisms), for the base configuration, variants A–D, a λ scan and ten convergence configurations. Station heights and source prisms are derived from one shared cell geometry (`outer_tiers()`, `side_height()`, `surface_height()`).
- Three light consistency checks run before the computation:
  - `check_station_surfaces.py`: every station of the base and of all ten convergence configurations lies on the surface of its containing source prism (+1 mm) → `outputs/check_station_surfaces.json`.
  - `check_single_point_marginal.py`: the single-point bound edge stays the same under seven covariance structures for the unused off-diagonal elements → `outputs/check_single_point_marginal.json`.
  - `check_projection_metric.py`: east–west metric change of the equirectangular DEM mapping over the full grids (+0.003159 / −0.003177 at ∓27 km northing; at most 0.0032) → `outputs/check_projection_metric.json`.
- `make_figures.py` writes the figures and tables; `verify_outputs.py` compares every numeric output with `reference/reference_results.json` by tolerance (|d| ≤ 1e-6 + 1e-6·|ref|; non-finite values and missing keys fail) and runs the physics/consistency checks.
- The B89/B90 bound values are conditional single-point marginal comparisons, not a reproduction of the correlated χ² analysis of the original report. R is a conditional ratio to a report bound, not σ.
- Scope: the deviation holds in the examined source and operator models and the chosen single-point comparisons; synthetic ring radii, a modern substitute DEM and uniform density are used. This is not an empirical reanalysis of the original experiment.
- r3: license added (CC BY-NC 4.0, `LICENSE.txt`), wording made neutral (text and license only).
- r4 (text only): the generic AI-assistance wording is replaced by "numerical cross-checks with Academia Co-scientist (AI-assisted)" in the README, the methodology notes, this changelog, the `status` field written by `bren_continuation.py` (and therefore in `outputs/bren_continuation_results.json` and `reference/reference_results.json`) and the title of `fig_residual_curve`. Every numeric value in every JSON, CSV and Markdown table is identical to r3 (parsed comparison); the input hashes in `SHA256SUMS_inputs` are unchanged. New SHA-256 of `outputs/bren_continuation_results.json`: a0cf690641b88737f924aa27dcfcb196939dc58447889ed0178eb533d1477f33.
