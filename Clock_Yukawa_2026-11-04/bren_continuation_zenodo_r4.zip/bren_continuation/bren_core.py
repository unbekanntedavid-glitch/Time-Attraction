# -*- coding: utf-8 -*-
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Core numerics for the BREN-tower continuation test (Step 27 refinement, V28 line, TAL).

Units: SI. Gravity is the downward (attractive, toward -z) vertical component. Fields are computed
per unit G*rho (kernel units: metres), and multiplied by G and rho afterwards.

Yukawa convention (as in V28 Step 27): V = -G_inf m1 m2/r (1 + alpha exp(-r/lambda)),
G_lab = G_inf (1 + alpha). The Yukawa vertical kernel of a point mass is the Newtonian kernel times
f(d) = (1 + d/lambda) exp(-d/lambda).
"""
import math
import numpy as np

G_LAB = 6.67430e-11
A_EARTH = 6371.0e3

# ------------------------------------------------------------------ point-to-prism kernels
GL8_X, GL8_W = np.polynomial.legendre.leggauss(8)
GL2_X, GL2_W = np.polynomial.legendre.leggauss(2)

def _log_plus(u, r, rest2):
    """log(u + r) with r = sqrt(u^2 + rest2), stable for u < 0."""
    out = np.empty_like(u)
    pos = u >= 0
    out[pos] = np.log(u[pos] + r[pos])
    neg = ~pos
    out[neg] = np.log(rest2[neg] / (r[neg] - u[neg]))
    return out

def prism_newton_gz(xp, yp, zp, x1, x2, y1, y2, z1, z2):
    """Downward vertical attraction (per unit G*rho) of right-rectangular prisms at point p.
    Closed form (Nagy et al. 2000 / Plouff 1976 type):
      g = - sum_{ijk} mu_ijk [ x ln(y+r) + y ln(x+r) - z atan(x y/(z r)) ],  x,y,z corner coords
    relative to p; sign validated in self_tests() against brute force and the Bouguer slab."""
    g = np.zeros(np.broadcast(x1, z1).shape)
    for xi, sx in ((x1, -1.0), (x2, 1.0)):
        X = xi - xp
        for yj, sy in ((y1, -1.0), (y2, 1.0)):
            Y = yj - yp
            for zk, sz in ((z1, -1.0), (z2, 1.0)):
                Z = zk - zp
                X_, Y_, Z_ = np.broadcast_arrays(X, Y, Z)
                r = np.sqrt(X_ * X_ + Y_ * Y_ + Z_ * Z_)
                with np.errstate(divide="ignore", invalid="ignore"):
                    at = np.where(Z_ != 0.0, np.arctan(X_ * Y_ / (Z_ * r)), 0.0)
                t = (X_ * _log_plus(Y_, r, X_ * X_ + Z_ * Z_) + Y_ * _log_plus(X_, r, Y_ * Y_ + Z_ * Z_)
                     - Z_ * at)
                g += sx * sy * sz * t
    return g

def one_minus_f(d, lam):
    u = d / lam
    return -np.expm1(-u) - u * np.exp(-u)

def field_prisms(p, S, lams, near_cells=6.0, nz=None, mid_cells=24.0):
    """Newtonian and Yukawa vertical field (per unit G*rho) at point p=(x,y,z) of a prism set S.
    S: dict with xc, yc, half (half-width), zb, zt, sgn (+-1), cell.
    Near prisms (horizontal distance < near_cells*cell): analytic Newton, Yukawa = Newton minus a
    smooth correction integral (2x2 horizontal, 8 vertical Gauss nodes).
    Mid prisms (near_cells..mid_cells): 2x2 horizontal x 8 vertical Gauss nodes for both kernels.
    Far prisms: vertical-column quadrature (1 horizontal x 8 vertical Gauss nodes) for both kernels."""
    xp, yp, zp = p
    gx, gw = (GL8_X, GL8_W) if nz is None else np.polynomial.legendre.leggauss(nz)
    dx = S["xc"] - xp; dy = S["yc"] - yp
    s2 = dx * dx + dy * dy
    near = s2 < (near_cells * S["cell"]) ** 2
    mid = (~near) & (s2 < (mid_cells * S["cell"]) ** 2)
    far = ~(near | mid)
    N = 0.0; Y = np.zeros(len(lams))
    h = S["half"]
    # far columns (1 horizontal point) and mid-distance columns (2x2 horizontal Gauss points)
    for sel, hx in ((far, ((0.0, 2.0),)), (mid, tuple(zip(GL2_X, GL2_W)))):
        if not sel.any():
            continue
        zb, zt, sg = S["zb"][sel], S["zt"][sel], S["sgn"][sel]
        hz = 0.5 * (zt - zb)
        zq = 0.5 * (zt + zb)[:, None] + hz[:, None] * gx[None, :]
        dz = zp - zq
        for ax, aw in hx:
            for bx, bw in hx:
                ddx = dx[sel] + h * ax; ddy = dy[sel] + h * bx
                d2 = (ddx * ddx + ddy * ddy)[:, None] + dz * dz
                d = np.sqrt(d2)
                k = (sg * hz)[:, None] * gw[None, :] * dz / (d2 * d) * (h * h) * aw * bw
                N += k.sum()
                for i, lam in enumerate(lams):
                    Y[i] += (k * (1.0 + d / lam) * np.exp(-d / lam)).sum()
    # near prisms
    if near.any():
        xc, yc, zb, zt, sg = S["xc"][near], S["yc"][near], S["zb"][near], S["zt"][near], S["sgn"][near]
        gn = prism_newton_gz(xp, yp, zp, xc - h, xc + h, yc - h, yc + h, zb, zt) * sg
        Nn = gn.sum(); N += Nn
        hz = 0.5 * (zt - zb)
        corr = np.zeros(len(lams))
        for ax, aw in zip(GL2_X, GL2_W):
            for bx, bw in zip(GL2_X, GL2_W):
                ddx = xc + h * ax - xp; ddy = yc + h * bx - yp
                ss = ddx * ddx + ddy * ddy
                zq = 0.5 * (zt + zb)[:, None] + hz[:, None] * gx[None, :]
                dz = zp - zq
                d2 = ss[:, None] + dz * dz
                d = np.sqrt(d2)
                kk = (sg * hz)[:, None] * gw[None, :] * dz / (d2 * d) * (h * h) * aw * bw
                for i, lam in enumerate(lams):
                    corr[i] += (kk * one_minus_f(d, lam)).sum()
        Y += Nn - corr
    return N, Y

def halfspace_field(z, lams):
    """Uniform half-space z' < 0 (surface through the tower base). Per unit G*rho.
    Newton: the constant 2 pi G rho D of the full Earth is part of the normal (WGS84) field and is
    removed with it; for z < 0 (station below the datum) the interior term -4 pi |z| remains.
    Yukawa: 2 pi lambda exp(-|z|/lambda) both above and below the surface (derived from infinite layers)."""
    N = -4.0 * math.pi * max(-z, 0.0)
    Y = np.array([2.0 * math.pi * lam * math.exp(-abs(z) / lam) for lam in lams])
    return N, Y

def field_model(p, sets, lams, near_cells=6.0, nz=None, mid_cells=24.0):
    N, Y = halfspace_field(p[2], lams)
    for S in sets:
        n, y = field_prisms(p, S, lams, near_cells, nz, mid_cells)
        N += n; Y = Y + y
    return N, Y

# ------------------------------------------------------------------ continuation operator
def ring_weights(edges, z, spherical=True, a=A_EARTH):
    """Ring integrals of the report kernel (Kasameyer 1989 eq. 7 = Kammeraad 1990 eq. 2):
    K_i(z) = z(1-2z/a) [ (r1^2 + b^2)^(-1/2) - (r2^2 + b^2)^(-1/2) ],  b^2 = z^2 (1 - z/a).
    spherical=False gives the planar Poisson kernel (a -> infinity)."""
    e = np.asarray(edges, float)
    if spherical:
        fac = z * (1.0 - 2.0 * z / a); b2 = z * z * (1.0 - z / a)
    else:
        fac = z; b2 = z * z
    if z == 0.0:
        w = np.zeros(len(e) - 1); w[0] = 1.0
        return w
    inv = 1.0 / np.sqrt(e * e + b2)
    return fac * (inv[:-1] - inv[1:])

def ring_layout(scale=1.0, R_trunc=240.0e3):
    """Synthetic ring layout following the counts of Kammeraad et al. 1990 (p. 3): 8 rings with
    M = 27 sectors for r < 150 m, 21 rings with M = 36 for 150 m - 10 km, beyond 10 km the number of
    sectors grows to 70 at 200 km; truncation radius 240 km. Ring radii are NOT published: we use
    geometric spacing (stated assumption). The innermost ring is the disc 0..r1.
    scale multiplies the number of rings in every zone (convergence test)."""
    n1 = max(int(round(8 * scale)), 2); n2 = max(int(round(21 * scale)), 2)
    q2 = (10.0e3 / 150.0) ** (1.0 / 21)                     # ring ratio of the 150 m - 10 km zone
    inner = np.geomspace(150.0 / q2 ** 7, 150.0, 8)          # 8 inner edges (first ring = disc)
    if scale != 1.0:
        inner = np.geomspace(inner[0], 150.0, n1)
    e1 = np.concatenate([[0.0], inner])
    e2 = np.geomspace(150.0, 10.0e3, n2 + 1)[1:]
    n3 = max(int(round(math.log(R_trunc / 10.0e3) / math.log(q2) * scale)), 1) if R_trunc > 10.0e3 else 0
    e3 = np.geomspace(10.0e3, R_trunc, n3 + 1)[1:] if n3 else np.array([])
    if R_trunc < 10.0e3:
        e2 = e2[e2 <= R_trunc]
        if e2[-1] < R_trunc: e2 = np.append(e2, R_trunc)
    edges = np.concatenate([e1, e2, e3])
    M = []
    for i in range(len(edges) - 1):
        rc = math.sqrt(0.5 * (edges[i] ** 2 + edges[i + 1] ** 2))
        if edges[i + 1] <= 150.0 + 1e-9: M.append(27)
        elif edges[i + 1] <= 10.0e3 * (1 + 1e-12): M.append(36)
        else: M.append(int(round(min(70, 36 + 34 * (math.log(rc / 10.0e3) / math.log(20.0))))))
    return edges, np.array(M)

def stations(edges, M, sub=1, sub_rmax=4.0e3):
    """Station coordinates: sector centres (equal-area radius, mid-angle). With sub=3, rings inside
    sub_rmax get 3x3 points per sector (mimicking the Phase II pattern of 8 extra points around
    each Phase I station, Kammeraad 1990 p. 2), averaged per sector."""
    pts = []; ring_of = []; sec_of = []
    for i in range(len(edges) - 1):
        r1, r2 = edges[i], edges[i + 1]
        m = M[i]
        nsub = sub if (sub > 1 and r2 <= sub_rmax) else 1
        for j in range(m):
            for a in range(nsub):
                for b in range(nsub):
                    fr = (a + 0.5) / nsub; fp = (b + 0.5) / nsub
                    r = math.sqrt(r1 * r1 + fr * (r2 * r2 - r1 * r1))
                    ph = 2 * math.pi * (j + fp) / m
                    pts.append((r * math.cos(ph), r * math.sin(ph))); ring_of.append(i); sec_of.append(j)
    return np.array(pts), np.array(ring_of), np.array(sec_of)

def ring_means(vals, ring_of, sec_of, nring):
    out = np.zeros(nring)
    for i in range(nring):
        m = ring_of == i
        # mean over sectors of sector means
        secs = np.unique(sec_of[m])
        out[i] = np.mean([vals[m & (sec_of == s)].mean() for s in secs])
    return out
