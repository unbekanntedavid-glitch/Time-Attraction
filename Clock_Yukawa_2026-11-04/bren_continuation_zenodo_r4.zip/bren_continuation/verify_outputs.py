#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Numeric verification of outputs/ against reference/reference_results.json.

Outputs are NOT expected to be byte-identical (floating-point summation order, library versions,
process scheduling). Every numeric leaf is compared with |x - ref| <= ATOL + RTOL |ref|.
Timing fields are skipped. In addition a set of physics/consistency checks is run.
Exit code 0 = all checks pass.
"""
import json, os, sys, csv, math

HERE = os.path.dirname(os.path.abspath(__file__))
RTOL, ATOL = 1e-6, 1e-6          # ATOL in the native unit of each field (uGal, m, or dimensionless)
SKIP = {"runtime_s", "seconds"}
out = json.load(open(os.path.join(HERE, "outputs", "bren_continuation_results.json")))
ref = json.load(open(os.path.join(HERE, "reference", "reference_results.json")))
fails, n = [], 0

def cmp(a, b, path):
    global n
    if isinstance(b, dict):
        if not isinstance(a, dict) or set(a) != set(b):
            fails.append(f"{path}: key mismatch"); return
        for k in b:
            if k not in SKIP: cmp(a[k], b[k], f"{path}/{k}")
    elif isinstance(b, list):
        if not isinstance(a, list) or len(a) != len(b):
            fails.append(f"{path}: length mismatch"); return
        for i, (x, y) in enumerate(zip(a, b)): cmp(x, y, f"{path}[{i}]")
    elif isinstance(b, bool) or b is None or isinstance(b, str):
        if a != b: fails.append(f"{path}: {a!r} != {b!r}")
    elif isinstance(b, (int, float)):
        n += 1
        if isinstance(a, bool) or not isinstance(a, (int, float)) or not (math.isfinite(a) and math.isfinite(b)) or not abs(a - b) <= ATOL + RTOL * abs(b):
            fails.append(f"{path}: {a!r} vs ref {b!r}")
cmp(out, ref, "")
print(f"numeric leaves compared: {n}, tolerance |d| <= {ATOL} + {RTOL}*|ref|")

def check(name, ok, val=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {val}")
    if not ok: fails.append(name)

# physics / consistency checks
for k, v in out["v28_reproduction"].items():
    check(f"V28 Step 27 reproduction {k}", v["max_rel_diff"] < 1e-12, f"(max rel diff {v['max_rel_diff']:.1e})")
st = out["self_tests"]
check("prism analytic vs brute force", st["prism_vs_brute_rel"] < 1e-4)
check("Yukawa near-field vs brute force", st["yukawa_near_vs_brute_rel_lam1km"] < 1e-3)
check("mid-zone 2x2 quadrature vs analytic", st["mid_2x2_vs_analytic_rel_at_6cells"] < 1e-3)
check("far-zone column vs analytic at 24 cells", st["column_far_vs_analytic_rel_at_24cells"] < 2e-3)
check("zoned vs all-analytic tower difference (Newton, Yukawa) < 1 uGal",
      abs(st["zoned_vs_all_analytic_tower_diff_newton_uGal_rho2200"]) < 1 and abs(st["zoned_vs_all_analytic_tower_diff_yukawa_uGal_rho2200"]) < 1)
check("Bouguer slab", st["bouguer_slab_rel"] < 1e-4)
check("harmonic point mass reproduced by operator", st["harmonic_point_mass_rel"] < 1e-4)
nb = out["newton_terrain_bias_check"]
check("Newtonian terrain bias within report 140 +- 20 uGal (rho = 2200)", abs(nb["direct_minus_continued_uGal"] - 140.0) <= 20.0,
      f"({nb['direct_minus_continued_uGal']:.1f} uGal)")
cv = out["convergence_lambda10km"]; b = cv["base"]
for k, v in cv.items():
    if k.startswith("Rtrunc"): continue
    check(f"convergence {k}: |cont B - base| < 5 uGal at top", abs(v["contB_uGal_rho2200"] - b["contB_uGal_rho2200"]) < 5.0,
          f"({v['contB_uGal_rho2200'] - b['contB_uGal_rho2200']:+.2f})")
for k in ("Rtrunc_60km", "Rtrunc_120km", "Rtrunc_480km"):
    check(f"convergence {k}: |cont B - base| < 5 uGal at top", abs(cv[k]["contB_uGal_rho2200"] - b["contB_uGal_rho2200"]) < 5.0,
          f"({cv[k]['contB_uGal_rho2200'] - b['contB_uGal_rho2200']:+.2f}; variant A {cv[k]['contA_uGal_rho2200'] - b['contA_uGal_rho2200']:+.1f}, expected to move)")
# light consistency tests (written by check_*.py before the computation)
def _load(name):
    p = os.path.join(HERE, "outputs", name)
    return json.load(open(p)) if os.path.isfile(p) else None
cs = _load("check_station_surfaces.json")
check("T_station_surfaces: every station at its containing prism surface + EPS_Z (base + all convergence configurations)",
      cs is not None and cs["total_mismatches"] == 0 and set(cs["configs"]) == set(cv),
      f"({'missing' if cs is None else str(cs['total_mismatches']) + ' mismatches, ' + str(len(cs['configs'])) + ' configurations'})")
cm = _load("check_single_point_marginal.json")
check("T_single_point_marginal: single-point marginal edge unchanged by unused off-diagonal covariance", cm is not None and cm["single_point_invariant"],
      "(missing)" if cm is None else f"({len(cm['rows'])} covariance structures)")
cp = _load("check_projection_metric.json")
check("T_projection_metric: projection metric change computed on the full grids", cp is not None and 3.1e-3 < cp["max_abs_rel_change_all_grids"] < 3.4e-3,
      "(missing)" if cp is None else f"(max |change| {cp['max_abs_rel_change_all_grids']:.6f})")
# CSV consistency with JSON
rows = list(csv.DictReader(open(os.path.join(HERE, "outputs", "table_residuals_report_heights.csv"))))
bad = 0
for r in rows:
    t = next(x for x in out["tables_lambda10km"][r["variant"]] if abs(x["z_m"] - float(r["z_m"])) < 0.006)[f"rho_{r['rho_kg_m3']}"]
    if not (abs(float(r["continuation_uGal"]) - t["continuation_uGal"]) <= 1e-3 and abs(float(r["flat_uGal"]) - t["flat_uGal"]) <= 1e-3): bad += 1
check("CSV table consistent with JSON", bad == 0 and len(rows) == 4 * 13 * 4, f"({len(rows)} rows)")
for f in ("fig_residual_curve", "fig_weights", "fig_lambda_scan"):
    for ext in ("png", "pdf"):
        p = os.path.join(HERE, "outputs", f"{f}.{ext}")
        check(f"figure present {f}.{ext}", os.path.isfile(p) and os.path.getsize(p) > 5000)
if fails:
    print(f"\n{len(fails)} problem(s):"); [print("  ", f) for f in fails[:40]]; sys.exit(1)
print("\nall checks passed")
