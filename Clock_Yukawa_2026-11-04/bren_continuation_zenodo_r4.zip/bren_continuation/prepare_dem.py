#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Prepare the terrain input for bren_continuation.py (run once; NOT part of run_all.sh).

Source: Copernicus GLO-90 DEM (COG, 3 arc-second, EGM2008 heights), public AWS bucket
  https://copernicus-dem-90m.s3.amazonaws.com/Copernicus_DSM_COG_30_<TILE>_DEM/Copernicus_DSM_COG_30_<TILE>_DEM.tif
Tiles: N36_00_W117_00, N36_00_W116_00, N37_00_W117_00, N37_00_W116_00.
Tower location: 36.78059 N, 116.24359 W (GeoNames 7282248 / Wikidata Q796933, BREN Tower, Jackass Flats).

Report geometry being reproduced (Kasameyer et al. 1989, OSTI 6190822, p. 12): a 54-km square centred
on the tower, 300 x 300 right-rectangular prisms (here 301 x 301, odd, tower at a cell centre) of identical square cross-section, tops at the height
of the smoothed terrain at their centres. Here the 1983 USGS contour maps / 15-arc-second grid used in
the report are replaced by the modern Copernicus GLO-90 DEM (stated deviation). Each cell height is the
mean of a 4 x 4 bilinear sub-sample inside the cell ("smoothed terrain").
Local plane coordinates: x east, y north, equirectangular about the tower (sphere, R = 6371 km). This
mapping is not distance-preserving: the local east-west scale at northing y differs from the true spherical
one by cos(lat0 + y/R)/cos(lat0) - 1, i.e. +0.003159 at y = -27 km and -0.003177 at y = +27 km (about
0.32 %; at most 0.0032 in magnitude over the full 151/301/451 grids including cell edges), computed by
check_projection_metric.py. The north-south scale is exact on the sphere. The metric change is stated, not corrected. It is not
automatically a residual error of the same size; its effect on the residuals would need a DEM regenerated
with a local geodetic projection. That is not done here: the raw Copernicus tiles are not part of the
package, so the inputs/bren_terrain_*.npz grids are unchanged.
Usage: python3 prepare_dem.py <directory with the four cop90_*.tif tiles>
Needs: tifffile + imagecodecs (only for this preparation step).
"""
import sys, os, json, hashlib, math
if len(sys.argv) < 2:
    sys.exit("usage: python3 prepare_dem.py <directory with the four cop90_*.tif tiles>")
import numpy as np
import tifffile

DEM_DIR = sys.argv[1]
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "inputs")
LAT0, LON0 = 36.78059, -116.24359
R_E = 6371.0e3
HALF = 27.0e3
TILES = {(36, -117): "cop90_N36_00_W117_00.tif", (36, -116): "cop90_N36_00_W116_00.tif",
         (37, -117): "cop90_N37_00_W117_00.tif", (37, -116): "cop90_N37_00_W116_00.tif"}

def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()

# mosaic on a common 3" lattice (pixel-is-point, tie point = NW corner of tile)
d = 1.0 / 1200.0
lat_top, lon_left = 38.0, -117.0
mos = np.full((2400, 2400), np.nan)
tile_sha = {}
for (la, lo), fn in TILES.items():
    p = os.path.join(DEM_DIR, fn); tile_sha[fn] = sha(p)
    with tifffile.TiffFile(p) as t:
        pg = t.pages[0]; a = pg.asarray().astype(float)
        tp = pg.tags["ModelTiepointTag"].value; sc = pg.tags["ModelPixelScaleTag"].value
        assert abs(sc[0] - d) < 1e-12 and a.shape == (1200, 1200)
        r0 = int(round((lat_top - tp[4]) / d)); c0 = int(round((tp[3] - lon_left) / d))
        mos[r0:r0 + 1200, c0:c0 + 1200] = a
assert np.isfinite(mos).all()

def dem_at(lat, lon):
    fr = (lat_top - lat) / d; fc = (lon - lon_left) / d
    r = np.floor(fr).astype(int); c = np.floor(fc).astype(int); tr = fr - r; tc = fc - c
    return ((1 - tr) * (1 - tc) * mos[r, c] + (1 - tr) * tc * mos[r, c + 1]
            + tr * (1 - tc) * mos[r + 1, c] + tr * tc * mos[r + 1, c + 1])

def xy_to_ll(x, y):
    lat = LAT0 + np.degrees(y / R_E)
    lon = LON0 + np.degrees(x / (R_E * math.cos(math.radians(LAT0))))
    return lat, lon

meta = {"tower_lat": LAT0, "tower_lon": LON0, "half_width_m": HALF, "tiles_sha256": tile_sha,
        "dem": "Copernicus GLO-90 (COG_30), EGM2008 heights", "tower_point_dem_m": float(dem_at(LAT0, LON0))}
for n in (151, 301, 451):
    # odd n so that the tower sits at the centre of a cell (report: 300 x 300 cells, centred square);
    # cell = 54 km/(n-1) -> 360 / 180 / 120 m, half-width 27 km + half a cell
    cell = 2 * HALF / (n - 1)
    xc = cell * (np.arange(n) - (n - 1) // 2)
    sub = (np.arange(4) + 0.5) / 4 - 0.5
    H = np.zeros((n, n))
    for a in sub:
        for b in sub:
            X, Y = np.meshgrid(xc + a * cell, xc + b * cell, indexing="xy")   # rows = y, cols = x
            la, lo = xy_to_ll(X, Y)
            H += dem_at(la, lo)
    H /= 16.0
    np.savez(os.path.join(OUT, f"bren_terrain_{n}.npz"), xc=xc, yc=xc, h=H, cell=cell)
    meta[f"grid_{n}"] = {"cell_m": cell, "h_min": float(H.min()), "h_max": float(H.max()), "h_mean": float(H.mean())}
json.dump(meta, open(os.path.join(OUT, "terrain_meta.json"), "w"), indent=1)
print(json.dumps(meta, indent=1))
