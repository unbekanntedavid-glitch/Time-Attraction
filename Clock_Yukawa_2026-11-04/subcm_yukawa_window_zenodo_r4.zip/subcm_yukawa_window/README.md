# subcm_yukawa_window: sub-cm Yukawa bounds against α = 1/(4π) (Zenodo variant)

Preliminary research, TAL line. Numerical cross-checks with Academia Co-scientist (AI-assisted).
Methodology: `methodology_en.md`, `methodology_hu.md`. Sources and links: `SOURCES.md`.

Version notes: `changelog_EN.md`, `valtozasnaplo_HU.md`; the transition band is checked by
`scripts/check_hust_free_gap.py`.
The 75.9 µm and 101.0 µm edges are unchanged.

The third-party source PDFs are not redistributed here. The default run starts from the
frozen digitization data in `inputs/frozen_digitization/` (SHA-256 in `inputs/SHA256SUMS_frozen.txt`).

## Run

    python run_check.py               # default, no PDFs and no poppler needed
    python run_check.py --from-pdfs   # optional: put the four PDFs from SOURCES.md into inputs/,
                                      # needs poppler-utils; checks inputs/SHA256SUMS_pdfs.txt and reruns digitization

Environment: `requirements.txt` (Python 3.13.5, NumPy 2.5.4, SciPy 1.18.1, matplotlib 3.11.2, Pillow 13.0.0).
Outputs are verified numerically against `reference/` (rtol = 1e-4); byte-identical PNG/PDF outputs are not expected.
In the default mode the digitized curves are inputs, so their comparison with `reference/digitized/` is a
consistency check only; the independent numeric checks are on the envelopes, crossings and ratio table.

## License

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Licensed under Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0): https://creativecommons.org/licenses/by-nc/4.0/ (legal code: https://creativecommons.org/licenses/by-nc/4.0/legalcode). All commercial, industrial and technological implementation rights are retained by the author; commercial use only with the author's written permission. Full text: `LICENSE.txt`. Third-party documents and data cited or included as sources remain under their own terms.

## Licenc

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Licenc: Creative Commons Nevezd meg! – Ne add el! 4.0 Nemzetközi (CC BY-NC 4.0): https://creativecommons.org/licenses/by-nc/4.0/deed.hu (jogi szöveg: https://creativecommons.org/licenses/by-nc/4.0/legalcode.hu). Valamennyi kereskedelmi, ipari és technológiai hasznosítási jogot a szerző fenntart; kereskedelmi hasznosítás kizárólag a szerző írásos engedélyével. A licenc szövege: `LICENSE.txt`. A forrásként idézett vagy mellékelt harmadik féltől származó dokumentumokra és adatokra azok saját feltételei vonatkoznak.
