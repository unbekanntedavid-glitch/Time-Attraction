# subcm_yukawa_window r4: version notes (preliminary research)

Numerical cross-checks with Academia Co-scientist (AI-assisted) of published figures and tables; no new measurement data.

## What this version contains

- Digitized sub-cm Yukawa bounds (AHN 2003 Fig. 4 and 5, Lee 2020 Fig. 5, Lee 2020 thesis Table 11.4) compared with the fixed line α0 = 1/(4π) = 0.0795775: envelopes, crossings, ratio table and EN/HU figures.
- Transition band 75.9–101.0 µm: it comes from comparing different experiments and bound constructions. 75.9 to ~98.1 µm depends on applying the HUST 2020/2016 |α| curves to α > 0; ~98.1–101.0 µm comes from the Eöt-Wash 2020 |α95| (drawn curve 98.074 µm, thesis column 98.14 µm) vs +α95 (101.029 µm) constructions (thesis p. 145: ±α95 from Δχ² = 6.17; |α95| from the 0.95 integral of the normal distribution; at 100 µm +α95 = 0.0813 > α0 = 0.0796 > |α95| = 0.0766).
- `scripts/check_hust_free_gap.py` recomputes these crossings from the digitized CSVs without any HUST curve (first non-HUST crossing: Eöt-Wash 2020 |α| at 98.074 µm; thesis |α95| 98.136 µm; thesis +α95 101.029 µm; HUST-free gap 2.893 µm; HUST 2020 |α| 75.877 µm) and checks that the headline band and the text/figure labels match → `outputs/check_hust_free_gap.json`.
- `scripts/verify_outputs.py` compares every numeric output with `reference/` by relative tolerance (rtol = 1e-4; non-finite values and missing keys or files fail).
- r3: license added (CC BY-NC 4.0, `LICENSE.txt`), wording made neutral (text and license only).
- r4 (text only): the generic AI-assistance wording is replaced by "numerical cross-checks with Academia Co-scientist (AI-assisted)" in the README, the methodology notes, this changelog, the `status` field written by `scripts/analyze_window.py` (and therefore in `outputs/results.json` and `reference/results.json`) and the footer of the EN/HU figures. Every numeric value in every JSON and CSV is identical to r3 (parsed comparison); the 75.9 µm and 101.0 µm edges are unchanged. `SHA256SUMS.txt` is regenerated for the changed files; the input hash lists are unchanged.
