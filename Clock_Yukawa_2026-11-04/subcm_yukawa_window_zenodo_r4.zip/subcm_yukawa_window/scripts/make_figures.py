#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Allowed/excluded plot for alpha0 = 1/(4 pi) in the sub-cm Yukawa regime.
Top: log lambda vs log |alpha| with the digitized curves, their lower envelope,
the excluded region (shaded), the alpha0 line, the allowed window and the
transition band.  Bottom: 1-D lambda strip per source.  EN and HU, PNG + PDF."""
import csv, json, os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIG = os.path.join(ROOT, 'outputs', 'digitized'); FIGD = os.path.join(ROOT, 'outputs', 'figures')
ALPHA0 = 1 / (4 * np.pi)
XMIN, XMAX = 1e-6, 3e-2

T = {
 'en': dict(
    title='Sub-cm Yukawa bounds vs. fixed α = 1/(4π) (95% CL, preliminary)',
    ylab='|α| (95% CL upper limit)', xlab='λ [m]',
    env='lower envelope of drawn |α| curves', thesis='Lee 2020 thesis +α₉₅\n(Table 11.4, sign-separated)',
    excl='excluded by |α| curves', a0='α = 1/(4π) = 0.0796', allowed='allowed window (all readings)',
    band='transition band: different experiments and\nbound constructions (below ~98 µm only HUST |α|;\n~98–101 µm Eöt-Wash |α₉₅| vs +α₉₅, no HUST)',
    ew='Eöt-Wash 2020 |α| crossing (no HUST)',
    rows=['AHN 2003 Fig. 5 (|α|)', 'AHN 2003 Fig. 4 (fills)', 'Lee 2020 Fig. 5 (|α|)',
          'Lee 2020 thesis +α₉₅', 'combined, |α| reading'],
    leg_allowed='allowed', leg_excl='excluded', leg_nc='not covered by this source',
    foot='Sources: Adelberger, Heckel, Nelson 2003 (Fig. 4, 5); Lee et al. PRL 124, 101101 (2020) Fig. 5 incl. HUST 2012/2016/2020; '
         'J. G. Lee PhD thesis UW 2020, Table 11.4. Numerical cross-checks with Academia Co-scientist (AI-assisted); preliminary.',
    other='other drawn curves (Stanford,\nColorado, unattributed, Lamoreaux, Moscow)',
    lc='λc'),
 'hu': dict(
    title='Cm alatti Yukawa-korlátok vs. rögzített α = 1/(4π) (95% CL, előzetes)',
    ylab='|α| (95% CL felső korlát)', xlab='λ [m]',
    env='a rajzolt |α| görbék\nalsó burkolója', thesis='Lee 2020 disszertáció +α₉₅\n(11.4 táblázat, előjelenként)',
    excl='|α| görbék által kizárt', a0='α = 1/(4π) = 0.0796', allowed='megengedett ablak\n(minden olvasat szerint)',
    band='átmeneti sáv: eltérő kísérletek és\nkorlátkonstrukciók (~98 µm alatt csak HUST |α|;\n~98–101 µm Eöt-Wash |α₉₅| vs +α₉₅, HUST nélkül)',
    ew='Eöt-Wash 2020 |α| metszés (HUST nélkül)',
    rows=['AHN 2003, 5. ábra (|α|)', 'AHN 2003, 4. ábra (kitöltés)', 'Lee 2020, 5. ábra (|α|)',
          'Lee 2020 diss. +α₉₅', 'együttes, |α| olvasat'],
    leg_allowed='megengedett', leg_excl='kizárt', leg_nc='ez a forrás nem fedi',
    foot='Források: Adelberger, Heckel, Nelson 2003 (4., 5. ábra); Lee et al. PRL 124, 101101 (2020) 5. ábra, benne HUST 2012/2016/2020; '
         'J. G. Lee PhD-disszertáció, UW 2020, 11.4 táblázat. Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); előzetes.',
    other='további rajzolt görbék (Stanford,\nColorado, azonosítatlan, Lamoreaux, Moszkva)',
    lc='λc'),
}
STYLE = {'Eot-Wash': '#5a00ff', 'HUST': '#000000', 'Stanford': '#777777', 'Colorado': '#999999',
         'unattributed': '#bbbbbb', 'Lamoreaux': '#bbbbbb', 'Irvine': '#666666', 'Moscow': '#aaaaaa'}


def rd(fn):
    d = np.genfromtxt(os.path.join(DIG, fn), delimiter=',', names=True)
    return d['lambda_m'], d['alpha_abs_lim']


def strip_row(ax, y, ivs_excl, cover, h=0.7):
    ax.add_patch(Rectangle((XMIN, y - h / 2), XMAX - XMIN, h, color='#dddddd', lw=0))
    ax.add_patch(Rectangle((cover[0], y - h / 2), cover[1] - cover[0], h, color='#7fd17f', lw=0))
    for a, b in ivs_excl:
        a, b = max(a, XMIN), min(b, XMAX)
        if b > a:
            ax.add_patch(Rectangle((a, y - h / 2), b - a, h, color='#e06060', lw=0))


def main():
    R = json.load(open(os.path.join(ROOT, 'outputs', 'results.json')))
    cal = json.load(open(os.path.join(DIG, 'calibration.json')))['figures']
    env = np.load(os.path.join(ROOT, 'outputs', 'envelopes.npz'))
    th = list(csv.DictReader(l for l in open(os.path.join(DIG, 'Lee2020_thesis_table11_4.csv')) if not l.startswith('#')))
    tl = np.array([float(r['lambda_mm']) for r in th]) * 1e-3; tp = np.array([float(r['alpha95_pos']) for r in th])
    H = R['headline']; lc_abs = H['abs_alpha_reading']['lambda_c_m']; lc_rng = H['abs_alpha_reading']['lambda_c_range_m']
    lc_pos = H['plus_alpha_reading']['lambda_c_m']
    os.makedirs(FIGD, exist_ok=True)
    for lang, L in T.items():
        fig = plt.figure(figsize=(12.5, 8.4))
        ax = fig.add_axes([0.15, 0.36, 0.54, 0.57]); sx = fig.add_axes([0.15, 0.10, 0.54, 0.19], sharex=ax)
        lg = env['log10_lambda']; E = env['combined_abs']; ok = np.isfinite(E)
        ax.fill_between(10 ** lg[ok], E[ok], 1e12, color='#ffef8a', alpha=0.7, lw=0, label=L['excl'])
        KEYC = {('Lee2020_fig5', 'Eot-Wash_2020'): ('#5a00ff', '-', 1.6, 'Eöt-Wash 2020 (Lee+ 2020)'),
                ('Lee2020_fig5', 'Eot-Wash_2007'): ('#5a00ff', '--', 1.1, 'Eöt-Wash 2007 (Kapner+)'),
                ('Lee2020_fig5', 'Eot-Wash_2004'): ('#5a00ff', ':', 1.2, 'Eöt-Wash 2004 (Hoyle+)'),
                ('Lee2020_fig5', 'HUST_2020'): ('#000000', '-', 1.6, 'HUST 2020 (Tan+)'),
                ('Lee2020_fig5', 'HUST_2016'): ('#000000', '--', 1.1, 'HUST 2016 (Tan+)'),
                ('Lee2020_fig5', 'HUST_2012'): ('#000000', ':', 1.2, 'HUST 2012 (Yang+)'),
                ('AHN2003_fig5', 'Eot-Wash'): ('#b07cff', '-.', 1.1, 'AHN 2003: Eöt-Wash 2001'),
                ('AHN2003_fig5', 'Irvine'): ('#8a6d3b', '-.', 1.1, 'AHN 2003: Irvine')}
        handles = []
        for fg in ('AHN2003_fig5', 'Lee2020_fig5'):
            for name, meta in cal[fg]['curves'].items():
                lam, alp = rd(meta['csv'])
                if (fg, name) in KEYC:
                    c, ls, lw, lab = KEYC[(fg, name)]
                    h, = ax.plot(lam, alp, color=c, ls=ls, lw=lw, label=lab); handles.append(h)
                else:
                    ax.plot(lam, alp, color='#9a9a9a', lw=0.7, ls='-' if fg == 'Lee2020_fig5' else '--')
        h, = ax.plot([], [], color='#9a9a9a', lw=0.7, label=L['other']); handles.append(h)
        ax.plot(10 ** lg[ok], E[ok], color='#c00000', lw=2.0, label=L['env'])
        ax.plot(tl, tp, 'o', ms=2.6, color='#0077aa', label=L['thesis'])
        ax.axhline(ALPHA0, color='#007a00', lw=1.6, label=L['a0'])
        ax.axvspan(XMIN, lc_abs, color='#9be39b', alpha=0.35, lw=0, label=L['allowed'])
        ax.axvspan(lc_abs, lc_pos, color='#ff9a3c', alpha=0.45, lw=0, label=L['band'])
        ax.axvspan(*lc_rng, color='#c00000', alpha=0.25, lw=0)
        lc_ew = [c for c in R['curves']['Lee2020_fig5/Eot-Wash_2020']['crossings'] if c['direction'] == 'enters_excluded'][0]['lambda_m']
        ax.axvline(lc_ew, color='#5a00ff', lw=0.9, ls=(0, (2, 2)), label=f"{L['ew']} ≈ {lc_ew * 1e6:.1f} µm")
        ax.annotate(f"{L['lc']} ≈ {lc_abs * 1e6:.1f} µm", (lc_abs, ALPHA0), xytext=(-78, -30), textcoords='offset points',
                    fontsize=8, arrowprops=dict(arrowstyle='->', lw=0.7))
        ax.annotate(f"{L['lc']}(+α) ≈ {lc_pos * 1e6:.0f} µm", (lc_pos, ALPHA0), xytext=(18, 26), textcoords='offset points',
                    fontsize=8, arrowprops=dict(arrowstyle='->', lw=0.7))
        ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(XMIN, XMAX); ax.set_ylim(1e-3, 1e5)
        ax.set_ylabel(L['ylab']); ax.set_title(L['title'], fontsize=11)
        ax.grid(True, which='major', lw=0.3, alpha=0.5)
        main_h = [h for h in ax.get_legend_handles_labels()[0] if h not in handles]
        lg1 = ax.legend(handles=main_h, fontsize=7.5, loc='upper left', bbox_to_anchor=(1.01, 1.0), framealpha=0.95)
        ax.add_artist(lg1); ax.legend(handles=handles, fontsize=7.5, loc='lower left', bbox_to_anchor=(1.01, 0.0), framealpha=0.95)
        plt.setp(ax.get_xticklabels(), visible=False)
        # strip
        S = R['sources']
        rows = [(S['AHN2003_fig5_all']['excluded_intervals_m'], S['AHN2003_fig5_all']['covered_lambda_range_m']),
                (S['AHN2003_fig4_fill']['excluded_intervals_m'], [S['AHN2003_fig4_fill']['excluded_intervals_m'][0][0], XMAX]),
                (S['Lee2020_fig5_all']['excluded_intervals_m'], S['Lee2020_fig5_all']['covered_lambda_range_m']),
                ([[lc_pos, S['Lee2020_thesis_plus_alpha95']['table_lambda_range_m'][1]]], S['Lee2020_thesis_plus_alpha95']['table_lambda_range_m']),
                ([[lc_abs, XMAX]], [XMIN, XMAX])]
        n = len(rows)
        for k, (ex, cov) in enumerate(rows):
            strip_row(sx, n - 1 - k, ex, cov)
        sx.axvline(lc_abs, color='k', lw=0.6, ls=':'); sx.axvline(lc_pos, color='k', lw=0.6, ls=':')
        sx.axvline(lc_ew, color='#5a00ff', lw=0.6, ls=(0, (2, 2)))
        sx.set_yticks(range(n)); sx.set_yticklabels(L['rows'][::-1], fontsize=7); sx.set_ylim(-0.6, n - 0.4)
        sx.set_xscale('log'); sx.set_xlim(XMIN, XMAX); sx.set_xlabel(L['xlab'])
        for c, lab in [('#7fd17f', L['leg_allowed']), ('#e06060', L['leg_excl']), ('#dddddd', L['leg_nc'])]:
            sx.add_patch(Rectangle((0, 0), 0, 0, color=c, label=lab))
        sx.legend(fontsize=7.5, loc='upper left', bbox_to_anchor=(1.01, 1.0), frameon=False)
        fig.text(0.01, 0.015, L['foot'], fontsize=6.5, wrap=True)
        for ext in ('png', 'pdf'):
            fig.savefig(os.path.join(FIGD, f'subcm_window_{lang}.{ext}'), dpi=200,
                        metadata={'CreationDate': None} if ext == 'pdf' else None)
        plt.close(fig)
        print('wrote', lang)


if __name__ == '__main__':
    sys.exit(main())
