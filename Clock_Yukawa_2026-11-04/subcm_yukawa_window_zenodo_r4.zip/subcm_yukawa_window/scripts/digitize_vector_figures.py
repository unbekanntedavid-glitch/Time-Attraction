# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Digitize the positive-coupling (|alpha|) short-range Yukawa bounds from the
vector drawings in the source PDFs.

The figures are vector graphics, so the curves are read from the PDF drawing
commands themselves (pdftocairo -svg), not from a raster image.  Axis
calibration is a least-squares fit of log10(value) against page coordinate
over all tick marks found on the frame.

Outputs (outputs/digitized/):
  calibration.json                     tick points, fit, residuals, curve ids
  <figure>__<curve>.csv                lambda_m, alpha_lim, page_x_pt, page_y_pt
  <figure>__fill_polygons.csv          excluded-region polygons as drawn (if any)
"""
import json, os, sys, csv, tempfile
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from svgvec import pdf_page_to_svg, parse_svg, chain_segments

ROOT = os.path.dirname(HERE)
INP = os.path.join(ROOT, 'inputs')
OUT = os.path.join(ROOT, 'outputs', 'digitized')

ADEL = 'adelberger2003.pdf'
LEE = 'lee2020_arXiv_2002.11761v1.pdf'

FIGS = [
    dict(
        key='AHN2003_fig5',
        title='Adelberger, Heckel, Nelson, Annu. Rev. Nucl. Part. Sci. 53, 77 (2003), arXiv:hep-ph/0307284v1, Fig. 5 (PDF p. 77): 95% CL, 1 um < lambda < 1 cm, |alpha|',
        pdf=ADEL, page=77,
        clip=(150, 430, 200, 450),
        frame_style=('rgb(0%, 0%, 0%)', 6.15285),
        x_major=[-6, -5, -4, -3, -2], x_first_minor_before_major=False,
        y_major_top_to_bottom=list(range(10, -5, -1)),
        curve_styles=[('rgb(0%, 0%, 0%)', 12.3057)],
        # arrow-head tips (page pt) of the figure's own labels, used to name curves
        labels=[('Stanford', (195.5, 249.5)), ('Lamoreaux', (259.2, 269.0)),
                ('Colorado', (269.8, 348.3)), ('Eot-Wash', (349.2, 407.5)),
                ('Irvine', (377.3, 383.6))],
        thin_curves=[('Moscow_thin', ('rgb(0%, 0%, 0%)', 4.03118), (289.6, 286.1))],
        fill='rgb(100%, 100%, 50%)'),
    dict(
        key='AHN2003_fig4',
        title='Adelberger, Heckel, Nelson 2003, Fig. 4 (PDF p. 76): 95% CL, lambda > 1 cm, |alpha|',
        pdf=ADEL, page=76,
        clip=(260, 540, 210, 460),
        frame_style=('rgb(0%, 0%, 0%)', 6.15285),
        x_major=list(range(-3, 16)), x_first_minor_before_major=False,
        y_major_top_to_bottom=list(range(-1, -11, -1)),
        curve_styles=[], labels=[], thin_curves=[],
        fill='rgb(100%, 100%, 50%)'),
    dict(
        key='Lee2020_fig5',
        title='Lee, Adelberger, Cook, Fleischer, Heckel, Phys. Rev. Lett. 124, 101101 (2020), arXiv:2002.11761v1, Fig. 5 bottom (p. 4): 95% CL, |alpha|, this and previous works',
        pdf=LEE, page=4,
        clip=(340, 560, 430, 620),
        frame_style=('rgb(0%, 0%, 0%)', 10.488),
        x_major=[-5, -4, -3], x_first_minor_before_major=True,
        y_major_top_to_bottom=list(range(6, -4, -1)),
        curve_styles=[('rgb(0%, 0%, 0%)', 13.0392), ('rgb(33.300781%, 0%, 100%)', 13.0392)],
        labels='rules',
        thin_curves=[], fill=None),
]


def in_clip(p, c):
    return p['x'].min() >= c[0] and p['x'].max() <= c[1] and p['y'].min() >= c[2] and p['y'].max() <= c[3]


def frame_of(strokes, style):
    S = [p for p in strokes if p['stroke'] == style[0] and abs(p['w'] - style[1]) < 1e-4]
    L = sorted(S, key=lambda p: -np.hypot(np.ptp(p['x']), np.ptp(p['y'])))[:8]
    xs = np.concatenate([p['x'] for p in L]); ys = np.concatenate([p['y'] for p in L])
    return float(xs.min()), float(xs.max()), float(ys.min()), float(ys.max())


def merge(vals, tol=0.5):
    vals = sorted(vals)
    groups = []
    for v, l in vals:
        if groups and abs(v - groups[-1][-1][0]) < tol:
            groups[-1].append((v, l))
        else:
            groups.append([(v, l)])
    return [(float(np.mean([g[0] for g in G])), float(max(g[1] for g in G)), len(G)) for G in groups]


def find_ticks(strokes, fr):
    x0, x1, y0, y1 = fr
    xt, yt = [], []
    for p in strokes:
        dx, dy = np.ptp(p['x']), np.ptp(p['y'])
        if dx < 0.02 and 0.5 < dy < 10 and x0 - 0.1 <= p['x'][0] <= x1 + 0.1 and abs(p['y'].max() - y1) < 0.1:
            xt.append((float(p['x'][0]), float(dy)))
        if dy < 0.02 and 0.5 < dx < 10 and y0 - 0.1 <= p['y'][0] <= y1 + 0.1 and abs(p['x'].min() - x0) < 0.1:
            yt.append((float(p['y'][0]), float(dx)))
    return merge(xt), merge(yt)


def assign_x(ticks, majors, minor_before):
    L = max(t[1] for t in ticks)
    isM = [t[1] > 0.75 * L for t in ticks]
    pts = []
    mi = [i for i, m in enumerate(isM) if m]
    if len(mi) != len(majors) and not (len(mi) == len(majors) and minor_before):
        # all ticks equal length -> every tick is a decade
        pass
    if all(isM):
        assert len(ticks) == len(majors), (len(ticks), len(majors))
        return [(t[0], float(v), 'major') for t, v in zip(ticks, majors)]
    assert len(mi) == len(majors), (len(mi), majors)
    for k, i in enumerate(mi):
        pts.append((ticks[i][0], float(majors[k]), 'major'))
        # minors after this major
        j = i + 1; m = 2
        while j < len(ticks) and not isM[j]:
            pts.append((ticks[j][0], majors[k] + np.log10(m), 'minor %d' % m)); j += 1; m += 1
    if minor_before:
        j = mi[0] - 1; m = 9
        while j >= 0:
            pts.append((ticks[j][0], majors[0] - 1 + np.log10(m), 'minor %d' % m)); j -= 1; m -= 1
    return sorted(pts)


def fit(pts):
    u = np.array([p[0] for p in pts]); v = np.array([p[1] for p in pts])
    A = np.vstack([u, np.ones_like(u)]).T
    (a, b), *_ = np.linalg.lstsq(A, v, rcond=None)
    res_dec = v - (a * u + b)
    return float(a), float(b), res_dec


def polyline_dist(l, q):
    d = np.inf
    for i in range(len(l) - 1):
        p0, p1 = l[i], l[i + 1]
        t = np.clip(np.dot(np.subtract(q, p0), p1 - p0) / max(np.dot(p1 - p0, p1 - p0), 1e-12), 0, 1)
        d = min(d, float(np.hypot(*(p0 + t * (p1 - p0) - q))))
    return d


def _cross(lam, alp, target):
    """lambda values where a digitized curve crosses alpha = target (log-log)."""
    la, lb = np.log10(lam), np.log10(alp) - np.log10(target)
    out = []
    for i in range(len(la) - 1):
        if lb[i] == 0:
            out.append(10 ** la[i])
        elif lb[i] * lb[i + 1] < 0:
            out.append(10 ** (la[i] + (la[i + 1] - la[i]) * lb[i] / (lb[i] - lb[i + 1])))
    return out


def identify_by_rules(cands, fx, fy):
    """Lee et al. 2020 Fig. 5: one label carries several arrows (HUST, Stanford,
    Eot-Wash), so curves are named by colour and by the |alpha| = 1 crossing
    stated in each paper's own abstract (checked in analyze_window.py)."""
    summ = []
    for i, (st, l) in enumerate(cands):
        o = np.argsort(l[:, 0])
        lam = 10 ** fx(l[o, 0]); alp = 10 ** fy(l[o, 1])
        c1 = _cross(lam, alp, 1.0)
        summ.append(dict(i=i, purple=st[0].startswith('rgb(33.3'), lmin=lam.min(), lmax=lam.max(),
                         amin=alp.min(), l1=min(c1) if c1 else None))
    named = {}
    pur = sorted([d for d in summ if d['purple']], key=lambda d: d['l1'])
    assert len(pur) == 3
    for nm, d in zip(['Eot-Wash_2020', 'Eot-Wash_2007', 'Eot-Wash_2004'], pur):
        named[nm] = (d['i'], None, None)
    blk = [d for d in summ if not d['purple']]
    hust = sorted([d for d in blk if d['l1'] is not None], key=lambda d: d['l1'])
    assert len(hust) == 2
    named['HUST_2020'] = (hust[0]['i'], None, None)
    named['HUST_2016'] = (hust[1]['i'], None, None)
    rest = [d for d in blk if d['l1'] is None]
    h12 = [d for d in rest if d['amin'] < 0.1]
    assert len(h12) == 1
    named['HUST_2012'] = (h12[0]['i'], None, None)
    col = [d for d in rest if 1 < d['amin'] < 10]
    assert len(col) == 1
    named['Colorado_2003'] = (col[0]['i'], None, None)
    iu = [d for d in rest if d['lmax'] < 3e-5 and d['lmin'] < 3e-6]
    assert len(iu) == 1
    named['unattributed_2to20um'] = (iu[0]['i'], None, None)
    used = {v[0] for v in named.values()}
    st_ = sorted([d for d in rest if d['i'] not in used], key=lambda d: d['amin'])
    assert len(st_) == 3
    for nm, d in zip(['Stanford_a', 'Stanford_b', 'Stanford_c'], st_):
        named[nm] = (d['i'], None, None)
    return named


def main():
    os.makedirs(OUT, exist_ok=True)
    calib = {'method': 'vector extraction: pdftocairo -svg, stroke segments chained into polylines, '
                       'axis fit log10(value) = a*page_coord + b over all tick marks', 'figures': {}}
    tmp = tempfile.mkdtemp()
    for F in FIGS:
        svg = pdf_page_to_svg(os.path.join(INP, F['pdf']), F['page'], os.path.join(tmp, F['key'] + '.svg'))
        strokes, fills = parse_svg(svg)
        strokes = [p for p in strokes if in_clip(p, F['clip'])]
        fr = frame_of(strokes, F['frame_style'])
        xt, yt = find_ticks(strokes, fr)
        xpts = assign_x(xt, F['x_major'], F['x_first_minor_before_major'])
        yt_sorted = sorted(yt)  # top to bottom
        assert len(yt_sorted) == len(F['y_major_top_to_bottom']), (F['key'], len(yt_sorted))
        ypts = [(t[0], float(v), 'major') for t, v in zip(yt_sorted, F['y_major_top_to_bottom'])]
        ax, bx, rx = fit(xpts); ay, by, ry = fit(ypts)
        fx = lambda x: ax * np.asarray(x) + bx
        fy = lambda y: ay * np.asarray(y) + by
        info = dict(title=F['title'], pdf=F['pdf'], pdf_page=F['page'],
                    frame_pt=dict(x_left=fr[0], x_right=fr[1], y_top=fr[2], y_bottom=fr[3]),
                    frame_data=dict(log10_lambda_left=float(fx(fr[0])), log10_lambda_right=float(fx(fr[1])),
                                    log10_alpha_top=float(fy(fr[2])), log10_alpha_bottom=float(fy(fr[3]))),
                    x_fit=dict(a_dec_per_pt=ax, b=bx, n_ticks=len(xpts), rms_residual_dec=float(np.sqrt(np.mean(rx ** 2))),
                               max_abs_residual_dec=float(np.max(np.abs(rx)))),
                    y_fit=dict(a_dec_per_pt=ay, b=by, n_ticks=len(ypts), rms_residual_dec=float(np.sqrt(np.mean(ry ** 2))),
                               max_abs_residual_dec=float(np.max(np.abs(ry)))),
                    x_calibration_points=[dict(page_x_pt=round(p[0], 4), log10_lambda_m=round(p[1], 6), kind=p[2],
                                               residual_dec=round(float(r), 6)) for p, r in zip(xpts, rx)],
                    y_calibration_points=[dict(page_y_pt=round(p[0], 4), log10_alpha=round(p[1], 6), kind=p[2],
                                               residual_dec=round(float(r), 6)) for p, r in zip(ypts, ry)],
                    curves={})
        # curves
        cands = []
        for st in F['curve_styles']:
            S = [p for p in strokes if p['stroke'] == st[0] and abs(p['w'] - st[1]) < 1e-4]
            for l in chain_segments(S):
                if len(l) >= 8:
                    cands.append((st, l))
        named = {}
        if F['labels'] == 'rules':
            named = identify_by_rules(cands, fx, fy)
        else:
            for name, tip in F['labels']:
                ds = sorted((polyline_dist(l, np.array(tip)), i) for i, (st, l) in enumerate(cands))
                named[name] = (ds[0][1], ds[0][0], ds[1][0] if len(ds) > 1 else None)
        idx = [v[0] for v in named.values()]
        assert len(set(idx)) == len(idx) == len(cands), (F['key'], named, len(cands))
        for name, st, tip in F['thin_curves']:
            S = [p for p in strokes if p['stroke'] == st[0] and abs(p['w'] - st[1]) < 1e-4]
            L = max(chain_segments(S), key=len)
            cands.append((st, L)); named[name] = (len(cands) - 1, polyline_dist(L, np.array(tip)), None)
        for name, (i, d1, d2) in named.items():
            st, l = cands[i]
            l = l[np.argsort(l[:, 0], kind='stable')]
            lam = 10 ** fx(l[:, 0]); alp = 10 ** fy(l[:, 1])
            # drop exact duplicate x
            keep = np.concatenate([[True], np.diff(l[:, 0]) > 1e-6])
            fn = '%s__%s.csv' % (F['key'], name)
            with open(os.path.join(OUT, fn), 'w', newline='') as fh:
                w = csv.writer(fh)
                w.writerow(['lambda_m', 'alpha_abs_lim', 'page_x_pt', 'page_y_pt'])
                for a, b, c, d in zip(lam[keep], alp[keep], l[keep, 0], l[keep, 1]):
                    w.writerow(['%.6e' % a, '%.6e' % b, '%.4f' % c, '%.4f' % d])
            info['curves'][name] = dict(csv=fn, stroke=st[0], stroke_width_pt=st[1] * 0.1 if F['key'].startswith('AHN') else st[1] * 0.049269,
                                        n_points=int(keep.sum()), label_tip_distance_pt=None if d1 is None else round(d1, 3),
                                        second_nearest_curve_distance_pt=None if d2 is None else round(d2, 3),
                                        lambda_range_m=[float(lam.min()), float(lam.max())],
                                        alpha_range=[float(alp.min()), float(alp.max())],
                                        lambda_monotonic=bool(np.all(np.diff(l[keep, 0]) > 0)))
        # fills
        if F['fill']:
            polys = [f for f in fills if f['fill'] == F['fill'] and f['x'].min() >= fr[0] - 0.5 and f['x'].max() <= fr[1] + 0.5]
            fn = '%s__fill_polygons.csv' % F['key']
            with open(os.path.join(OUT, fn), 'w', newline='') as fh:
                w = csv.writer(fh); w.writerow(['polygon', 'vertex', 'page_x_pt', 'page_y_pt', 'lambda_m', 'alpha'])
                for k, f in enumerate(polys):
                    for j, (x, y) in enumerate(zip(f['x'], f['y'])):
                        w.writerow([k, j, '%.4f' % x, '%.4f' % y, '%.6e' % 10 ** fx(x), '%.6e' % 10 ** fy(y)])
            info['fill_polygons'] = dict(csv=fn, n_polygons=len(polys), colour=F['fill'])
        calib['figures'][F['key']] = info
        print(F['key'], 'x rms %.2e dec, y rms %.2e dec' % (info['x_fit']['rms_residual_dec'], info['y_fit']['rms_residual_dec']),
              'curves:', {k: (v['n_points'], v['label_tip_distance_pt']) for k, v in info['curves'].items()})
    with open(os.path.join(OUT, 'calibration.json'), 'w') as fh:
        json.dump(calib, fh, indent=1)


if __name__ == '__main__':
    main()
