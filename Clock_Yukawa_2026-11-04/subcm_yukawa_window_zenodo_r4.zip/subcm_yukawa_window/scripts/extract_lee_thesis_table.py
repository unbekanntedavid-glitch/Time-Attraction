#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Extract Table 11.4 (Yukawa fits, 95% CL limits) from J. G. Lee, PhD thesis,
University of Washington 2020 (hdl:1773/45542, CC BY), PDF pages 145-148
(printed pp. 133-136) into a CSV.  Text layer read with `pdftotext -layout`;
no numbers are typed by hand.  Columns: lambda [mm], alpha* +- sigma,
+alpha95, -alpha95, |alpha95|, chi2 (thesis notation)."""
import csv, os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PDF = os.path.join(ROOT, 'inputs', 'lee2020_thesis_UW_hdl1773-45542.pdf')
OUT = os.path.join(ROOT, 'outputs', 'digitized', 'Lee2020_thesis_table11_4.csv')

NUM = r'-?\d+(?:\.\d+)?(?:×10-?\d+)?'
ROW = re.compile(rf'^\s*(\d\.\d{{4}})\s+({NUM})\s*±\s*({NUM})\s+({NUM})\s+({NUM})\s+({NUM})\s+({NUM})\s*$')


def val(s):
    if '×10' in s:
        m, e = s.split('×10')
        return float(m) * 10 ** int(e)
    return float(s)


def main():
    txt = subprocess.run(['pdftotext', '-layout', '-f', '145', '-l', '148', PDF, '-'],
                         check=True, capture_output=True, text=True).stdout
    rows = []
    for line in txt.splitlines():
        m = ROW.match(line)
        if m:
            g = m.groups()
            rows.append(dict(lambda_mm=float(g[0]), alpha_star=val(g[1]), sigma_alpha=val(g[2]),
                             alpha95_pos=val(g[3]), alpha95_neg=val(g[4]), alpha95_abs=val(g[5]),
                             chi2=float(g[6]), raw=line.strip()))
    lam = [r['lambda_mm'] for r in rows]
    assert len(rows) == 66, len(rows)                      # 66 lambda values, 5 um .. 8.9 mm
    assert lam == sorted(lam) and lam[0] == 0.005 and lam[-1] == 8.9
    assert all(r['alpha95_pos'] > 0 > r['alpha95_neg'] and r['alpha95_abs'] > 0 for r in rows)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, 'w', newline='') as f:
        f.write('# Source: J. G. Lee, "A Fourier-Bessel Test of the Gravitational Inverse-Square Law", '
                'PhD thesis, Univ. of Washington (2020), hdl:1773/45542, Table 11.4, PDF pp.145-148\n')
        f.write('# Convention: V = -G m1 m2/r (1 + alpha exp(-r/lambda)); +alpha95/-alpha95 from the '
                'Delta chi2 = 6.17 surface; |alpha95| from 95% integral of N(alpha*, sigma)\n')
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f'{len(rows)} rows -> {OUT}')


if __name__ == '__main__':
    sys.exit(main())
