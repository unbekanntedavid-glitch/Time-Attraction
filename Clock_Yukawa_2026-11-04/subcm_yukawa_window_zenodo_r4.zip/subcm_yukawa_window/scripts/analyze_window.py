#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Compare the digitized short-range Yukawa bounds with alpha0 = 1/(4 pi).

Convention (all sources): V = -G m1 m2 / r * (1 + alpha exp(-r/lambda)), 95% CL.
Inputs : outputs/digitized/*.csv, calibration.json, Lee2020_thesis_table11_4.csv,
         outputs/raster_crosscheck.json
Outputs: outputs/results.json, outputs/crossings.csv, outputs/ratio_table.csv,
         outputs/validation_checks.csv
R = alpha0 / alpha_lim(lambda) is a ratio to the 95% CL bound (R > 1: alpha0 lies
inside the region the bound excludes).  It is not a significance in sigma.
Preliminary: numerical cross-checks with Academia Co-scientist (AI-assisted) of published figures/tables.
"""
import csv, glob, json, os, sys
import numpy as np
from scipy.interpolate import PchipInterpolator

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIG = os.path.join(ROOT, 'outputs', 'digitized')
OUT = os.path.join(ROOT, 'outputs')
ALPHA0 = 1.0 / (4.0 * np.pi)
LA0 = np.log10(ALPHA0)
KEY_LAMBDA_UM = [5, 10, 20, 30, 38.6, 48, 50, 56, 59, 70, 75, 80, 90, 100, 110, 150, 200,
                 300, 500, 1000, 3000, 8900, 10000]
GRID = np.linspace(-6.0, -2.0, 40001)          # log10(lambda/m), 1e-4 dec step


def read_curve(path):
    d = np.genfromtxt(path, delimiter=',', names=True)
    return d['lambda_m'], d['alpha_abs_lim'], d['page_x_pt'], d['page_y_pt']


def loglog(lam, alp, x):
    """log-log linear interpolation, NaN outside the drawn range."""
    lx = np.log10(np.atleast_1d(x)); out = np.interp(lx, np.log10(lam), np.log10(alp))
    out[(lx < np.log10(lam[0])) | (lx > np.log10(lam[-1]))] = np.nan
    return 10 ** out


def crossings(lam, alp, a0=ALPHA0):
    """lambda where log alpha_lim(lambda) crosses log a0, with local slope and index."""
    la, lb = np.log10(lam), np.log10(alp) - np.log10(a0)
    res = []
    for i in range(len(la) - 1):
        if lb[i] * lb[i + 1] < 0 or (lb[i] == 0 and i > 0):
            t = lb[i] / (lb[i] - lb[i + 1])
            lc = la[i] + t * (la[i + 1] - la[i])
            slope = (np.log10(alp[i + 1]) - np.log10(alp[i])) / (la[i + 1] - la[i])
            res.append(dict(lambda_m=10 ** lc, i=i, t=t, slope_dlogalpha_dloglambda=slope,
                            direction='enters_excluded' if lb[i + 1] < 0 else 'leaves_excluded'))
    return res


def crossing_uncertainty(cr, px, py, cal, width_pt):
    """1-sigma-like reading uncertainty of a crossing, in dex of lambda.
    cal : tick-fit rms residual in x and y (propagated through the local slope);
    stroke : the drawn line has finite width; the centre line is exact in the
             vector data, but we allow +-w/2 perpendicular offset as a reading
             tolerance, mapped onto the horizontal alpha0 row: dx = (w/2)/|sin theta|."""
    i = cr['i']; s = cr['slope_dlogalpha_dloglambda']
    ax, ay = cal['x_fit']['a_dec_per_pt'], cal['y_fit']['a_dec_per_pt']
    sx, sy = cal['x_fit']['rms_residual_dec'], cal['y_fit']['rms_residual_dec']
    d_cal = float(np.hypot(sx, sy / abs(s)))
    dxp, dyp = px[i + 1] - px[i], py[i + 1] - py[i]
    sin_t = abs(dyp) / np.hypot(dxp, dyp)
    d_stroke = float((width_pt / 2) / max(sin_t, 1e-6) * abs(ax))
    return dict(cal_dex=d_cal, stroke_half_width_dex=d_stroke, combined_dex=float(np.hypot(d_cal, d_stroke)))


def intervals_from_mask(lg, mask):
    out, i = [], 0
    while i < len(mask):
        if mask[i]:
            j = i
            while j + 1 < len(mask) and mask[j + 1]:
                j += 1
            out.append([10 ** lg[i], 10 ** lg[j]]); i = j + 1
        else:
            i += 1
    return out


def fill_row_intervals(path, la0=LA0):
    """Intersections of the horizontal line log alpha = la0 with the drawn fill polygons."""
    rows = list(csv.DictReader(open(path)))
    polys = {}
    for r in rows:
        polys.setdefault(int(r['polygon']), []).append((np.log10(float(r['lambda_m'])), np.log10(float(r['alpha']))))
    ivs = []
    for P in polys.values():
        P = np.array(P); xs = []
        for k in range(len(P)):
            (x0, y0), (x1, y1) = P[k], P[(k + 1) % len(P)]
            if (y0 - la0) * (y1 - la0) < 0:
                xs.append(x0 + (la0 - y0) * (x1 - x0) / (y1 - y0))
        xs.sort()
        ivs += [[xs[m], xs[m + 1]] for m in range(0, len(xs) - 1, 2)]
    ivs.sort(); merged = []
    for a, b in ivs:                       # union, joining touching polygons (<1e-3 dec)
        if merged and a <= merged[-1][1] + 1e-3:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [[10 ** a, 10 ** b] for a, b in merged]


def transition_note(R, vec_abs, pos, tl, tpos, tabs):
    """Headline note on the transition band. The band is not explained by the HUST
    sign treatment alone: it comes from comparing different experiments and bound constructions. Between
    the Eot-Wash 2020 |alpha95| crossings (~98.1 um) and the +alpha95 crossing (101.0 um) the two Eot-Wash
    constructions already differ without any HUST curve (thesis p. 145: +-alpha95 from the Delta chi2 = 6.17
    surface, |alpha95| from the 0.95 integral of N(alpha*, sigma) between -|alpha95| and +|alpha95|)."""
    ew = [c for c in R['curves']['Lee2020_fig5/Eot-Wash_2020']['crossings'] if c['direction'] == 'enters_excluded'][0]['lambda_m']
    tha = R['sources']['Lee2020_thesis_abs_alpha95']['crossings'][0]['lambda_m_loglog']
    i100 = int(np.argmin(np.abs(tl - 1e-4)))
    return ('The %.1f-%.1f um transition band comes from comparing different experiments and bound constructions, '
            'not from the HUST sign treatment alone. %.1f to ~%.1f um: alpha0 is excluded only by the HUST 2020/2016 |alpha| '
            'curves as drawn, if they are applied to alpha > 0 (sign-separated HUST limits not available, abstract only). '
            '~%.1f to %.1f um: already without HUST, the Eot-Wash 2020 |alpha95| reading (drawn curve %.3f um, thesis |alpha95| '
            'column %.2f um) and the thesis +alpha95 column (%.3f um) differ; thesis p. 145: +-alpha95 from the Delta chi2 = 6.17 '
            'surface, |alpha95| from the 0.95 integral of the normal distribution between -|alpha95| and +|alpha95|. '
            'Row %.0f um: +alpha95 = %.4g, |alpha95| = %.4g, alpha0 = %.5f. Published bounds are used as defined, not redefined.'
            % (vec_abs * 1e6, pos['lambda_m_loglog'] * 1e6, vec_abs * 1e6, ew * 1e6, min(ew, tha) * 1e6, pos['lambda_m_loglog'] * 1e6,
               ew * 1e6, tha * 1e6, pos['lambda_m_loglog'] * 1e6, tl[i100] * 1e6, tpos[i100], tabs[i100], ALPHA0))


def main():
    cal = json.load(open(os.path.join(DIG, 'calibration.json')))['figures']
    raster = json.load(open(os.path.join(OUT, 'raster_crosscheck.json')))['figures']
    th = list(csv.DictReader(l for l in open(os.path.join(DIG, 'Lee2020_thesis_table11_4.csv')) if not l.startswith('#')))
    tl = np.array([float(r['lambda_mm']) for r in th]) * 1e-3
    tpos = np.array([float(r['alpha95_pos']) for r in th])
    tabs = np.array([float(r['alpha95_abs']) for r in th])
    tneg = np.array([-float(r['alpha95_neg']) for r in th])

    R = dict(alpha0=ALPHA0, log10_alpha0=LA0, convention='V = -G m1 m2/r (1 + alpha e^{-r/lambda}); 95% CL',
             status='preliminary; numerical cross-checks with Academia Co-scientist (AI-assisted)', curves={}, sources={})

    # ---------------- 1. digitized curves: crossings + reading uncertainty
    curves = {}
    cross_rows = []
    for fig in ('AHN2003_fig5', 'Lee2020_fig5'):
        for name, meta in cal[fig]['curves'].items():
            lam, alp, px, py = read_curve(os.path.join(DIG, meta['csv']))
            curves[(fig, name)] = (lam, alp)
            crs = crossings(lam, alp)
            for c in crs:
                u = crossing_uncertainty(c, px, py, cal[fig], meta['stroke_width_pt'])
                c.update(u); c['lambda_um'] = c['lambda_m'] * 1e6
                c['lambda_um_lo'] = c['lambda_um'] * 10 ** -u['combined_dex']
                c['lambda_um_hi'] = c['lambda_um'] * 10 ** u['combined_dex']
                cross_rows.append(dict(figure=fig, curve=name, kind='|alpha| curve (drawn)', **{k: c[k] for k in (
                    'lambda_um', 'lambda_um_lo', 'lambda_um_hi', 'direction', 'slope_dlogalpha_dloglambda',
                    'cal_dex', 'stroke_half_width_dex', 'combined_dex')}))
            R['curves'][f'{fig}/{name}'] = dict(lambda_range_m=[float(lam[0]), float(lam[-1])],
                                                alpha_min=float(alp.min()),
                                                crossings=[{k: v for k, v in c.items() if k not in ('i', 't')} for c in crs])

    # ---------------- 2. envelopes on a common grid
    def envelope(keys):
        E = np.full(GRID.shape, np.nan); who = np.array([''] * len(GRID), dtype=object)
        for k in keys:
            lam, alp = curves[k]; v = loglog(lam, alp, 10 ** GRID)
            better = np.isfinite(v) & ~(v >= E)
            E[better] = v[better]; who[better] = k[1]
        return E, who

    env = {}
    for label, keys in [('AHN2003_fig5_all', [k for k in curves if k[0] == 'AHN2003_fig5']),
                        ('Lee2020_fig5_all', [k for k in curves if k[0] == 'Lee2020_fig5']),
                        ('combined_abs', list(curves))]:
        E, who = envelope(keys)
        excl = np.isfinite(E) & (E < ALPHA0)
        ivs = intervals_from_mask(GRID, excl)
        first = ivs[0][0] if ivs else None
        lim_at_first = who[np.argmax(excl)] if ivs else None
        env[label] = dict(E=E, who=who)
        R['sources'][label] = dict(kind='lower envelope of drawn |alpha| curves',
                                   excluded_intervals_m=ivs, first_excluded_lambda_m=first,
                                   curve_setting_first_crossing=lim_at_first,
                                   covered_lambda_range_m=[float(10 ** GRID[np.isfinite(E)][0]), float(10 ** GRID[np.isfinite(E)][-1])])
    np.savez_compressed(os.path.join(OUT, 'envelopes.npz'), log10_lambda=GRID,
                        **{k: v['E'] for k, v in env.items()})

    # ---------------- 3. drawn fill polygons (second vector reading of the excluded region)
    for fig in ('AHN2003_fig5', 'AHN2003_fig4'):
        ivs = fill_row_intervals(os.path.join(DIG, f'{fig}__fill_polygons.csv'))
        R['sources'][f'{fig}_fill'] = dict(kind='drawn excluded-region fill polygons (vector)',
                                           excluded_intervals_m=ivs, first_excluded_lambda_m=ivs[0][0] if ivs else None)

    # ---------------- 4. Lee 2020 thesis Table 11.4 (sign-separated)
    def table_cross(vals, label):
        lx, ly = np.log10(tl), np.log10(vals)
        k = np.where((ly[:-1] - LA0) * (ly[1:] - LA0) < 0)[0]
        out = []
        for i in k:
            lin = lx[i] + (LA0 - ly[i]) * (lx[i + 1] - lx[i]) / (ly[i + 1] - ly[i])
            p = PchipInterpolator(lx, ly - LA0)
            r = p.roots(extrapolate=False); r = r[(r >= lx[i]) & (r <= lx[i + 1])]
            pch = float(r[0]) if len(r) else np.nan
            # linear alpha vs log lambda (a third interpolation scheme)
            lin2 = lx[i] + (ALPHA0 - vals[i]) * (lx[i + 1] - lx[i]) / (vals[i + 1] - vals[i])
            ests = 10 ** np.array([lin, pch, lin2])
            out.append(dict(bracket_m=[float(tl[i]), float(tl[i + 1])],
                            bracket_values=[float(vals[i]), float(vals[i + 1])],
                            lambda_m_loglog=float(ests[0]), lambda_m_pchip_loglog=float(ests[1]),
                            lambda_m_lin_alpha_log_lambda=float(ests[2]),
                            interpolation_spread_m=[float(ests.min()), float(ests.max())],
                            direction='enters_excluded' if ly[i + 1] < LA0 else 'leaves_excluded'))
            cross_rows.append(dict(figure='Lee2020_thesis_table11_4', curve=label, kind='table (published numbers)',
                                   lambda_um=ests[0] * 1e6, lambda_um_lo=ests.min() * 1e6, lambda_um_hi=ests.max() * 1e6,
                                   direction=out[-1]['direction'], slope_dlogalpha_dloglambda=(ly[i + 1] - ly[i]) / (lx[i + 1] - lx[i]),
                                   cal_dex=0.0, stroke_half_width_dex=0.0,
                                   combined_dex=float(np.log10(ests.max() / ests.min()) / 2)))
        excl = [[float(tl[i]), float(tl[i])] for i in range(len(tl)) if vals[i] < ALPHA0]
        return out, excl

    for col, vals in [('plus_alpha95', tpos), ('abs_alpha95', tabs), ('minus_alpha95_magnitude', tneg)]:
        cr, ex = table_cross(vals, col)
        R['sources'][f'Lee2020_thesis_{col}'] = dict(
            kind='published table, J. G. Lee PhD thesis (UW 2020) Table 11.4',
            crossings=cr, table_lambda_range_m=[float(tl[0]), float(tl[-1])],
            rows_excluded_count=len(ex), first_row_excluded_m=ex[0][0] if ex else None,
            all_rows_beyond_first_excluded=bool(ex) and all(v < ALPHA0 for v in vals[tl >= ex[0][0]]))

    # ---------------- 5. raster cross-check summary
    R['raster_crosscheck'] = {k: dict(first_excluded_lambda_m=v['first_excluded_lambda_m'],
                                      spread_over_pm2_rows_m=v['first_excluded_lambda_spread_m'],
                                      excluded_intervals_m=v['excluded_intervals_m_by_row_offset']['0'])
                              for k, v in raster.items()}

    # ---------------- 6. headline numbers
    hust = [c for c in R['curves']['Lee2020_fig5/HUST_2020']['crossings'] if c['direction'] == 'enters_excluded'][0]
    vec_abs = R['sources']['combined_abs']['first_excluded_lambda_m']
    ras_abs = raster['Lee2020_fig5']['first_excluded_lambda_m']
    pos = R['sources']['Lee2020_thesis_plus_alpha95']['crossings'][0]
    abs_sys = abs(np.log10(ras_abs / vec_abs))
    tot_abs = float(np.hypot(hust['combined_dex'], abs_sys))
    R['headline'] = dict(
        abs_alpha_reading=dict(
            description='all drawn |alpha| bounds treated as bounds on +alpha (most restrictive reading)',
            lambda_c_m=vec_abs, set_by='HUST 2020 (Tan et al., PRL 124, 051301) as drawn in Lee 2020 Fig. 5',
            uncertainty_dex=dict(reading=hust['combined_dex'], raster_vs_vector=float(abs_sys), combined=tot_abs),
            lambda_c_range_m=[vec_abs * 10 ** -tot_abs, vec_abs * 10 ** tot_abs],
            allowed='lambda < lambda_c (down to 1 um in the drawn curves; 1 nm-1 um only Casimir-derived bounds >= 1e9, AHN 2003 Fig. 9)',
            excluded='lambda_c .. 1 cm (AHN Fig. 5, Lee Fig. 5) and %.3g mm .. %.2g m (AHN Fig. 4 fills)' % (
                R['sources']['AHN2003_fig4_fill']['first_excluded_lambda_m'] * 1e3,
                R['sources']['AHN2003_fig4_fill']['excluded_intervals_m'][-1][1])),
        plus_alpha_reading=dict(
            description='sign-separated +alpha95 (Lee 2020 thesis Table 11.4, Eot-Wash 2020 data only)',
            lambda_c_m=pos['lambda_m_loglog'], interpolation_spread_m=pos['interpolation_spread_m'],
            table_bracket_m=pos['bracket_m'], table_bracket_values=pos['bracket_values']),
        transition_band_m=[vec_abs, pos['lambda_m_loglog']],
        note=transition_note(R, vec_abs, pos, tl, tpos, tabs))

    # ---------------- 7. ratio table
    ratio_rows = []
    sel = [('Lee2020_thesis +alpha95', lambda x: np.interp(np.log10(x), np.log10(tl), np.log10(tpos), left=np.nan, right=np.nan)),
           ('Lee2020_thesis |alpha95|', lambda x: np.interp(np.log10(x), np.log10(tl), np.log10(tabs), left=np.nan, right=np.nan))]
    for (lab, fn) in sel:
        for lu in KEY_LAMBDA_UM:
            v = 10 ** fn(lu * 1e-6)
            ratio_rows.append(dict(source=lab, lambda_um=lu, alpha_lim=v, R=ALPHA0 / v if np.isfinite(v) else np.nan))
    for lab, key in [('envelope Lee2020 Fig.5 (|alpha|)', 'Lee2020_fig5_all'),
                     ('envelope AHN2003 Fig.5 (|alpha|)', 'AHN2003_fig5_all'),
                     ('envelope combined (|alpha|)', 'combined_abs')]:
        E, who = env[key]['E'], env[key]['who']
        for lu in KEY_LAMBDA_UM:
            j = int(round((np.log10(lu * 1e-6) - GRID[0]) / (GRID[1] - GRID[0])))
            v = E[j] if 0 <= j < len(GRID) else np.nan
            ratio_rows.append(dict(source=lab, lambda_um=lu, alpha_lim=v, R=ALPHA0 / v if np.isfinite(v) else np.nan,
                                   set_by=who[j] if 0 <= j < len(GRID) and np.isfinite(v) else ''))
    for fig, name in [('Lee2020_fig5', 'HUST_2020'), ('Lee2020_fig5', 'Eot-Wash_2020'), ('AHN2003_fig5', 'Eot-Wash')]:
        lam, alp = curves[(fig, name)]
        for lu in KEY_LAMBDA_UM:
            v = loglog(lam, alp, lu * 1e-6)[0]
            ratio_rows.append(dict(source=f'{fig}/{name} (|alpha|)', lambda_um=lu, alpha_lim=v, R=ALPHA0 / v if np.isfinite(v) else np.nan))
    R['ratio_table'] = ratio_rows

    # ---------------- 8. validation against numbers stated in the texts
    def lam_at(fig, name, a, which='enters_excluded'):
        lam, alp = curves[(fig, name)]
        c = [x for x in crossings(lam, alp, a) if x['direction'] == which]
        return c[0]['lambda_m'] if c else np.nan
    V = []
    def add(qty, dig, stated, tol_rel, src):
        dev = dig / stated - 1
        V.append(dict(check=qty, digitized=dig, stated=stated, rel_dev=dev, tolerance_rel=tol_rel,
                      result='consistent' if abs(dev) <= tol_rel else 'TENSION', stated_in=src))
    add('Lee2020 Fig5 Eot-Wash 2020 curve: lambda at |alpha|=1 [um]', lam_at('Lee2020_fig5', 'Eot-Wash_2020', 1) * 1e6, 38.6, 0.03,
        'Lee et al. PRL 124, 101101 (2020) abstract: lambda < 38.6 um')
    add('Lee2020 Fig5 Eot-Wash 2007 curve: lambda at |alpha|=1 [um]', lam_at('Lee2020_fig5', 'Eot-Wash_2007', 1) * 1e6, 56, 0.03,
        'Kapner et al. PRL 98, 021101 (2007) abstract: down to 56 um')
    add('Lee2020 Fig5 Eot-Wash 2004 curve: lambda at |alpha|=1 [um]', lam_at('Lee2020_fig5', 'Eot-Wash_2004', 1) * 1e6, 197, 0.03,
        'Hoyle et al. PRD 70, 042004 (2004), arXiv:hep-ph/0405262 abstract: lambda >= 197 um')
    add('Lee2020 Fig5 HUST 2020 curve: lambda at |alpha|=1 [um]', lam_at('Lee2020_fig5', 'HUST_2020', 1) * 1e6, 48, 0.03,
        'Tan et al. PRL 124, 051301 (2020) abstract: down to 48 um')
    add('Lee2020 Fig5 HUST 2016 curve: lambda at |alpha|=1 [um]', lam_at('Lee2020_fig5', 'HUST_2016', 1) * 1e6, 59, 0.03,
        'Tan et al. PRL 116, 131101 (2016) abstract: down to 59 um')
    add('Lee2020 Fig5 Eot-Wash 2020 curve: lambda at |alpha|=8/3 [um]', lam_at('Lee2020_fig5', 'Eot-Wash_2020', 8 / 3) * 1e6, 30, 0.05,
        'Lee 2020 abstract: R < 30 um (largest extra dimension, toroidal, alpha = 8/3)')
    add('Lee2020 Fig5 Eot-Wash 2007 curve: lambda at |alpha|=8/3 [um]', lam_at('Lee2020_fig5', 'Eot-Wash_2007', 8 / 3) * 1e6, 44, 0.05,
        'Kapner 2007 abstract: R <= 44 um')
    add('Lee2020 Fig5 Eot-Wash 2004 curve: lambda at |alpha|=8/3 [um]', lam_at('Lee2020_fig5', 'Eot-Wash_2004', 8 / 3) * 1e6, 160, 0.05,
        'Hoyle 2004 abstract: R* <= 160 um')
    add('AHN2003 Fig5 Eot-Wash curve: lambda at alpha=16/3 [um]', lam_at('AHN2003_fig5', 'Eot-Wash', 16 / 3) * 1e6, 130, 0.05,
        'AHN 2003 text p.45: alpha >= 16/3 consistent only for lambda < 130 um')
    add('AHN2003 Fig5 Eot-Wash curve: lambda at alpha=8/3 [um]', lam_at('AHN2003_fig5', 'Eot-Wash', 8 / 3) * 1e6, 155, 0.05,
        'AHN 2003 text p.45: R* <= 155 um')
    add('AHN2003 Fig5 Eot-Wash curve: lambda at alpha=1 [um]', lam_at('AHN2003_fig5', 'Eot-Wash', 1) * 1e6, 200, 0.05,
        'AHN 2003 text p.56-57: verified down to lambda = 200 um (rounded)')
    # table <-> figure: thesis |alpha95| vs the drawn Eot-Wash 2020 curve
    lam, alp = curves[('Lee2020_fig5', 'Eot-Wash_2020')]
    m = (tl >= lam[0]) & (tl <= lam[-1])
    dd = np.log10(loglog(lam, alp, tl[m]) / tabs[m])
    V.append(dict(check='Lee2020 Fig5 Eot-Wash 2020 curve vs thesis Table 11.4 |alpha95| (all %d rows in range): '
                        'median / max |log10 ratio| [dex]' % m.sum(),
                  digitized=float(np.median(dd)), stated=float(np.max(np.abs(dd))), rel_dev=float(10 ** np.max(np.abs(dd)) - 1),
                  tolerance_rel=0.05, result='consistent' if 10 ** np.max(np.abs(dd)) - 1 <= 0.05 else 'TENSION',
                  stated_in='Lee thesis Table 11.4 (|alpha95| column)'))
    add('thesis |alpha95| crossing of alpha0 vs drawn Eot-Wash 2020 curve crossing [um]',
        R['curves']['Lee2020_fig5/Eot-Wash_2020']['crossings'][0]['lambda_m'] * 1e6,
        R['sources']['Lee2020_thesis_abs_alpha95']['crossings'][0]['lambda_m_loglog'] * 1e6, 0.03,
        'Lee thesis Table 11.4, log-log interpolation')
    add('raster (600 dpi) vs vector first excluded lambda, Lee2020 Fig5 [um]', ras_abs * 1e6, vec_abs * 1e6, 0.03, 'this package, two methods')
    add('raster (600 dpi) vs vector first excluded lambda, AHN2003 Fig5 [um]',
        raster['AHN2003_fig5']['first_excluded_lambda_m'] * 1e6, R['sources']['AHN2003_fig5_all']['first_excluded_lambda_m'] * 1e6, 0.03,
        'this package, two methods')
    add('vector fill vs curve-centre first excluded lambda, AHN2003 Fig5 [um]',
        R['sources']['AHN2003_fig5_fill']['first_excluded_lambda_m'] * 1e6, R['sources']['AHN2003_fig5_all']['first_excluded_lambda_m'] * 1e6, 0.03,
        'this package, two vector readings')
    add('raster vs vector-fill first excluded lambda, AHN2003 Fig4 [mm]',
        raster['AHN2003_fig4']['first_excluded_lambda_m'] * 1e3, R['sources']['AHN2003_fig4_fill']['first_excluded_lambda_m'] * 1e3, 0.03,
        'this package, two methods')
    R['validation'] = V

    # ---------------- write
    def clean(o):
        if isinstance(o, dict): return {str(k): clean(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)): return [clean(v) for v in o]
        if isinstance(o, (np.floating, float)): return None if not np.isfinite(o) else float(o)
        if isinstance(o, np.integer): return int(o)
        if isinstance(o, np.bool_): return bool(o)
        return o
    json.dump(clean(R), open(os.path.join(OUT, 'results.json'), 'w'), indent=1)
    for fn, rows in [('crossings.csv', cross_rows), ('ratio_table.csv', ratio_rows), ('validation_checks.csv', V)]:
        keys = []
        for r in rows:
            keys += [k for k in r if k not in keys]
        with open(os.path.join(OUT, fn), 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
            for r in rows:
                w.writerow({k: (f'{v:.6g}' if isinstance(v, (float, np.floating)) else v) for k, v in r.items()})
    h = R['headline']
    print('|alpha| reading: lambda_c = %.2f um  [%.2f, %.2f]' % (h['abs_alpha_reading']['lambda_c_m'] * 1e6,
          *(np.array(h['abs_alpha_reading']['lambda_c_range_m']) * 1e6)))
    print('+alpha (thesis): lambda_c = %.2f um  spread %s' % (h['plus_alpha_reading']['lambda_c_m'] * 1e6,
          np.round(np.array(h['plus_alpha_reading']['interpolation_spread_m']) * 1e6, 2)))
    for v in V:
        print(f"  [{v['result']}] {v['check']}: {v['digitized']:.4g} vs {v['stated']:.4g} ({100 * v['rel_dev']:+.1f}%)")
    for k, s in R['sources'].items():
        if 'excluded_intervals_m' in s:
            print(k, [(f'{a:.4g}', f'{b:.4g}') for a, b in s['excluded_intervals_m']])


if __name__ == '__main__':
    sys.exit(main())
