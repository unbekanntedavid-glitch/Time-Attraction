#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Automated check of the HUST-free crossings in the transition band.

Computes, directly from the digitized CSVs in outputs/digitized/ and without any HUST curve:
  * the first lambda where any non-HUST drawn |alpha| curve (Lee 2020 Fig. 5, AHN 2003 Fig. 5)
    falls below alpha0 = 1/(4 pi)  (expected: Eot-Wash 2020, ~98.07 um);
  * the crossing of the thesis |alpha95| column (Lee 2020 thesis Table 11.4, ~98.14 um);
  * the crossing of the thesis +alpha95 column (~101.03 um).
Crossings: log-log linear interpolation between neighbouring points, root by bisection.
Asserts that the ~98.1 um vs 101.0 um gap exists (both Eot-Wash constructions, no HUST),
that the 100 um table row has |alpha95| < alpha0 < +alpha95, that the HUST 2020 |alpha|
crossing stays at the lower band edge (~75.9 um), and that results.json, the methodology
texts and the figure labels no longer say the band depends on the HUST sign treatment alone.
Writes outputs/check_hust_free_gap.json. Exit 1 on any failed assertion. Nothing is deleted."""
import csv, json, math, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIG = os.path.join(ROOT, 'outputs', 'digitized')
ALPHA0 = 1 / (4 * math.pi)
LO, HI = 30e-6, 1e-3          # search range [m]


def rows(fn):
    return list(csv.DictReader(l for l in open(os.path.join(DIG, fn), encoding='utf-8') if not l.startswith('#')))


def crossings(lam, alp, a0=ALPHA0):
    """lambda where log(alpha) - log(a0) changes sign from >0 to <0 (enters excluded), log-log linear."""
    out = []
    pts = sorted((l, a) for l, a in zip(lam, alp) if l > 0 and a > 0 and LO <= l <= HI)
    for (l1, a1), (l2, a2) in zip(pts, pts[1:]):
        f1, f2 = math.log10(a1 / a0), math.log10(a2 / a0)
        if f1 > 0 >= f2 and l2 > l1:
            x1, x2 = math.log10(l1), math.log10(l2)
            lo, hi = x1, x2
            for _ in range(200):                       # bisection on the linear segment
                m = 0.5 * (lo + hi); fm = f1 + (f2 - f1) * (m - x1) / (x2 - x1)
                lo, hi = (m, hi) if fm > 0 else (lo, m)
            out.append(10 ** (0.5 * (lo + hi)))
    return out


def main():
    bad, res = [], {}
    cal = json.load(open(os.path.join(DIG, 'calibration.json'), encoding='utf-8'))['figures']
    per_curve = {}
    for fg in ('Lee2020_fig5', 'AHN2003_fig5'):
        for name, meta in cal[fg]['curves'].items():
            r = rows(meta['csv'])
            per_curve[f'{fg}/{name}'] = crossings([float(x['lambda_m']) for x in r], [float(x['alpha_abs_lim']) for x in r])
    nonhust = {k: v for k, v in per_curve.items() if 'HUST' not in k and v}
    first_k = min(nonhust, key=lambda k: nonhust[k][0])
    ew = per_curve['Lee2020_fig5/Eot-Wash_2020'][0]
    hust20 = per_curve['Lee2020_fig5/HUST_2020'][0]
    th = rows('Lee2020_thesis_table11_4.csv')
    tl = [float(x['lambda_mm']) * 1e-3 for x in th]
    tpos = [float(x['alpha95_pos']) for x in th]; tabs = [float(x['alpha95_abs']) for x in th]
    th_abs = crossings(tl, tabs)[0]; th_pos = crossings(tl, tpos)[0]
    i100 = min(range(len(tl)), key=lambda i: abs(tl[i] - 1e-4))
    res.update(alpha0=ALPHA0,
               crossings_um={k: [x * 1e6 for x in v] for k, v in per_curve.items()},
               first_non_hust_curve=first_k, first_non_hust_crossing_um=nonhust[first_k][0] * 1e6,
               eot_wash_2020_abs_um=ew * 1e6, thesis_abs_alpha95_um=th_abs * 1e6, thesis_plus_alpha95_um=th_pos * 1e6,
               hust_2020_abs_um=hust20 * 1e6,
               hust_free_gap_um=[min(ew, th_abs) * 1e6, th_pos * 1e6], gap_width_um=(th_pos - max(ew, th_abs)) * 1e6,
               row_100um=dict(lambda_um=tl[i100] * 1e6, plus_alpha95=tpos[i100], abs_alpha95=tabs[i100]))

    def need(cond, msg):
        (res.setdefault('passed', []) if cond else bad).append(msg)
    need(first_k == 'Lee2020_fig5/Eot-Wash_2020', f'first non-HUST crossing is Eot-Wash 2020 (got {first_k})')
    need(97.5 < ew * 1e6 < 98.6, f'Eot-Wash 2020 |alpha| crossing {ew*1e6:.3f} um in (97.5, 98.6)')
    need(97.6 < th_abs * 1e6 < 98.6, f'thesis |alpha95| crossing {th_abs*1e6:.3f} um in (97.6, 98.6)')
    need(100.5 < th_pos * 1e6 < 101.5, f'thesis +alpha95 crossing {th_pos*1e6:.3f} um in (100.5, 101.5)')
    need(th_pos - max(ew, th_abs) > 2.0e-6, f'HUST-free gap {(th_pos-max(ew,th_abs))*1e6:.3f} um > 2.0 um')
    need(abs(tl[i100] - 1e-4) < 1e-12 and tabs[i100] < ALPHA0 < tpos[i100],
         f'row 100 um: |alpha95| {tabs[i100]} < alpha0 {ALPHA0:.5f} < +alpha95 {tpos[i100]}')
    need(abs(tpos[i100] - 0.0813) < 1e-9 and abs(tabs[i100] - 0.0766) < 1e-9, 'row 100 um values 0.0813 / 0.0766 as tabulated')
    need(75.0 < hust20 * 1e6 < 76.8, f'HUST 2020 |alpha| crossing {hust20*1e6:.3f} um at the lower band edge')
    # consistency with the machine headline (numbers unchanged, note no longer HUST-only)
    H = json.load(open(os.path.join(ROOT, 'outputs', 'results.json'), encoding='utf-8'))['headline']
    b0, b1 = H['transition_band_m']
    need(abs(b0 * 1e6 - 75.9) < 0.05 and abs(b1 * 1e6 - 101.0) < 0.05, f'headline band {b0*1e6:.2f}-{b1*1e6:.2f} um (75.9-101.0)')
    need(math.isclose(b1, th_pos, rel_tol=1e-6), 'headline upper edge equals the thesis +alpha95 crossing recomputed here')
    need('only if the HUST' not in H['note'] and 'Eot-Wash 2020 |alpha95|' in H['note'], 'results.json headline note: not HUST-only')
    # text and figure-label consistency (the HUST-only wording must not appear)
    old = {'methodology_en.md': ['excluded only if the HUST 2020/2016'], 'methodology_hu.md': ['csak akkor kizárt, ha a HUST'],
           os.path.join('scripts', 'make_figures.py'): ['depends on the sign', 'előjel-kezelésétől függ']}
    new = {'methodology_en.md': ['98.1', '101.0'], 'methodology_hu.md': ['98.1', '101.0'],
           os.path.join('scripts', 'make_figures.py'): ['Eöt-Wash |α₉₅| vs +α₉₅']}
    for f in old:
        s = open(os.path.join(ROOT, f), encoding='utf-8').read()
        need(not any(o in s for o in old[f]) and all(n in s for n in new[f]), f'{f}: transition-band wording updated')
    res['failed'] = bad
    os.makedirs(os.path.join(ROOT, 'outputs'), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, 'outputs', 'check_hust_free_gap.json'), 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    print('check_hust_free_gap: Eot-Wash 2020 |a| %.3f um, thesis |a95| %.3f um, thesis +a95 %.3f um, gap %.3f um; %s'
          % (ew * 1e6, th_abs * 1e6, th_pos * 1e6, res['gap_width_um'], 'PASS' if not bad else 'FAIL'))
    for b in bad: print('  FAIL', b)
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
