# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Vector extraction helpers: PDF page -> SVG (poppler pdftocairo) -> stroked
segments and filled polygons in PDF page coordinates (pt, y downwards)."""
import re, subprocess, os
import numpy as np

_NUM = r'[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?'


def pdf_page_to_svg(pdf, page, out_svg):
    subprocess.run(['pdftocairo', '-svg', '-f', str(page), '-l', str(page), pdf, out_svg],
                   check=True)
    return out_svg


def _tokens(d):
    return re.findall(r'[MLCZz]|' + _NUM, d)


def _subpaths(d, n_bezier=8):
    toks = _tokens(d)
    subs, cur, cmd, i = [], [], None, 0
    while i < len(toks):
        t = toks[i]
        if t in 'MLCZz':
            cmd = t
            i += 1
            if t == 'M' and cur:
                subs.append(cur)
                cur = []
            if t in 'Zz' and cur:
                cur.append(cur[0])
            continue
        n = 2 if cmd in 'ML' else 6
        v = [float(x) for x in toks[i:i + n]]
        i += n
        if cmd == 'C':
            p0 = cur[-1]
            P = [p0, (v[0], v[1]), (v[2], v[3]), (v[4], v[5])]
            for tt in np.linspace(1.0 / n_bezier, 1, n_bezier):
                b = [(1 - tt) ** 3, 3 * (1 - tt) ** 2 * tt, 3 * (1 - tt) * tt ** 2, tt ** 3]
                cur.append((sum(b[k] * P[k][0] for k in range(4)),
                            sum(b[k] * P[k][1] for k in range(4))))
        else:
            if cmd == 'M' and cur:  # implicit lineto after first pair
                pass
            cur.append((v[0], v[1]))
            if cmd == 'M':
                cmd = 'L'
    if cur:
        subs.append(cur)
    return subs


def _apply(m, arr):
    X = m[0] * arr[:, 0] + m[2] * arr[:, 1] + m[4]
    Y = m[1] * arr[:, 0] + m[3] * arr[:, 1] + m[5]
    return X, Y


def parse_svg(svg):
    """Return (strokes, fills). strokes: list of dict(stroke,w,x,y); fills: list of
    dict(fill,x,y). Only top-level <path> elements (glyph definitions are skipped
    because they carry no stroke or fill attribute)."""
    s = open(svg, encoding='utf-8').read()
    strokes, fills = [], []
    for p in re.findall(r'<path ([^>]*)/>', s):
        a = dict(re.findall(r'([\w-]+)="([^"]*)"', p))
        if 'd' not in a:
            continue
        m = [float(v) for v in re.findall(_NUM, a['transform'])] if 'transform' in a else [1, 0, 0, 1, 0, 0]
        for sp in _subpaths(a['d']):
            arr = np.array(sp, dtype=float)
            X, Y = _apply(m, arr)
            if a.get('stroke') not in (None, 'none'):
                strokes.append(dict(stroke=a['stroke'], w=float(a.get('stroke-width', 0)), x=X, y=Y))
            elif a.get('fill') not in (None, 'none'):
                fills.append(dict(fill=a['fill'], x=X, y=Y))
    return strokes, fills


def chain_segments(strokes, tol=0.05):
    """Join 2-point stroke segments that share end points into polylines."""
    segs, seen = [], set()
    for p in strokes:
        s = (p['x'][0], p['y'][0], p['x'][-1], p['y'][-1])
        k = tuple(np.round(s, 2))
        k2 = (k[2], k[3], k[0], k[1])
        if k in seen or k2 in seen:
            continue
        seen.add(k)
        segs.append(s)
    used = [False] * len(segs)
    lines = []
    for i in range(len(segs)):
        if used[i]:
            continue
        used[i] = True
        L = [(segs[i][0], segs[i][1]), (segs[i][2], segs[i][3])]
        grown = True
        while grown:
            grown = False
            for j in range(len(segs)):
                if used[j]:
                    continue
                a = (segs[j][0], segs[j][1])
                b = (segs[j][2], segs[j][3])
                for end in (1, 0):
                    p = L[-1] if end else L[0]
                    for q, r in ((a, b), (b, a)):
                        if np.hypot(p[0] - q[0], p[1] - q[1]) < tol:
                            if end:
                                L.append(r)
                            else:
                                L.insert(0, r)
                            used[j] = True
                            grown = True
                            break
                    if used[j]:
                        break
        lines.append(np.array(L))
    return lines


def points_in_polygon(px, py, poly_x, poly_y):
    """Even-odd ray casting; vectorised over points."""
    px = np.asarray(px, float)
    py = np.asarray(py, float)
    inside = np.zeros(px.shape, bool)
    n = len(poly_x)
    j = n - 1
    for i in range(n):
        xi, yi, xj, yj = poly_x[i], poly_y[i], poly_x[j], poly_y[j]
        cond = ((yi > py) != (yj > py))
        with np.errstate(divide='ignore', invalid='ignore'):
            xint = (xj - xi) * (py - yi) / (yj - yi) + xi
        inside ^= cond & (px < xint)
        j = i
    return inside
