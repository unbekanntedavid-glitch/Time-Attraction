#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Numeric regression check of a fresh run against reference/ (shipped with the
package).  Compares every numeric value in results.json, calibration.json,
raster_crosscheck.json and every digitized CSV with a relative tolerance.
Byte-identical outputs are NOT expected (PNG/PDF and float formatting may
differ between platforms); only numbers within tolerance are checked."""
import csv, glob, json, math, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REF = os.path.join(ROOT, 'reference')
RTOL = float(os.environ.get('VERIFY_RTOL', '1e-4'))
ATOL = 1e-12
bad = []; n = 0


def cmp(a, b, path):
    global n
    if isinstance(a, dict):
        if set(a) != set(b):
            bad.append(f'{path}: key sets differ {sorted(set(a) ^ set(b))}'); return
        for k in a: cmp(a[k], b[k], f'{path}/{k}')
    elif isinstance(a, list):
        if len(a) != len(b):
            bad.append(f'{path}: length {len(a)} vs {len(b)}'); return
        for i, (x, y) in enumerate(zip(a, b)): cmp(x, y, f'{path}[{i}]')
    elif isinstance(a, bool) or a is None or isinstance(a, str):
        n += 1
        if a != b and not (isinstance(a, str) and path.endswith(('/method', '/csv', '/note'))):
            bad.append(f'{path}: {a!r} vs {b!r}')
    elif isinstance(a, (int, float)):
        n += 1
        if (not isinstance(b, (int, float)) or isinstance(b, bool) or not (math.isfinite(a) and math.isfinite(b))
                or not math.isclose(a, b, rel_tol=RTOL, abs_tol=ATOL)):
            bad.append(f'{path}: {a} vs {b}')


def num(s):
    try: return float(s)
    except ValueError: return s


def main():
    pairs = [('outputs/results.json', 'results.json'), ('outputs/digitized/calibration.json', 'calibration.json'),
             ('outputs/raster_crosscheck.json', 'raster_crosscheck.json')]
    for new, ref in pairs:
        cmp(json.load(open(os.path.join(ROOT, new))), json.load(open(os.path.join(REF, ref))), new)
    refcsv = sorted(glob.glob(os.path.join(REF, 'digitized', '*.csv')))
    newcsv = sorted(glob.glob(os.path.join(ROOT, 'outputs', 'digitized', '*.csv')))
    if [os.path.basename(p) for p in refcsv] != [os.path.basename(p) for p in newcsv]:
        bad.append('digitized CSV file sets differ')
    for r in refcsv:
        p = os.path.join(ROOT, 'outputs', 'digitized', os.path.basename(r))
        if not os.path.exists(p):
            bad.append(f'missing output CSV: {os.path.basename(p)}'); continue
        A = [[num(x) for x in row] for row in csv.reader(l for l in open(p) if not l.startswith('#'))]
        B = [[num(x) for x in row] for row in csv.reader(l for l in open(r) if not l.startswith('#'))]
        cmp(A, B, os.path.basename(p))
    for f in ('subcm_window_en.png', 'subcm_window_en.pdf', 'subcm_window_hu.png', 'subcm_window_hu.pdf'):
        if not os.path.getsize(os.path.join(ROOT, 'outputs', 'figures', f)) > 10000:
            bad.append(f'figure missing or tiny: {f}')
    print(f'verify_outputs: {n} values compared, rtol={RTOL}: ' + ('OK' if not bad else f'{len(bad)} MISMATCHES'))
    for b in bad[:40]: print('  ', b)
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
