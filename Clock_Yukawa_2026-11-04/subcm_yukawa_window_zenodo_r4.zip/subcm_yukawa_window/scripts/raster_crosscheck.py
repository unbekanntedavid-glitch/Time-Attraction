#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Second, independent reading of where alpha = 1/(4 pi) leaves the allowed
(white) region, from a 600 dpi raster render (pdftoppm) of each figure.

Independence from the vector digitizer: the axis calibration here uses only
the plot frame found in the pixels plus the decade values printed at the frame
edges (read by eye from the figure, listed in NOMINAL below); no tick fit, no
SVG parsing.  Along the pixel row of alpha = 1/(4 pi) the colour of every
pixel is classified (white / fill / ink) and excluded intervals are the fill
runs, with each white->fill boundary placed at the centre of the ink run
(the drawn curve) that separates them.  Result: outputs/raster_crosscheck.json
"""
import json, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INP = os.path.join(ROOT, 'inputs')
ALPHA0 = 1.0 / (4.0 * np.pi)
DPI = 600

# crop box (page pt: x0, x1, y0, y1) and the decade at each frame edge as printed
NOMINAL = {
    'AHN2003_fig5': dict(pdf='adelberger2003.pdf', page=77, crop=(150, 430, 200, 450),
                         x_left=-6.0, x_right=-2.0, y_top=10.0, y_bottom=-4.0,
                         note='frame edges carry the 1e-6 m / 1e-2 m and 1e10 / 1e-4 labels'),
    'AHN2003_fig4': dict(pdf='adelberger2003.pdf', page=76, crop=(260, 540, 210, 460),
                         x_left=-3.0, x_right=15.0, y_top=-1.0, y_bottom=-11.0,
                         note='frame edges carry the 1e-3 m / 1e15 m and 1e-1 / 1e-11 labels (bottom edge one decade below last label)'),
    'Lee2020_fig5': dict(pdf='lee2020_arXiv_2002.11761v1.pdf', page=4, crop=(340, 560, 430, 620),
                         x_left=float(np.log10(2e-6)), x_right=-3.0, y_top=6.0, y_bottom=-3.0,
                         note='left frame edge sits on the 2e-6 m minor tick; right edge taken as 1e-3 m '
                              '(vector frame is 0.27 pt = 0.004 dec right of the 1e-3 tick, a known small bias)'),
}


def render(cfg):
    x0, x1, y0, y1 = cfg['crop']; s = DPI / 72.0
    with tempfile.TemporaryDirectory() as td:
        base = os.path.join(td, 'r')
        subprocess.run(['pdftoppm', '-f', str(cfg['page']), '-l', str(cfg['page']), '-r', str(DPI),
                        '-x', str(int(x0 * s)), '-y', str(int(y0 * s)), '-W', str(int((x1 - x0) * s)),
                        '-H', str(int((y1 - y0) * s)), '-png', os.path.join(INP, cfg['pdf']), base], check=True)
        f = [n for n in os.listdir(td) if n.endswith('.png')][0]
        return np.asarray(Image.open(os.path.join(td, f)).convert('RGB')).astype(int)


def frame(img):
    dark = img.sum(axis=2) < 200
    cols = np.where(dark.mean(axis=0) > 0.6)[0]
    rows = np.where(dark.mean(axis=1) > 0.6)[0]
    # outer frame line centres (lines are several px wide -> take each edge cluster centre)
    def edges(ix):
        lo = ix[ix <= ix[0] + 10]; hi = ix[ix >= ix[-1] - 10]
        return float(lo.mean()), float(hi.mean())
    return edges(cols), edges(rows)


def classify(px):
    r, g, b = px[..., 0], px[..., 1], px[..., 2]
    white = (r > 235) & (g > 235) & (b > 235)
    fill = ((r > 200) & (g > 200) & (b < 190)) | ((g > 180) & (r < 120) & (b < 120))  # yellow or green
    return np.where(white, 'W', np.where(fill, 'F', 'I'))


def intervals(cls):
    """excluded runs: from centre of ink run before an F run to centre of ink run after."""
    s = ''.join(cls)
    runs = []
    i = 0
    while i < len(s):
        j = i
        while j < len(s) and s[j] == s[i]:
            j += 1
        runs.append([s[i], i, j - 1]); i = j
    out = []
    k = 0
    while k < len(runs):
        if runs[k][0] == 'F':
            # extend over F / short ink runs (curves drawn inside the fill, dashed lines)
            m = k
            while m + 2 < len(runs) and runs[m + 1][0] == 'I' and runs[m + 2][0] == 'F':
                m += 2
            lo = runs[k][1]; hi = runs[m][2]
            if k > 0 and runs[k - 1][0] == 'I':
                lo = 0.5 * (runs[k - 1][1] + runs[k - 1][2])
            if m + 1 < len(runs) and runs[m + 1][0] == 'I':
                hi = 0.5 * (runs[m + 1][1] + runs[m + 1][2])
            out.append((float(lo), float(hi), runs[k][1] == 0 or (k == 1 and runs[0][0] == 'I')))
            k = m + 1
        else:
            k += 1
    return out


def main():
    res = dict(alpha0=ALPHA0, dpi=DPI, method=__doc__.strip().splitlines()[0], figures={})
    for key, cfg in NOMINAL.items():
        img = render(cfg)
        (xl, xr), (yt, yb) = frame(img)
        fx = lambda c: cfg['x_left'] + (c - xl) * (cfg['x_right'] - cfg['x_left']) / (xr - xl)
        row = yt + (np.log10(ALPHA0) - cfg['y_top']) * (yb - yt) / (cfg['y_bottom'] - cfg['y_top'])
        per_row = {}
        for dr in (-2, -1, 0, 1, 2):
            r = int(round(row)) + dr
            cls = classify(img[r, int(xl) + 6:int(xr) - 5])
            iv = intervals(cls)
            per_row[dr] = [(10 ** fx(lo + int(xl) + 6), 10 ** fx(hi + int(xl) + 6)) for lo, hi, _ in iv]
        res['figures'][key] = dict(
            frame_px=dict(x_left=xl, x_right=xr, y_top=yt, y_bottom=yb), nominal=cfg,
            px_per_decade_x=(xr - xl) / (cfg['x_right'] - cfg['x_left']),
            alpha0_row_px=float(row),
            excluded_intervals_m_by_row_offset={str(k): v for k, v in per_row.items()},
            first_excluded_lambda_m=per_row[0][0][0] if per_row[0] else None,
            first_excluded_lambda_spread_m=[min(v[0][0] for v in per_row.values() if v),
                                            max(v[0][0] for v in per_row.values() if v)])
        print(key, 'row', round(row, 1), 'excluded (m):', [(f'{a:.4g}', f'{b:.4g}') for a, b in per_row[0]])
    with open(os.path.join(ROOT, 'outputs', 'raster_crosscheck.json'), 'w') as f:
        json.dump(res, f, indent=1)


if __name__ == '__main__':
    sys.exit(main())
