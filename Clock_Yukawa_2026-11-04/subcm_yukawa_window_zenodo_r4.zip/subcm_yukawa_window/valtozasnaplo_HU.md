# subcm_yukawa_window r4: változatleírás (előzetes kutatás)

Közölt ábrák és táblázatok: numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); új mérési adat nélkül.

## Mit tartalmaz ez a változat

- Digitalizált cm alatti Yukawa-korlátok (AHN 2003 4. és 5. ábra, Lee 2020 5. ábra, Lee 2020 disszertáció 11.4. táblázat) összevetése a rögzített α0 = 1/(4π) = 0,0795775 egyenessel: burkolók, metszéspontok, aránytábla és EN/HU ábrák.
- A 75,9–101,0 µm-es átmeneti sáv eltérő kísérletek és korlátkonstrukciók összevetéséből adódik. 75,9-től ~98,1 µm-ig attól függ, hogy a HUST 2020/2016 |α| görbéket α > 0-ra is alkalmazzuk-e; ~98,1–101,0 µm között az Eöt-Wash 2020 |α95| (rajzolt görbe 98,074 µm, disszertáció-oszlop 98,14 µm) és +α95 (101,029 µm) konstrukciója tér el (disszertáció 145. o.: ±α95 a Δχ² = 6,17-ből; |α95| a normális eloszlás 0,95-ös integráljából; 100 µm-nél +α95 = 0,0813 > α0 = 0,0796 > |α95| = 0,0766).
- A `scripts/check_hust_free_gap.py` HUST-görbe nélkül újraszámolja ezeket a metszéspontokat a digitalizált CSV-kből (első nem HUST metszés: Eöt-Wash 2020 |α| 98,074 µm; disszertáció |α95| 98,136 µm; +α95 101,029 µm; HUST nélküli rés 2,893 µm; HUST 2020 |α| 75,877 µm), és ellenőrzi, hogy a fő sáv és a szöveg/ábrafeliratok egyeznek → `outputs/check_hust_free_gap.json`.
- A `scripts/verify_outputs.py` minden numerikus kimenetet relatív tűréssel vet össze a `reference/` adataival (rtol = 1e-4; nem véges érték, hiányzó kulcs vagy fájl hibának számít).
- r3: licenc (CC BY-NC 4.0, `LICENSE.txt`), semleges megfogalmazás (csak szöveg és licenc).
- r4 (csak szöveg): az általános MI-segítségre utaló megfogalmazás helyén mostantól „numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú)” (angolul „numerical cross-checks with Academia Co-scientist (AI-assisted)”) áll a README-ben, a módszertani jegyzetekben, ebben a változatleírásban, a `scripts/analyze_window.py` által írt `status` mezőben (így az `outputs/results.json` és a `reference/results.json` fájlban) és az EN/HU ábrák lábjegyzetében. Minden JSON- és CSV-fájl minden számértéke azonos az r3-mal (feldolgozott összevetés); a 75,9 µm-es és 101,0 µm-es határ változatlan. A `SHA256SUMS.txt` a megváltozott fájlokra frissült; a bemeneti hash-listák változatlanok.
