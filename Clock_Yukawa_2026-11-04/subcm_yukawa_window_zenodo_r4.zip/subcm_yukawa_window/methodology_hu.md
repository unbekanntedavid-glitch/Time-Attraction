# Cm alatti Yukawa-ablak α = 1/(4π)-hez – módszertan (előzetes)

Állapot: előzetes. Publikált ábrák és táblázatok: numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú), új mérési adat nélkül.

## Feladat
A V28 27. lépése a 10 km-es ág után a centiméter alatti hatótávolságot (λ < 1 cm) újratesztelendő jelöltként nevezi meg. A 10 km-es ág David szerint lezárt; ez egy másik λ-tartomány. A pozitív csatolású rövidtávú korlátokat újradigitalizáltam, és összevetettem a rögzített α0 = 1/(4π) = 0.0795775 vonallal.

Konvenció minden forrásban: V(r) = −G m1 m2 / r · (1 + α e^(−r/λ)), 95% CL. A pozitív α vonzó, előjele megegyezik α0-éval.

## A forrás azonosítása
- Elsődleges ábra: E. G. Adelberger, B. R. Heckel, A. E. Nelson, Annu. Rev. Nucl. Part. Sci. 53, 77 (2003), arXiv:hep-ph/0307284v1. Ez a csomagban már meglévő Adelberger-féle összefoglaló.
  - Az **5. ábra** (PDF 77. o.) az 1 µm < λ < 1 cm ábra, ezt használtam.
  - A 4. ábrát itt csak a PDF-ből (vektoros adat) olvastam ki, és csak λ > 2 mm-re használtam.
  - A 9. ábra (PDF 80. o., 1 nm–1 µm) Casimir-alapú korlátokat mutat, amelyeket a szöveg „nem annyira szigorúnak” nevez. Mindegyik ≥ 10^9, így ez a tartomány α0 számára megengedett. A 9. ábrát nem digitalizáltam.
- Újabb korlátok, más forrásból (újabb cikk):
  - J. G. Lee et al., PRL 124, 101101 (2020), arXiv:2002.11761v1, 5. ábra alsó panel. Ebben szerepel az Eöt-Wash 2020/2007/2004, a HUST 2020/2016/2012, valamint a Stanford és a Colorado görbe, Lee és mtsai rajzolásában (hivatkozott források: [5, 10, 16, 21–26, 29]).
  - A HUST 2020-at (Tan et al., PRL 124, 051301) **csak** ebből az ábrából, illetve az absztrakt számaiból vettem. A cikk szövegét nem sikerült megszerezni (csak az absztrakt volt elérhető).
- Előjelenként szétválasztott számok:
  - J. G. Lee PhD-disszertáció, University of Washington 2020, hdl:1773/45542 (CC BY), 11.4 táblázat.
  - A táblázat +α95, −α95 (a Δχ² = 6.17 felületből) és |α95| értékeket ad 66 λ-értékre, 5 µm és 8.9 mm között. A PDF szövegrétegéből olvastam ki, kézzel begépelt szám nincs benne.
  - A PRL Supplemental Material nem volt letölthető (HTTP 403).

## Digitalizálás (vektoros, elsődleges módszer)
- A PDF-oldalakat SVG-vé alakítottam (`pdftocairo -svg`). A vonalútvonalakat a transzformációikkal együtt vettem, a kétpontos szakaszokat poligonvonalakká fűztem össze.
- A tengelyeket legkisebb négyzetes illesztéssel kalibráltam: log10(érték) a lapkoordináta függvényében, a keret összes osztásjelére. Az osztáspontok, a reziduumok és az illesztés a `outputs/digitized/calibration.json` fájlban vannak. RMS reziduumok:
  - AHN 5. ábra: 3.5e-4 dek (x) és 3.5e-4 dek (y);
  - AHN 4. ábra: 4.0e-4 és 2.4e-4;
  - Lee 5. ábra: 6.2e-5 és 1.9e-4.
- Görbék elnevezése:
  - AHN: a címke nyílhegyéhez legközelebbi görbe (1.0–4.9 pt, a második legközelebbi görbe ≥ 13 pt-re).
  - Lee: szín, valamint az egyes cikkek absztraktjában közölt |α| = 1 metszés alapján. A HUST 2012 görbét kizárásos alapon azonosítottam (0.4–1 mm, nem metszi az |α| = 1 szintet). A Stanford a/b/c görbéket nem datáltam egyenként. Egy negyedik rövidtávú görbe (2–20 µm, |α| ≥ 7e3) `unattributed_2to20um` néven, azonosítatlanul maradt, mert Lee 2020 nem hivatkozik IUPUI-munkára. Egyik sem befolyásolja a metszést.
- A sárga kitöltő poligonokat (a rajzolt kizárt tartományt) második vektoros olvasatként exportáltam.

## Második módszer (raszter)
- Az AHN 5. és 4. ábráját, valamint a Lee 5. ábrát 600 dpi-vel rendereltem.
- A kalibráció csak a pixelkeretet és a keret szélein feltüntetett dekádértékeket használja; sem osztásjelet, sem SVG-t nem.
- Az α0 pixelsorban minden pixelt fehér, kitöltés vagy tinta kategóriába soroltam. Minden határt a tintaszakasz közepére tettem, és ±2 sorra is ellenőriztem.

## Összevetés és bizonytalanság
- Metszési λ: log-log lineáris interpoláció az egyes görbék, illetve az alsó burkoló mentén (1e-4 dekádos lépésű rács).
- A rajzolt metszés leolvasási bizonytalansága: a kalibrációs RMS a helyi meredekségen át terjesztve, négyzetesen összegezve a ±½ vonalvastagságú tűréssel, a vízszintes α0 sorra vetítve. A vonalvastagság 1.23 pt (AHN), illetve 0.64 pt (Lee).
- A raszter–vektor eltérést szintén négyzetesen hozzáadtam.
- Disszertáció-táblázat: a metszést háromféle interpolációval számoltam (log-log lineáris, PCHIP log-log térben, lineáris α a log λ függvényében). Az ezek közötti szórást és a közrefogó táblázatsorokat is megadom.
- R = α0 / α_lim(λ) a 95% CL korláthoz viszonyított arány. R > 1 esetén α0 a kizárt tartományba esik. **R nem σ-ban kifejezett szignifikancia.**

## Előzetes eredmény
| olvasat | metszés λc | α0 megengedett | α0 kizárt |
|---|---|---|---|
| \|α\| görbék a rajz szerint (a határt a HUST 2020 adja) | 75.9 µm (74.7–77.1 µm) | λ < 75.9 µm | 75.9 µm – 1 cm, illetve λ > 2 mm-től az AHN 4. ábra szerint kb. 10^15 m-ig |
| előjelenkénti +α95 (Lee 2020 disszertáció, Eöt-Wash 2020 adatok) | 101.0 µm (interpolációs szórás 100.99–101.12 µm; táblázatsorok 100–110 µm) | λ < 101 µm | 101 µm – 8.9 mm (minden ≥ 110 µm-es sorban +α95 < α0) |

- **Átmeneti sáv: 75.9–101.0 µm.** A 75.9–101.0 µm-es eltérés különböző kísérletek és korlátkonstrukciók összevetéséből adódik, nem csupán a HUST-korlátok előjel-kezeléséből:
  - 75.9 – kb. 98.1 µm: α0-t csak a rajzolt HUST 2020/2016 |α| görbék zárják ki, ha α > 0-ra is alkalmazzuk őket. Az előjelenkénti HUST-korlátok nem voltak elérhetők.
  - Kb. 98.1–101.0 µm között már HUST-görbe nélkül is eltér az Eöt-Wash 2020 saját |α95| és +α95 konstrukciója. A rajzolt Eöt-Wash 2020 |α| görbe 98.074 µm-nél, a disszertáció |α95| oszlopa 98.14 µm-nél metszi α0-t, a +α95 oszlop pedig 101.029 µm-nél.
  - A disszertáció (145. o.) a ±α95-öt a Δχ² = 6.17 felületből, az |α95|-öt a normális eloszlás −|α95| és +|α95| közötti 0.95-ös integráljából definiálja. Példa, a 100 µm-es sor: +α95 = 0.0813 > α0 = 0.0796 > |α95| = 0.0766, vagyis ugyanazon λ-nál α0-t a +α95 megengedi, az |α95| kizárja.
  - A korlátokat a közölt formában használom, nem definiálom át őket. A HUST-görbék nélküli metszéseket a `scripts/check_hust_free_gap.py` számolja újra (kimenet: `outputs/check_hust_free_gap.json`).
- Önmagában a 2003-as AHN 5. ábra burkolója 417 µm-nél adná a határt (Eöt-Wash 2001). Az újabb korlátok ezt nagyjából ötödére tolják le.

Néhány R-érték:

| λ | R (+α95, disszertáció) | R (\|α\| burkoló) |
|---|---|---|
| 50 µm | 0.16 | 0.19 |
| 70 µm | 0.42 | 0.70 |
| 80 µm | 0.59 | 1.26 |
| 100 µm | 0.98 | 2.92 |
| 200 µm | 3.25 | 16.0 |
| 1 mm | 8.8 | 58 |

Az összes érték a `outputs/ratio_table.csv` fájlban van.

## Keresztellenőrzések
Mind megtalálható a `outputs/validation_checks.csv` fájlban.
- λ az |α| = 1 metszésnél 1%-on belül egyezik a közölt értékekkel:
  - Eöt-Wash 2020: 38.57 vs 38.6 µm;
  - Eöt-Wash 2007: 55.5 vs 56;
  - Eöt-Wash 2004: 196.1 vs 197;
  - HUST 2020: 47.9 vs 48;
  - HUST 2016: 59.3 vs 59.
- α = 8/3 ellenőrzések:
  - Eöt-Wash 2020: 30.2 vs 30 µm;
  - Eöt-Wash 2007: 44.2 vs 44;
  - Eöt-Wash 2004: 153 vs 160 (−4.3%, a legnagyobb eltérés).
- Az AHN szövegével való ellenőrzések:
  - α = 16/3 esetén 131 vs 130 µm;
  - α = 8/3 esetén 154 vs 155 µm;
  - α = 1 esetén 197.5 vs „200 µm” (a szövegben kerekítve).
- A rajzolt Eöt-Wash 2020 görbe 45 soron egyezik a disszertáció |α95| értékeivel: medián −0.0002 dex, maximum 0.0023 dex.
- Raszter vs vektor: a Lee 5. ábrán 75.5 vs 75.9 µm, az AHN 5. ábrán 414 vs 417 µm. Kitöltés vs görbeközép (AHN 5. ábra): 418 vs 417 µm. Az AHN 4. ábra bal széle: 1.98 vs 2.00 mm.

## Ismert korlátok (nyitott pontok)
- Az |α| görbék nem +α-korlátok. Hiányzik a HUST előjel-szétválasztás, a Lee PRL Supplemental Material és a Tan 2020 cikk szövege (csak absztrakt). Ez csak az átmeneti sáv 75.9 – kb. 98.1 µm-es részét érinti; a kb. 98.1–101.0 µm-es rész az Eöt-Wash 2020 |α95| és +α95 konstrukciójának eltéréséből következik.
- Az 1 nm–1 µm tartományt csak a 9. ábra tengelyminimuma alapján ítéltem meg.
- 1 és 2.4 µm között a korlátok a rajzolt kereten kívül, felette vannak (≥ 10^10).
- λ > 10^15 m-t az ábrák nem fedik le.
- Egy gyors keresés nem talált 2020 utáni publikált korlátot, amely α ≈ 0.08-nál, 50–150 µm körül erősebb lenne. Ez nem kimerítő áttekintés.
- A rajzolt korlátok attól függnek, hogyan rajzolták át a szerzők mások eredményeit. A vektoros középvonal pontos, a vonalvastagság-tűrés viszont csak leolvasási közelítés.

## Futtatás
`python run_check.py` (Windows, Linux, macOS). Alapesetben SHA-256-tal ellenőrzi az `inputs/frozen_digitization/` rögzített digitalizálási adatait, és ezekből újraépíti a burkolókat, a metszéspontokat, az aránytáblát és az ábrákat; a `python run_check.py --from-pdfs` (a `SOURCES.md` szerinti forrás-PDF-ekkel és poppler-utils-szal) a PDF-eket ellenőrzi és a digitalizálást is újrafuttatja. Mindkét módban csak a bemeneteket ellenőrzi hash-sel; majd lefuttatja a `scripts/check_hust_free_gap.py`-t (HUST nélküli metszések) és a `scripts/verify_outputs.py`-t, amely numerikusan veti össze az eredményt a `reference/` könyvtárral (rtol = 1e-4). Bájtra azonos PNG/PDF kimenetet nem ígér.
