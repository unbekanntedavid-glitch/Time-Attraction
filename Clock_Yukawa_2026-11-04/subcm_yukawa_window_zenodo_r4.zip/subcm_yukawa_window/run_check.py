#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Cross-platform runner (Windows, Linux, macOS).

Default:      python run_check.py
              SHA-256 check of inputs/frozen_digitization/, then envelopes, crossings,
              ratio table, figures, HUST-free transition-band check
              (scripts/check_hust_free_gap.py) and numeric
              verification against reference/.
--from-pdfs:  python run_check.py --from-pdfs
              needs the four source PDFs (links in SOURCES.md) in inputs/ and
              poppler-utils (pdftocairo, pdftoppm, pdftotext); SHA-256 check of the
              PDFs, then the digitization is rerun before the same steps.
Only inputs are hash-checked; outputs are verified numerically (rtol 1e-4).
Nothing is deleted."""
import hashlib, os, shutil, subprocess, sys
here = os.path.dirname(os.path.abspath(__file__)); os.chdir(here)
from_pdfs = "--from-pdfs" in sys.argv[1:]

def check(listfile, folder):
    bad = 0
    for line in open(listfile, encoding="utf-8"):
        if not line.strip(): continue
        h, name = line.split(None, 1); p = os.path.join(folder, name.strip())
        if not os.path.isfile(p): print("MISSING", p); bad += 1; continue
        ok = hashlib.sha256(open(p, "rb").read()).hexdigest() == h
        bad += (not ok); print("OK  " if ok else "FAIL", p)
    if bad: sys.exit("input check failed: %d file(s); nothing was run (see SOURCES.md)" % bad)

def run(script):
    print("==", script); r = subprocess.run([sys.executable, os.path.join("scripts", script)])
    if r.returncode: sys.exit("%s failed (exit %d)" % (script, r.returncode))

if from_pdfs:
    for tool in ("pdftocairo", "pdftoppm", "pdftotext"):
        if shutil.which(tool) is None: sys.exit("missing system tool: %s (poppler-utils)" % tool)
    check(os.path.join("inputs", "SHA256SUMS_pdfs.txt"), "inputs")
    for s in ("digitize_vector_figures.py", "extract_lee_thesis_table.py", "raster_crosscheck.py"):
        run(s)
else:
    fz = os.path.join("inputs", "frozen_digitization")
    check(os.path.join("inputs", "SHA256SUMS_frozen.txt"), fz)
    dig = os.path.join("outputs", "digitized"); os.makedirs(dig, exist_ok=True)
    for f in sorted(os.listdir(fz)):
        dst = os.path.join("outputs", f) if f == "raster_crosscheck.json" else os.path.join(dig, f)
        shutil.copyfile(os.path.join(fz, f), dst)
    print("frozen digitization copied to outputs/ (digitization not rerun)")
for s in ("analyze_window.py", "make_figures.py", "check_hust_free_gap.py", "verify_outputs.py"):
    run(s)
print("all steps passed (%s mode)" % ("from-pdfs" if from_pdfs else "frozen-digitization"))
