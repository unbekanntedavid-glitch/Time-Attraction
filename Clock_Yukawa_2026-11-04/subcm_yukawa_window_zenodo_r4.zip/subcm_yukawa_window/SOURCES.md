# Sources (preliminary)

The source PDFs are not redistributed in this package. Download them from the links below if you want to rerun the digitization; place them in `inputs/` under the file names given, and `python run_check.py --from-pdfs` checks them against `inputs/SHA256SUMS_pdfs.txt`. The default run uses the frozen digitization data in `inputs/frozen_digitization/` (SHA-256-checked through `inputs/SHA256SUMS_frozen.txt`).

## Used for numbers
1. **AHN 2003.** E. G. Adelberger, B. R. Heckel, A. E. Nelson, "Tests of the gravitational inverse-square law", Annu. Rev. Nucl. Part. Sci. 53, 77 (2003). arXiv:hep-ph/0307284v1 (https://arxiv.org/abs/hep-ph/0307284v1), download file name `adelberger2003.pdf` (not included in this package).
   - Fig. 5 (PDF p. 77) was vector-digitized; it covers 1 µm–1 cm.
   - Fig. 4 (PDF p. 76) was vector-digitized for λ > 1 cm.
   - Fig. 9 (PDF p. 80) was read only for its axis minimum.
   - Numbers from the text used as checks: α = 16/3 → 130 µm, α = 8/3 → 155 µm, |α| = 1 → "200 µm".
   - Figure-related references cited in AHN (listed so that the citation trail has no gaps):
     - ref. 71: Hoyle CD et al., PRL 86, 1418 (2001);
     - ref. 148: Hoyle CD, PhD thesis, Univ. Washington (2001);
     - ref. 149: Adelberger EG, Proc. Second Meeting on CPT and Lorentz Symmetry, ed. V. A. Kostelecky, p. 9, World Sci. (2002).
2. **Lee 2020 PRL.** J. G. Lee, E. G. Adelberger, T. S. Cook, S. M. Fleischer, B. R. Heckel, "New test of the gravitational 1/r² law at separations down to 52 µm", PRL 124, 101101 (2020). arXiv:2002.11761v1 (https://arxiv.org/abs/2002.11761v1), download file name `lee2020_arXiv_2002.11761v1.pdf` (not included in this package).
   - Fig. 5 bottom (|α| constraints) was vector-digitized.
   - Stated value used as a check: λ < 38.6 µm at |α| = 1.
   - Its ref. [29] prints "PRL 124, 051310 (2020)". The correct page is **051301**; this is a misprint in the arXiv v1.
   - The Supplemental Material (ref. [27]) was not obtained (HTTP 403).
3. **Lee 2020 thesis.** J. G. Lee, PhD thesis, University of Washington (2020), https://hdl.handle.net/1773/45542 (CC BY). Download file name `lee2020_thesis_UW_hdl1773-45542.pdf` (not included in this package).
   - Table 11.4 (PDF pp. 145–148) gives +α95, −α95 and |α95| for 66 λ values. It was parsed from the text layer.
4. **Kapner 2007.** D. J. Kapner et al., PRL 98, 021101 (2007). arXiv:hep-ph/0611184v1 (https://arxiv.org/abs/hep-ph/0611184v1), download file name `kapner2007_arXiv_hep-ph_0611184v1.pdf` (not included in this package).
   - Stated values used as checks: 56 µm at |α| = 1 and 44 µm at α = 8/3.
5. **Hoyle 2004.** C. D. Hoyle et al., PRD 70, 042004 (2004). arXiv:hep-ph/0405262, abstract only (not in `inputs/`).
   - Stated values used as checks: |α| ≥ 1 is ruled out for λ ≥ 197 µm; for α = 8/3, R* ≤ 160 µm.
6. **Tan 2020 (HUST).** W.-H. Tan et al., PRL 124, 051301 (2020), abstract only.
   - Stated value used as a check: λ = 48 µm at |α| = 1.
   - The curve itself is taken only as drawn in Lee 2020 Fig. 5.
7. **Tan 2016 (HUST).** W.-H. Tan et al., PRL 116, 131101 (2016), abstract only.
   - Stated value used as a check: λ = 59 µm at |α| = 1.

## Cited and drawn in Lee 2020 Fig. 5, not used separately
- Yang et al. (HUST 2012), PRL 108, 081101 (2012), Lee ref. [25]. The curve was named by elimination.
- Long et al. (Colorado 2003), Nature 421, 922 (2003), Lee ref. [21].
- Chiaverini et al., PRL 90, 151101 (2003); Smullin et al., PRD 72, 122001 (2005); Geraci et al., PRD 78, 022002 (2008). These are Lee refs. [22–24], the Stanford curves; the years of the individual curves were not assigned.
- Hoskins et al. (Irvine 1985), PRD 32, 3084 (1985), Lee ref. [16]. Cited by Lee, but no Lee curve was assigned to it.
- One drawn short-range curve (2–20 µm) is left unattributed (`unattributed_2to20um`). The Lee reference list has no IUPUI entry.
- Adelberger et al., PRL 98, 131104 (2007), Lee ref. [11].
- Hoyle et al. (2001/2004), Lee refs. [9, 10].

## Checked but not used for the bound
- Levitated-microsphere results (e.g. arXiv:2412.13167) give about 10^6–10^7 near 5–10 µm, so they do not matter at α ≈ 0.08.
- The HUST 32-fold design is a proposal; it gives no bound.
- The search for bounds after 2020 was quick and is not exhaustive.
