#!/usr/bin/env bash
# Shell wrapper for run_check.py.  Pass --from-pdfs to rerun the digitization
# from the source PDFs (see SOURCES.md).  Only INPUTS are SHA-256 checked;
# outputs are checked numerically by scripts/verify_outputs.py (rtol).
set -euo pipefail
cd "$(dirname "$0")"
python3 run_check.py "$@"
