# Sub-cm Yukawa window for α = 1/(4π): methodology (preliminary)

Status: preliminary. Numerical cross-checks with Academia Co-scientist (AI-assisted) of published figures and tables. No new data.

## Task
The V28 Step 27 candidate: retest the sub-centimetre range (λ < 1 cm) after the 10 km branch (that branch is closed per David; this is a different λ regime). Re-digitize the positive-coupling short-range bounds and compare them with the fixed line α0 = 1/(4π) = 0.0795775.

Convention used by every source here: V(r) = −G m1 m2 / r · (1 + α e^(−r/λ)), 95% CL. Positive α means attractive, the same sign as α0.

## Source identification
- Primary figure: E. G. Adelberger, B. R. Heckel, A. E. Nelson, Annu. Rev. Nucl. Part. Sci. 53, 77 (2003), arXiv:hep-ph/0307284v1. This is the "Adelberger summary" already in the package.
  - **Fig. 5** (PDF p. 77) is the 1 µm < λ < 1 cm figure, so it is the one used here.
  - Fig. 4 itself is read here only from the PDF (vector data), and only for λ > 2 mm.
  - Fig. 9 (PDF p. 80, 1 nm–1 µm) shows Casimir-derived limits that the text calls "not as rigorous". All of them are ≥ 10^9, so that range is allowed for α0. Fig. 9 was not digitized.
- Newer bounds, from a different source (a newer paper):
  - J. G. Lee et al., PRL 124, 101101 (2020), arXiv:2002.11761v1, Fig. 5 bottom. It contains Eöt-Wash 2020/2007/2004, HUST 2020/2016/2012, Stanford and Colorado as drawn by Lee et al. (cited refs. [5, 10, 16, 21–26, 29]).
  - HUST 2020 (Tan et al., PRL 124, 051301) is taken **only** as drawn in that figure, plus its abstract numbers. Its full text was not obtained.
- Sign-separated numbers:
  - J. G. Lee, PhD thesis, University of Washington 2020, hdl:1773/45542 (CC BY), Table 11.4.
  - The table gives +α95, −α95 (from the Δχ² = 6.17 surface) and |α95| for 66 λ values from 5 µm to 8.9 mm. It was parsed from the PDF text layer; no numbers were typed by hand.
  - The PRL Supplemental Material could not be fetched (HTTP 403).

## Digitization (vector, primary method)
- The PDF pages are converted to SVG (`pdftocairo -svg`). Stroke paths are taken with their transforms, and the 2-point segments are chained into polylines.
- Axes are calibrated by a least-squares fit of log10(value) against page coordinate over all tick marks found on the frame. The tick points, residuals and fit are stored in `outputs/digitized/calibration.json`. RMS residuals:
  - AHN Fig. 5: 3.5e-4 dec (x) and 3.5e-4 dec (y);
  - AHN Fig. 4: 4.0e-4 and 2.4e-4;
  - Lee Fig. 5: 6.2e-5 and 1.9e-4.
- Curve naming:
  - AHN: the curve nearest to each label's arrowhead tip (distance 1.0–4.9 pt, second-nearest curve ≥ 13 pt away).
  - Lee: by colour and by the |α| = 1 crossing stated in each paper's own abstract. HUST 2012 is named by elimination (0.4–1 mm, it does not cross |α| = 1). Stanford a/b/c are not individually dated. A fourth short-range curve (2–20 µm, |α| ≥ 7e3) is left as `unattributed_2to20um`, because Lee 2020 cites no IUPUI work. None of these affect the crossing.
- Yellow fill polygons, i.e. the excluded region as drawn, are exported as a second vector reading.

## Second method (raster)
- Fig. 5 (AHN), Fig. 4 (AHN) and Fig. 5 (Lee) are rendered at 600 dpi.
- The calibration uses only the pixel frame and the decade values printed at the frame edges. No ticks and no SVG are used.
- Along the α0 pixel row, each pixel is classified as white, fill or ink. Each boundary is placed at the centre of the ink run, and the result is checked over ±2 rows.

## Comparison and uncertainty
- Crossing λ: log-log linear interpolation along each curve and along the lower envelope (a grid with a step of 1e-4 dec).
- Reading uncertainty of a drawn crossing: the calibration RMS propagated through the local slope, combined in quadrature with a ±½ stroke-width tolerance mapped onto the horizontal α0 row. Strokes are 1.23 pt (AHN) and 0.64 pt (Lee).
- The raster-vs-vector difference is added in quadrature.
- Thesis table: the crossing uses three interpolation schemes (log-log linear, PCHIP in log-log, linear α vs log λ). The spread between them is quoted, together with the bracketing table rows.
- R = α0 / α_lim(λ) is the ratio to the 95% CL bound. R > 1 means α0 lies in the excluded region. **R is not a significance in σ.**

## Preliminary result
| reading | crossing λc | α0 allowed | α0 excluded |
|---|---|---|---|
| \|α\| curves as drawn (HUST 2020 sets the edge) | 75.9 µm (74.7–77.1 µm) | λ < 75.9 µm | 75.9 µm – 1 cm, and λ > 2 mm per AHN Fig. 4 up to ~10^15 m |
| sign-separated +α95 (Lee 2020 thesis, Eöt-Wash 2020 data) | 101.0 µm (100.99–101.12 µm interpolation spread; table bracket 100–110 µm) | λ < 101 µm | 101 µm – 8.9 mm (every table row ≥ 110 µm has +α95 < α0) |

- **Transition band 75.9–101.0 µm.** The difference between the two readings comes from comparing different experiments and bound constructions, not from the HUST sign treatment alone:
  - 75.9 to ~98.1 µm: α0 is excluded only by the HUST 2020/2016 |α| curves as drawn, if they are applied to α > 0. Their sign-separated limits were not available.
  - ~98.1 to 101.0 µm: already without any HUST curve, the two Eöt-Wash 2020 constructions differ. The drawn Eöt-Wash 2020 |α| curve crosses α0 at 98.074 µm and the thesis |α95| column at 98.14 µm, while the thesis +α95 column crosses at 101.029 µm.
  - The thesis (p. 145) defines ±α95 from the Δχ² = 6.17 surface and |α95| from the 0.95 integral of the normal distribution between −|α95| and +|α95|. Example, row 100 µm: +α95 = 0.0813 > α0 = 0.0796 > |α95| = 0.0766, so α0 is allowed by +α95 and excluded by |α95| at the same λ.
  - The bounds are used as published; they are not redefined here. The crossings are recomputed without HUST curves by `scripts/check_hust_free_gap.py` (output `outputs/check_hust_free_gap.json`).
- The 2003 AHN Fig. 5 envelope alone would put the edge at 417 µm (Eöt-Wash 2001). The newer bounds move it down by a factor of about 5.

Selected R values:

| λ | R (+α95, thesis) | R (\|α\| envelope) |
|---|---|---|
| 50 µm | 0.16 | 0.19 |
| 70 µm | 0.42 | 0.70 |
| 80 µm | 0.59 | 1.26 |
| 100 µm | 0.98 | 2.92 |
| 200 µm | 3.25 | 16.0 |
| 1 mm | 8.8 | 58 |

The full table is in `outputs/ratio_table.csv`.

## Cross-checks
All are listed in `outputs/validation_checks.csv`.
- λ at |α| = 1 matches the stated values within 1%:
  - Eöt-Wash 2020: 38.57 vs 38.6 µm;
  - Eöt-Wash 2007: 55.5 vs 56;
  - Eöt-Wash 2004: 196.1 vs 197;
  - HUST 2020: 47.9 vs 48;
  - HUST 2016: 59.3 vs 59.
- α = 8/3 checks:
  - Eöt-Wash 2020: 30.2 vs 30 µm;
  - Eöt-Wash 2007: 44.2 vs 44;
  - Eöt-Wash 2004: 153 vs 160 (−4.3%, the largest deviation).
- AHN text checks:
  - α = 16/3 gives 131 vs 130 µm;
  - α = 8/3 gives 154 vs 155 µm;
  - α = 1 gives 197.5 vs "200 µm" (rounded in the text).
- The drawn Eöt-Wash 2020 curve agrees with thesis |α95| over 45 rows: median −0.0002 dex, maximum 0.0023 dex.
- Raster vs vector: Lee Fig. 5 gives 75.5 vs 75.9 µm, AHN Fig. 5 gives 414 vs 417 µm. Fill vs curve centre (AHN Fig. 5): 418 vs 417 µm. AHN Fig. 4 left edge: 1.98 vs 2.00 mm.

## Known limits (open items)
- The |α| curves are not +α bounds. The HUST sign split, the Lee PRL Supplemental Material and the Tan 2020 full text are missing. This affects only the 75.9 to ~98.1 µm part of the transition band; the ~98.1–101.0 µm part follows from the Eöt-Wash 2020 |α95| vs +α95 constructions.
- The 1 nm–1 µm range is judged from the Fig. 9 axis minimum only.
- Coverage between 1 µm and 2.4 µm is above the drawn frame (≥ 10^10).
- λ > 10^15 m is not covered.
- A quick search found no post-2020 published bound stronger at α ≈ 0.08 near 50–150 µm. This is not an exhaustive survey.
- The bounds as drawn depend on how the authors re-plotted others' results. The vector centre line is exact, but the stroke-width tolerance is only a reading proxy.

## Reproduce
`python run_check.py` (Windows, Linux, macOS). By default it SHA-256-checks the frozen digitization data in `inputs/frozen_digitization/` and rebuilds the envelopes, crossings, ratio table and figures from it; `python run_check.py --from-pdfs` (needs the source PDFs from `SOURCES.md` and poppler-utils) SHA-256-checks the PDFs and also reruns the digitization. In both modes only inputs are hash-checked; it then runs `scripts/check_hust_free_gap.py` (HUST-free crossings) and `scripts/verify_outputs.py`, a numeric comparison with `reference/` at rtol = 1e-4. Byte-identical PNG/PDF outputs are not expected.
