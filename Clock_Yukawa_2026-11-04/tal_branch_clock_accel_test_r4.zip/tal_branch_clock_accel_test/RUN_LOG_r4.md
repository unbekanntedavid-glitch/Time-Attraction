# RUN_LOG r4 (2026-11-04)

Preliminary research. Numerical cross-checks with Academia Co-scientist (AI-assisted).

This log records one run of the suite from a fresh unzip of a staging zip whose content is
identical to this package except for RUN_LOG_r4.md (this file, written after the run) and
MANIFEST_SHA256.txt (regenerated when the package is built).

## Environment

```
2026-11-04 18:57:05 CET (UTC+0100)
python 3.13.5 (main, Aug 10 2026, 12:06:59) [GCC 14.2.0]
platform Linux-6.12.94+-x86_64-with-glibc2.41
numpy 2.5.4
scipy 1.18.1
matplotlib 3.11.2
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
```

## Exact command (from the unzip folder)

```
python3 run_check.py --out runs/fresh_r4
```

## Console output (absolute paths replaced by `<unzip folder>`)

```
[1/6] preflight ...
   numpy 2.5.4: ok
   scipy 1.18.1: ok
   matplotlib 3.11.2: ok
   python 3.13.5 on Linux
[2/6] input SHA-256 check (inputs only) ...
   6 input files OK
   4 bound inputs match their recorded source SHA-256 (BREN revision: BREN continuation package (this publication set))
[3/6] computation -> <unzip folder>/runs/fresh_r4
[4/6] physics self-tests (C.. = deliberately broken controls, must fail internally) ...
   PASS  T01 quadrature mass = rho*pi*(r2^2-r1^2)*h  [M_quad=170.9183483 kg, M_exact=170.9183483 kg]
   PASS  T02 Newton on-axis: 3D quadrature vs closed form  [rel err 2.22e-16]
   PASS  T03 Yukawa on-axis (L=1cm..1km): 3D quadrature vs exact-radial+quad  [rel errs 8.2e-13, 3.3e-16, 2.2e-16, 3.4e-14]
   PASS  T04 far field U -> -G M/D (D = 200 m)  [rel dev 8.39e-08]
   PASS  T05 alpha=0: full TAL route equals separate GR route; delta = 0  [Dy_TAL-Dy_GR=9.2e-41, dy=0.0e+00, da=0.0e+00]
   PASS  T06 calibrated delta: stable form = direct form = full TAL-GR route (L=1,10 m)  [max rel diff 5.7e-13]
   PASS  T07 calibration: L>>s gives G_inf -> G_lab/(1+alpha) (V28 Step 27 convention)  [G_inf/(G_lab/(1+a))-1 = 3.708e-14]
   PASS  T08 U_A-U_B = int_A^B delta_a dx (redshift and force from one potential)  [max rel 9.1e-15]
   PASS (control failed as required)  C01 BROKEN CONTROL: force without (1+d/L) factor must FAIL T08  [broken max rel 2.2e+04 (expected large)]
   PASS  T09 swap symmetry: delta_a(A) = delta_a(B)  [max rel 0.0e+00]
   PASS  T10 grid refinement n=12 -> 16 (tested L grid only)  [max rel change 6.4e-13]
   PASS  T11 analytic upper bound >= quadrature (L <= 5 cm)  [max log10(quad/bound) = -0.91]
   PASS  T12 declared clock-to-surface distance matches geometry  [dA=0.100000 m, dB=0.100000 m]
   PASS  T13 allowed edge from envelope within crossing interval  [edge 75.88 um vs file 75.88 um]
   PASS  T14 BREN-derived values equal the BREN input file (independent JSON traversal)  [17 values, max rel diff 0.0e+00]
   PASS  T15 sub-cm band: HUST |a| < Eot-Wash 2020 |a| < thesis |a95| < thesis +a95; edge = HUST crossing  [75.8771 < 98.0737 < 98.1355 < 101.0290 um]
   PASS  T16 non-universal addon: dy_extra/k_c = -Delta(phi_A-phi_B), phi with G_inf (P1-P3, rtol 1e-12)  [max rel diff per set: P1 0.0e+00, P2 0.0e+00, P3 0.0e+00]
   PASS (control failed as required)  C05 BROKEN CONTROL: phi normalized with G_lab must FAIL T16 at every parameter set  [rel diff per set: P1 8.0e-02, P2 2.7e-02, P3 8.0e-02 (expected large)]
   PASS (control failed as required)  C02 BROKEN CONTROL: perturbed reference (1e-6) must be detected  [detected]
   PASS (control failed as required)  C03 BROKEN CONTROL: one-byte change of an input must fail the SHA check  [detected]
   PASS (control failed as required)  C04 BROKEN CONTROL: provenance record with a wrong SHA-256 must fail  [detected]
[5/6] numeric-tolerance comparison with reference (rtol=1e-08) ...
   0 differences
[6/6] decision
   branch: V26 Branch II-Fluid with universal matter coupling (assumption U)
   P1: (b) signal exists but its force is excluded
   P2: (b) signal exists but its force is excluded
   P3: (b) signal exists but its force is excluded
   DECISION (primary set P1): (b) signal exists but its force is excluded
   alpha_Y = 1 bound-allowed remainder (lambda < 75.88 um, |alpha| curves incl. HUST 2020): (c) allowed but too small
   transition band 75.88-101.03 um (experiment/construction dependent), upper edge: (c) allowed but too small
RESULT: PASS   (outputs in <unzip folder>/runs/fresh_r4)
exit 0
elapsed_s 102
```

## PDF build note

The PDFs in docs/ were rebuilt with pdfLaTeX (TeX Live 2026, two passes) via
`python3 docs/build_docs.py`, which regenerates docs/generated/ from
reference/reference_results.json and then compiles docs/tal_branch_clock_accel_en.tex and
docs/tal_branch_clock_accel_hu.tex. EN: 7 pages, HU: 7 pages; license footer present on every page.
