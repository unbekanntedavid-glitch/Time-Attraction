# Változatleírás r4 (tal_branch_clock_accel_test)

Előzetes kutatás. Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú); új mérési adat nélkül.

## Változások ebben a változatban (r4, 2026. november 4.)

A skalártér normálásának javítása a nem univerzális kiegészítőben (a jelentések „Nem univerzális csatolás (a rögzített ágon kívül)” szakasza; a rögzített ágon kívül).

- A kiegészítő képlete δy_extra = −k_c Δ(φ_A − φ_B), ahol φ(x) = α_Y G_∞ / (4π c²) ∫ ρ(x′) e^(−d/L)/d d³x′, ahogy a jelentésekben áll. Az r3 változat ezt a φ-t G_∞ helyett G_lab-bal számolta, vagyis a G_∞/G_lab tényező nélkül. Az r4 a φ-t közvetlenül G_∞-nel építi fel (`talcheck/compute.py`: `scalar_field_phi`, `delta_phi_AB`, `dy_extra`, `nonuniversal`).
- Megváltozott számok (δy_extra k_c = 1-re; az S = 5-höz szükséges k_c a 7,6e-21-es Sr differenciális szinten):

| készlet | G_∞/G_lab | δy_extra (k_c = 1), r3 | δy_extra (k_c = 1), r4 | szükséges k_c, r3 | szükséges k_c, r4 |
|---|---|---|---|---|---|
| P1 (L = 10 km, α_Y = 1) | 0.9262883177542528 | −4.9713903860190284e-26 | −4.6049408375652313e-26 | 764373.6872257481 | 825200.6125683847 |
| P2 (L = 10 km, α_Y = 1/3) | 0.9741596136881324 | −1.6571301286730092e-26 | −1.6143092459790636e-26 | 2293121.0616772445 | 2353947.9870198816 |
| P3 (L = 1 km, α_Y = 1) | 0.9262883180922076 | −4.971388831937201e-26 | −4.6049393997174937e-26 | 764373.9261729108 | 825200.8702292856 |

  A jelentésekben (P1): δy_extra −4,971e-26 → −4,605e-26; k_c ≈ 7,644e5 → 8,252e5.
- Új eredménykulcs paraméterkészletenként: `nonuniversal/Delta_phi_AB` (Δ(φ_A − φ_B), G_∞-nel számolt φ); új CSV-oszlopok a `docs/generated/table_parameter_sets.csv` fájlban (és minden futási mappában): `nonuni_Delta_phi_AB`, `nonuni_dy_extra_k1`, `nonuni_k_c_needed_5sigma_Bothwell`; új táblázat: `docs/generated/tab_nonuni_en.tex` / `docs/generated/tab_nonuni_hu.tex` (a jelentések „Nem univerzális kiegészítő” táblázata, mindhárom készlettel).
- Új ellenőrzés, T16: δy_extra/k_c = −Δ(φ_A − φ_B), ahol φ közvetlenül G_∞-nel, friss integrálokból épül fel, P1, P2 és P3 esetén (k_c = 1, 1e3, 1e6; a szükséges k_c is), 1e-12 relatív toleranciával; hiányzó vagy nem véges érték hibának számít. Új, szándékosan elrontott kontroll, C05: ugyanez az ellenőrzés G_lab-bal normált φ-vel minden paraméterkészletnél bukik (8,0e-2, 2,7e-2, 8,0e-2 eltéréssel).
- Változatlan: a `reference/reference_results.json` minden más száma (700 numerikus érték, köztük δy_cal, δa_cal, az R arányok, az S értékek, a λ-letapogatás, a csak korlátos tartomány és a cm alatti sáv) azonos az r3-mal (legnagyobb relatív eltérés 0). A rögzített ághoz, annak kalibrációjához és a V26 α_Y = 1 normálásához nem nyúltunk. A nagy hatótávú MICROSCOPE-proxy k_c-korlátja (α_Y = 1-re 4,2547e-11) nem függ φ-től, változatlan.
- Szöveg: a jelentésekben a linearizált téregyenlet most kifejezetten G_∞-t ír (∇²φ − φ/L² = −α_Y G_∞ ρ/c²), összhangban φ megoldásával; a kiegészítő megfogalmazása S = 5-öt használ.
- Csak szöveg (a számítás és a referenciaértékek érintetlenek): a δy/δa táblázat „nyers” oszlopát, a kapcsolódó bekezdést és az ábra jelmagyarázatát „GR G_∞-nel” leírás kísérte, ami nem egyezett a kóddal (dy_raw = −G_lab·α·ΔY_U/c², a Yukawa-tag önmagában G_lab-bal). Most azt írják, amit a kód számol: kalibrálatlan szemléltetés G_lab-bal, nem a fő megfigyelhető; a fő számok a kalibrált TAL−GR különbségek (`docs/*.tex`, a `talcheck/figures.py` jelmagyarázata).
- Csak szöveg (a számítás és minden referenciaszám érintetlen): S leírása most megvalósíthatósági mutató, amely a deklarált műszer- és modellbizonytalansági proxykból épül fel, nem egy megfigyelt jel szignifikanciája; a döntés megfogalmazása „S = 5 megvalósíthatósági küszöb” (`docs/*.tex`, 8. és 10. szakasz, angolul és magyarul). R továbbra is feltételes arány a korláthoz. A `resolution_threshold_sigma` és `k_c_needed_5sigma_Bothwell` adatkulcsnevek és a `nonuni_k_c_needed_5sigma_Bothwell` CSV-oszlop megmarad, így a referenciakulcsok ugyanazok.
- Korlátbemenet frissítése (a forrásban csak szöveg): az `inputs/bounds/bren_continuation_results_r2.json` a BREN-folytatás csomag r4 fájlja (a fájlnév megmaradt), amelyben csak a `status` szövege változott; minden numerikus érték azonos. Új SHA-256: a0cf690641b88737f924aa27dcfcb196939dc58447889ed0178eb533d1477f33; ezt hordozza az `inputs/PROVENANCE_bounds.json`, az `inputs/SHA256SUMS_inputs.txt` és a `reference/reference_results.json` rögzített bemeneti hash-e (`bound_inputs/bren_sha256`); minden referenciaszám azonos.
- `RUN_LOG_r4.md`: a csomag friss futásának környezete és pontos parancsa.

## Mit tartalmaz ez a változat

- `run_check.py` a `talcheck/` modulokkal: a rögzített ág δy (óra-vöröseltolódás) és δa (gyorsulás) értékei a deklarált gránithéj-geometriára, összevetve a korlátbemenetekkel; döntési kategória paraméterkészletenként.
- Korlátbemenetek az `inputs/bounds/` mappában: a BREN-torony folytatásának eredményei (BREN-folytatás csomag, ebben a publikációs sorozatban), valamint a cm alatti burkolók, metszéspontok és az AHN 2003 4. ábra poligonjai (cm alatti Yukawa-ablak csomag, ebben a publikációs sorozatban). Minden fájl SHA-256-tal szerepel az `inputs/PROVENANCE_bounds.json` fájlban.
- Az `inputs/setup_declared.json` által idézett háttérrekordok: TAL V20 (DOI 10.5281/zenodo.23540741), TAL V26 (DOI 10.5281/zenodo.23727585), TAL V28 Step 27 (DOI 10.5281/zenodo.23814053).
- Ellenőrzések: bemeneti SHA-256, a korlátbemenetek eredete, T01–T16 öntesztek, C01–C05 szándékosan elrontott kontrollok, numerikus összevetés a `reference/reference_results.json` fájllal (rtol 1e-8; nem véges érték, típuseltérés és hiányzó kulcs hibának számít).
- Jelentések: `docs/tal_branch_clock_accel_en.pdf` és `docs/tal_branch_clock_accel_hu.pdf`, a referenciaeredményekből generált táblázatokkal és ábrával.
- Korábbi r3 változat: licenc (CC BY-NC 4.0, `LICENSE.txt`), semleges megfogalmazás.
