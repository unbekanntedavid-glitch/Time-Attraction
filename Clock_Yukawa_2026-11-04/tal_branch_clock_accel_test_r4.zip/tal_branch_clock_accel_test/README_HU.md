# TAL-ág: kétórás frekvenciaarány és gyorsulás (ellenőrző csomag)

Előzetes kutatás. Numerikus keresztellenőrzés az Academia Co-scientist segítségével (MI-alapú).

## Mit csinál a csomag?

A csomag egyetlen TAL-ágat rögzít: a V26 II-Fluid ágat univerzális anyagcsatolással. A paraméterkészletek: P1 = (L = 10 km, α_Y = 1), P2 = (10 km, 1/3) és P3 = (1 km, 1). Egy deklarált gránitforrást két helyzet között mozgat, és ugyanabból a hatásból kiszámolja:

- δy = Δln(νA/νB)_TAL − Δln(νA/νB)_GR, a kétórás frekvenciaarány változását;
- δa = Δa_TAL − Δa_GR, a vízszintes gyorsulás változását az órák helyén.

Ezután összeveti az eredményt a meglévő korlátokkal és az elrendezés felbontásával, majd kiírja a döntési kategóriát.

**Döntés a rögzített ágra: (b), van jel, de az ereje kizárt** az elérhető korlátok szerint (R > 1, feltételes arányok; a BREN-arányok a vizsgált forrás- és operátormodelleken belül érvényesek, nem kategorikus kizárásként). Az α_Y = 1 család korlát által megengedett maradéka (c) kategória; a cm alatti határ (75,88 µm, a legtágabb olvasatban 101,03 µm-ig) a korlátkonstrukciótól függ, lásd `docs/tal_branch_clock_accel_hu.pdf`, 10. szakasz.

**r4 változat (2026. november 4.):** a skalártér normálásának javítása a nem univerzális kiegészítőben (a rögzített ágon kívül): φ most G_lab helyett G_∞-nel épül fel, ahogy a jelentésekben áll. Ez megváltoztatja a kiegészítő δy_extra és szükséges k_c értékeit P1, P2 és P3 esetén (P1: δy_extra(k_c = 1) −4.9713903860190284e-26 → −4.6049408375652313e-26; szükséges k_c 764373.6872257481 → 825200.6125683847; minden régi és új érték a `VALTOZASNAPLO_HU.md` fájlban). A rögzített ág δy, δa eredményei és minden más szám változatlan. A BREN-bemenetek a BREN-folytatás csomagból, a cm alatti bemenetek a cm alatti Yukawa-ablak csomagból származnak (mindkettő ebben a publikációs sorozatban). Változatleírás: `VALTOZASNAPLO_HU.md`; a friss futás környezete és parancsa: `RUN_LOG_r4.md`.

A levezetés a `docs/tal_branch_clock_accel_hu.pdf` fájlban van. Az angol változat a `docs/tal_branch_clock_accel_en.pdf`.

## Lépésről lépésre Windowson (programozás nem kell)

1. **Telepítse a Pythont.** Töltse le a Python 3.13-at a https://www.python.org/downloads/windows/ oldalról, és indítsa el a telepítőt. Az első képernyőn pipálja be az **„Add python.exe to PATH”** négyzetet, majd kattintson az „Install Now” gombra.
2. **Csomagolja ki a csomagot.** Kattintson jobb gombbal a `tal_branch_clock_accel_test_r4.zip` fájlra, válassza a **„Az összes kibontása…”** menüpontot, majd kattintson a „Kibontás” gombra.
3. **Nyisson parancsablakot a mappában.** Nyissa meg a kibontott `tal_branch_clock_accel_test` mappát, azt, amelyikben a `run_check.py` van. Kattintson az ablak tetején a címsorba, írja be: `cmd`, majd nyomjon Entert. Megnyílik egy fekete ablak ebben a mappában.
4. **Telepítse a három szükséges könyvtárat** (ez csak egyszer kell). Írja be a következőt, és nyomjon Entert:
   ```
   python -m pip install -r requirements.txt
   ```
5. **Futtassa az ellenőrzést.** Írja be a következőt, és nyomjon Entert:
   ```
   python run_check.py
   ```
   A futás kb. 2–3 percig tart. Az ablakban hat szakasz jelenik meg, [1/6]-tól [6/6]-ig.
6. **Olvassa le az eredményt.** Az utolsó sornak `RESULT: PASS`-nak kell lennie. Közvetlenül fölötte látható a döntés paraméterkészletenként.
7. **Keresse meg a kimeneteket.** Minden futás új mappába ír: `runs\run_<dátum>_<idő>\` (a `run_check.py` futtatása hozza létre; a csomag nem tartalmazza). Semmit nem ír felül és nem töröl. A mappában:
   - `results.json`: minden szám;
   - `check_summary.json`: a tesztlista PASS/FAIL jelöléssel;
   - `table_parameter_sets.csv`: δy és δa paraméterkészletenként (Excelben megnyitható);
   - `table_lambda_scan.csv` és `table_bound_only.csv`: a λ-letapogatás;
   - `fig_delta_vs_lambda.png` és `fig_delta_vs_lambda.pdf`: az ábra.

macOS-en és Linuxon a parancsok ugyanezek. Ha ott a `python` parancs nem található, használja a `python3` parancsot.

## Mit ellenőriz?

1. **Előellenőrzés, mielőtt bármit írna.** Ellenőrzi a Python-verziót, a szükséges csomagokat, a bemeneti és a referenciafájlt, valamint azt, hogy a kimeneti mappa új.
2. **Csak a bemenetek SHA-256 összege.** A bemenetek listája az `inputs/SHA256SUMS_inputs.txt` fájlban van. Ha egy bemenet eltér a deklarált összegtől, a futás leáll. Emellett az `inputs/PROVENANCE_bounds.json` minden korlátfájlhoz rögzíti a forráscsomagot és az SHA-256-ot; a futás minden másolatot ehhez veti össze, és leáll, ha egy korlátfájl nincs felsorolva, vagy az SHA-256-ja eltér.
3. **A kimenetek összevetése a referenciával.** A kimeneteket nem hash alapján veti össze, hanem numerikusan a `reference/reference_results.json` fájllal, 1e-8 relatív toleranciával.
4. **Fizikai tesztek, T01–T16.** Ezek a következőket fedik le:
   - a tömeget;
   - a zárt alakot és a független 1D integrálokat;
   - a távoltéri határesetet;
   - az α = 0 esetet;
   - a stabil és a direkt numerikus alakot;
   - a kalibrációs határesetet;
   - hogy a vöröseltolódás egyenlő az erő vonalintegráljával;
   - a szimmetriát;
   - a rácsfinomítást;
   - az analitikus korlátot;
   - a geometriát;
   - a korlát élét;
   - T14: minden felhasznált BREN-érték egyezik a BREN-bemenetfájlban lévővel (független JSON-bejárás);
   - T15: a cm alatti sáv metszéspontjainak sorrendjét;
   - T16: a nem univerzális kiegészítőben δy_extra/k_c = −Δ(φ_A − φ_B), ahol φ közvetlenül G_∞-nel épül fel, P1, P2 és P3 esetén (1e-12 relatív tolerancia).
5. **Szándékosan elrontott kontrollok, C01–C05.** Ezeknek belül el kell bukniuk, és a futás csak akkor jelzi őket rendben lévőnek, ha elbuknak. A kontrollok:
   - C01: hibás erőmag;
   - C02: elrontott referencia;
   - C03: egy bájttal módosított bemenet;
   - C04: hibás SHA-256-ot tartalmazó eredetrekord;
   - C05: G_∞ helyett G_lab-bal normált φ (a T16-nak minden paraméterkészletnél buknia kell).

## Fontos korlátozások

- **Deklarált feltevések.** A forrásgeometria és a két helyzet deklarált feltevés: az órák 10 cm-re vannak a gránit felületétől, az R1/R3 tervfájlok nem voltak elérhetők. Minden bemenet az `inputs/setup_declared.json` fájlban van.
- **Proxyk.** A modellbizonytalansági ε szintek és a Coulomb-energia-hányad megjelölt proxyk.
- **A pontossági állítás tartománya.** A kvadratúra pontosságára csak az 1 cm ≤ L ≤ 100 km tartományban teszünk állítást. 1 cm alatt csak szigorú felső korlátot használunk.

## A mappa tartalma

- `run_check.py`: az egyetlen belépési pont.
- `talcheck/`: a számítási modulok (physics, geometry, bounds, compute, selftests, verify, figures, report).
- `inputs/`: a deklarált bemenetek és a korlátadatok, SHA-256 összegekkel; az `inputs/PROVENANCE_bounds.json` megadja minden korlátfájl forrását.
- `CHANGELOG_EN.md`, `VALTOZASNAPLO_HU.md`: változatleírás: mi változott, és mit tartalmaz ez a változat.
- `RUN_LOG_r4.md`: a friss futás környezete (Python- és csomagverziók) és pontos parancsa.
- `LICENSE.txt`: a licenc szövege; `MANIFEST_SHA256.txt`: a csomag fájljainak SHA-256 listája.
- `reference/reference_results.json`: a referenciaeredmények.
- `docs/`: a LaTeX-források, a PDF-ek (HU/EN), a `generated/` mappa (táblázatok, ábra) és a `build_docs.py` (opcionális, pdflatex kell hozzá).
- `requirements.txt`: a rögzített verziók (Python 3.13.5, NumPy 2.5.4, SciPy 1.18.1, Matplotlib 3.11.2).

## Licenc

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Licenc: Creative Commons Nevezd meg! – Ne add el! 4.0 Nemzetközi (CC BY-NC 4.0): https://creativecommons.org/licenses/by-nc/4.0/deed.hu (jogi szöveg: https://creativecommons.org/licenses/by-nc/4.0/legalcode.hu). Valamennyi kereskedelmi, ipari és technológiai hasznosítási jogot a szerző fenntart; kereskedelmi hasznosítás kizárólag a szerző írásos engedélyével. A licenc szövege: `LICENSE.txt`. A forrásként idézett vagy mellékelt harmadik féltől származó dokumentumokra és adatokra azok saját feltételei vonatkoznak.
