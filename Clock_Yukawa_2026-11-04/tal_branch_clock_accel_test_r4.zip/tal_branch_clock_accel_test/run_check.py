#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Single entry point (Windows/macOS/Linux, no bash):   python run_check.py

Steps: preflight (nothing is written before it passes) -> input SHA-256 check ->
computation -> physics self-tests incl. deliberately broken controls -> numeric-tolerance
comparison with reference/reference_results.json -> report in a NEW run directory.
Nothing is ever deleted or overwritten. Preliminary research; numerical cross-checks with Academia Co-scientist (AI-assisted).
"""
import argparse
import copy
import datetime
import json
import os
import platform
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
INPUTS = os.path.join(HERE, "inputs")
REF = os.path.join(HERE, "reference", "reference_results.json")
SUMS = os.path.join(INPUTS, "SHA256SUMS_inputs.txt")
RTOL = 1e-8


def _jsonable(o):
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if hasattr(o, "item"):
        return o.item()
    return o


def preflight(out_dir):
    problems = []
    if sys.version_info < (3, 10):
        problems.append(f"Python >= 3.10 needed, found {platform.python_version()}")
    try:
        import numpy, scipy, matplotlib  # noqa: F401
    except Exception as e:  # noqa: BLE001
        problems.append(f"missing package: {e}  ->  pip install -r requirements.txt")
    for p in (INPUTS, SUMS, REF):
        if not os.path.exists(p):
            problems.append(f"missing: {p}")
    if os.path.exists(out_dir):
        problems.append(f"output directory already exists (never overwritten): {out_dir}")
    parent = os.path.dirname(out_dir)
    if os.path.isdir(parent) and not os.access(parent, os.W_OK):
        problems.append(f"not writable: {parent}")
    return problems


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", help="new output directory (must not exist); default runs/run_<timestamp>")
    ap.add_argument("--write-reference", metavar="PATH",
                    help="maintainer only: write this run's results as a new reference file at PATH (must not exist)")
    args = ap.parse_args()
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.abspath(args.out or os.path.join(HERE, "runs", f"run_{stamp}"))

    print("[1/6] preflight ...")
    probs = preflight(out_dir)
    if args.write_reference and os.path.exists(args.write_reference):
        probs.append(f"reference target exists: {args.write_reference}")
    if probs:
        for p in probs:
            print("   PROBLEM:", p)
        print("RESULT: NOT RUN (preflight failed; nothing written)")
        return 2
    sys.path.insert(0, HERE)
    import numpy
    import scipy
    import matplotlib
    from talcheck.verify import check_inputs, check_provenance, compare
    from talcheck.compute import run, load_setup
    from talcheck.selftests import run_tests
    from talcheck.figures import make_figure
    from talcheck.report import write_tables
    pinned = {}
    with open(os.path.join(HERE, "requirements.txt")) as f:
        for line in f:
            if "==" in line and not line.startswith("#"):
                k, v = line.strip().split("==")
                pinned[k.lower()] = v
    found = {"numpy": numpy.__version__, "scipy": scipy.__version__, "matplotlib": matplotlib.__version__}
    for k, v in found.items():
        tag = "ok" if pinned.get(k) == v else f"differs from pinned {pinned.get(k)} (tolerance check still applies)"
        print(f"   {k} {v}: {tag}")
    print(f"   python {platform.python_version()} on {platform.system()}")

    print("[2/6] input SHA-256 check (inputs only) ...")
    n, bad = check_inputs(INPUTS, SUMS)
    if bad:
        for b in bad:
            print("   FAIL:", b)
        print("RESULT: FAIL (inputs differ from the declared inputs; nothing written)")
        return 3
    print(f"   {n} input files OK")
    S0 = load_setup(INPUTS)
    prov_file = os.path.join(INPUTS, S0["bounds"]["provenance_file"])
    n_p, bad_p = check_provenance(INPUTS, prov_file, S0["bounds"])
    if bad_p:
        for b in bad_p:
            print("   FAIL:", b)
        print("RESULT: FAIL (bound-input provenance check failed; nothing written)")
        return 3
    print(f"   {n_p} bound inputs match their recorded source SHA-256 (BREN revision: {S0['bounds']['bren_revision']})")

    os.makedirs(out_dir)
    print(f"[3/6] computation -> {out_dir}")
    S = load_setup(INPUTS)
    res = _jsonable(run(INPUTS))
    with open(os.path.join(out_dir, "results.json"), "w") as f:
        json.dump(res, f, indent=1)
    make_figure(res, S, os.path.join(out_dir, "fig_delta_vs_lambda.png"), os.path.join(out_dir, "fig_delta_vs_lambda.pdf"))
    write_tables(res, S, out_dir)

    print("[4/6] physics self-tests (C.. = deliberately broken controls, must fail internally) ...")
    tests = run_tests(S, res, INPUTS)
    with open(REF) as f:
        ref = json.load(f)
    diffs = compare(res, ref, RTOL)
    # C02 broken reference: a 1e-6 relative perturbation must be detected
    broken = copy.deepcopy(ref)
    broken["parameter_sets"][0]["dy_cal"] *= 1.0 + 1e-6
    c02 = len(compare(res, broken, RTOL)) > 0
    tests.append(("C02 BROKEN CONTROL: perturbed reference (1e-6) must be detected", c02, "detected" if c02 else "NOT detected"))
    # C03 broken input: a one-byte change in a copied input must fail the SHA check
    ctrl = os.path.join(out_dir, "control_broken_inputs")
    os.makedirs(ctrl)
    with open(os.path.join(INPUTS, "setup_declared.json"), "rb") as f:
        raw = bytearray(f.read())
    raw[-2] = ord(" ") if raw[-2] != ord(" ") else ord("\t")
    with open(os.path.join(ctrl, "setup_declared.json"), "wb") as f:
        f.write(raw)
    ctrl_sums = os.path.join(ctrl, "SHA256SUMS_control.txt")
    with open(SUMS, encoding="utf-8") as f, open(ctrl_sums, "w", encoding="utf-8") as g:
        g.write("".join(l for l in f if l.strip().endswith("setup_declared.json")))
    _, bad_c = check_inputs(ctrl, ctrl_sums)
    tests.append(("C03 BROKEN CONTROL: one-byte change of an input must fail the SHA check", len(bad_c) == 1,
                  "detected" if bad_c else "NOT detected"))
    # C04 broken provenance: a record with a wrong SHA-256 must be rejected
    with open(prov_file, encoding="utf-8") as f:
        pr = json.load(f)
    rec = pr["files"][S["bounds"]["bren_file"]]
    rec["sha256"] = "0" * 64
    ctrl_prov = os.path.join(ctrl, "PROVENANCE_control.json")
    with open(ctrl_prov, "w", encoding="utf-8") as f:
        json.dump(pr, f, indent=1)
    _, bad_c4 = check_provenance(INPUTS, ctrl_prov, S["bounds"])
    tests.append(("C04 BROKEN CONTROL: provenance record with a wrong SHA-256 must fail", len(bad_c4) > 0,
                  "detected" if bad_c4 else "NOT detected"))
    for name, ok, det in tests:
        tag = ("PASS" if ok else "FAIL") + (" (control failed as required)" if name.startswith("C") and ok else "")
        print(f"   {tag}  {name}  [{det}]")

    print(f"[5/6] numeric-tolerance comparison with reference (rtol={RTOL:g}) ...")
    if diffs:
        for d in diffs[:20]:
            print("   DIFF:", d)
    print(f"   {len(diffs)} differences")

    all_ok = all(bool(t[1]) for t in tests) and not diffs
    d = res["decision"]
    summary = {"all_ok": all_ok, "n_tests": len(tests), "n_failed": sum(not bool(t[1]) for t in tests),
               "n_reference_diffs": len(diffs), "decision": d,
               "tests": [{"name": t[0], "pass": bool(t[1]), "detail": t[2]} for t in tests],
               "python": platform.python_version(), "platform": platform.platform(), "versions": found}
    with open(os.path.join(out_dir, "check_summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    if args.write_reference:
        with open(args.write_reference, "w") as f:
            json.dump(res, f, indent=1)
        print("   reference written:", args.write_reference)

    print("[6/6] decision")
    names = {"a": "(a) no new signal", "b": "(b) signal exists but its force is excluded",
             "c": "(c) allowed but too small", "d": "(d) allowed and resolvable (pre-registrable test)"}
    print(f"   branch: {res['branch']}")
    for pid, cat in d["all_sets"].items():
        print(f"   {pid}: {names[cat]}")
    print(f"   DECISION (primary set {d['primary_set']}): {names[d['category']]}")
    tb = res["edge"]["transition_band"]
    print(f"   alpha_Y = 1 bound-allowed remainder (lambda < {res['edge']['lambda_edge_m'] * 1e6:.2f} um, |alpha| curves incl. HUST 2020): "
          f"{names[d['alphaY1_allowed_remainder']]}")
    print(f"   transition band {tb['lower_edge_curve']['lambda_m'] * 1e6:.2f}-{tb['thesis_plus_alpha95']['lambda_m'] * 1e6:.2f} um "
          f"(experiment/construction dependent), upper edge: {names[d['alphaY1_transition_band_upper_edge']]}")
    print(f"RESULT: {'PASS' if all_ok else 'FAIL'}   (outputs in {out_dir})")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
