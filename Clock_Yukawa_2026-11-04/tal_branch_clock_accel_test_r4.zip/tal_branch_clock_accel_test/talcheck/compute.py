# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Main computation: delta_y and delta_a (TAL minus GR) for the declared setup."""
import json
import math
import os

import numpy as np

from . import physics as ph
from .bounds import Bounds
from .geometry import ShellQuadrature

LN10 = math.log(10.0)


def _sha(path):
    import hashlib
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def load_setup(inputs_dir):
    with open(os.path.join(inputs_dir, "setup_declared.json")) as f:
        return json.load(f)


def _states(S):
    sp = S["source_positions"]
    return [("S1", tuple(sp["S1_axis_xy_m"])), ("S2", tuple(sp["S2_axis_xy_m"]))]


def facing_angle(axis_xy, A, B):
    """Azimuth from the source axis toward the clock midpoint (panel refinement only)."""
    mx, my = 0.5 * (A[0] + B[0]), 0.5 * (A[1] + B[1])
    return math.atan2(my - axis_xy[1], mx - axis_xy[0])


def integrate_all(S, L_list, s_cal, n=None, broken_force=False, extra_points=None):
    sm, q = S["source_mass"], S["quadrature"]
    A, B = S["clocks"]["A_xyz_m"], S["clocks"]["B_xyz_m"]
    pts = {"A": A, "B": B}
    if extra_points:
        pts.update(extra_points)
    out, masses = {}, {}
    for st, ax in _states(S):
        Q = ShellQuadrature(sm["r_in_m"], sm["r_out_m"], sm["height_m"], sm["rho_kg_m3"],
                            ax, facing_angle(ax, A, B), q, n)
        masses[st] = (Q.mass, Q.mass_exact)
        for name, p in pts.items():
            out[(st, name)] = Q.integrals(p, L_list, s_cal, q["stable_form_switch_L_m"], broken_force)
    return out, masses


def observables(I, S, i_L, alpha, L, s_cal):
    """delta_y, delta_a (x component, clocks A and B) for the declared swap S1 - S2."""
    G, c = S["constants_SI"]["G_lab_m3_kg_s2"], S["constants_SI"]["c_m_s"]
    ap = ph.alpha_prime(alpha, L, s_cal)

    def pl(st, cn):
        return I[(st, cn)]["per_L"][i_L]

    def D_pot(key, pref):
        return pref * ((pl("S1", "A")[key] - pl("S1", "B")[key]) - (pl("S2", "A")[key] - pl("S2", "B")[key])) / c ** 2

    def D_acc(key, pref, cn):
        return pref * (pl("S1", cn)[key][0] - pl("S2", cn)[key][0])

    return {
        "dy_cal": D_pot("C_U", -G * ap),
        "da_cal_A": D_acc("C_a", G * ap, "A"),
        "da_cal_B": D_acc("C_a", G * ap, "B"),
        "dy_raw": D_pot("Y_U", -G * alpha),
        "da_raw_A": D_acc("Y_a", -G * alpha, "A"),
        "da_raw_B": D_acc("Y_a", -G * alpha, "B"),
        "alpha_prime": ap,
        "Ginf_over_Glab": 1.0 / (1.0 + alpha * float(ph.kappa(s_cal / L))),
    }


def gr_reference(I, S):
    """GR (G = G_lab) with the same source geometry, built from the Newton integrals only."""
    G, c = S["constants_SI"]["G_lab_m3_kg_s2"], S["constants_SI"]["c_m_s"]
    U = {k: -G * v["N_U"] for k, v in I.items()}
    ax = {k: -G * v["N_a"][0] for k, v in I.items()}
    y1 = (U[("S1", "A")] - U[("S1", "B")]) / c ** 2
    y2 = (U[("S2", "A")] - U[("S2", "B")]) / c ** 2
    return {"y_S1": y1, "y_S2": y2, "Dy_GR": y1 - y2,
            "Da_GR_A": ax[("S1", "A")] - ax[("S2", "A")],
            "Da_GR_B": ax[("S1", "B")] - ax[("S2", "B")],
            "a_GR_A_S1": ax[("S1", "A")], "a_GR_A_S2": ax[("S2", "A")]}


def log10_upper_bounds(S, alpha, L, s_cal, d_min):
    """Rigorous upper bounds (log10) for |Delta y_cal| and |Delta a_cal| for any source with
    density <= rho and all mass at distance >= d_min from both clocks."""
    G, c = S["constants_SI"]["G_lab_m3_kg_s2"], S["constants_SI"]["c_m_s"]
    rho, M = S["source_mass"]["rho_kg_m3"], None
    sm = S["source_mass"]
    M = rho * math.pi * (sm["r_out_m"] ** 2 - sm["r_in_m"] ** 2) * sm["height_m"]
    y = s_cal / L
    lk = -y + math.log1p(y)  # ln kappa(y)
    ap = ph.alpha_prime(alpha, L, s_cal)
    lnU = np.logaddexp(math.log(4 * math.pi * rho * L * (L + d_min)) - d_min / L, lk + math.log(M / d_min))
    lna = np.logaddexp(math.log(4 * math.pi * rho * (2 * L + d_min)) - d_min / L, lk + math.log(M / d_min ** 2))
    pre = math.log(G * ap)
    return {"log10_Dy_bound": float((pre + lnU + math.log(4.0) - 2 * math.log(c)) / LN10),
            "log10_Da_bound": float((pre + lna + math.log(2.0)) / LN10)}


def resolution(S, dy, da, gr):
    eps = S["model_uncertainty_scenarios"]
    thr = S["resolution_threshold_sigma"]
    cu = S["clock_uncertainty"]
    au = S["acceleration_uncertainty"]
    out = {"clock": {}, "accel": {}}
    for ek in ("eps_rel_granite", "eps_rel_precision"):
        sm_y = eps[ek] * abs(gr["Dy_GR"])
        sm_a = eps[ek] * abs(gr["Da_GR_A"])
        for ck in ("OCXO_8663_short_term", "Sr_systematic_Aeppli2024", "Sr_differential_Bothwell2022"):
            sig = math.hypot(cu[ck]["value"], sm_y)
            out["clock"][f"{ck}|{ek}"] = {"sigma": sig, "S": abs(dy) / sig, "resolvable": abs(dy) / sig >= thr}
        sig = math.hypot(au["torsion_balance_Schlamminger2008"]["value"], sm_a)
        out["accel"][f"torsion_balance_Schlamminger2008|{ek}"] = {"sigma": sig, "S": abs(da) / sig, "resolvable": abs(da) / sig >= thr}
    out["any_resolvable"] = any(v["resolvable"] for d in (out["clock"], out["accel"]) for v in d.values())
    out["max_S"] = max(v["S"] for d in (out["clock"], out["accel"]) for v in d.values())
    return out


def bound_ratios(Bd, S, alpha, L):
    r = {"alpha": alpha}
    al = Bd.alpha_lim_combined(L)
    r["alpha_lim_lab_compilation"] = al
    r["R_lab_compilation"] = alpha / al if np.isfinite(al) else None
    bren = Bd.bren_alpha_lims(L)
    r["bren_B89_rho2000"] = bren
    if bren:
        r["R_bren_min"] = alpha / max(bren.values())
        r["R_bren_max"] = alpha / min(bren.values())
    k90 = S["bounds"]["K90_1km"]
    if np.isclose(L, k90["lambda_m"], rtol=1e-9):
        r["alpha_lim_K90"] = float(Bd.bren_value(k90["alpha_lim_json_path"]))
        r["R_K90"] = alpha / r["alpha_lim_K90"]
    sp = S["bounds"]["B90_single_point_1km"]
    if np.isclose(L, sp["lambda_m"], rtol=1e-9):
        # context only (different test construction); not used in R_conservative
        r["alpha_lim_B90_single_point"] = float(Bd.bren_value(sp["alpha_lim_json_path"]))
        r["R_B90_single_point_conditional"] = alpha / r["alpha_lim_B90_single_point"]
        r["B90_single_point_note"] = Bd.bren_value(sp["note_json_path"])
    Rs = [v for v in (r.get("R_lab_compilation"), r.get("R_bren_min")) if v is not None]
    r["R_conservative"] = min(Rs) if Rs else None
    r["excluded"] = bool(r["R_conservative"] is not None and r["R_conservative"] > 1.0)
    return r


def category(signal_nonzero, excluded, resolvable):
    if not signal_nonzero:
        return "a"
    if excluded:
        return "b"
    return "d" if resolvable else "c"


def scalar_field_phi(Y_U, alpha_Y, G_inf, c):
    """phi(x) = alpha_Y * G_inf / (4 pi c^2) * int rho(x') exp(-d/L)/d d^3x'  (Y_U = that integral).
    The scalar field is normalized with G_inf, the same G as in the action and in U_TAL."""
    return alpha_Y * G_inf / (4.0 * math.pi * c ** 2) * Y_U


def delta_phi_AB(I, i_L, alpha_Y, G_inf, c):
    """Delta(phi_A - phi_B) for the declared swap S1 - S2, phi built directly with G_inf."""
    ph_ = {k: scalar_field_phi(v["per_L"][i_L]["Y_U"], alpha_Y, G_inf, c) for k, v in I.items()}
    return (ph_[("S1", "A")] - ph_[("S1", "B")]) - (ph_[("S2", "A")] - ph_[("S2", "B")])


def dy_extra(k_c, dphi_AB):
    """Clock-only extra term of the non-universal model: delta y_extra = -k_c * Delta(phi_A - phi_B)."""
    return -k_c * dphi_AB


def nonuniversal(S, alpha, dphi_AB):
    """Non-universal clock addon (outside the fixed branch). dphi_AB = Delta(phi_A - phi_B) with phi
    normalized by G_inf (scalar_field_phi)."""
    nu = S["nonuniversal_proxy"]

    def xi(el):
        Z, A = nu[el]["Z"], nu[el]["A"]
        return nu["a_C_MeV"] * Z * (Z - 1) * A ** (-1.0 / 3.0) / (A * nu["u_MeV"])
    ep = S["bounds"]["EP_MICROSCOPE"]
    sig = math.hypot(ep["sigma_stat"], ep["sigma_syst"])
    eta95 = abs(ep["eta_TiPt"]) + 1.96 * sig
    dxi = xi("Pt") - xi("Ti")
    kmax = eta95 / (alpha * dxi)
    bothwell = S["clock_uncertainty"]["Sr_differential_Bothwell2022"]["value"]
    thr = S["resolution_threshold_sigma"]
    dy_k1 = dy_extra(1.0, dphi_AB)
    return {"xi_Ti": xi("Ti"), "xi_Pt": xi("Pt"), "dxi": dxi, "eta95": eta95,
            "k_c_max_long_range_proxy": kmax, "Delta_phi_AB": dphi_AB, "dy_extra_for_k1": dy_k1,
            "k_c_needed_5sigma_Bothwell": thr * bothwell / abs(dy_k1)}


def run(inputs_dir, n=None, broken_force=False):
    S = load_setup(inputs_dir)
    Bd = Bounds(inputs_dir, S["bounds"])
    G = S["constants_SI"]["G_lab_m3_kg_s2"]
    s_cal = S["calibration"]["s_cal_m"]
    ls = S["lambda_scan"]
    nd = int(round((ls["quadrature_log10L_max"] - ls["quadrature_log10L_min"]) * ls["quadrature_points_per_decade"])) + 1
    L_scan = list(np.logspace(ls["quadrature_log10L_min"], ls["quadrature_log10L_max"], nd))
    P = S["parameter_sets"]
    L_P = [p["L_m"] for p in P]
    L_all = L_P + L_scan
    I, masses = integrate_all(S, L_all, s_cal, n, broken_force)
    gr = gr_reference(I, S)
    res = {"status": S["_status"], "branch": S["branch"]["name"], "s_cal_m": s_cal,
           "n_per_panel": n or S["quadrature"]["n_per_panel"], "masses": masses, "GR": gr}
    # s_cal variants (same quadrature nodes, separate runs only for P-sets)
    var = {}
    for sv in S["calibration"]["s_cal_variants_m"]:
        Iv, _ = integrate_all(S, L_P, sv, n, broken_force)
        var[sv] = Iv
    psets = []
    for i, p in enumerate(P):
        alpha = ph.alpha_from_alphaY(p["alpha_Y"])
        ob = observables(I, S, i, alpha, p["L_m"], s_cal)
        ob_var = {f"{sv:g}": {k: v for k, v in observables(var[sv], S, i, alpha, p["L_m"], sv).items()
                              if k in ("dy_cal", "da_cal_A")} for sv in var}
        br = bound_ratios(Bd, S, alpha, p["L_m"])
        rs = resolution(S, ob["dy_cal"], ob["da_cal_A"], gr)
        nonzero = (ob["dy_cal"] != 0.0) or (ob["da_cal_A"] != 0.0)
        Gi = ph.G_inf(G, alpha, p["L_m"], s_cal)
        dphi = delta_phi_AB({k: I[k] for k in I if k[1] in ("A", "B")}, i, p["alpha_Y"], Gi, S["constants_SI"]["c_m_s"])
        psets.append({**p, "alpha": alpha, **ob, "s_cal_variants": ob_var,
                      "dy_over_DyGR": ob["dy_cal"] / gr["Dy_GR"], "da_over_DaGR": ob["da_cal_A"] / gr["Da_GR_A"],
                      "bounds": br, "resolution": rs,
                      "nonuniversal": nonuniversal(S, alpha, dphi),
                      "category": category(nonzero, br["excluded"], rs["any_resolvable"])})
    res["parameter_sets"] = psets
    # lambda scan, alpha_Y fixed
    aY = ph.alpha_from_alphaY(ls["alpha_Y"])
    sc = {k: [] for k in ("L_m", "dy_cal", "da_cal_A", "dy_raw", "da_raw_A", "alpha_lim", "R")}
    for j, L in enumerate(L_scan):
        ob = observables(I, S, len(L_P) + j, aY, L, s_cal)
        al = Bd.alpha_lim_combined(L)
        sc["L_m"].append(L)
        for k in ("dy_cal", "da_cal_A", "dy_raw", "da_raw_A"):
            sc[k].append(ob[k])
        sc["alpha_lim"].append(al)
        sc["R"].append(aY / al if np.isfinite(al) else float("nan"))
    res["scan"] = sc
    # bound-only region (below the quadrature grid)
    nb = int(round((ls["quadrature_log10L_min"] - ls["bound_only_log10L_min"]) * ls["bound_only_points_per_decade"]))
    L_b = list(np.logspace(ls["bound_only_log10L_min"], ls["quadrature_log10L_min"], nb + 1))[:-1]
    d_min = S["source_positions"]["clock_to_surface_m"]
    bo = {"L_m": [], "log10_Dy_bound": [], "log10_Da_bound": [], "alpha_lim": [], "R": []}
    for L in L_b:
        ub = log10_upper_bounds(S, aY, L, s_cal, d_min)
        al = Bd.alpha_lim_combined(L)
        bo["L_m"].append(L)
        bo["log10_Dy_bound"].append(ub["log10_Dy_bound"])
        bo["log10_Da_bound"].append(ub["log10_Da_bound"])
        bo["alpha_lim"].append(al)
        bo["R"].append(aY / al)
    res["bound_only"] = bo
    # allowed edge of the alpha_Y = 1 family
    edge = Bd.allowed_edge(aY)
    ub = log10_upper_bounds(S, aY, edge, s_cal, d_min)
    unit = resolution(S, 1.0, 1.0, gr)  # S for unit signal = 1/sigma
    best_clock = max(v["S"] for v in unit["clock"].values())
    best_acc = max(v["S"] for v in unit["accel"].values())
    log10_S = max(ub["log10_Dy_bound"] + math.log10(best_clock), ub["log10_Da_bound"] + math.log10(best_acc))
    thr = S["resolution_threshold_sigma"]
    res["edge"] = {"alpha": aY, "lambda_edge_m": edge, "from_crossings_file": Bd.edge_crossing_from_file(), **ub,
                   "sigma_y_min": 1.0 / best_clock, "sigma_a_min": 1.0 / best_acc,
                   "log10_max_S_upper": log10_S,
                   "R_at_50um": aY / Bd.alpha_lim_combined(5.0e-5),
                   "category": category(True, False, log10_S >= math.log10(thr))}
    # sub-cm transition band: edges of the different experiments / bound constructions
    tb = S["bounds"]["subcm_transition_band"]
    band = {}
    for key in ("lower_edge_curve", "first_non_hust_curve", "thesis_abs_alpha95", "thesis_plus_alpha95"):
        cr = Bd.crossing(*tb[key])
        u = log10_upper_bounds(S, aY, cr["lambda_m"], s_cal, d_min)
        lS = max(u["log10_Dy_bound"] + math.log10(best_clock), u["log10_Da_bound"] + math.log10(best_acc))
        band[key] = {**cr, **u, "log10_max_S_upper": lS, "category": category(True, False, lS >= math.log10(thr))}
    res["edge"]["transition_band"] = band
    cats = [p["category"] for p in psets]
    primary = psets[0]["category"]
    res["decision"] = {"primary_set": P[0]["id"], "category": primary, "all_sets": dict(zip([p["id"] for p in P], cats)),
                       "alphaY1_allowed_remainder": res["edge"]["category"],
                       "alphaY1_transition_band_upper_edge": band["thesis_plus_alpha95"]["category"]}
    res["bound_inputs"] = {"bren_file": S["bounds"]["bren_file"], "bren_revision": S["bounds"]["bren_revision"],
                           "bren_sha256": _sha(os.path.join(inputs_dir, S["bounds"]["bren_file"]))}
    return res
