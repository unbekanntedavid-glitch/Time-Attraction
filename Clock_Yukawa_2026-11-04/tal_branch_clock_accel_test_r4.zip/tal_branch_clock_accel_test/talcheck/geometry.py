# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Panel Gauss-Legendre quadrature for a uniform vertical cylindrical shell.

Panels are refined toward the outer surface, the midplane and the azimuth that
faces the clocks, because the short-range Yukawa integrand is concentrated there.
"""
import numpy as np

from . import physics as ph


def _gl_panels(breaks, n):
    x, w = np.polynomial.legendre.leggauss(n)
    nodes, weights = [], []
    for a, b in zip(breaks[:-1], breaks[1:]):
        nodes.append(0.5 * (b - a) * x + 0.5 * (b + a))
        weights.append(0.5 * (b - a) * w)
    return np.concatenate(nodes), np.concatenate(weights)


class ShellQuadrature:
    def __init__(self, r_in, r_out, height, rho, axis_xy, facing_angle, qcfg, n=None):
        n = int(n or qcfg["n_per_panel"])
        rb = [r_in] + [r_out - b for b in qcfg["r_breaks_from_outer_m"] if r_out - b > r_in] + [r_out]
        rb = sorted(set(rb))
        zb = sorted({-height / 2, height / 2, 0.0}
                    | {s * b for b in qcfg["z_breaks_abs_m"] if b < height / 2 for s in (-1, 1)})
        pb = sorted({-np.pi, np.pi, 0.0}
                    | {s * b for b in qcfg["phi_breaks_abs_rad"] if b < np.pi for s in (-1, 1)})
        r, wr = _gl_panels(rb, n)
        z, wz = _gl_panels(zb, n)
        p, wp = _gl_panels(pb, n)
        R, Z, P = np.meshgrid(r, z, p, indexing="ij")
        W = (wr[:, None, None] * r[:, None, None]) * wz[None, :, None] * wp[None, None, :]
        ang = P + facing_angle
        self.x = (axis_xy[0] + R * np.cos(ang)).ravel()
        self.y = (axis_xy[1] + R * np.sin(ang)).ravel()
        self.z = Z.ravel()
        self.w = (rho * W).ravel()  # kg
        self.n = n
        self.mass_exact = rho * np.pi * (r_out ** 2 - r_in ** 2) * height

    @property
    def mass(self):
        return float(np.sum(self.w))

    def integrals(self, point, L_list, s_cal, switch_L, broken_force=False):
        """Return per-L integrals at a field point (SI, without G).

        N_U = int rho/d,  N_a = int rho (x-x')/d^3 (vector)
        Y_U = int rho e^{-x}/d,  Y_a = int rho (1+x)e^{-x}(x-x')/d^3
        C_U = calibrated-excess potential integral (constant G alpha' M/L dropped
              in the stable form; both forms give identical differences)
        C_a = int rho [h(x)-h(y)] (x-x')/d^3
        broken_force=True deliberately drops the (1+x) factor (control that must fail).
        """
        dx = point[0] - self.x
        dy = point[1] - self.y
        dz = point[2] - self.z
        d = np.sqrt(dx * dx + dy * dy + dz * dz)
        inv_d = 1.0 / d
        inv_d3 = inv_d ** 3
        wd = self.w * inv_d
        wv = self.w * inv_d3
        vec = np.stack([dx, dy, dz])
        out = {"N_U": float(np.sum(wd)), "N_a": (vec @ wv).tolist(), "per_L": []}
        for L in L_list:
            xx = d / L
            yk = s_cal / L
            e = np.exp(-xx)
            ff = e if broken_force else (1.0 + xx) * e
            Y_U = float(np.sum(wd * e))
            Y_a = (vec @ (wv * ff)).tolist()
            if L >= switch_L:
                C_U = float(np.sum(wd * (ph.phi2(xx) + ph.h(np.array([yk]))[0])))
                form = "stable"
            else:
                C_U = float(np.sum(wd * (e - ph.kappa(yk))))
                form = "direct"
            fac = ph.force_factor_excess(xx, yk)
            if broken_force:
                fac = ph.force_factor_excess(xx, yk) - xx * e
            C_a = (vec @ (wv * fac)).tolist()
            out["per_L"].append({"L": float(L), "Y_U": Y_U, "Y_a": Y_a,
                                 "C_U": C_U, "C_a": C_a, "form": form})
        return out
