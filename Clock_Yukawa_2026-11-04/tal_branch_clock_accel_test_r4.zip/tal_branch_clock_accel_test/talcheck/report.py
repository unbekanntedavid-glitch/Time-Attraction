# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Tables (CSV + LaTeX fragments in EN and HU) generated from results only."""
import csv
import math
import os

CAT_EN = {"a": "(a) no new signal", "b": "(b) force excluded", "c": "(c) allowed, too small", "d": "(d) resolvable"}
CAT_HU = {"a": "(a) nincs új jel", "b": "(b) az erő kizárt", "c": "(c) megengedett, túl kicsi", "d": "(d) feloldható"}


def tex_num(x, d=3):
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "--"
    if x == 0:
        return "$0$"
    e = int(math.floor(math.log10(abs(x))))
    m = x / 10 ** e
    if -2 <= e <= 3:
        return f"${x:.{max(0, d - 1 - e)}f}$"
    return f"${m:.{d}f}\\times10^{{{e}}}$"


def _one(P, key):
    """The single parameter set that carries `key` (bound values defined only at lambda = 1 km)."""
    vals = [p["bounds"][key] for p in P if key in p["bounds"]]
    if len(vals) != 1:
        raise KeyError(f"{key}: {len(vals)} parameter sets")
    return vals[0]


def write_tables(res, S, out_dir):
    P = res["parameter_sets"]
    gr = res["GR"]
    with open(os.path.join(out_dir, "table_parameter_sets.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id", "L_m", "alpha_Y", "alpha", "alpha_prime", "Ginf_over_Glab", "Dy_GR", "Da_GR_A_m_s2",
                    "dy_cal", "da_cal_A_m_s2", "dy_raw", "da_raw_A_m_s2", "dy_over_DyGR", "da_over_DaGR",
                    "R_lab_compilation", "R_bren_min", "R_bren_max", "R_K90", "R_B90_single_point_conditional",
                    "R_conservative", "max_S", "category", "nonuni_Delta_phi_AB", "nonuni_dy_extra_k1",
                    "nonuni_k_c_needed_5sigma_Bothwell"])
        for p in P:
            b = p["bounds"]
            w.writerow([p["id"], p["L_m"], p["alpha_Y"], p["alpha"], p["alpha_prime"], p["Ginf_over_Glab"], gr["Dy_GR"],
                        gr["Da_GR_A"], p["dy_cal"], p["da_cal_A"], p["dy_raw"], p["da_raw_A"], p["dy_over_DyGR"],
                        p["da_over_DaGR"], b.get("R_lab_compilation"), b.get("R_bren_min"), b.get("R_bren_max"),
                        b.get("R_K90"), b.get("R_B90_single_point_conditional"), b.get("R_conservative"),
                        p["resolution"]["max_S"], p["category"], p["nonuniversal"]["Delta_phi_AB"],
                        p["nonuniversal"]["dy_extra_for_k1"], p["nonuniversal"]["k_c_needed_5sigma_Bothwell"]])
    sc = res["scan"]
    with open(os.path.join(out_dir, "table_lambda_scan.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["L_m", "dy_cal", "da_cal_A_m_s2", "dy_raw", "da_raw_A_m_s2", "alpha_lim", "R"])
        for row in zip(*(sc[k] for k in ("L_m", "dy_cal", "da_cal_A", "dy_raw", "da_raw_A", "alpha_lim", "R"))):
            w.writerow(row)
    bo = res["bound_only"]
    with open(os.path.join(out_dir, "table_bound_only.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["L_m", "log10_Dy_bound", "log10_Da_bound_m_s2", "alpha_lim", "R"])
        for row in zip(*(bo[k] for k in ("L_m", "log10_Dy_bound", "log10_Da_bound", "alpha_lim", "R"))):
            w.writerow(row)
    for lang in ("en", "hu"):
        _tex(res, S, out_dir, lang)


def _dec(text, lang):
    """Hungarian decimal comma for numeric table/macro content."""
    return text.replace(".", "{,}") if lang == "hu" else text


def _tex(res, S, out_dir, lang):
    P = res["parameter_sets"]
    cat = CAT_EN if lang == "en" else CAT_HU
    L1 = []
    for p in P:
        L1.append(f"{p['id']} & {tex_num(p['L_m'])} & {p['alpha_Y']:.4g} & {p['alpha']:.4f} & {tex_num(p['dy_cal'])} & "
                  f"{tex_num(p['dy_raw'])} & {tex_num(p['da_cal_A'])} & {tex_num(p['da_raw_A'])} \\\\")
    with open(os.path.join(out_dir, f"tab_delta_{lang}.tex"), "w", encoding="utf-8") as f:
        f.write(_dec("\n".join(L1), lang) + "\n")
    L2 = []
    for p in P:
        b = p["bounds"]
        bren = b.get("bren_B89_rho2000", {})
        br = (f"{tex_num(min(bren.values()))}--{tex_num(max(bren.values()))}" if bren else "--")
        rb = (f"{b['R_bren_min']:.2f}--{b['R_bren_max']:.2f}" if bren else "--")
        L2.append(f"{p['id']} & {tex_num(b['alpha_lim_lab_compilation'])} & {b['R_lab_compilation']:.1f} & {br} & {rb} & "
                  f"{(format(b['R_K90'], '.1f') if 'R_K90' in b else '--')} & {b['R_conservative']:.2f} \\\\")
    with open(os.path.join(out_dir, f"tab_bounds_{lang}.tex"), "w", encoding="utf-8") as f:
        f.write(_dec("\n".join(L2), lang) + "\n")
    L3 = []
    for p in P:
        rc, ra = p["resolution"]["clock"], p["resolution"]["accel"]
        L3.append(f"{p['id']} & {tex_num(rc['OCXO_8663_short_term|eps_rel_granite']['S'])} & "
                  f"{tex_num(rc['Sr_differential_Bothwell2022|eps_rel_precision']['S'])} & "
                  f"{tex_num(ra['torsion_balance_Schlamminger2008|eps_rel_granite']['S'])} & "
                  f"{tex_num(ra['torsion_balance_Schlamminger2008|eps_rel_precision']['S'])} & ({p['category']}) \\\\")
    with open(os.path.join(out_dir, f"tab_resolution_{lang}.tex"), "w", encoding="utf-8") as f:
        f.write(_dec("\n".join(L3), lang) + "\n")
    L4 = []
    for p in P:
        v = p["s_cal_variants"]
        ks = sorted(v, key=float)
        L4.append(f"{p['id']} & " + " & ".join(f"{tex_num(v[k]['da_cal_A'])}" for k in ks[:1]) +
                  f" & {tex_num(p['da_cal_A'])} & " + " & ".join(f"{tex_num(v[k]['da_cal_A'])}" for k in ks[1:]) + " \\\\")
    with open(os.path.join(out_dir, f"tab_scal_{lang}.tex"), "w", encoding="utf-8") as f:
        f.write(_dec("\n".join(L4), lang) + "\n")
    L5 = []
    for p in P:
        n_ = p["nonuniversal"]
        L5.append(f"{p['id']} & {tex_num(p['L_m'])} & {p['alpha_Y']:.4g} & {p['Ginf_over_Glab']:.6f} & "
                  f"{tex_num(n_['dy_extra_for_k1'])} & {tex_num(n_['k_c_needed_5sigma_Bothwell'])} \\\\")
    with open(os.path.join(out_dir, f"tab_nonuni_{lang}.tex"), "w", encoding="utf-8") as f:
        f.write(_dec("\n".join(L5), lang) + "\n")
    nu = P[0]["nonuniversal"]
    e, g = res["edge"], res["GR"]
    macros = {
        "DyGR": tex_num(g["Dy_GR"]), "DaGR": tex_num(g["Da_GR_A"]), "Mquad": f"{res['masses']['S1'][0]:.4f}",
        "LamEdgeUm": f"{e['lambda_edge_m'] * 1e6:.2f}", "LogDaEdge": f"{e['log10_Da_bound']:.1f}",
        "LogDyEdge": f"{e['log10_Dy_bound']:.1f}", "LogSEdge": f"{e['log10_max_S_upper']:.1f}",
        "XiTi": tex_num(nu["xi_Ti"]), "XiPt": tex_num(nu["xi_Pt"]), "DXi": tex_num(nu["dxi"]),
        "EtaNF": tex_num(nu["eta95"]), "KcMax": tex_num(nu["k_c_max_long_range_proxy"]),
        "DyKone": tex_num(nu["dy_extra_for_k1"]), "KcNeed": tex_num(nu["k_c_needed_5sigma_Bothwell"]),
        "DecisionCat": res["decision"]["category"],
        "OnedyRel": tex_num(P[0]["dy_over_DyGR"]), "OnedaRel": tex_num(P[0]["da_over_DaGR"]),
        "OneMaxS": tex_num(P[0]["resolution"]["max_S"]), "ThreeMaxS": tex_num(P[2]["resolution"]["max_S"]),
        "MinFactor": tex_num(min(S["resolution_threshold_sigma"] / q["resolution"]["max_S"] for q in P)),
        "RFifty": f"{e['R_at_50um']:.3f}", "ImpFifty": f"{1.0 / e['R_at_50um']:.1f}",
        "SigYmin": tex_num(e["sigma_y_min"]), "SigAmin": tex_num(e["sigma_a_min"]),
        "RConsOne": f"{P[0]['bounds']['R_conservative']:.2f}", "RConsTwo": f"{P[1]['bounds']['R_conservative']:.2f}",
        "RConsThree": f"{P[2]['bounds']['R_conservative']:.2f}",
        "RLabOne": f"{P[0]['bounds']['R_lab_compilation']:.1f}", "RLabTwo": f"{P[1]['bounds']['R_lab_compilation']:.1f}",
        "RLabThree": f"{P[2]['bounds']['R_lab_compilation']:.1f}",
        "KNinety": f"{_one(P, 'alpha_lim_K90'):.4g}", "BNinetySP": f"{_one(P, 'alpha_lim_B90_single_point'):.5g}",
        "RBNinetySP": f"{_one(P, 'R_B90_single_point_conditional'):.1f}",
        "BandLow": f"{e['transition_band']['lower_edge_curve']['lambda_m'] * 1e6:.2f}",
        "BandEW": f"{e['transition_band']['first_non_hust_curve']['lambda_m'] * 1e6:.2f}",
        "BandAbs": f"{e['transition_band']['thesis_abs_alpha95']['lambda_m'] * 1e6:.2f}",
        "BandPlus": f"{e['transition_band']['thesis_plus_alpha95']['lambda_m'] * 1e6:.2f}",
        "LogDaPlus": f"{e['transition_band']['thesis_plus_alpha95']['log10_Da_bound']:.1f}",
        "LogDyPlus": f"{e['transition_band']['thesis_plus_alpha95']['log10_Dy_bound']:.1f}",
    }
    with open(os.path.join(out_dir, f"values_{lang}.tex"), "w", encoding="utf-8") as f:
        for k, v in macros.items():
            f.write(f"\\newcommand{{\\v{k}}}{{{_dec(v.strip('$'), lang)}}}\n")
