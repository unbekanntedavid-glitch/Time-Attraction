# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Figures (matplotlib, Agg backend)."""
import math

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402


def make_figure(res, S, path_png, path_pdf):
    sc, bo, gr = res["scan"], res["bound_only"], res["GR"]
    L = np.array(sc["L_m"])
    R = np.array(sc["R"])
    eps = S["model_uncertainty_scenarios"]
    cu, au = S["clock_uncertainty"], S["acceleration_uncertainty"]
    fig, axs = plt.subplots(2, 2, figsize=(9.0, 7.0))
    excl = R > 1

    def shade(ax):
        i = 0
        while i < len(L):
            if excl[i]:
                j = i
                while j + 1 < len(L) and excl[j + 1]:
                    j += 1
                ax.axvspan(L[i], L[j], color="0.9", lw=0, zorder=0)
                i = j + 1
            else:
                i += 1

    ax = axs[0, 0]
    shade(ax)
    ax.loglog(L, np.abs(sc["da_cal_A"]), "C0-", label=r"$|\delta a|$ calibrated (G$_{lab}$)")
    ax.loglog(L, np.abs(sc["da_raw_A"]), "C1--", label=r"$|\delta a|$ raw, uncalibrated (Yukawa term, G$_{lab}$)")
    ax.axhline(au["torsion_balance_Schlamminger2008"]["value"], color="k", ls=":", label="torsion balance 3.1e-15")
    for ek, ls_ in (("eps_rel_granite", "-."), ("eps_rel_precision", (0, (5, 1)))):
        ax.axhline(eps[ek] * abs(gr["Da_GR_A"]), color="C3", ls=ls_, label=f"GR model, eps={eps[ek]:g}")
    for p in res["parameter_sets"]:
        ax.plot(p["L_m"], abs(p["da_cal_A"]), "ks", ms=4)
        ax.annotate(p["id"], (p["L_m"], abs(p["da_cal_A"])), textcoords="offset points", xytext=(4, 4), fontsize=8)
    ax.set_xlabel(r"$L=\lambda$ [m]")
    ax.set_ylabel(r"$|\Delta a_{TAL}-\Delta a_{GR}|$ [m s$^{-2}$]")
    ax.set_title(r"acceleration, $\alpha_Y=1$ scan + P-sets", fontsize=10)
    ax.legend(fontsize=7, loc="lower left")

    ax = axs[0, 1]
    shade(ax)
    ax.loglog(L, np.abs(sc["dy_cal"]), "C0-", label=r"$|\delta y|$ calibrated (G$_{lab}$)")
    ax.loglog(L, np.abs(sc["dy_raw"]), "C1--", label=r"$|\delta y|$ raw, uncalibrated (Yukawa term, G$_{lab}$)")
    for ck, ls_ in (("OCXO_8663_short_term", ":"), ("Sr_systematic_Aeppli2024", "-."), ("Sr_differential_Bothwell2022", "--")):
        ax.axhline(cu[ck]["value"], color="k", ls=ls_, lw=0.9, label=f"{ck.split('_')[0]} {cu[ck]['value']:.1e}")
    ax.axhline(eps["eps_rel_precision"] * abs(gr["Dy_GR"]), color="C3", ls=(0, (5, 1)), label="GR model, eps=1e-4")
    for p in res["parameter_sets"]:
        ax.plot(p["L_m"], abs(p["dy_cal"]), "ks", ms=4)
    ax.set_xlabel(r"$L=\lambda$ [m]")
    ax.set_ylabel(r"$|\Delta\ln(\nu_A/\nu_B)_{TAL}-\Delta\ln(\nu_A/\nu_B)_{GR}|$")
    ax.set_title("two-clock frequency ratio", fontsize=10)
    ax.legend(fontsize=7, loc="center left")

    ax = axs[1, 0]
    Lb = np.concatenate([bo["L_m"], L])
    Rb = np.concatenate([bo["R"], R])
    ax.loglog(Lb, Rb, "C2-")
    ax.axhline(1.0, color="k", lw=0.8)
    ax.axvline(res["edge"]["lambda_edge_m"], color="C3", ls="--", lw=0.8)
    ax.annotate(f"edge {res['edge']['lambda_edge_m'] * 1e6:.1f} um", (res["edge"]["lambda_edge_m"], 1.5), fontsize=8)
    for p in res["parameter_sets"]:
        ax.plot(p["L_m"], p["bounds"]["R_conservative"], "ks", ms=4)
        ax.annotate(p["id"], (p["L_m"], p["bounds"]["R_conservative"]), textcoords="offset points", xytext=(4, -10), fontsize=8)
    ax.set_xlabel(r"$\lambda$ [m]")
    ax.set_ylabel(r"$R=\alpha/\alpha_{lim}$ (conditional, not sigma)")
    ax.set_title(r"bound ratio, $\alpha_Y=1$ (lab compilation); P-sets: conservative", fontsize=9)

    ax = axs[1, 1]
    ax.semilogx(bo["L_m"], bo["log10_Da_bound"], "C0-", label=r"log$_{10}$ bound $|\delta a|$ [m s$^{-2}$]")
    ax.semilogx(bo["L_m"], bo["log10_Dy_bound"], "C1--", label=r"log$_{10}$ bound $|\delta y|$")
    ax.axvline(res["edge"]["lambda_edge_m"], color="C3", ls="--", lw=0.8)
    ax.set_xlabel(r"$\lambda$ [m] (bound-only region)")
    ax.set_ylabel("log10 of rigorous upper bound")
    ax.set_title("allowed region: analytic upper bound", fontsize=10)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(path_png, dpi=150)
    fig.savefig(path_pdf)
    plt.close(fig)
