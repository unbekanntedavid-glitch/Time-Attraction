# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Kernels of the V26 II-Fluid branch (universal coupling, weak field, SI units).

Conventions (one convention everywhere):
  g~_tt = -exp(2 U/c^2) in the matter (clock) frame, U = Phi_N - c^2 phi;
  ln(nu_A/nu_B) = (U_A - U_B)/c^2  (static, Killing-vector ratio; ln nu, not 1+z);
  a = -grad U.
Yukawa:  U_TAL = -G_inf int rho (1 + alpha e^{-d/L})/d,  G_inf = G_lab/(1 + alpha kappa(s/L)).
"""
import numpy as np


def kappa(y):
    """kappa(y) = e^{-y}(1+y): Yukawa force factor at separation y = s/L."""
    y = np.asarray(y, dtype=float)
    return np.exp(-y) * (1.0 + y)


def h(x):
    """h(x) = 1 - e^{-x}(1+x), accurate for all x >= 0 (series for x < 0.5)."""
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    small = x < 0.5
    xs = x[small]
    # sum_{n>=2} (-1)^n (n-1) x^n / n!
    term_sum = np.zeros_like(xs)
    fact = 1.0
    p = np.ones_like(xs)
    for n in range(1, 26):
        fact *= n
        p = p * xs
        if n >= 2:
            term_sum += ((-1.0) ** n) * (n - 1) * p / fact
    out[small] = term_sum
    xl = x[~small]
    out[~small] = 1.0 - np.exp(-xl) * (1.0 + xl)
    return out


def phi2(x):
    """phi2(x) = e^{-x} - 1 + x, accurate for small x (series for x < 0.5)."""
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    small = x < 0.5
    xs = x[small]
    s = np.zeros_like(xs)
    fact = 1.0
    p = np.ones_like(xs)
    for n in range(1, 26):
        fact *= n
        p = p * xs
        if n >= 2:
            s += ((-1.0) ** n) * p / fact
    out[small] = s
    xl = x[~small]
    out[~small] = np.expm1(-xl) + xl
    return out


def force_factor_excess(x, y):
    """[h(x) - h(y)] computed without cancellation for small or large arguments."""
    x = np.asarray(x, dtype=float)
    y = float(y)
    if y >= 1.0:
        return kappa(y) - kappa(x)
    return h(x) - h(np.array([y]))[0]


def alpha_from_alphaY(alpha_Y):
    return alpha_Y / (4.0 * np.pi)


def G_inf(G_lab, alpha, L, s_cal):
    return G_lab / (1.0 + alpha * kappa(s_cal / L))


def alpha_prime(alpha, L, s_cal):
    """alpha' = alpha/(1+alpha kappa): prefactor of the calibrated excess (times G_lab)."""
    return alpha / (1.0 + alpha * kappa(s_cal / L))
