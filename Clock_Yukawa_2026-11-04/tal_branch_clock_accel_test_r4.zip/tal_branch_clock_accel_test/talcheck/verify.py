# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Input SHA-256 check and numeric-tolerance comparison of outputs with reference results."""
import hashlib
import math
import os


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def check_inputs(inputs_dir, sums_file):
    bad, n = [], 0
    with open(sums_file, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            digest, rel = line.split(None, 1)
            rel = rel.lstrip("*")
            p = os.path.join(inputs_dir, *rel.split("/"))
            n += 1
            if not os.path.isfile(p):
                bad.append((rel, "missing"))
            elif sha256(p) != digest:
                bad.append((rel, "sha mismatch"))
    return n, bad


def compare(a, b, rtol, atol=0.0, path="", diffs=None):
    """Recursive comparison. Numbers: |a-b| <= atol + rtol*|b|; others: equality."""
    if diffs is None:
        diffs = []
    if isinstance(b, dict):
        if not isinstance(a, dict):
            diffs.append((path, "type"))
            return diffs
        for k in b:
            if k not in a:
                diffs.append((path + "/" + str(k), "missing"))
            else:
                compare(a[k], b[k], rtol, atol, path + "/" + str(k), diffs)
    elif isinstance(b, (list, tuple)):
        if not isinstance(a, (list, tuple)) or len(a) != len(b):
            diffs.append((path, "length"))
            return diffs
        for i, (x, y) in enumerate(zip(a, b)):
            compare(x, y, rtol, atol, f"{path}[{i}]", diffs)
    elif isinstance(b, bool) or b is None or isinstance(b, str):
        if a != b:
            diffs.append((path, f"{a!r} != {b!r}"))
    elif isinstance(b, (int, float)):
        if isinstance(a, bool) or not isinstance(a, (int, float)):
            diffs.append((path, "type"))
        elif not (math.isfinite(a) and math.isfinite(b)):
            diffs.append((path, f"non-finite value {a!r} / ref {b!r}"))
        elif not abs(a - b) <= atol + rtol * abs(b):
            diffs.append((path, f"{a!r} vs ref {b!r}"))
    return diffs


def check_provenance(inputs_dir, prov_file, bounds_cfg):
    """Every bound input must be listed with its source and SHA-256; the copy must match."""
    import json
    with open(prov_file, encoding="utf-8") as f:
        prov = json.load(f)["files"]
    bad, n = [], 0
    used = {v for k, v in bounds_cfg.items() if k.endswith("_file") and k != "provenance_file"}
    for rel in sorted(used - set(prov)):
        bad.append((rel, "bound input without provenance record"))
    bdir = os.path.join(inputs_dir, "bounds")
    for fn in sorted(os.listdir(bdir)):
        if f"bounds/{fn}" not in prov:
            bad.append((f"bounds/{fn}", "file in inputs/bounds without provenance record"))
    for rel, rec in prov.items():
        n += 1
        p = os.path.join(inputs_dir, *rel.split("/"))
        if not os.path.isfile(p):
            bad.append((rel, "missing"))
            continue
        if sha256(p) != rec["sha256"]:
            bad.append((rel, "copy sha differs from recorded source sha"))
    return n, bad
