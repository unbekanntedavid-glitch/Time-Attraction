# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Existing bounds on (alpha, lambda) and the ratio R = alpha/alpha_lim (conditional, not sigma)."""
import csv
import json
import os

import numpy as np


class Bounds:
    def __init__(self, inputs_dir, cfg):
        self.cfg = cfg
        z = np.load(os.path.join(inputs_dir, cfg["subcm_envelope_file"]))
        self.sub_log10L = np.array(z["log10_lambda"], dtype=float)
        self.sub_alpha = np.array(z[cfg["subcm_envelope_key"]], dtype=float)
        self.polys = {}
        with open(os.path.join(inputs_dir, cfg["ahn_fig4_file"]), newline="") as f:
            for row in csv.DictReader(f):
                k = int(row["polygon"])
                self.polys.setdefault(k, []).append((float(row["vertex"]), float(row["lambda_m"]), float(row["alpha"])))
        for k in self.polys:
            self.polys[k].sort()
        self.crossings = []
        with open(os.path.join(inputs_dir, cfg["crossings_file"]), newline="") as f:
            for row in csv.DictReader(f):
                self.crossings.append(row)
        with open(os.path.join(inputs_dir, cfg["bren_file"])) as f:
            self.bren = json.load(f)

    # --- AHN 2003 Fig. 4 lower edge of the excluded fill (lambda >= 2 mm) ---
    def alpha_lim_ahn4(self, lam):
        if lam < self.cfg["ahn_fig4_min_lambda_m"]:
            return np.nan
        x = np.log10(lam)
        best = np.inf
        for verts in self.polys.values():
            X = np.log10([v[1] for v in verts])
            Y = np.log10([v[2] for v in verts])
            X2, Y2 = np.roll(X, -1), np.roll(Y, -1)
            for a, b, c, d in zip(X, Y, X2, Y2):
                if (a - x) * (c - x) <= 0 and a != c:
                    best = min(best, b + (d - b) * (x - a) / (c - a))
        return float(10 ** best) if np.isfinite(best) else np.nan

    def alpha_lim_subcm(self, lam):
        lo, hi = self.cfg["subcm_range_m"]
        if not (lo <= lam <= hi):
            return np.nan
        return float(10 ** np.interp(np.log10(lam), self.sub_log10L, np.log10(self.sub_alpha)))

    def alpha_lim_combined(self, lam):
        vals = [v for v in (self.alpha_lim_ahn4(lam), self.alpha_lim_subcm(lam)) if np.isfinite(v)]
        return float(min(vals)) if vals else np.nan

    def bren_alpha_lims(self, lam, rtol=1e-9):
        """B89 (rho=2000) alpha_lim_cont for each variant, matched by relative tolerance."""
        out = {}
        for var in self.cfg["bren_variants"]:
            table = self.bren["lambda_scan"][var]
            for key, val in table.items():
                if np.isclose(float(key), lam, rtol=rtol, atol=0.0):
                    out[var] = float(val["rho_2000"]["B89"]["alpha_lim_cont"])
        return out

    def allowed_edge(self, alpha0):
        """Largest lambda below which alpha0 is allowed in the sub-cm envelope (log-interp)."""
        la, al = self.sub_log10L, np.log10(self.sub_alpha)
        excl = al < np.log10(alpha0)
        idx = np.where(excl)[0]
        i = idx[0]
        x0, x1, y0, y1 = la[i - 1], la[i], al[i - 1], al[i]
        t = (np.log10(alpha0) - y0) / (y1 - y0)
        return float(10 ** (x0 + t * (x1 - x0)))

    def crossing(self, fig, curve):
        """One row of the crossings file (lambda in m); raises if absent or ambiguous."""
        rows = [r for r in self.crossings if r["figure"] == fig and r["curve"] == curve]
        if len(rows) != 1:
            raise KeyError(f"crossing {fig}/{curve}: {len(rows)} rows")
        r = rows[0]
        return {"figure": fig, "curve": curve, "kind": r["kind"],
                "lambda_m": float(r["lambda_um"]) * 1e-6,
                "lambda_lo_m": float(r["lambda_um_lo"]) * 1e-6,
                "lambda_hi_m": float(r["lambda_um_hi"]) * 1e-6}

    def edge_crossing_from_file(self):
        return self.crossing(*self.cfg["edge_curve"])

    def bren_value(self, json_path):
        """A single value from the BREN input file, addressed by an explicit key path (no defaults)."""
        v = self.bren
        for k in json_path:
            v = v[k]
        return v
