# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Physics self-tests. Each returns (name, passed, detail). Non-tautological: every test
compares two independently built quantities. The broken controls must FAIL."""
import math

import numpy as np
from scipy import integrate

from . import physics as ph
from .compute import integrate_all, gr_reference, log10_upper_bounds, observables, dy_extra
from .geometry import ShellQuadrature


def _onaxis_newton(r1, r2, h, z0):
    """Closed form int rho/d for a shell at an on-axis point z0 > h/2 (per unit density)."""
    def F(R, zeta):
        s = math.sqrt(R * R + zeta * zeta)
        return 0.5 * (zeta * s + R * R * math.asinh(zeta / R))
    a, b = z0 - h / 2, z0 + h / 2
    return 2 * math.pi * ((F(r2, b) - F(r2, a)) - (F(r1, b) - F(r1, a)))


def _onaxis_yukawa(r1, r2, h, z0, L):
    """int rho e^{-d/L}/d on axis: exact radial integral, scipy quad in z (per unit density)."""
    def f(zeta):
        return 2 * math.pi * L * (math.exp(-math.hypot(r1, zeta) / L) - math.exp(-math.hypot(r2, zeta) / L))
    v, _ = integrate.quad(f, z0 - h / 2, z0 + h / 2, epsabs=0, epsrel=1e-13, limit=200)
    return v


def run_tests(S, ref_res, inputs_dir):
    out = []
    sm, q = S["source_mass"], S["quadrature"]
    r1, r2, hh, rho = sm["r_in_m"], sm["r_out_m"], sm["height_m"], sm["rho_kg_m3"]
    G, c = S["constants_SI"]["G_lab_m3_kg_s2"], S["constants_SI"]["c_m_s"]
    s_cal = S["calibration"]["s_cal_m"]

    # T1 mass
    Q = ShellQuadrature(r1, r2, hh, rho, (0.0, 0.0), 0.0, q)
    out.append(("T01 quadrature mass = rho*pi*(r2^2-r1^2)*h", abs(Q.mass / Q.mass_exact - 1) < 1e-12,
                f"M_quad={Q.mass:.10g} kg, M_exact={Q.mass_exact:.10g} kg"))

    # T2/T3 on-axis Newton and Yukawa vs independent 1D methods
    z0 = hh / 2 + S["source_positions"]["clock_to_surface_m"]
    Qa = ShellQuadrature(r1, r2, hh, 1.0, (0.0, 0.0), 0.0, q)
    Ls = [0.01, 0.1, 1.0, 1.0e3]
    Ia = Qa.integrals((0.0, 0.0, z0), Ls, s_cal, q["stable_form_switch_L_m"])
    nN = _onaxis_newton(r1, r2, hh, z0)
    e2 = abs(Ia["N_U"] / nN - 1)
    out.append(("T02 Newton on-axis: 3D quadrature vs closed form", e2 < 1e-10, f"rel err {e2:.2e}"))
    errs = []
    for k, L in enumerate(Ls):
        ya = _onaxis_yukawa(r1, r2, hh, z0, L)
        errs.append(abs(Ia["per_L"][k]["Y_U"] / ya - 1))
    out.append(("T03 Yukawa on-axis (L=1cm..1km): 3D quadrature vs exact-radial+quad", max(errs) < 1e-9,
                "rel errs " + ", ".join(f"{e:.1e}" for e in errs)))

    # T4 far-field monopole limit
    D = 200.0
    If = Q.integrals((D, 0.0, 0.0), [1.0e4], s_cal, q["stable_form_switch_L_m"])
    # quadrupole of a shell is O((r/D)^2): bound it by 1e-5 at D=200 m
    e4 = abs(If["N_U"] * D / Q.mass_exact - 1)
    out.append(("T04 far field U -> -G M/D (D = 200 m)", e4 < 1e-5, f"rel dev {e4:.2e}"))

    # T5 alpha -> 0: TAL built from the full raw route with alpha=0 equals the separate GR route
    I, _ = integrate_all(S, [1.0e4], s_cal)
    gr = gr_reference(I, S)
    alpha0 = 0.0
    Ginf = ph.G_inf(G, alpha0, 1.0e4, s_cal)
    U_tal = {k: -Ginf * (v["N_U"] + alpha0 * v["per_L"][0]["Y_U"]) for k, v in I.items()}
    Dy_tal = ((U_tal[("S1", "A")] - U_tal[("S1", "B")]) - (U_tal[("S2", "A")] - U_tal[("S2", "B")])) / c ** 2
    ob0 = observables(I, S, 0, alpha0, 1.0e4, s_cal)
    tiny = 1e-13
    ok5 = (abs(Dy_tal - gr["Dy_GR"]) <= tiny * abs(gr["Dy_GR"]) and abs(ob0["dy_cal"]) <= tiny * abs(gr["Dy_GR"])
           and abs(ob0["da_cal_A"]) <= tiny * abs(gr["Da_GR_A"]))
    out.append(("T05 alpha=0: full TAL route equals separate GR route; delta = 0", ok5,
                f"Dy_TAL-Dy_GR={Dy_tal - gr['Dy_GR']:.1e}, dy={ob0['dy_cal']:.1e}, da={ob0['da_cal_A']:.1e}"))

    # T6 stable vs direct form and vs full route at L = 1 m and 10 m (calibrated differences)
    alpha = ph.alpha_from_alphaY(1.0)
    errs = []
    for L in (1.0, 10.0):
        Sd = {**S, "quadrature": {**q, "stable_form_switch_L_m": 1e9}}   # force direct form
        Ss = {**S, "quadrature": {**q, "stable_form_switch_L_m": 0.0}}   # force stable form
        Id, _ = integrate_all(Sd, [L], s_cal)
        Is, _ = integrate_all(Ss, [L], s_cal)
        od = observables(Id, S, 0, alpha, L, s_cal)
        os_ = observables(Is, S, 0, alpha, L, s_cal)
        Gi = ph.G_inf(G, alpha, L, s_cal)
        U = {k: -Gi * (v["N_U"] + alpha * v["per_L"][0]["Y_U"]) - (-G * v["N_U"]) for k, v in Id.items()}
        dy_full = ((U[("S1", "A")] - U[("S1", "B")]) - (U[("S2", "A")] - U[("S2", "B")])) / c ** 2
        errs += [abs(od["dy_cal"] / os_["dy_cal"] - 1), abs(dy_full / os_["dy_cal"] - 1),
                 abs(od["da_cal_A"] / os_["da_cal_A"] - 1)]
    out.append(("T06 calibrated delta: stable form = direct form = full TAL-GR route (L=1,10 m)",
                max(errs) < 1e-7, f"max rel diff {max(errs):.1e}"))

    # T7 calibration limit
    L = 1.0e5
    g1 = ph.G_inf(G, alpha, L, s_cal)
    g2 = G / (1 + alpha)
    pred = alpha / (1 + alpha) * (1 - float(ph.kappa(s_cal / L)))
    e7 = abs((g1 / g2 - 1) - pred)
    out.append(("T07 calibration: L>>s gives G_inf -> G_lab/(1+alpha) (V28 Step 27 convention)", e7 < 1e-15 and g1 / g2 - 1 < 1e-11,
                f"G_inf/(G_lab/(1+a))-1 = {g1 / g2 - 1:.3e}"))

    # T8 redshift = line integral of force (same potential), raw and calibrated, L = 1 m and 10 km
    def line_test(broken):
        xs, ws = np.polynomial.legendre.leggauss(48)
        A, B = S["clocks"]["A_xyz_m"], S["clocks"]["B_xyz_m"]
        xa, xb = A[0], B[0]
        xg = 0.5 * (xb - xa) * xs + 0.5 * (xb + xa)
        pts = {f"g{i}": (float(x), 0.0, 0.0) for i, x in enumerate(xg)}
        res = []
        for L in (1.0, 1.0e4):
            I, _ = integrate_all(S, [L], s_cal, broken_force=broken, extra_points=pts)
            for st in ("S1",):
                for key, pref_U, pref_a in (("raw", -G * alpha, -G * alpha),
                                            ("cal", -G * ph.alpha_prime(alpha, L, s_cal), G * ph.alpha_prime(alpha, L, s_cal))):
                    kU, ka = ("Y_U", "Y_a") if key == "raw" else ("C_U", "C_a")
                    dU = pref_U * (I[(st, "A")]["per_L"][0][kU] - I[(st, "B")]["per_L"][0][kU])
                    line = sum(w * pref_a * I[(st, f"g{i}")]["per_L"][0][ka][0] for i, w in enumerate(ws)) * 0.5 * (xb - xa)
                    res.append(abs(line / dU - 1))
        return max(res)
    e8 = line_test(False)
    out.append(("T08 U_A-U_B = int_A^B delta_a dx (redshift and force from one potential)", e8 < 1e-9, f"max rel {e8:.1e}"))
    e8b = line_test(True)
    out.append(("C01 BROKEN CONTROL: force without (1+d/L) factor must FAIL T08", not (e8b < 1e-9),
                f"broken max rel {e8b:.1e} (expected large)"))

    # T9 mirror symmetry of the swap geometry
    ref_ps = ref_res["parameter_sets"]
    e9 = max(abs(p["da_cal_A"] / p["da_cal_B"] - 1) for p in ref_ps)
    out.append(("T09 swap symmetry: delta_a(A) = delta_a(B)", e9 < 1e-9, f"max rel {e9:.1e}"))

    # T10 convergence n -> n_check at the parameter sets and every 4th scan point
    Lc = [p["L_m"] for p in ref_ps] + ref_res["scan"]["L_m"][::4]
    aYs = [p["alpha_Y"] for p in ref_ps] + [S["lambda_scan"]["alpha_Y"]] * len(ref_res["scan"]["L_m"][::4])
    I1, _ = integrate_all(S, Lc, s_cal, q["n_per_panel"])
    I2, _ = integrate_all(S, Lc, s_cal, q["n_per_panel_check"])
    worst = 0.0
    for k, (L, aY) in enumerate(zip(Lc, aYs)):
        a_ = ph.alpha_from_alphaY(aY)
        o1, o2 = observables(I1, S, k, a_, L, s_cal), observables(I2, S, k, a_, L, s_cal)
        for key in ("dy_cal", "da_cal_A", "dy_raw", "da_raw_A"):
            worst = max(worst, abs(o1[key] / o2[key] - 1))
    out.append((f"T10 grid refinement n={q['n_per_panel']} -> {q['n_per_panel_check']} (tested L grid only)",
                worst < 1e-8, f"max rel change {worst:.1e}"))

    # T11 analytic upper bound >= quadrature where both exist
    ok, worst = True, -math.inf
    for L, dy, da in zip(ref_res["scan"]["L_m"], ref_res["scan"]["dy_cal"], ref_res["scan"]["da_cal_A"]):
        if L > 0.05:
            break
        ub = log10_upper_bounds(S, alpha, L, s_cal, S["source_positions"]["clock_to_surface_m"])
        worst = max(worst, math.log10(abs(da)) - ub["log10_Da_bound"], math.log10(abs(dy)) - ub["log10_Dy_bound"])
    ok = worst < 0
    out.append(("T11 analytic upper bound >= quadrature (L <= 5 cm)", ok, f"max log10(quad/bound) = {worst:.2f}"))

    # T12 declared geometry: clock-to-surface distance
    sp = S["source_positions"]
    dA = math.dist(S["clocks"]["A_xyz_m"][:2], sp["S1_axis_xy_m"]) - r2
    dB = math.dist(S["clocks"]["B_xyz_m"][:2], sp["S2_axis_xy_m"]) - r2
    out.append(("T12 declared clock-to-surface distance matches geometry", abs(dA - sp["clock_to_surface_m"]) < 1e-12
                and abs(dB - sp["clock_to_surface_m"]) < 1e-12, f"dA={dA:.6f} m, dB={dB:.6f} m"))

    # T13 sub-cm edge reproduces the crossings file
    e = ref_res["edge"]
    fc = e["from_crossings_file"]
    out.append(("T13 allowed edge from envelope within crossing interval", fc["lambda_lo_m"] <= e["lambda_edge_m"] <= fc["lambda_hi_m"],
                f"edge {e['lambda_edge_m'] * 1e6:.2f} um vs file {fc['lambda_m'] * 1e6:.2f} um"))

    # T14 every BREN-derived number used equals the BREN input file value (independent traversal of the raw JSON)
    import json
    import os
    with open(os.path.join(inputs_dir, S["bounds"]["bren_file"])) as f:
        raw = json.load(f)
    worst, nchk = 0.0, 0
    for p in ref_res["parameter_sets"]:
        b = p["bounds"]
        key = str(int(round(p["L_m"])))
        for var in S["bounds"]["bren_variants"]:
            v = raw["lambda_scan"][var][key]["rho_2000"]["B89"]["alpha_lim_cont"]
            worst = max(worst, abs(b["bren_B89_rho2000"][var] / v - 1)); nchk += 1
        lims = [raw["lambda_scan"][var][key]["rho_2000"]["B89"]["alpha_lim_cont"] for var in S["bounds"]["bren_variants"]]
        worst = max(worst, abs(b["R_bren_min"] / (p["alpha"] / max(lims)) - 1), abs(b["R_bren_max"] / (p["alpha"] / min(lims)) - 1))
        nchk += 2
        if "R_K90" in b:
            worst = max(worst, abs(b["alpha_lim_K90"] / raw["report_alpha_limit_check_1km"]["report_1sigma_correlated_chi2"] - 1)); nchk += 1
        if "R_B90_single_point_conditional" in b:
            worst = max(worst, abs(b["alpha_lim_B90_single_point"] / raw["report_alpha_limit_check_1km"]["this_work_single_top_point_1sigma_rho2200_contA"] - 1)); nchk += 1
    out.append(("T14 BREN-derived values equal the BREN input file (independent JSON traversal)", worst < 1e-15 and nchk > 0,
                f"{nchk} values, max rel diff {worst:.1e}"))

    # T15 transition band: ordering of the crossings and the envelope edge at the HUST 2020 |alpha| crossing
    tb = ref_res["edge"]["transition_band"]
    lam = [tb[k]["lambda_m"] for k in ("lower_edge_curve", "first_non_hust_curve", "thesis_abs_alpha95", "thesis_plus_alpha95")]
    ok = lam == sorted(lam) and tb["lower_edge_curve"]["lambda_lo_m"] <= e["lambda_edge_m"] <= tb["lower_edge_curve"]["lambda_hi_m"] \
        and all(tb[k]["category"] == "c" for k in tb)
    out.append(("T15 sub-cm band: HUST |a| < Eot-Wash 2020 |a| < thesis |a95| < thesis +a95; edge = HUST crossing", ok,
                " < ".join(f"{x * 1e6:.4f}" for x in lam) + " um"))
    # T16 non-universal addon: delta_y_extra / k_c = -Delta(phi_A - phi_B), phi built directly with G_inf
    # (fresh integrals, G_inf from the closed form, phi from the field equation), all three parameter sets.
    # C05: the same check with phi normalized by G_lab must FAIL at every parameter set.
    T16_RTOL = 1e-12
    P = S["parameter_sets"]
    I16, _ = integrate_all(S, [p["L_m"] for p in P], s_cal)

    def nonuni_check(G_norm):
        worst, n_fail, n_chk, details = 0.0, 0, 0, []
        for i, p in enumerate(P):
            rp = ref_ps[i]
            nu = rp.get("nonuniversal", {})
            vals = [nu.get(k) for k in ("dy_extra_for_k1", "k_c_needed_5sigma_Bothwell", "Delta_phi_AB")]
            if rp.get("id") != p["id"] or any(not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v)
                                                for v in vals):
                return math.inf, len(P), 0, ["missing/non-finite key"]
            a_ = p["alpha_Y"] / (4.0 * math.pi)
            Gn = G_norm(a_, p["L_m"])
            phi = {k: p["alpha_Y"] * Gn / (4.0 * math.pi * c ** 2) * v["per_L"][i]["Y_U"] for k, v in I16.items()}
            dphi = (phi[("S1", "A")] - phi[("S1", "B")]) - (phi[("S2", "A")] - phi[("S2", "B")])
            if not (math.isfinite(dphi) and dphi != 0.0):
                return math.inf, len(P), 0, ["non-finite or zero Delta phi"]
            errs = [abs(nu["dy_extra_for_k1"] / 1.0 / (-dphi) - 1)]
            for kc in (1.0, 1.0e3, 1.0e6):
                errs.append(abs(dy_extra(kc, nu["Delta_phi_AB"]) / kc / (-dphi) - 1))
            thr = S["resolution_threshold_sigma"]
            bw = S["clock_uncertainty"]["Sr_differential_Bothwell2022"]["value"]
            errs.append(abs(nu["k_c_needed_5sigma_Bothwell"] / (thr * bw / abs(dphi)) - 1))
            e = max(errs)
            worst = max(worst, e)
            n_chk += 1
            n_fail += int(not e <= T16_RTOL)
            details.append(f"{p['id']} {e:.1e}")
        return worst, n_fail, n_chk, details

    def g_inf(a_, L):
        return G / (1.0 + a_ * math.exp(-s_cal / L) * (1.0 + s_cal / L))
    w16, f16, n16, d16 = nonuni_check(g_inf)
    out.append((f"T16 non-universal addon: dy_extra/k_c = -Delta(phi_A-phi_B), phi with G_inf (P1-P3, rtol {T16_RTOL:g})",
                f16 == 0 and n16 == len(P), "max rel diff per set: " + ", ".join(d16)))
    wc5, fc5, nc5, dc5 = nonuni_check(lambda a_, L: G)
    out.append(("C05 BROKEN CONTROL: phi normalized with G_lab must FAIL T16 at every parameter set",
                fc5 == len(P) and nc5 == len(P), "rel diff per set: " + ", ".join(dc5) + " (expected large)"))
    return out
