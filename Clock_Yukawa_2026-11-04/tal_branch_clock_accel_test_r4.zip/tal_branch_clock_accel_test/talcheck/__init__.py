# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""TAL branch clock + acceleration check (preliminary research).

Numerical cross-checks with Academia Co-scientist (AI-assisted).
"""
__version__ = "0.1"  # package revision r4
