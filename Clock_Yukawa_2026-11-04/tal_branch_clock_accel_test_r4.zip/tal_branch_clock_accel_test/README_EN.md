# TAL branch: two-clock frequency ratio and acceleration (verification package)

Preliminary research. Numerical cross-checks with Academia Co-scientist (AI-assisted).

## What this package does

The package fixes one TAL branch: V26 Branch II-Fluid with universal matter coupling. It uses the parameter sets P1 = (L = 10 km, α_Y = 1), P2 = (10 km, 1/3) and P3 = (1 km, 1). It moves a declared granite source between two positions and computes, from the same action:

- δy = Δln(νA/νB)_TAL − Δln(νA/νB)_GR, the change of the two-clock frequency ratio;
- δa = Δa_TAL − Δa_GR, the change of the horizontal acceleration at the clocks.

It then checks the result against existing bounds and against the resolution of the setup, and prints the decision category.

**Decision for the fixed branch: (b), a signal exists but its force is excluded** by the available bounds (R > 1, conditional ratios; the BREN ratios hold within the examined source and operator models, not as a categorical exclusion). The bound-allowed remainder of the α_Y = 1 family is category (c); the sub-cm edge (75.88 µm, up to 101.03 µm in the widest reading) depends on the bound construction, see `docs/tal_branch_clock_accel_en.pdf`, Section 10.

**Version r4 (4 November 2026):** correction of the scalar-field normalization in the non-universal addon (outside the fixed branch): φ is now built with G_∞ as written in the reports, instead of G_lab. This changes the addon numbers δy_extra and the k_c needed for P1, P2 and P3 (P1: δy_extra(k_c = 1) −4.9713903860190284e-26 → −4.6049408375652313e-26; k_c needed 764373.6872257481 → 825200.6125683847; all old and new values in `CHANGELOG_EN.md`). The fixed-branch results δy, δa and all other numbers are unchanged. The BREN inputs come from the BREN continuation package and the sub-cm inputs from the sub-cm Yukawa window package (both in this publication set). Version notes: `CHANGELOG_EN.md`; environment and command of the fresh run: `RUN_LOG_r4.md`.

The derivation is in `docs/tal_branch_clock_accel_en.pdf`. The Hungarian version is `docs/tal_branch_clock_accel_hu.pdf`.

## Step by step on Windows (no programming needed)

1. **Install Python.** Download Python 3.13 from https://www.python.org/downloads/windows/ and start the installer. On the first screen, tick **"Add python.exe to PATH"**, then click "Install Now".
2. **Unpack the package.** Right-click `tal_branch_clock_accel_test_r4.zip`, choose **"Extract All…"**, then click "Extract".
3. **Open a command window in the folder.** Open the extracted folder `tal_branch_clock_accel_test`, the one that contains `run_check.py`. Click the address bar at the top of the window, type `cmd` and press Enter. A black window opens in this folder.
4. **Install the three required libraries** (this is needed only once). Type the following and press Enter:
   ```
   python -m pip install -r requirements.txt
   ```
5. **Run the check.** Type the following and press Enter:
   ```
   python run_check.py
   ```
   The run takes about 2–3 minutes. The window shows six stages, [1/6] to [6/6].
6. **Read the result.** The last line must be `RESULT: PASS`. Just above it you will find the decision for each parameter set.
7. **Find the outputs.** Each run writes its outputs to a new folder, `runs\run_<date>_<time>\` (created by running `run_check.py`; not included in the package). Nothing is overwritten or deleted. That folder contains:
   - `results.json`: all numbers;
   - `check_summary.json`: the test list with PASS/FAIL;
   - `table_parameter_sets.csv`: δy and δa per parameter set (opens in Excel);
   - `table_lambda_scan.csv` and `table_bound_only.csv`: the λ scan;
   - `fig_delta_vs_lambda.png` and `fig_delta_vs_lambda.pdf`: the figure.

On macOS or Linux the commands are the same. If `python` is not found there, use `python3`.

## What is checked

1. **Preflight, before anything is written.** The check confirms the Python version, the required packages, the input files and the reference file, and that the output folder is new.
2. **SHA-256 of the input files only.** The inputs are listed in `inputs/SHA256SUMS_inputs.txt`. If an input differs from its declared hash, the run stops. In addition, `inputs/PROVENANCE_bounds.json` records, for every bound file, its source package and SHA-256; the run checks every copy against this record and stops if a bound file is not listed or its SHA-256 differs.
3. **Outputs against the reference.** Outputs are not compared by hash. They are compared numerically with `reference/reference_results.json`, using a relative tolerance of 1e-8.
4. **Physics tests T01–T16.** These cover:
   - the mass;
   - the closed-form and independent 1D integrals;
   - the far-field limit;
   - α = 0;
   - the stable and direct numerical forms;
   - the calibration limit;
   - redshift = line integral of the force;
   - symmetry;
   - grid refinement;
   - the analytic bound;
   - the geometry;
   - the bound edge;
   - T14: every BREN value used equals the value in the BREN input file (independent JSON traversal);
   - T15: the order of the sub-cm band crossings;
   - T16: in the non-universal addon, δy_extra/k_c = −Δ(φ_A − φ_B) with φ built directly with G_∞, for P1, P2 and P3 (relative tolerance 1e-12).
5. **Deliberately broken controls C01–C05.** These must fail internally, and the run reports them as passed only when they do. They are:
   - C01: the force with a wrong kernel;
   - C02: a perturbed reference;
   - C03: an input changed by one byte;
   - C04: a provenance record with a wrong SHA-256;
   - C05: φ normalized with G_lab instead of G_∞ (T16 must fail at every parameter set).

## Important limitations

- **Declared assumptions.** The source geometry and the two positions are declared assumptions. Each clock is placed 10 cm from the granite surface, and the R1/R3 plan files were not available. All inputs are in `inputs/setup_declared.json`.
- **Proxies.** The model-uncertainty levels ε and the Coulomb-energy fraction are labelled proxies.
- **Range of the accuracy claims.** Quadrature accuracy is claimed only for 1 cm ≤ L ≤ 100 km. Below 1 cm only a rigorous upper bound is used.

## Folder contents

- `run_check.py`: the single entry point.
- `talcheck/`: the computation modules (physics, geometry, bounds, compute, selftests, verify, figures, report).
- `inputs/`: the declared inputs and the bound data, with SHA-256 sums; `inputs/PROVENANCE_bounds.json` gives the source of every bound file.
- `CHANGELOG_EN.md`, `VALTOZASNAPLO_HU.md`: version notes: what changed and what this version contains.
- `RUN_LOG_r4.md`: environment (Python and package versions) and exact command of the fresh run.
- `LICENSE.txt`: license text; `MANIFEST_SHA256.txt`: SHA-256 list of the package files.
- `reference/reference_results.json`: the reference results.
- `docs/`: the LaTeX sources, the PDFs (HU/EN), `generated/` (tables and figure) and `build_docs.py` (optional; needs pdflatex).
- `requirements.txt`: the pinned versions (Python 3.13.5, NumPy 2.5.4, SciPy 1.18.1, Matplotlib 3.11.2).

## License

© 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Licensed under Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0): https://creativecommons.org/licenses/by-nc/4.0/ (legal code: https://creativecommons.org/licenses/by-nc/4.0/legalcode). All commercial, industrial and technological implementation rights are retained by the author; commercial use only with the author's written permission. Full text: `LICENSE.txt`. Third-party documents and data cited or included as sources remain under their own terms.
