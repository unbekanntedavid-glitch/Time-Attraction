#!/usr/bin/env python3
# SPDX-License-Identifier: CC-BY-NC-4.0
# Copyright (c) 2026 Szabolcsi Dávid (ORCID 0009-0005-6300-074X). Commercial use only with the author's written permission.
"""Optional: rebuild the two PDFs (needs pdflatex). Regenerates docs/generated/ from
reference/reference_results.json, runs pdflatex twice per document and reports any
overfull/underfull boxes or errors found in the log. Nothing is deleted."""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)


def main():
    from talcheck.compute import load_setup
    from talcheck.figures import make_figure
    from talcheck.report import write_tables
    with open(os.path.join(ROOT, "reference", "reference_results.json")) as f:
        res = json.load(f)
    S = load_setup(os.path.join(ROOT, "inputs"))
    gen = os.path.join(HERE, "generated")
    os.makedirs(gen, exist_ok=True)
    write_tables(res, S, gen)
    make_figure(res, S, os.path.join(gen, "fig_delta_vs_lambda.png"), os.path.join(gen, "fig_delta_vs_lambda.pdf"))
    bad = 0
    for lang in ("en", "hu"):
        tex = f"tal_branch_clock_accel_{lang}.tex"
        for _ in range(2):
            subprocess.run(["pdflatex", "-interaction=nonstopmode", tex], cwd=HERE,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        with open(os.path.join(HERE, tex.replace(".tex", ".log")), encoding="latin-1") as f:
            log = f.read()
        hits = re.findall(r"^(?:!.*|Overfull.*|Underfull.*)$", log, flags=re.M)
        print(f"{tex}: {len(hits)} problems")
        for h in hits:
            print("   ", h)
        bad += len(hits)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
