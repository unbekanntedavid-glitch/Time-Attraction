# Version notes r4 (tal_branch_clock_accel_test)

Preliminary research. Numerical cross-checks with Academia Co-scientist (AI-assisted); no new measurement data.

## Changes in this version (r4, 4 November 2026)

Correction of the scalar-field normalization in the non-universal addon (Section "Non-universal coupling (outside the fixed branch)" of the reports; outside the fixed branch).

- The addon uses δy_extra = −k_c Δ(φ_A − φ_B) with φ(x) = α_Y G_∞ / (4π c²) ∫ ρ(x′) e^(−d/L)/d d³x′, as written in the reports. Version r3 built this φ with G_lab instead of G_∞, i.e. without the factor G_∞/G_lab. Version r4 builds φ directly with G_∞ (`talcheck/compute.py`: `scalar_field_phi`, `delta_phi_AB`, `dy_extra`, `nonuniversal`).
- Changed numbers (k_c = 1 for δy_extra; k_c needed for S = 5 at the Sr differential level 7.6e-21):

| set | G_∞/G_lab | δy_extra (k_c = 1), r3 | δy_extra (k_c = 1), r4 | k_c needed, r3 | k_c needed, r4 |
|---|---|---|---|---|---|
| P1 (L = 10 km, α_Y = 1) | 0.9262883177542528 | −4.9713903860190284e-26 | −4.6049408375652313e-26 | 764373.6872257481 | 825200.6125683847 |
| P2 (L = 10 km, α_Y = 1/3) | 0.9741596136881324 | −1.6571301286730092e-26 | −1.6143092459790636e-26 | 2293121.0616772445 | 2353947.9870198816 |
| P3 (L = 1 km, α_Y = 1) | 0.9262883180922076 | −4.971388831937201e-26 | −4.6049393997174937e-26 | 764373.9261729108 | 825200.8702292856 |

  In the reports (P1): δy_extra −4.971e-26 → −4.605e-26; k_c ≈ 7.644e5 → 8.252e5.
- New result key `nonuniversal/Delta_phi_AB` (Δ(φ_A − φ_B), φ with G_∞) for each parameter set; new CSV columns `nonuni_Delta_phi_AB`, `nonuni_dy_extra_k1`, `nonuni_k_c_needed_5sigma_Bothwell` in `docs/generated/table_parameter_sets.csv` (and in each run folder); new table `docs/generated/tab_nonuni_en.tex` / `docs/generated/tab_nonuni_hu.tex` (Table "Non-universal addon" in the reports, all three sets).
- New check T16: δy_extra/k_c = −Δ(φ_A − φ_B), with φ built directly with G_∞ from fresh integrals, for P1, P2 and P3 (k_c = 1, 1e3, 1e6; also k_c needed), relative tolerance 1e-12; missing or non-finite values fail. New broken control C05: the same check with φ normalized by G_lab must fail at every parameter set (it fails by 8.0e-2, 2.7e-2, 8.0e-2).
- Unchanged: every other number of `reference/reference_results.json` (700 numeric values, including δy_cal, δa_cal, R ratios, S values, the λ scan, the bound-only region and the sub-cm band) is identical to r3 (maximum relative difference 0). The fixed branch, its calibration and the V26 α_Y = 1 normalization are not touched. The long-range MICROSCOPE proxy k_c bound (4.2547e-11 for α_Y = 1) does not depend on φ and is unchanged.
- Text: the linearized field equation in the reports now writes G_∞ explicitly (∇²φ − φ/L² = −α_Y G_∞ ρ/c²), matching the solution for φ; the addon wording now uses S = 5.
- Text only (the computation and the reference values are untouched): the "raw" column of the δy/δa table, the related paragraph and the figure legend described it as "GR with G_∞", which did not match the code (dy_raw = −G_lab·α·ΔY_U/c², the Yukawa term alone with G_lab). They now state what is computed: an uncalibrated illustration using G_lab, not the main observable; the main numbers are the calibrated TAL−GR differences (`docs/*.tex`, `talcheck/figures.py` legend).
- Text only (the computation and every reference number are untouched): S is now described as a feasibility indicator built from the declared instrument and model uncertainty proxies, not the significance of an observed signal; the decision wording reads "S = 5 feasibility threshold" (`docs/*.tex`, Sections 8 and 10, EN and HU). R remains a conditional ratio to the bound. The data key names `resolution_threshold_sigma` and `k_c_needed_5sigma_Bothwell` and the CSV column `nonuni_k_c_needed_5sigma_Bothwell` are kept, so the reference keys stay the same.
- Bound input refresh (text only upstream): `inputs/bounds/bren_continuation_results_r2.json` is the file of the BREN continuation package r4 (filename kept), in which only the `status` text changed; every numeric value is identical. New SHA-256 a0cf690641b88737f924aa27dcfcb196939dc58447889ed0178eb533d1477f33; `inputs/PROVENANCE_bounds.json`, `inputs/SHA256SUMS_inputs.txt` and the recorded input hash `bound_inputs/bren_sha256` in `reference/reference_results.json` carry it; every reference number is identical.
- `RUN_LOG_r4.md`: environment and exact command of the fresh run of this package.

## What this version contains

- `run_check.py` with the `talcheck/` modules: δy (clock redshift) and δa (acceleration) of the fixed branch for the declared granite-shell geometry, compared with the bound inputs; decision category per parameter set.
- Bound inputs in `inputs/bounds/`: the BREN tower continuation results (BREN continuation package, this publication set) and the sub-cm envelopes, crossings and AHN 2003 Fig. 4 polygons (sub-cm Yukawa window package, this publication set). Each file is listed with its SHA-256 in `inputs/PROVENANCE_bounds.json`.
- Background records cited in `inputs/setup_declared.json`: TAL V20 (DOI 10.5281/zenodo.23540741), TAL V26 (DOI 10.5281/zenodo.23727585), TAL V28 Step 27 (DOI 10.5281/zenodo.23814053).
- Checks: input SHA-256, bound-input provenance, self-tests T01–T16, deliberately broken controls C01–C05, numeric comparison with `reference/reference_results.json` (rtol 1e-8; non-finite values, type mismatches and missing keys fail).
- Reports `docs/tal_branch_clock_accel_en.pdf` and `docs/tal_branch_clock_accel_hu.pdf` with tables and figure generated from the reference results.
- Earlier version r3: license added (CC BY-NC 4.0, `LICENSE.txt`), wording made neutral.
